"""Inspect local listener owners and act only on a captured process identity."""
from contextlib import contextmanager
from pathlib import Path
import hashlib
import os
import socket
import tempfile


def listener_pids(port):
    import psutil
    rows = [c for c in psutil.net_connections(kind='tcp')
            if c.status == psutil.CONN_LISTEN and c.laddr.port == port]
    if any(c.pid is None for c in rows):
        raise RuntimeError('Cannot identify the process owning the bridge port')
    return {c.pid for c in rows}


def snapshot(pid):
    import psutil
    p = psutil.Process(pid)
    result = dict(pid=p.pid, created_at=p.create_time(), executable=p.exe(), command=p.cmdline())
    if not p.is_running() or not result['command'] or not result['executable']:
        raise RuntimeError('Process identity is unavailable or changed')
    return result


def checked_process(identity):
    import psutil
    p = psutil.Process(identity['pid'])
    if snapshot(p.pid) != identity or p.create_time() != identity['created_at']:
        raise RuntimeError('Process identity changed; refusing to signal it')
    return p


def wait_for_exit(identity, timeout_s):
    import psutil
    try:
        p = checked_process(identity)
        p.wait(timeout=timeout_s)
        return True
    except psutil.NoSuchProcess:
        return True
    except psutil.TimeoutExpired:
        return False


def force_exit(identity, timeout_s):
    """No process tree or name-wide kill; psutil also checks PID reuse."""
    import psutil
    try:
        checked_process(identity).kill()
    except psutil.NoSuchProcess:
        return True
    return wait_for_exit(identity, timeout_s)


def port_is_free(port):
    if listener_pids(port):
        return False
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        if os.name == 'nt':
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            probe.bind(('127.0.0.1', port))
        except OSError:
            return False
    return True


@contextmanager
def bridge_process_lock(port):
    """A kernel file lock shared by CMD/dashboard, independent of their state dirs."""
    path = Path(tempfile.gettempdir()) / 'a221-workbench-process-locks'
    path.mkdir(parents=True, exist_ok=True)
    name = hashlib.sha256(f'loopback:{port}'.encode()).hexdigest()[:20] + '.lock'
    with (path / name).open('a+b') as stream:
        stream.seek(0, 2)
        if stream.tell() == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError('Another bridge lifecycle operation is running for this port') from exc
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)
