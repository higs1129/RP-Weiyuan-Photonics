"""Code locations and the single machine-configuration directory."""
from importlib.util import find_spec
from pathlib import Path
import os

def module_file(name):
    spec = find_spec(name)
    if spec is None or spec.origin is None:
        raise RuntimeError(f"Missing workbench module: {name}")
    return Path(spec.origin).resolve()

def package_dir(name):
    return module_file(name).parent

def checkout_root():
    configured = os.environ.get("MEASUREMENT_WORKBENCH_ROOT")
    if configured:
        return Path(configured).expanduser().resolve()
    return next((p for p in Path(__file__).resolve().parents
                 if (p / "workspace/pyproject.toml").is_file() and (p / "workspace/a221_workbench").is_dir()), None)

def project_root():
    return checkout_root() or Path.cwd()

def configuration_dir(name):
    explicit = os.environ.get("A221_CONFIG_HOME")
    if explicit:
        return Path(explicit).expanduser() / name
    root = checkout_root()
    if root is not None:
        return root / "workspace/config" / name
    return Path.home() / ".config/a221-workbench" / name
