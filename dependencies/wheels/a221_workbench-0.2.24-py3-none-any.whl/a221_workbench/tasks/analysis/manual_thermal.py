"""Offline MZI calibration of explicit human-selected thermal dip times."""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import numpy as np

from a221_workbench.tasks.analysis.large_scan.process_large_scan import find_mzi_index


def _finite(value: Any, label: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{label} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{label} must be finite")
    return result


def refine_manual_dip(
    frame_path: str | Path,
    *,
    hint_time_s: float,
    half_window_s: float,
) -> dict[str, Any]:
    """Locate the nearest significant dip, then return its raw basin minimum.

    Light filtering and noise-based prominence locate candidates only.
    Candidate rank uses time distance, never dip depth. Neighboring basins
    are separated at filtered shoulders. Final time/index/voltage name one
    unfiltered sample; flat minima choose the sample nearest the hint.
    Search failures return ok=False with error_code/error and null selection.
    Invalid inputs raise ValueError; file I/O errors propagate.
    """
    from scipy.ndimage import gaussian_filter1d, median_filter
    from scipy.signal import find_peaks

    hint = _finite(hint_time_s, "hint_time_s")
    half = _finite(half_window_s, "half_window_s")
    if half <= 0:
        raise ValueError("half_window_s must be positive")
    left = _finite(hint - half, "search_min_s")
    right = _finite(hint + half, "search_max_s")
    with np.load(frame_path, allow_pickle=False) as data:
        time_s = np.asarray(data["trans_time_s"], dtype=float)
        signal = np.asarray(data["trans_v"], dtype=float)
    if (time_s.ndim != 1 or signal.ndim != 1 or len(time_s) != len(signal)
            or len(time_s) < 3 or not np.all(np.isfinite(time_s))
            or not np.all(np.diff(time_s) > 0)):
        raise ValueError("trans_time_s/trans_v must be matching 1-D arrays with finite, strictly increasing times")
    if not time_s[0] <= hint <= time_s[-1]:
        raise ValueError("hint_time_s is outside the frame")
    start = int(np.searchsorted(time_s, left, side="left"))
    stop = int(np.searchsorted(time_s, right, side="right"))
    window_t = time_s[start:stop]
    window_y = signal[start:stop]
    result = {
        "ok": False,
        "frame_path": str(frame_path),
        "time_s": None,
        "sample_index": None,
        "detector_v": None,
        "hint_time_s": hint,
        "search_half_width_s": half,
        "search_min_s": left,
        "search_max_s": right,
        "window_sample_count": int(len(window_t)),
        "candidate_count": 0,
        "method": "nearest_significant_dip_raw_basin_minimum",
    }

    def failed(code: str, message: str) -> dict[str, Any]:
        return {**result, "error_code": code, "error": message}

    if len(window_t) < 3:
        return failed("insufficient_window_samples", "search window needs at least three samples")
    if not np.all(np.isfinite(window_y)):
        raise ValueError("trans_v contains non-finite samples in the search window")
    # Median-of-three rejects isolated spikes. Gaussian smoothing is only
    # for candidate identity; its radius never changes the returned voltage.
    sigma = min(8.0, max(1.0, len(window_y) / 500.0)) if len(window_y) >= 15 else 0.0
    located = gaussian_filter1d(median_filter(window_y, size=3, mode="nearest"),
                                sigma=sigma, mode="nearest") if sigma else window_y.copy()
    # Second differences remove a linear shoulder before robust noise
    # estimation; sqrt(6) converts independent sample noise back to volts.
    differences = np.diff(window_y, n=2)
    noise = float(np.median(np.abs(differences - np.median(differences))) / (0.67448975 * math.sqrt(6.0)))
    span = float(np.ptp(located))
    minimum_prominence = max(5.0 * noise, 0.001 * span,
                             np.finfo(float).eps * max(1.0, float(np.max(np.abs(window_y)))) * 16)
    candidates, properties = find_peaks(-located, prominence=minimum_prominence, plateau_size=True)
    result.update(noise_sigma_v=noise, minimum_prominence_v=minimum_prominence,
                  smoothing_sigma_samples=sigma)
    result["candidate_count"] = len(candidates)
    # Treat an endpoint plateau that falls towards the clipped boundary as
    # an incomplete dip, not an eligible fitted/selected minimum.
    boundaries = []
    changes = np.flatnonzero(np.diff(located) != 0)
    if len(changes):
        if located[0] < located[int(changes[0]) + 1]:
            boundaries.append(0)
        if located[-1] < located[int(changes[-1])]:
            boundaries.append(len(window_y) - 1)
    if any(located[i] == np.min(located) or window_y[i] == np.min(window_y) for i in boundaries):
        return failed("boundary_minimum", "window minimum lies at the search boundary; adjust the hint/window")
    if not len(candidates):
        return failed(
            "boundary_minimum" if boundaries else "no_internal_dip",
            "minimum lies at the search boundary; adjust the hint/window" if boundaries
            else "no significant internal dip with two shoulders in the search window",
        )
    choice = min(range(len(candidates)), key=lambda k: (abs(float(window_t[candidates[k]]) - hint), int(candidates[k])))
    selected = int(candidates[choice])
    distance = abs(float(window_t[selected]) - hint)
    if any(abs(float(window_t[i]) - hint) <= distance for i in boundaries):
        return failed("boundary_minimum", "nearest minimum is at the search boundary; adjust the hint/window")
    basin_left = int(properties["left_bases"][choice])
    basin_right = int(properties["right_bases"][choice])
    # Prominence bases of a deep dip can span a shallower neighboring dip.
    # Clamp each side to the intervening maximum to preserve dip identity.
    if choice > 0:
        previous = int(candidates[choice - 1])
        basin_left = max(basin_left, previous + int(np.argmax(located[previous:selected + 1])))
    if choice + 1 < len(candidates):
        following = int(candidates[choice + 1])
        basin_right = min(basin_right, selected + int(np.argmax(located[selected:following + 1])))
    raw_basin = window_y[basin_left:basin_right + 1]
    minima = np.flatnonzero(raw_basin == np.min(raw_basin)) + basin_left
    raw_selected = int(min(minima, key=lambda i: (abs(float(window_t[i]) - hint), int(i))))
    if raw_selected in (basin_left, basin_right):
        return failed("boundary_minimum", "raw minimum lies at the selected basin boundary; adjust the hint/window")
    sample_index = start + raw_selected
    return {
        **result,
        "ok": True,
        "time_s": float(time_s[sample_index]),
        "sample_index": sample_index,
        "detector_v": float(signal[sample_index]),
        "offset_from_hint_s": float(time_s[sample_index]) - hint,
        "candidate_time_s": float(window_t[selected]),
        "candidate_prominence_v": float(properties["prominences"][choice]),
        "basin_start_sample_index": start + basin_left,
        "basin_end_sample_index": start + basin_right,
        "basin_min_s": float(window_t[basin_left]),
        "basin_max_s": float(window_t[basin_right]),
    }


def analyze_manual_thermal(
    frames: list[dict[str, Any]],
    marks: list[dict[str, Any]],
    *,
    mzi_d1_mhz: float,
    frequency_axis_sign: float = -1.0,
) -> dict[str, Any]:
    """Fit Δf = slope * V² using marked times, without searching transmission.

    Every frame requires one mark: an explicit finite time or excluded=True.
    Excluded rows retain the supplied time but are not loaded or calibrated.
    At least four included marks, including exactly 0 V, are required.
    Invalid inputs/calibration raise ValueError; file I/O errors propagate.
    No instruments are connected and no files are written.
    """
    d1 = _finite(mzi_d1_mhz, "mzi_d1_mhz")
    sign = _finite(frequency_axis_sign, "frequency_axis_sign")
    if d1 <= 0 or sign not in (-1.0, 1.0):
        raise ValueError("mzi_d1_mhz must be positive; frequency_axis_sign must be -1 or +1")

    def by_voltage(items, label):
        indexed = {}
        for item in items:
            voltage = _finite(item.get("voltage_v"), f"{label}.voltage_v")
            if voltage in indexed:
                raise ValueError(f"duplicate voltage {voltage:g} V in {label}")
            if not math.isfinite(voltage * voltage):
                raise ValueError(f"voltage_squared_v2 is not finite at {voltage:g} V")
            indexed[voltage] = item
        return indexed

    frame_map = by_voltage(frames, "frames")
    mark_map = by_voltage(marks, "marks")
    if frame_map.keys() != mark_map.keys():
        raise ValueError("frames and marks must contain the same voltages; missing marks cannot be filled automatically")
    rows = []
    for voltage, frame in sorted(frame_map.items()):
        mark = mark_map[voltage]
        excluded = mark.get("excluded", False)
        if not isinstance(excluded, bool):
            raise ValueError("excluded must be a boolean")
        selected_time = mark.get("time_s")
        if selected_time is not None:
            selected_time = _finite(selected_time, f"time_s at {voltage:g} V")
        elif not excluded:
            raise ValueError(f"missing time_s at {voltage:g} V; explicitly exclude uncertain points")
        rows.append({
            "voltage_v": voltage,
            "voltage_squared_v2": voltage * voltage,
            "frame_path": str(frame["frame_path"]),
            "center_time_s": selected_time,
            "excluded": excluded,
            "delta_freq_ghz": None,
            "fit_delta_freq_ghz": None,
            "fit_residual_ghz": None,
        })
    included = [row for row in rows if not row["excluded"]]
    baseline = next((row for row in included if row["voltage_v"] == 0.0), None)
    if baseline is None:
        raise ValueError("an included 0 V time mark is required as the reference")
    if len(included) < 4:
        raise ValueError("at least four included marks (including 0 V) are required")
    reference_time = baseline["center_time_s"]

    for row in included:
        with np.load(row["frame_path"], allow_pickle=False) as data:
            mzi_time = np.asarray(data["mzi_time_s"], dtype=float)
            mzi = np.asarray(data["mzi_v"], dtype=float)
        if (mzi_time.ndim != 1 or mzi.ndim != 1 or len(mzi) != len(mzi_time)
                or len(mzi) < 4 or not np.all(np.isfinite(mzi_time))
                or not np.all(np.isfinite(mzi)) or not np.all(np.diff(mzi_time) > 0)):
            raise ValueError(f"invalid MZI arrays in {row['frame_path']}")
        indices = find_mzi_index(mzi, 0.0)
        if len(indices) < 4:
            raise ValueError(f"too few MZI extrema ({len(indices)}) in {row['frame_path']}")
        # Same two interpolations as thermal_voltage_sweep_worker: extrema
        # -> sample coordinate -> time. Do not snap the human time to a sample.
        mu = np.interp(np.arange(len(mzi), dtype=float), indices.astype(float),
                       np.arange(len(indices), dtype=float) / 2.0,
                       left=np.nan, right=np.nan)
        marked_mu, reference_mu = np.interp(
            [row["center_time_s"], reference_time], mzi_time, mu,
            left=np.nan, right=np.nan,
        )
        if not np.isfinite(marked_mu) or not np.isfinite(reference_mu):
            raise ValueError(f"marked or reference time is outside the valid MZI range at {row['voltage_v']:g} V")
        row["center_freq_ghz"] = _finite(sign * (marked_mu - reference_mu) * d1 / 1000.0, "center_freq_ghz")
        row["mzi_extrema_count"] = int(len(indices))
        row["tracking_reference_time_s"] = reference_time

    baseline_freq = baseline["center_freq_ghz"]
    for row in included:
        row["delta_freq_ghz"] = _finite(row["center_freq_ghz"] - baseline_freq, "delta_freq_ghz")
    x = np.asarray([row["voltage_squared_v2"] for row in included])
    y = np.asarray([row["delta_freq_ghz"] for row in included])
    denominator = float(np.dot(x, x))
    if not math.isfinite(denominator) or denominator <= 0:
        raise ValueError("invalid V² fit denominator")
    slope = _finite(np.dot(x, y) / denominator, "slope_ghz_per_v2")
    slope_mhz = _finite(slope * 1000.0, "slope_mhz_per_v2")
    for row in included:
        row["fit_delta_freq_ghz"] = _finite(slope * row["voltage_squared_v2"], "fit_delta_freq_ghz")
        row["fit_residual_ghz"] = _finite(row["delta_freq_ghz"] - row["fit_delta_freq_ghz"], "fit_residual_ghz")
    ss_res = float(np.sum((y - slope * x) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else None
    if r2 is not None and not math.isfinite(r2):
        raise ValueError("non-finite fit r2")
    return {
        "ok": True,
        "analysis_method": "manual_time_marks",
        "mzi_d1_mhz": d1,
        "frequency_axis_sign": sign,
        "reference_time_s": reference_time,
        "rows": rows,
        "thermal_tuning_fit": {
            "model": "delta_freq_ghz = slope_ghz_per_v2 * voltage_squared_v2",
            "slope_ghz_per_v2": slope,
            "slope_mhz_per_v2": slope_mhz,
            "intercept_ghz": 0.0,
            "r2": r2,
            "point_count": len(included),
            "minimum_point_count": 4,
            "frequency_axis_sign": sign,
            "ok": True,
        },
    }
