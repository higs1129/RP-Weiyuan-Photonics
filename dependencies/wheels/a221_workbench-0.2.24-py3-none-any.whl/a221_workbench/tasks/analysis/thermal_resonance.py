"""Fit candidates in an already-calibrated thermal transmission frame."""

from __future__ import annotations
import math
import numpy as np
from scipy.optimize import least_squares, minimize_scalar
from scipy.signal import find_peaks, peak_widths, savgol_filter
from a221_workbench.tasks.analysis.optical_q import lorentzian_notch

def finite_float(value):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def expected_linewidth_ghz(row):
    linewidth_mhz = finite_float(row.get("linewidth_loaded_mhz"))
    if linewidth_mhz is not None and linewidth_mhz > 0:
        return linewidth_mhz / 1000.0
    ql = finite_float(row.get("QL"))
    frequency_ghz = finite_float(row.get("current_frequency_ghz"))
    if ql is not None and ql > 0 and frequency_ghz is not None and frequency_ghz > 0:
        return frequency_ghz / ql
    return None


def odd_window_samples(span_ghz, step_ghz, point_count):
    count = max(7, int(round(span_ghz / max(step_ghz, 1e-12))))
    if count % 2 == 0:
        count += 1
    maximum = point_count if point_count % 2 == 1 else point_count - 1
    return max(5, min(count, maximum))


def fit_lorentzian_candidate(
    x_ghz,
    y_v,
    smooth_v,
    candidate_index,
    candidate_prominence_v,
    candidate_width_ghz,
    expected_fwhm_ghz,
    expected_depth,
    noise_v,
    tolerance_ghz,
    search_half_ghz,
):
    step_ghz = float(np.nanmedian(np.diff(x_ghz)))
    reference_fwhm_ghz = expected_fwhm_ghz or candidate_width_ghz
    reference_fwhm_ghz = max(6.0 * step_ghz, float(reference_fwhm_ghz or 0.2))
    fit_half_ghz = max(0.18, min(search_half_ghz * 0.9, 1.75 * reference_fwhm_ghz))
    candidate_frequency_ghz = float(x_ghz[candidate_index])
    local = np.abs(x_ghz - candidate_frequency_ghz) <= fit_half_ghz
    local_x_ghz = np.asarray(x_ghz[local] - candidate_frequency_ghz, dtype=float)
    local_y_v = np.asarray(y_v[local], dtype=float)
    if len(local_x_ghz) < 30:
        return {
            "valid": False,
            "candidate_frequency_ghz": candidate_frequency_ghz,
            "candidate_prominence_v": float(candidate_prominence_v),
            "reason": "too_few_fit_points",
        }

    edge_count = max(5, len(local_y_v) // 6)
    baseline_guess = float(np.nanmedian(np.r_[local_y_v[:edge_count], local_y_v[-edge_count:]]))
    y_min_guess = float(smooth_v[candidate_index])
    y_span = max(float(np.nanpercentile(local_y_v, 95) - np.nanpercentile(local_y_v, 5)), noise_v * 10.0, 1e-9)
    if abs(baseline_guess) > 1e-12:
        eta_guess = (baseline_guess - y_min_guess) / abs(baseline_guess)
    else:
        eta_guess = 0.5
    eta_guess = min(0.995, max(0.01, eta_guess))
    gamma_guess_ghz = max(3.0 * step_ghz, 0.5 * reference_fwhm_ghz)
    gamma_low_ghz = max(2.0 * step_ghz, 0.002, 0.04 * reference_fwhm_ghz)
    gamma_high_ghz = max(
        gamma_low_ghz * 2.0,
        min(fit_half_ghz * 0.95, 1.5 * reference_fwhm_ghz),
    )
    gamma_guess_ghz = min(gamma_high_ghz * 0.95, max(gamma_low_ghz * 1.05, gamma_guess_ghz))
    center_limit_ghz = min(
        fit_half_ghz * 0.72,
        max(0.10, 0.85 * reference_fwhm_ghz, 0.75 * candidate_width_ghz),
    )
    slope_limit_v_per_ghz = max(1e-8, 4.0 * y_span / max(float(np.ptp(local_x_ghz)), step_ghz))
    lower = np.asarray(
        [
            float(np.nanmin(local_y_v) - 2.0 * y_span),
            -slope_limit_v_per_ghz,
            0.0,
            gamma_low_ghz,
            -center_limit_ghz,
        ],
        dtype=float,
    )
    upper = np.asarray(
        [
            float(np.nanmax(local_y_v) + 2.0 * y_span),
            slope_limit_v_per_ghz,
            0.9999,
            gamma_high_ghz,
            center_limit_ghz,
        ],
        dtype=float,
    )
    p0 = np.asarray([baseline_guess, 0.0, eta_guess, gamma_guess_ghz, 0.0], dtype=float)
    p0 = np.minimum(upper - 1e-12, np.maximum(lower + 1e-12, p0))
    fit_scale_v = max(noise_v * 3.0, 0.01 * y_span, 1e-9)
    try:
        result = least_squares(
            lambda params: lorentzian_notch(local_x_ghz, *params) - local_y_v,
            p0,
            bounds=(lower, upper),
            loss="soft_l1",
            f_scale=fit_scale_v,
            x_scale="jac",
            max_nfev=30_000,
        )
    except Exception as exc:
        return {
            "valid": False,
            "candidate_frequency_ghz": candidate_frequency_ghz,
            "candidate_prominence_v": float(candidate_prominence_v),
            "reason": f"fit_exception:{exc!r}",
        }

    fit_v = lorentzian_notch(local_x_ghz, *result.x)
    residual_v = local_y_v - fit_v
    residual_sum_sq = float(np.sum(residual_v**2))
    total_sum_sq = float(np.sum((local_y_v - np.mean(local_y_v)) ** 2))
    fit_r2 = 1.0 - residual_sum_sq / total_sum_sq if total_sum_sq > 0 else math.nan
    fit_rmse_v = math.sqrt(residual_sum_sq / len(local_y_v))
    baseline_v, baseline_slope, fit_depth, gamma_ghz, center_offset_ghz = [float(value) for value in result.x]
    fit_model_center_ghz = candidate_frequency_ghz + center_offset_ghz
    fit_fwhm_ghz = 2.0 * abs(gamma_ghz)
    fit_depth_v = abs(baseline_v * fit_depth)
    depth_snr = fit_depth_v / max(noise_v, 1e-12)
    normalized_rmse = fit_rmse_v / max(fit_depth_v, 1e-12)
    center_std_ghz = math.nan
    degrees_of_freedom = len(local_y_v) - len(result.x)
    if degrees_of_freedom > 0 and result.jac.size:
        try:
            covariance = np.linalg.pinv(result.jac.T @ result.jac) * residual_sum_sq / degrees_of_freedom
            center_variance = float(covariance[4, 4])
            if center_variance >= 0:
                center_std_ghz = math.sqrt(center_variance)
        except Exception:
            center_std_ghz = math.nan

    quality_failures = []
    if not result.success:
        quality_failures.append("optimizer_failed")
    if depth_snr < 6.0:
        quality_failures.append("depth_snr_below_6")
    if not math.isfinite(fit_r2) or fit_r2 < 0.80:
        quality_failures.append("fit_r2_below_0.80")
    if normalized_rmse > 0.25:
        quality_failures.append("normalized_rmse_above_0.25")
    if fit_fwhm_ghz < 4.0 * step_ghz or fit_fwhm_ghz > 1.9 * fit_half_ghz:
        quality_failures.append("implausible_linewidth")
    center_std_limit_ghz = max(3.0 * step_ghz, 0.5 * tolerance_ghz)
    if not math.isfinite(center_std_ghz) or center_std_ghz > center_std_limit_ghz:
        quality_failures.append("center_uncertainty_too_large")
    if abs(center_offset_ghz) >= 0.98 * center_limit_ghz:
        quality_failures.append("center_at_fit_boundary")

    minimum_low_ghz = max(float(np.min(local_x_ghz)), center_offset_ghz - 2.5 * abs(gamma_ghz))
    minimum_high_ghz = min(float(np.max(local_x_ghz)), center_offset_ghz + 2.5 * abs(gamma_ghz))
    minimum_result = minimize_scalar(
        lambda offset: float(lorentzian_notch(np.asarray([offset]), *result.x)[0]),
        bounds=(minimum_low_ghz, minimum_high_ghz),
        method="bounded",
        options={"xatol": max(1e-10, step_ghz * 1e-4)},
    )
    if minimum_result.success and math.isfinite(float(minimum_result.x)):
        fit_minimum_offset_ghz = float(minimum_result.x)
    else:
        fit_minimum_offset_ghz = center_offset_ghz
        quality_failures.append("fit_minimum_search_failed")
    fit_minimum_ghz = candidate_frequency_ghz + fit_minimum_offset_ghz

    width_error = (
        abs(math.log(max(fit_fwhm_ghz, 1e-12) / expected_fwhm_ghz))
        if expected_fwhm_ghz is not None and expected_fwhm_ghz > 0
        else 0.0
    )
    depth_error = abs(fit_depth - expected_depth) if expected_depth is not None else 0.0
    return {
        "valid": not quality_failures,
        "reason": ",".join(quality_failures),
        "candidate_frequency_ghz": candidate_frequency_ghz,
        "candidate_prominence_v": float(candidate_prominence_v),
        "candidate_width_ghz": float(candidate_width_ghz),
        "fit_center_ghz": fit_minimum_ghz,
        "fit_minimum_ghz": fit_minimum_ghz,
        "fit_minimum_offset_from_candidate_ghz": fit_minimum_offset_ghz,
        "fit_model_center_ghz": fit_model_center_ghz,
        "fit_center_offset_from_candidate_ghz": center_offset_ghz,
        "fit_center_std_ghz": center_std_ghz if math.isfinite(center_std_ghz) else None,
        "fit_fwhm_ghz": fit_fwhm_ghz,
        "fit_gamma_ghz": abs(gamma_ghz),
        "fit_baseline_v": baseline_v,
        "fit_baseline_slope_v_per_ghz": baseline_slope,
        "fit_depth_fraction": fit_depth,
        "fit_depth_v": fit_depth_v,
        "fit_depth_snr": depth_snr,
        "fit_r2": fit_r2 if math.isfinite(fit_r2) else None,
        "fit_rmse_v": fit_rmse_v,
        "fit_normalized_rmse": normalized_rmse,
        "fit_point_count": int(len(local_y_v)),
        "fit_half_window_ghz": fit_half_ghz,
        "width_prior_log_error": width_error,
        "depth_prior_abs_error": depth_error,
    }


