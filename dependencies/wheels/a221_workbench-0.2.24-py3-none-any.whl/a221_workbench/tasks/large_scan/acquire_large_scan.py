"""Acquire a TOPTICA DLC PRO large scan with a VISA oscilloscope.

Default channel map for a microcavity large-scan measurement:
CH1 = large-scan trigger, CH2 = chip transmission PD, CH3 = MZI PD,
CH4 = fine-scan trigger (not used here).
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.large_scan'

from a221_workbench._shared.paths import module_file, project_root
#!/usr/bin/env python3


import argparse
import csv
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import field, asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
from urllib.error import URLError
from urllib.request import Request, urlopen

import numpy as np


from a221_workbench.instruments.tektronix import TekVisaSession
from a221_workbench._shared.runtime import (
    expand_optional_path as core_expand_optional_path,
    python_has_module as core_python_has_module,
)

from a221_workbench._shared.campaign_paths import CAMPAIGN_ENV, CHIP_ENV, DATA_ROOT_ENV, default_campaign, default_chip, default_cavity_dir


@dataclass
class ScanConfig:
    campaign: str
    chip: str
    die: str
    cavity: str
    start_nm: float
    stop_nm: float
    speed_nm_s: float
    laser_connection: str
    laser_port: str
    laser_host: str
    toptica_python: str
    scope_type: str
    scope_resource: str
    visa_backend: str
    scope_timeout_ms: int
    sample_rate_hz: float
    record_seconds: float
    pre_trigger_seconds: float
    post_trigger_seconds: float
    trigger_channel: int
    trans_channel: int
    mzi_channel: int
    aux_mzi_channel: int | None
    save_transmission: bool
    save_trigger: bool
    trigger_level_v: float
    trigger_slope: str
    disable_arc_factor_for_large_scan: bool
    restore_fine_scope_after_scan: bool
    fine_trigger_channel: int
    fine_trigger_level_v: float
    fine_trigger_slope: str
    fine_horizontal_delay_s: float | None
    fine_arc_factor_v_per_v: float
    fine_center_nm: float
    arm_delay_s: float
    post_scan_wait_s: float
    laser_readback_samples: int
    laser_readback_interval_s: float
    laser_settle_timeout_s: float
    laser_settle_tolerance_nm: float
    cycle_smile_before_scan: bool
    cycle_smile_after_scan: bool
    smile_settle_seconds: float
    cycle_emission_before_scan: bool
    cycle_emission_after_scan: bool
    emission_off_seconds: float
    emission_on_settle_seconds: float
    pc_voltage_v: float | None
    pc_voltage_tolerance_v: float
    restore_wavelength_mode: str
    storage_format: str
    output_dir: str


# Device operations are implemented once in the instrument modules.
from a221_workbench.instruments.toptica import TopticaDlcPro, TcpTopticaDlcPro, create_laser
from a221_workbench.instruments.tektronix import TektronixMso6
from a221_workbench.instruments.rohde_schwarz import RohdeSchwarzRte
from a221_workbench.instruments.oscilloscopes import create_scope
from a221_workbench.tasks.large_scan.restore_fine_scan_scope import RestoreOptions, restore_fine_scan


def write_csv(path: Path, columns: dict[str, list[float]]) -> int:
    lengths = [len(values) for values in columns.values()]
    if not lengths:
        raise ValueError("No columns to save.")
    n = min(lengths)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(columns.keys())
        for i in range(n):
            writer.writerow([values[i] for values in columns.values()])
    return n


def write_npz(path: Path, columns: dict[str, list[float]], *, compressed: bool) -> int:
    lengths = [len(values) for values in columns.values()]
    if not lengths:
        raise ValueError("No columns to save.")
    n = min(lengths)
    if "time_s" not in columns:
        raise ValueError("NPZ storage requires a time_s column for metadata.")
    time_s = columns["time_s"][:n]
    arrays: dict[str, np.ndarray] = {}
    for name, values in columns.items():
        if name == "time_s":
            continue
        arrays[name] = np.asarray(values[:n], dtype=np.float32)
    t0 = float(time_s[0]) if n else 0.0
    t1 = float(time_s[-1]) if n else 0.0
    sample_rate = float((n - 1) / (t1 - t0)) if n > 1 and t1 != t0 else math.nan
    arrays["time_start_s"] = np.asarray(t0, dtype=np.float64)
    arrays["time_stop_s"] = np.asarray(t1, dtype=np.float64)
    arrays["sample_rate_hz"] = np.asarray(sample_rate, dtype=np.float64)
    arrays["rows"] = np.asarray(n, dtype=np.int64)
    if compressed:
        np.savez_compressed(path, **arrays)
    else:
        np.savez(path, **arrays)
    return n


def build_time_axis(n: int, sample_rate_hz: float) -> list[float]:
    dt = 1.0 / sample_rate_hz
    return [i * dt for i in range(n)]


def sample_laser_readbacks_during_wait(
    laser: TopticaDlcPro | TcpTopticaDlcPro,
    *,
    scan_command_started_at: float,
    wait_deadline_at: float,
    pre_trigger_seconds: float,
    sample_count: int,
    interval_s: float,
) -> list[dict[str, Any]]:
    samples: list[dict[str, Any]] = []
    if sample_count <= 0:
        return samples
    interval_s = max(0.02, float(interval_s))
    next_sample_at = time.perf_counter()
    for index in range(sample_count):
        now = time.perf_counter()
        if now < next_sample_at:
            time.sleep(min(next_sample_at - now, max(0.0, wait_deadline_at - now)))
        if time.perf_counter() >= wait_deadline_at:
            break

        read_started_at = time.perf_counter()
        wavelength_nm = None
        error = None
        try:
            wavelength_nm = float(laser.wavelength_nm())
        except Exception as exc:
            error = repr(exc)
        read_finished_at = time.perf_counter()
        midpoint_at = 0.5 * (read_started_at + read_finished_at)
        elapsed_mid_s = midpoint_at - scan_command_started_at
        samples.append(
            {
                "index": index + 1,
                "ok": error is None,
                "wavelength_nm": wavelength_nm,
                "error": error,
                "elapsed_since_scan_command_s": elapsed_mid_s,
                "scope_time_estimate_s": elapsed_mid_s - pre_trigger_seconds,
                "read_started_elapsed_s": read_started_at - scan_command_started_at,
                "read_finished_elapsed_s": read_finished_at - scan_command_started_at,
                "read_duration_s": read_finished_at - read_started_at,
                "time_basis": "perf_counter midpoint; scope_time_estimate = elapsed_since_scan_command_s - pre_trigger_seconds",
            }
        )
        next_sample_at += interval_s
    return samples


@dataclass
class AcquisitionOptions:
    """Typed inputs shared by the CLI and callable step; no device I/O on construction."""
    sample_id: str | None = None
    campaign: str = field(default_factory=default_campaign)
    chip: str = field(default_factory=default_chip)
    die: str = 'die1-1'
    cavity: str = 'c1'
    start_nm: float = 1530.0
    stop_nm: float = 1570.0
    speed_nm_s: float = 2.0
    laser_connection: str = 'serial'
    laser_port: str = 'COM3'
    laser_host: str = '192.168.1.13'
    toptica_python: str = ''
    scope_type: str = 'rs_rte'
    scope_resource: str = 'TCPIP::192.168.1.8::INSTR'
    visa_backend: str = '@py'
    scope_timeout_ms: int = 120000
    sample_rate_hz: float = 200000.0
    record_seconds: float = 20.0
    trigger_channel: int = 1
    trans_channel: int = 2
    mzi_channel: int = 3
    aux_mzi_channel: int | None = None
    no_save_transmission: bool = False
    no_save_trigger: bool = False
    trigger_level_v: float = 1.0
    trigger_slope: str = 'positive'
    no_restore_fine_scope: bool = False
    fine_trigger_channel: int = 4
    fine_trigger_level_v: float = 0.0
    fine_trigger_slope: str = 'negative'
    fine_horizontal_delay_s: float | None = None
    fine_arc_factor_v_per_v: float = 25.0
    fine_center_nm: float = 1550.0
    keep_arc_factor_during_large_scan: bool = False
    arm_delay_s: float = 0.5
    post_scan_wait_s: float = 2.0
    laser_readback_samples: int = 0
    laser_readback_interval_s: float = 0.02
    laser_settle_timeout_s: float = 90.0
    laser_settle_tolerance_nm: float = 0.01
    cycle_smile_before_scan: bool = True
    cycle_smile_after_scan: bool = True
    smile_settle_seconds: float = 0.0
    cycle_emission_before_scan: bool = False
    cycle_emission_after_scan: bool = False
    emission_off_seconds: float = 2.0
    emission_on_settle_seconds: float = 2.0
    pc_voltage_v: float = 75.0
    pc_voltage_tolerance_v: float = 1.0
    skip_pc_voltage_set: bool = False
    restore_wavelength_mode: str = 'initial'
    storage_format: str = 'npz'
    output_dir: str | None = None
    dry_run: bool = False
    laser_prepare_only: bool = False


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--sample-id", default=None,
        help="Optional opaque sample label (e.g. batch_xxx_chip_xxx_die_xxx), saved in acquisition config; does not change output routing.",
    )
    parser.add_argument(
        "--campaign",
        default=default_campaign(),
        help=f"Campaign path under ${DATA_ROOT_ENV}/experiments. Defaults to ${CAMPAIGN_ENV} or wafer_measuement/Batch_260515.",
    )
    parser.add_argument("--chip", default=default_chip(), help=f"Chip/sample id. Defaults to ${CHIP_ENV} or chip7.")
    parser.add_argument("--die", default="die1-1")
    parser.add_argument("--cavity", default="c1")
    parser.add_argument("--start-nm", type=float, default=1530.0)
    parser.add_argument("--stop-nm", type=float, default=1570.0)
    parser.add_argument("--speed-nm-s", type=float, default=2.0)
    parser.add_argument("--laser-connection", choices=["serial", "tcp"], default="serial")
    parser.add_argument("--laser-port", default="COM3")
    parser.add_argument("--laser-host", default="192.168.1.13")
    parser.add_argument(
        "--toptica-python",
        default="",
        help="Python executable containing the TOPTICA SDK, used only for --laser-connection tcp.",
    )
    parser.add_argument("--scope-type", choices=["rs_rte", "tektronix_mso66b"], default="rs_rte")
    parser.add_argument("--scope-resource", default="TCPIP::192.168.1.8::INSTR")
    parser.add_argument("--visa-backend", default="@py")
    parser.add_argument(
        "--scope-timeout-ms",
        type=int,
        default=120000,
        help="VISA timeout for large binary waveform reads from the oscilloscope.",
    )
    parser.add_argument("--sample-rate-hz", type=float, default=200_000.0)
    parser.add_argument(
        "--record-seconds",
        type=float,
        default=20.0,
        help="Total oscilloscope window centered on CH1 trigger; default 20 s means 10 s before and 10 s after trigger.",
    )
    parser.add_argument("--trigger-channel", type=int, default=1)
    parser.add_argument("--trans-channel", type=int, default=2)
    parser.add_argument("--mzi-channel", type=int, default=3)
    parser.add_argument(
        "--aux-mzi-channel",
        type=int,
        default=None,
        help="Optional second MZI oscilloscope channel to save in the same raw file, e.g. CH5 for FSR comparison.",
    )
    parser.add_argument(
        "--no-save-transmission",
        action="store_true",
        help="Do not enable or read the transmission channel. Useful for MZI-only calibration checks.",
    )
    parser.add_argument("--no-save-trigger", action="store_true")
    parser.add_argument("--trigger-level-v", type=float, default=1.0)
    parser.add_argument("--trigger-slope", choices=["positive", "negative"], default="positive")
    parser.add_argument("--no-restore-fine-scope", action="store_true")
    parser.add_argument("--fine-trigger-channel", type=int, default=4)
    parser.add_argument("--fine-trigger-level-v", type=float, default=0.0)
    parser.add_argument("--fine-trigger-slope", choices=["positive", "negative"], default="negative")
    parser.add_argument(
        "--fine-horizontal-delay-s",
        type=float,
        default=None,
        help="Optional oscilloscope horizontal delay to restore for fine-scan viewing.",
    )
    parser.add_argument("--fine-arc-factor-v-per-v", type=float, default=25.0)
    parser.add_argument("--fine-center-nm", type=float, default=1550.0)
    parser.add_argument("--keep-arc-factor-during-large-scan", action="store_true")
    parser.add_argument("--arm-delay-s", type=float, default=0.5)
    parser.add_argument("--post-scan-wait-s", type=float, default=2.0)
    parser.add_argument(
        "--laser-readback-samples",
        type=int,
        default=0,
        help="During the scan wait, read TOPTICA actual wavelength this many times for MZI-vs-laser comparison.",
    )
    parser.add_argument(
        "--laser-readback-interval-s",
        type=float,
        default=0.02,
        help="Spacing between TOPTICA actual-wavelength samples during the scan wait.",
    )
    parser.add_argument("--laser-settle-timeout-s", type=float, default=90.0)
    parser.add_argument(
        "--laser-settle-tolerance-nm",
        type=float,
        default=0.01,
        help="Required actual-wavelength error before operations that depend on the target wavelength, including SMILE cycling.",
    )
    parser.add_argument(
        "--cycle-smile-before-scan",
        action=argparse.BooleanOptionalAction,
        default=AcquisitionOptions.cycle_smile_before_scan,
        help="At the scan start wavelength, briefly disable then re-enable TOPTICA Motor Control SMILE before the large scan (enabled by default).",
    )
    parser.add_argument(
        "--cycle-smile-after-scan",
        action=argparse.BooleanOptionalAction,
        default=AcquisitionOptions.cycle_smile_after_scan,
        help="After waveform readout and fine-scan restore, briefly disable then re-enable TOPTICA Motor Control SMILE (enabled by default).",
    )
    parser.add_argument("--smile-settle-seconds", type=float, default=0.0)
    parser.add_argument(
        "--cycle-emission-before-scan",
        action="store_true",
        help="At the scan start wavelength, turn TOPTICA emission off, wait, turn it on, wait, then start the large scan.",
    )
    parser.add_argument(
        "--cycle-emission-after-scan",
        action="store_true",
        help="After waveform readout, turn TOPTICA emission off, wait, turn it on, then restore the requested wavelength.",
    )
    parser.add_argument("--emission-off-seconds", type=float, default=2.0)
    parser.add_argument("--emission-on-settle-seconds", type=float, default=2.0)
    parser.add_argument(
        "--pc-voltage-v",
        type=float,
        default=75.0,
        help="Set TOPTICA PC piezo voltage before acquisition; pass --skip-pc-voltage-set to leave it unchanged.",
    )
    parser.add_argument("--pc-voltage-tolerance-v", type=float, default=1.0)
    parser.add_argument("--skip-pc-voltage-set", action="store_true")
    parser.add_argument(
        "--restore-wavelength-mode",
        choices=["fine-center", "initial", "none"],
        default="initial",
        help=(
            "Wavelength restore target after the large scan. 'fine-center' uses --fine-center-nm; "
            "'initial' returns to the laser wavelength read before moving to the large-scan start; "
            "'none' leaves the laser at the post-scan state."
        ),
    )
    parser.add_argument(
        "--storage-format",
        choices=["csv", "npz", "npz-compressed", "both"],
        default="npz",
        help="Raw data storage. npz stores float32 channel arrays and reconstructs time from metadata.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help=f"Output directory. Defaults to ${DATA_ROOT_ENV}/experiments/.../results/<chip>/<die>/<cavity>.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print planned settings without connecting.")
    parser.add_argument(
        "--laser-prepare-only",
        action="store_true",
        help="Configure TOPTICA wide scan and move to start wavelength, then exit before touching the scope.",
    )
    return parser.parse_args(list(argv))


def acquire_scan(args: AcquisitionOptions) -> dict[str, object]:
    for label, channel in (
        ("large-scan trigger", args.trigger_channel),
        ("transmission", args.trans_channel),
        ("MZI", args.mzi_channel),
        ("auxiliary MZI", args.aux_mzi_channel),
        ("fine-scan trigger", args.fine_trigger_channel),
    ):
        if channel is None:
            continue
        if channel < 1 or channel > 6:
            raise ValueError(f"{label} channel must be CH1-CH6, got CH{channel}")
    if args.aux_mzi_channel is not None and args.aux_mzi_channel in {
        args.trigger_channel,
        args.trans_channel,
        args.mzi_channel,
    }:
        raise ValueError("Auxiliary MZI channel must differ from trigger, transmission, and primary MZI channels.")
    scan_time = abs(args.stop_nm - args.start_nm) / args.speed_nm_s
    record_seconds = args.record_seconds
    if record_seconds is None:
        record_seconds = scan_time
    pre_trigger_seconds = record_seconds / 2.0
    post_trigger_seconds = record_seconds / 2.0

    if args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        try:
            output_dir = default_cavity_dir(args.chip, args.die, args.cavity, campaign=args.campaign)
        except RuntimeError as exc:
            if not args.dry_run:
                raise SystemExit(str(exc)) from exc
            output_dir = Path(f"<set {DATA_ROOT_ENV} or pass --output-dir>") / args.chip / args.die / args.cavity
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    basename = f"large_scan_{timestamp}_{args.start_nm:g}-{args.stop_nm:g}nm"
    csv_path = output_dir / f"{basename}.csv"
    npz_path = output_dir / f"{basename}.npz"
    meta_path = output_dir / f"{basename}.json"

    config = ScanConfig(
        campaign=args.campaign,
        chip=args.chip,
        die=args.die,
        cavity=args.cavity,
        start_nm=args.start_nm,
        stop_nm=args.stop_nm,
        speed_nm_s=args.speed_nm_s,
        laser_connection=args.laser_connection,
        laser_port=args.laser_port,
        laser_host=args.laser_host,
        toptica_python=str(args.toptica_python or ""),
        scope_type=args.scope_type,
        scope_resource=args.scope_resource,
        visa_backend=args.visa_backend,
        scope_timeout_ms=args.scope_timeout_ms,
        sample_rate_hz=args.sample_rate_hz,
        record_seconds=record_seconds,
        pre_trigger_seconds=pre_trigger_seconds,
        post_trigger_seconds=post_trigger_seconds,
        trigger_channel=args.trigger_channel,
        trans_channel=args.trans_channel,
        mzi_channel=args.mzi_channel,
        aux_mzi_channel=args.aux_mzi_channel,
        save_transmission=not args.no_save_transmission,
        save_trigger=not args.no_save_trigger,
        trigger_level_v=args.trigger_level_v,
        trigger_slope=args.trigger_slope,
        disable_arc_factor_for_large_scan=not args.keep_arc_factor_during_large_scan,
        restore_fine_scope_after_scan=not args.no_restore_fine_scope,
        fine_trigger_channel=args.fine_trigger_channel,
        fine_trigger_level_v=args.fine_trigger_level_v,
        fine_trigger_slope=args.fine_trigger_slope,
        fine_horizontal_delay_s=args.fine_horizontal_delay_s,
        fine_arc_factor_v_per_v=args.fine_arc_factor_v_per_v,
        fine_center_nm=args.fine_center_nm,
        arm_delay_s=args.arm_delay_s,
        post_scan_wait_s=args.post_scan_wait_s,
        laser_readback_samples=max(0, int(args.laser_readback_samples)),
        laser_readback_interval_s=args.laser_readback_interval_s,
        laser_settle_timeout_s=args.laser_settle_timeout_s,
        laser_settle_tolerance_nm=args.laser_settle_tolerance_nm,
        cycle_smile_before_scan=args.cycle_smile_before_scan,
        cycle_smile_after_scan=args.cycle_smile_after_scan,
        smile_settle_seconds=args.smile_settle_seconds,
        cycle_emission_before_scan=args.cycle_emission_before_scan,
        cycle_emission_after_scan=args.cycle_emission_after_scan,
        emission_off_seconds=args.emission_off_seconds,
        emission_on_settle_seconds=args.emission_on_settle_seconds,
        pc_voltage_v=None if args.skip_pc_voltage_set else args.pc_voltage_v,
        pc_voltage_tolerance_v=args.pc_voltage_tolerance_v,
        restore_wavelength_mode=args.restore_wavelength_mode,
        storage_format=args.storage_format,
        output_dir=str(output_dir),
    )

    config_metadata = asdict(config)
    if args.sample_id is not None:
        config_metadata["sample_id"] = args.sample_id
    print(json.dumps(config_metadata, indent=2, ensure_ascii=False))
    if args.dry_run:
        return config_metadata

    output_dir.mkdir(parents=True, exist_ok=True)
    meta = {
        "config": config_metadata,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "csv_path": str(csv_path) if args.storage_format in {"csv", "both"} else None,
        "npz_path": str(npz_path) if args.storage_format in {"npz", "npz-compressed", "both"} else None,
        "phase_seconds": {},
    }

    def mark_phase(name: str, started_at: float) -> None:
        seconds = time.perf_counter() - started_at
        meta["phase_seconds"][name] = round(seconds, 3)
        print(f"Phase {name}: {seconds:.3f} s")

    laser: TopticaDlcPro | TcpTopticaDlcPro | None = None
    scope: RohdeSchwarzRte | TektronixMso6 | None = None
    try:
        phase_t = time.perf_counter()
        print(f"Connecting to TOPTICA DLC PRO via {args.laser_connection}...")
        laser = create_laser(
            args.laser_connection,
            args.laser_port,
            laser_host=args.laser_host,
            toptica_python=args.toptica_python,
        )
        initial_wavelength_nm = laser.wavelength_nm()
        meta["laser_initial_readback_nm"] = initial_wavelength_nm
        print(f"Initial laser readback before large-scan setup: {initial_wavelength_nm:.9f} nm")
        meta["pc_voltage_before_set_v"] = laser.pc_voltage_set_v()
        meta["pc_voltage_before_act_v"] = laser.pc_voltage_act_v()
        if config.pc_voltage_v is not None:
            print(f"Setting TOPTICA PC piezo voltage to {config.pc_voltage_v:.6g} V...")
            laser.set_pc_voltage_v(config.pc_voltage_v)
            meta["pc_voltage_target_v"] = config.pc_voltage_v
            meta["pc_voltage_after_set_v"] = laser.pc_voltage_set_v()
            meta["pc_voltage_after_act_v"] = laser.pc_voltage_act_v()
            pc_error_v = abs(float(meta["pc_voltage_after_act_v"]) - config.pc_voltage_v)
            meta["pc_voltage_error_v"] = pc_error_v
            meta["pc_voltage_ok"] = pc_error_v <= config.pc_voltage_tolerance_v
            if not meta["pc_voltage_ok"]:
                raise RuntimeError(
                    "TOPTICA PC piezo voltage readback is outside tolerance: "
                    f"target={config.pc_voltage_v:.6g} V, "
                    f"act={float(meta['pc_voltage_after_act_v']):.6g} V, "
                    f"tolerance={config.pc_voltage_tolerance_v:.6g} V."
                )
        else:
            meta["pc_voltage_target_v"] = None
            meta["pc_voltage_ok"] = True
        if not args.keep_arc_factor_during_large_scan:
            print("Disabling TOPTICA external input arc factor for large scan...")
            laser.set_arc_factor_enabled(False)
        mark_phase("laser_connect_pc_arc_setup", phase_t)
        if args.laser_prepare_only:
            phase_t = time.perf_counter()
            print("Configuring laser wide scan...")
            laser.configure_wide_scan(args.start_nm, args.stop_nm, args.speed_nm_s)
            print(f"Moving laser to start wavelength {args.start_nm:g} nm...")
            laser.move_to_wavelength(
                args.start_nm,
                args.laser_settle_timeout_s,
                tolerance_nm=args.laser_settle_tolerance_nm,
            )
            readback = laser.wavelength_nm()
            print(f"Laser readback: {readback:.9f} nm")
            mark_phase("configure_and_move_to_start", phase_t)
            return meta

        phase_t = time.perf_counter()
        print(f"Connecting to oscilloscope ({args.scope_type})...")
        scope = create_scope(
            args.scope_type,
            args.scope_resource,
            visa_backend=args.visa_backend,
            timeout_ms=args.scope_timeout_ms,
        )
        meta["scope_idn"] = scope.idn()
        print(f"Scope: {meta['scope_idn']}")
        mark_phase("scope_connect", phase_t)

        phase_t = time.perf_counter()
        print("Configuring laser wide scan...")
        laser.configure_wide_scan(args.start_nm, args.stop_nm, args.speed_nm_s)
        print(f"Moving laser to start wavelength {args.start_nm:g} nm...")
        laser.move_to_wavelength(
            args.start_nm,
            args.laser_settle_timeout_s,
            tolerance_nm=args.laser_settle_tolerance_nm,
        )
        meta["laser_start_readback_nm"] = laser.wavelength_nm()
        meta["laser_start_tolerance_nm"] = args.laser_settle_tolerance_nm
        mark_phase("configure_and_move_to_start", phase_t)

        if args.cycle_smile_before_scan:
            phase_t = time.perf_counter()
            print("Cycling TOPTICA Motor Control SMILE before scan: OFF -> ON...")
            meta["smile_cycle_before_scan_result"] = laser.cycle_motor_control_smile()
            if args.smile_settle_seconds > 0:
                time.sleep(args.smile_settle_seconds)
            meta["smile_cycle_before_scan"] = True
            meta["smile_cycle_kind"] = "motor_control_smile_enable"
            meta["smile_cycle_param"] = laser.MOTOR_CONTROL_SMILE_PARAM
            meta["smile_cycle_settle_seconds"] = args.smile_settle_seconds
            meta["laser_start_readback_after_smile_cycle_nm"] = laser.wavelength_nm()
            mark_phase("pre_smile_cycle", phase_t)

        if args.cycle_emission_before_scan:
            phase_t = time.perf_counter()
            print("Cycling TOPTICA emission before scan: OFF...")
            laser.set_emission_enabled(False)
            time.sleep(args.emission_off_seconds)
            meta["emission_cycle_off_seconds"] = args.emission_off_seconds
            print("Cycling TOPTICA emission before scan: ON...")
            laser.set_emission_enabled(True)
            time.sleep(args.emission_on_settle_seconds)
            meta["emission_cycle_on_settle_seconds"] = args.emission_on_settle_seconds
            meta["laser_start_readback_after_emission_cycle_nm"] = laser.wavelength_nm()
            mark_phase("pre_emission_cycle", phase_t)

        phase_t = time.perf_counter()
        print("Configuring oscilloscope acquisition and CH1 trigger...")
        scope.stop()
        scope.configure_large_scan(
            record_seconds=record_seconds,
            sample_rate_hz=args.sample_rate_hz,
            trigger_channel=args.trigger_channel,
            trigger_level_v=args.trigger_level_v,
            trigger_slope=args.trigger_slope,
            trans_channel=args.trans_channel,
            mzi_channel=args.mzi_channel,
            aux_mzi_channel=args.aux_mzi_channel,
            save_transmission=not args.no_save_transmission,
            save_trigger=not args.no_save_trigger,
        )

        print("Arming oscilloscope single acquisition...")
        scope.single()
        time.sleep(args.arm_delay_s)
        mark_phase("scope_config_arm", phase_t)
        print("Starting laser wide scan...")
        scan_command_started_at = time.perf_counter()
        start_response = laser.start_wide_scan()
        scan_command_finished_at = time.perf_counter()
        meta["wide_scan_start_response"] = start_response
        meta["wide_scan_start_response_timeout"] = start_response is None
        meta["wide_scan_start_command_duration_s"] = scan_command_finished_at - scan_command_started_at
        if start_response is None:
            print("TOPTICA did not return a serial response for wide-scan:start; continuing to validate via scope trigger/readout.")
        wait_s = max(scan_time, record_seconds) + args.post_scan_wait_s
        print(f"Waiting {wait_s:.1f} s for scan/acquisition...")
        phase_t = time.perf_counter()
        wait_deadline_at = phase_t + wait_s
        meta["laser_scan_readback_config"] = {
            "samples_requested": max(0, int(args.laser_readback_samples)),
            "interval_s": float(args.laser_readback_interval_s),
            "enabled": int(args.laser_readback_samples) > 0,
        }
        if int(args.laser_readback_samples) > 0:
            print(
                "Sampling TOPTICA actual wavelength during scan wait: "
                f"{int(args.laser_readback_samples)} samples, {args.laser_readback_interval_s:g} s spacing..."
            )
            meta["laser_scan_readback_samples"] = sample_laser_readbacks_during_wait(
                laser,
                scan_command_started_at=scan_command_started_at,
                wait_deadline_at=wait_deadline_at,
                pre_trigger_seconds=pre_trigger_seconds,
                sample_count=int(args.laser_readback_samples),
                interval_s=float(args.laser_readback_interval_s),
            )
        else:
            meta["laser_scan_readback_samples"] = []
        remaining_wait_s = wait_deadline_at - time.perf_counter()
        if remaining_wait_s > 0:
            time.sleep(remaining_wait_s)
        if isinstance(scope, TektronixMso6):
            meta["scope_single_complete"] = scope.wait_for_single_complete(timeout_s=max(10.0, args.post_scan_wait_s + 5.0))
        mark_phase("scan_wait", phase_t)

        columns: dict[str, list[float]] = {}
        channel_data: dict[str, list[float]] = {}
        first_sample_rate = args.sample_rate_hz
        channel_headers: dict[str, dict[str, float]] = {}
        time_axes: dict[str, list[float]] = {}
        phase_t = time.perf_counter()
        if not args.no_save_trigger:
            print(f"Reading trigger CH{args.trigger_channel}...")
            trigger_time, trigger, trigger_header = scope.read_channel(args.trigger_channel)
            first_sample_rate = trigger_header["sample_rate_hz"]
            time_axes[f"ch{args.trigger_channel}_trigger_v"] = trigger_time
            channel_data[f"ch{args.trigger_channel}_trigger_v"] = trigger
            channel_headers[f"ch{args.trigger_channel}_trigger_v"] = trigger_header

        if not args.no_save_transmission:
            print(f"Reading transmission CH{args.trans_channel}...")
            trans_time, trans, trans_header = scope.read_channel(args.trans_channel)
            first_sample_rate = trans_header["sample_rate_hz"]
            time_axes[f"ch{args.trans_channel}_trans_v"] = trans_time
            channel_data[f"ch{args.trans_channel}_trans_v"] = trans
            channel_headers[f"ch{args.trans_channel}_trans_v"] = trans_header
        print(f"Reading MZI CH{args.mzi_channel}...")
        mzi_time, mzi, mzi_header = scope.read_channel(args.mzi_channel)
        first_sample_rate = mzi_header["sample_rate_hz"]
        time_axes[f"ch{args.mzi_channel}_mzi_v"] = mzi_time
        channel_data[f"ch{args.mzi_channel}_mzi_v"] = mzi
        channel_headers[f"ch{args.mzi_channel}_mzi_v"] = mzi_header
        if args.aux_mzi_channel is not None:
            print(f"Reading auxiliary MZI CH{args.aux_mzi_channel}...")
            aux_mzi_time, aux_mzi, aux_mzi_header = scope.read_channel(args.aux_mzi_channel)
            first_sample_rate = aux_mzi_header["sample_rate_hz"]
            time_axes[f"ch{args.aux_mzi_channel}_auxmzi_v"] = aux_mzi_time
            channel_data[f"ch{args.aux_mzi_channel}_auxmzi_v"] = aux_mzi
            channel_headers[f"ch{args.aux_mzi_channel}_auxmzi_v"] = aux_mzi_header
        mark_phase("scope_readout", phase_t)

        n = min(len(values) for values in channel_data.values())
        first_name = next(iter(channel_data))
        columns["time_s"] = time_axes[first_name][:n]
        for name, values in channel_data.items():
            columns[name] = values[:n]

        rows = 0
        phase_t = time.perf_counter()
        if args.storage_format in {"csv", "both"}:
            rows = write_csv(csv_path, columns)
            print(f"Saved {rows} rows to {csv_path}")
        if args.storage_format in {"npz", "npz-compressed", "both"}:
            rows = write_npz(npz_path, columns, compressed=args.storage_format == "npz-compressed")
            print(f"Saved {rows} rows to {npz_path}")
        mark_phase("save_waveform", phase_t)
        meta["rows"] = rows
        meta["actual_sample_rate_hz"] = first_sample_rate
        meta["channel_lengths"] = {name: len(values) for name, values in channel_data.items()}
        meta["channel_headers"] = channel_headers
        expected_x_start = -pre_trigger_seconds
        expected_x_stop = post_trigger_seconds
        trigger_window_tolerance_s = 0.05
        trigger_window_check = {}
        trigger_window_ok = True
        for name, header in channel_headers.items():
            x_start = float(header["x_start_s"])
            x_stop = float(header["x_stop_s"])
            start_error = x_start - expected_x_start
            stop_error = x_stop - expected_x_stop
            ok = (
                abs(start_error) <= trigger_window_tolerance_s
                and abs(stop_error) <= trigger_window_tolerance_s
            )
            trigger_window_ok = trigger_window_ok and ok
            trigger_window_check[name] = {
                "expected_x_start_s": expected_x_start,
                "expected_x_stop_s": expected_x_stop,
                "actual_x_start_s": x_start,
                "actual_x_stop_s": x_stop,
                "start_error_s": start_error,
                "stop_error_s": stop_error,
                "tolerance_s": trigger_window_tolerance_s,
                "ok": ok,
            }
        meta["trigger_window_check"] = trigger_window_check
        meta["trigger_window_ok"] = trigger_window_ok
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Saved metadata to {meta_path}")
        if not args.no_restore_fine_scope:
            restore_fine_scan(
                RestoreOptions(
                    trigger_channel=args.fine_trigger_channel,
                    trigger_level_v=args.fine_trigger_level_v,
                    trigger_slope=args.fine_trigger_slope,
                    horizontal_delay_s=args.fine_horizontal_delay_s,
                    arc_factor_v_per_v=args.fine_arc_factor_v_per_v,
                    fine_center_nm=args.fine_center_nm,
                    restore_wavelength_mode=args.restore_wavelength_mode,
                    initial_wavelength_nm=initial_wavelength_nm,
                    laser_settle_timeout_s=args.laser_settle_timeout_s,
                    laser_settle_tolerance_nm=args.laser_settle_tolerance_nm,
                    cycle_smile_after_scan=args.cycle_smile_after_scan,
                    smile_settle_seconds=args.smile_settle_seconds,
                    cycle_emission_after_scan=args.cycle_emission_after_scan,
                    emission_off_seconds=args.emission_off_seconds,
                    emission_on_settle_seconds=args.emission_on_settle_seconds,
                ), laser=laser, scope=scope, metadata=meta, mark_phase=mark_phase,
            )
            meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
        if not trigger_window_ok:
            raise RuntimeError(
                "Scope trigger window check failed: expected "
                f"{expected_x_start:.3f} s to {expected_x_stop:.3f} s around trigger. "
                "Raw data was saved, but this acquisition should be treated as invalid."
            )
        return meta
    finally:
        if scope is not None:
            scope.close()
        if laser is not None:
            laser.close()


def main(argv: Iterable[str]) -> int:
    acquire_scan(AcquisitionOptions(**vars(parse_args(argv))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
