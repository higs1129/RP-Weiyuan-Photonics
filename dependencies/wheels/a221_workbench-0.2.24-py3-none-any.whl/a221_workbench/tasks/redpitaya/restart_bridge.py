"""Explicitly replace a verified local RP bridge; leave the new outputs disabled."""
from __future__ import annotations

import sys
from pathlib import Path
if __package__ in (None, ''):
    root = next((p for p in Path(__file__).resolve().parents if (p / 'a221_workbench').is_dir()), None)
    if root is not None:
        sys.path.insert(0, str(root))
        __package__ = 'a221_workbench.tasks.redpitaya'

import argparse
from contextlib import ExitStack
import ipaddress
import json
import math
import os
import re
import subprocess
import time
import uuid
from urllib.parse import urlparse
from a221_workbench._shared import local_process as processes
from a221_workbench._shared.paths import configuration_dir, module_file, project_root
from a221_workbench.instruments.redpitaya.bridge_client import BridgeClient
from a221_workbench.instruments.redpitaya.network import resolve_host, rp_identity
from a221_workbench.instruments.redpitaya.output_safety import OFF_VALUES
from a221_workbench.instruments.redpitaya.runtime import runtime_python

BRIDGE_MODULE = 'a221_workbench.instruments.redpitaya.pyrpl_backend'
DISPLAY_OPTIONS = {
    'spectrum-load-ohm', 'spectrum-power-correction-enabled', 'spectrum-highz-correction-db',
    'spectrum-external-gain-db', 'scope-ch1-response-v-per-w', 'scope-ch2-response-v-per-w',
    'scope-zero-enabled', 'scope-ch1-zero-offset-v', 'scope-ch2-zero-offset-v', 'loglevel',
}


def _endpoint(url):
    p = urlparse(url)
    if (p.scheme != 'http' or p.hostname not in {'127.0.0.1', 'localhost'} or
            p.username or p.password or p.path not in {'', '/'} or p.query or p.fragment):
        raise ValueError('Restart supports a local http://127.0.0.1:PORT bridge only')
    port = p.port or 80
    return f'http://127.0.0.1:{port}', port


def _option(arguments, flag, default=None):
    values = []
    for i, value in enumerate(arguments):
        if value == flag:
            if i + 1 >= len(arguments):
                raise ValueError('Missing value for ' + flag)
            values.append(arguments[i + 1])
        elif value.startswith(flag + '='):
            values.append(value.split('=', 1)[1])
    if len(values) > 1:
        raise ValueError('Ambiguous process command: ' + flag)
    return values[0] if values else default


def _bridge_arguments(command):
    """Recognize the actual program, never a Python command containing a substring."""
    i = 1
    while i < len(command):
        value = command[i]
        if value in {'-X', '-W'}:
            i += 2; continue
        if value in {'-u', '-B', '-I', '-E', '-s'}:
            i += 1; continue
        if value == '-m':
            return command[i + 2:] if command[i + 1:i + 2] == [BRIDGE_MODULE] else None
        path = value.replace('\\', '/').lower()
        endings = ('/a221_workbench/instruments/redpitaya/pyrpl_backend.py',
                   '/workspace/scripts/redpitaya_microcavity_lock/src/bridge/pyrpl_live_bridge.py')
        return command[i + 1:] if path.endswith(endings) else None
    return None


def _normalize_host(host):
    return str(host).lower().rstrip('.').removesuffix('.local')


def _host_matches(requested, actual):
    requested_id, actual_id = rp_identity(requested), rp_identity(actual)
    if requested_id and actual_id:
        # Two explicit board identities cannot become aliases through DNS.
        return requested_id == actual_id
    if _normalize_host(requested) == _normalize_host(actual):
        return True
    try:
        return resolve_host(requested, discover=False)[1] == resolve_host(actual, discover=False)[1]
    except (OSError, ValueError, RuntimeError):
        return False


def _candidate_processes(port):
    import psutil
    targets = []
    for p in psutil.process_iter(['pid', 'cmdline']):
        command = p.info.get('cmdline') or []
        arguments = _bridge_arguments(command)
        if arguments is None or int(_option(arguments, '--listen-port', '7870')) != port:
            continue
        if _option(arguments, '--listen-host', '127.0.0.1') not in {'127.0.0.1', 'localhost', '0.0.0.0'}:
            continue
        try:
            identity = processes.snapshot(p.pid)
        except psutil.NoSuchProcess:
            continue
        if identity['command'] != command:
            raise RuntimeError('Bridge command changed during identification')
        if not re.fullmatch(r'python(?:w|[\d.]*)?(?:\.exe)?', Path(identity['executable']).name.lower()):
            raise RuntimeError('Bridge listener is not a verified Python process')
        targets.append(identity)
    return targets


def _matches_target(host, arguments):
    actual = _option(arguments, '--hostname')
    claimed = _option(arguments, '--rp-identity')
    if not actual:
        return False
    requested_id, claimed_id = rp_identity(host), rp_identity(claimed)
    actual_id = rp_identity(actual)
    if requested_id and actual_id and requested_id != actual_id:
        return False
    if requested_id and claimed_id:
        if requested_id != claimed_id:
            return False
        # This identifies the OLD local process, not a live board connection.
        # A retained numeric address is historical after a DHCP change. The
        # executable/PID/creation time/listener/HTTP checks remain mandatory.
        if actual_id == requested_id:
            return True
        try:
            ipaddress.ip_address(actual)
        except ValueError:
            return False
        return True
    if claimed and not _host_matches(host, claimed):
        return False
    # Legacy commands without an explicit RP identity still need a matching
    # hostname or a current, unambiguous verified address. Never guess old IPs.
    return _host_matches(host, actual)


def _targets(host, port):
    targets = _candidate_processes(port)
    for identity in targets:
        if not _matches_target(host, _bridge_arguments(identity['command'])):
            raise RuntimeError(f"PID {identity['pid']} does not identify the requested board {host!r}; no process stopped")
    listeners = processes.listener_pids(port)
    if not listeners.issubset({p['pid'] for p in targets}):
        raise RuntimeError('Bridge port has an unknown owner; no process stopped')
    return targets, listeners


def _assert_listener(identity, port):
    processes.checked_process(identity)
    if processes.listener_pids(port) != {identity['pid']}:
        raise RuntimeError('Bridge listener changed; refusing to send a control request')


def _assert_http_identity(health, identity, port):
    meta = health.get('bridge', {})
    arguments = _bridge_arguments(identity['command'])
    if (not isinstance(meta, dict) or arguments is None or
            meta.get('pid') != identity['pid'] or
            _normalize_host(meta.get('hostname')) != _normalize_host(_option(arguments, '--hostname')) or
            _normalize_host(meta.get('rp_identity')) != _normalize_host(_option(arguments, '--rp-identity')) or
            ('listen_port' in meta and meta['listen_port'] != port) or
            ('instance_token' in meta and meta['instance_token'] != _option(arguments, '--instance-token'))):
        raise RuntimeError('HTTP identity does not match the verified process/board')


def _old_outputs_off(client, health, identity, port, timeout_s):
    result = dict(status='unknown', outputs_off_confirmed=None)
    try:
        _assert_listener(identity, port)
        if health.get('supports_output_safety'):
            state = client.request('/outputs/off', timeout_s=timeout_s)
            if not state.get('ok') or not state.get('outputs_off_confirmed'):
                raise RuntimeError(str(state))
        else:
            # Old bridges have no aggregate output endpoint. Prove register I/O
            # works before attempting a bounded sequence of writes/readbacks.
            state = client.request('/feedback/state', timeout_s=min(4., timeout_s))
            if not state.get('ok'):
                raise RuntimeError(str(state))
            deadline = time.monotonic() + timeout_s
            client.request('/acquisition/stop', timeout_s=min(3., timeout_s))
            readback = {}
            for name, attr, value in OFF_VALUES:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('Output-off verification timed out')
                _assert_listener(identity, port)
                key = name + '.' + attr
                reply = client.set(key, value, timeout_s=min(2., remaining))
                if not reply.get('ok') or reply.get('after') != value:
                    raise RuntimeError(f'{key} off readback failed: {reply}')
                readback[key] = reply['after']
            state = dict(registers=readback)
        result.update(status='confirmed_off', outputs_off_confirmed=True, readback=state)
    except Exception as exc:
        result['error'] = str(exc)
    return result


def _stop_existing(host, base, port, stop_timeout_s):
    targets, listeners = _targets(host, port)
    old = dict(processes=targets, outputs=dict(status='unknown', outputs_off_confirmed=None),
               exited=False, port_released=False, forced_pids=[])
    client = BridgeClient(base)
    if listeners:
        if len(listeners) != 1:
            raise RuntimeError('Multiple bridge listener owners; refusing ambiguous shutdown')
        identity = next(p for p in targets if p['pid'] in listeners)
        _assert_listener(identity, port)
        health = client.health(timeout_s=2.)
        if health.get('ok') or health.get('bridge'):
            _assert_http_identity(health, identity, port)
        old['outputs'] = _old_outputs_off(client, health, identity, port, stop_timeout_s)
        _assert_listener(identity, port)
        old['shutdown'] = client.request('/shutdown', timeout_s=2., return_errors=True)
    # Wait for the verified bridge and its Python launcher, including a bridge
    # still starting with no listening socket. Never kill unrelated children.
    deadline = time.monotonic() + stop_timeout_s
    for identity in targets:
        if not processes.wait_for_exit(identity, max(0., deadline - time.monotonic())):
            old['forced_pids'].append(identity['pid'])
            if not processes.force_exit(identity, stop_timeout_s):
                old['error'] = 'Verified old process did not exit'
                return old
    old['exited'] = True
    deadline = time.monotonic() + stop_timeout_s
    while not processes.port_is_free(port):
        if time.monotonic() >= deadline:
            old['error'] = 'Bridge port was not released; no replacement started'
            return old
        time.sleep(.1)
    # Catch a still-starting old process, even when /health and the port are gone.
    remaining, _ = _targets(host, port)
    if remaining:
        old['error'] = 'Another bridge process is still present; no replacement started'
        return old
    old['port_released'] = True
    return old


def stop_bridge(host, *, bridge_url='http://127.0.0.1:7870', stop_timeout_s=5.):
    """Stop only positively identified local bridge processes; report output uncertainty."""
    result = dict(ok=False, action='stop_bridge', stage='identify', rp_host=host)
    try:
        base, port = _endpoint(bridge_url)
        if not 0 < stop_timeout_s <= 30:
            raise ValueError('stop_timeout_s must be in (0, 30]')
        with processes.bridge_process_lock(port):
            old = _stop_existing(host, base, port, stop_timeout_s)
            result.update(old=old, ok=old['exited'] and old['port_released'])
            result['stage'] = 'stopped' if result['ok'] else 'stop_old'
            if old.get('error'):
                result['error'] = old['error']
    except Exception as exc:
        result['error'] = str(exc)
    return result


def restart_bridge(host, *, bridge_url='http://127.0.0.1:7870', state_dir=None,
                   python=None, timeout_s=60., stop_timeout_s=5., headless=True,
                   display_options=None, _on_started=None, _require_idle=False):
    """Explicit restart, JSON-serializable result. No automatic sweep or laser action.

    Operational failures return ok=False with stage/error/log_path. The new bridge
    is ready only after live output-register verification; /health alone is not enough.
    """
    result = dict(ok=False, action='restart_bridge', stage='preflight', rp_host=host,
                  outputs_off_confirmed=None, warnings=[])
    proc = None
    ownership = ExitStack()
    try:
        base, port = _endpoint(bridge_url)
        result['bridge_url'] = base
        if not str(host).strip() or any(c in str(host) for c in '/\\?#@ \r\n'):
            raise ValueError('Provide an explicit RP hostname or IP')
        if not 0 < timeout_s <= 300 or not 0 < stop_timeout_s <= 30:
            raise ValueError('timeout_s must be in (0, 300]; stop_timeout_s in (0, 30]')
        executable = runtime_python(python)
        backend = module_file(BRIDGE_MODULE)
        extra = []
        for key, value in (display_options or {}).items():
            if key not in DISPLAY_OPTIONS:
                raise ValueError('Unsupported display option: ' + key)
            extra.extend(['--' + key, str(value)])
        # Check the selected runtime before stopping a working process.
        probe = subprocess.run([str(executable), str(backend), '--help'], capture_output=True,
                               timeout=15, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if probe.returncode or b'--startup-output-off' not in probe.stdout:
            raise RuntimeError('Selected Python cannot run the new bridge entry point')
        directory = Path(state_dir) if state_dir else configuration_dir('redpitaya_microcavity_lock') / '.runtime/restarts'
        directory.mkdir(parents=True, exist_ok=True)
        token = uuid.uuid4().hex
        config = directory / f'restart-{token}.yml'
        config.write_bytes(backend.with_name('restart_startup.yml').read_bytes())
        log_path = directory / f'restart-{token}.log'
        result.update(log_path=str(log_path), config_path=str(config), instance_token=token)
        ownership.enter_context(processes.bridge_process_lock(port))
        result['stage'] = 'stop_old'
        if _require_idle and (_candidate_processes(port) or not processes.port_is_free(port)):
            raise RuntimeError('A bridge is already present; use the explicit restart action')
        old = _stop_existing(host, base, port, stop_timeout_s)
        result['old'] = old
        if old['processes'] and old['outputs']['outputs_off_confirmed'] is not True:
            result['warnings'].append('Old RP output state was unknown; process exit does not prove outputs were off.')
        if not old['exited'] or not old['port_released']:
            raise RuntimeError(old.get('error', 'Old bridge has not exited'))
        result['stage'] = 'resolve_board'
        _, address = resolve_host(host, discover=False)
        command = [str(executable), '-X', 'utf8', str(backend), '--hostname', address,
                   '--rp-identity', host, '--config', str(config), '--listen-host', '127.0.0.1',
                   '--listen-port', str(port), '--startup-output-off', '--instance-token', token,
                   '--allow-risky', *extra]
        if headless:
            command.append('--headless')
        if not processes.port_is_free(port):
            raise RuntimeError('Port became occupied before startup; no process started')
        result.update(stage='start_new', command=command, address=address)
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
        with log_path.open('ab', buffering=0) as log:
            log.write((json.dumps(result, ensure_ascii=False) + '\n').encode('utf-8'))
            spawned_at = time.time()
            proc = subprocess.Popen(command, cwd=project_root(), stdin=subprocess.DEVNULL,
                                    stdout=log, stderr=subprocess.STDOUT, creationflags=flags,
                                    start_new_session=os.name != 'nt')
        result['launcher_pid'] = proc.pid
        if _on_started is not None:
            _on_started(proc, dict(result))
        result['stage'] = 'verify_new'
        client = BridgeClient(base)
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                raise RuntimeError(f'New bridge exited with code {proc.returncode}; see log')
            health = client.health(timeout_s=1.)
            if health.get('ok'):
                meta = health.get('bridge', {})
                if meta.get('instance_token') != token:
                    raise RuntimeError('A different process answered on the bridge URL')
                targets, listeners = _targets(host, port)
                identity = next((p for p in targets if p['pid'] == meta.get('pid')), None)
                if not identity or identity['created_at'] < spawned_at - 1.0 or listeners != {identity['pid']} or any(
                    _option(_bridge_arguments(p['command']), '--instance-token') != token for p in targets
                ):
                    raise RuntimeError('New bridge process identity/command mismatch')
                _assert_http_identity(health, identity, port)
                _assert_listener(identity, port)
                state = client.request('/outputs/state', timeout_s=min(4., max(.1, deadline - time.monotonic())), return_errors=True)
                result['new_readback'] = state
                expected = {name + '.' + attr: value for name, attr, value in OFF_VALUES}
                verified = (state.get('ok') and state.get('outputs_off_confirmed') and
                            state.get('registers') == expected and
                            all(math.isfinite(float(state.get('sampler', {}).get(k, float('nan')))) for k in ('out1_v', 'out2_v')))
                if verified:
                    result.update(ok=True, stage='ready', outputs_off_confirmed=True, new_process=identity)
                    break
            time.sleep(.2)
        if not result['ok']:
            raise TimeoutError('New bridge did not confirm live registers and disabled outputs; see log')
    except Exception as exc:
        result['error'] = str(exc)
        if proc is not None:
            # Leave no late-starting replacement after a timeout. Match its unique
            # command token; a process that took over the port is never stopped.
            try:
                targets = _candidate_processes(port)
                owned = [p for p in targets if _option(_bridge_arguments(p['command']), '--instance-token') == token]
                listeners = processes.listener_pids(port)
                for identity in owned:
                    if listeners == {identity['pid']}:
                        _assert_listener(identity, port)
                        BridgeClient(base).request('/shutdown', timeout_s=2., return_errors=True)
                deadline = time.monotonic() + stop_timeout_s
                result['failed_start_cleanup'] = []
                for identity in owned:
                    exited = processes.wait_for_exit(identity, max(0., deadline - time.monotonic()))
                    if not exited:
                        exited = processes.force_exit(identity, stop_timeout_s)
                    result['failed_start_cleanup'].append(dict(pid=identity['pid'], exited=exited))
            except Exception as cleanup_error:
                result['cleanup_error'] = str(cleanup_error)
    finally:
        ownership.close()
    if result.get('log_path'):
        try:
            Path(result['log_path']).with_suffix('.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        except OSError as exc:
            result['warnings'].append('Could not save result JSON: ' + str(exc))
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True, help='Explicit RP hostname or verified IP')
    parser.add_argument('--bridge-url', default='http://127.0.0.1:7870')
    parser.add_argument('--state-dir', type=Path)
    parser.add_argument('--python', type=Path, help='Configured instrument Python override')
    parser.add_argument('--timeout-s', type=float, default=60.)
    parser.add_argument('--stop-timeout-s', type=float, default=5.)
    parser.add_argument('--gui', action='store_true')
    args = parser.parse_args(argv)
    try:
        executable = runtime_python(args.python)
        # The standalone CMD can use the Windows launcher without assuming that
        # its default interpreter contains instrument/process dependencies.
        if Path(sys.executable).resolve() != executable.resolve():
            return subprocess.call([str(executable), '-X', 'utf8', str(Path(__file__).resolve()), *(sys.argv[1:] if argv is None else argv)])
        result = restart_bridge(args.host, bridge_url=args.bridge_url, state_dir=args.state_dir,
                                python=executable, timeout_s=args.timeout_s,
                                stop_timeout_s=args.stop_timeout_s, headless=not args.gui)
    except Exception as exc:
        result = dict(ok=False, stage='preflight', error=str(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
