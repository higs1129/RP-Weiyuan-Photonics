@echo off
setlocal
if "%~1"=="" (
  echo Usage: restart_bridge.cmd --host RP-device-name [--bridge-url http://127.0.0.1:7870]
  echo An explicit RP target is required. No process has been changed.
  pause
  exit /b 2
)
py -3 -X utf8 "%~dp0restart_bridge.py" %*
exit /b %errorlevel%
