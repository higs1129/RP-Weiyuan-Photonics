"""Resolve PyQt5 plugins from the installed wheel, including Unicode paths."""
from pathlib import Path
import sys


def prepare_qt_plugins():
    if sys.platform != 'win32':
        return
    from qtpy import API_NAME, QtCore
    if API_NAME != 'PyQt5':
        return
    import PyQt5
    plugins = Path(PyQt5.__file__).resolve().parent / 'Qt5/plugins'
    if not (plugins / 'platforms/qwindows.dll').is_file():
        raise RuntimeError('PyQt5 Windows 插件缺失，请运行软件包的 repair.cmd')
    # PyQt5 5.15's generated Qt prefix can lose non-ASCII characters on Windows.
    # Passing a Python Unicode path directly bypasses that compiled prefix.
    QtCore.QCoreApplication.setLibraryPaths([str(plugins)])
