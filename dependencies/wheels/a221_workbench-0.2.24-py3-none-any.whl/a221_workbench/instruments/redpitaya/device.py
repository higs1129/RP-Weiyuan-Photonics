from __future__ import annotations
from contextlib import contextmanager
import threading
from .bridge_client import BridgeClient
from .acquisition import Acquisition
from .parameters import Parameters
from .feedback import Feedback
from ..transports import HttpSerialTransport
from .network import resolve_host, rp_identity

class InstrumentBusy(RuntimeError):
    pass

class BridgeIdentityMismatch(RuntimeError):
    pass

class BridgeConnectionLost(RuntimeError):
    """The identity-checked bridge failed its read-only connection probe."""

class RedPitaya:
    def __init__(self, host, *, bridge_url='http://127.0.0.1:7870', client=None):
        self.host = host
        self.client = client or BridgeClient(bridge_url, timeout_s=30)
        self._guard = threading.RLock()
        self.connected = False
        self.bridge_status = None
        self.scope = Acquisition(self, 'scope')
        self.spectrum = Acquisition(self, 'spectrumanalyzer')
        self.feedback = Feedback(self)
        self.asg = Parameters(self, 'asg0', {'waveform', 'frequency', 'amplitude', 'offset', 'output_direct', 'trigger_source'})
        self.pid = Parameters(self, 'pid0', {'p', 'i', 'setpoint', 'ival', 'input', 'inputfilter',
                                           'output_direct', 'min_voltage', 'max_voltage'})

    def connect(self):
        self.connected = False
        status = self.client.health(return_errors=False)
        if not status.get('ok'):
            raise RuntimeError(status)
        actual = status.get('bridge', {}).get('hostname')
        if not actual:
            raise RuntimeError('Bridge does not report its device hostname')
        requested_id = rp_identity(self.host)
        for reported in (actual, status.get('bridge', {}).get('rp_identity')):
            reported_id = rp_identity(reported)
            if requested_id and reported_id and requested_id != reported_id:
                raise BridgeIdentityMismatch(f'Bridge reports board {reported}, not requested {self.host}')
        # Retained identity permits identifying an old local process for an
        # explicit restart; it does not prove its stale connection is live.
        def normalized(value):
            return value.lower().rstrip('.').removesuffix('.local')
        if normalized(actual) != normalized(self.host):
            def addresses(host):
                return {resolve_host(host)[1]}
            if not addresses(actual).intersection(addresses(self.host)):
                raise BridgeIdentityMismatch(f'Bridge controls {actual}, not requested {self.host}')
        if status.get('supports_feedback') and not status.get('bridge', {}).get('simulated'):
            # A local HTTP health page may survive a board power-cycle. Verify a
            # read-only register transaction before reporting a live connection.
            try:
                sample = self.client.request('/feedback/state', timeout_s=5)
                if not sample.get('ok'):
                    raise RuntimeError('RP 后台仍在，但硬件读取未成功：' + str(sample.get('error')))
            except (OSError, RuntimeError) as exc:
                detail = str(exc).lower()
                if isinstance(exc, (ConnectionResetError, BrokenPipeError)) or any(
                    marker in detail for marker in ('socket is closed', 'connection reset',
                                                     'broken pipe', 'winerror 10054')
                ):
                    raise BridgeConnectionLost(str(exc)) from exc
                raise
        self.connected = True
        self.bridge_status = status
        return status

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        """Release this client only; does not change PID, laser or ASG outputs."""
        self.connected = False

    @contextmanager
    def operation(self):
        if not self.connected:
            raise RuntimeError('Connect and verify the RP identity first')
        if not self._guard.acquire(blocking=False):
            raise InstrumentBusy('RP is busy with another operation in this session')
        try:
            yield
        finally:
            self._guard.release()

    def request(self, path, params=None, **kwargs):
        with self.operation():
            result = self.client.request(path, params, **kwargs)
            if not result.get('ok'):
                raise RuntimeError(result)
            return result

    def uart(self, *, service_url=None, token='', timeout_s=5):
        return HttpSerialTransport(service_url or f'http://{self.host}:8092', token=token, timeout_s=timeout_s)

    def stop_acquisition(self):
        # Deliberately bypass the local operation guard so a second thread can stop a capture.
        if not self.connected:
            raise RuntimeError('Connect first')
        result = self.client.request('/acquisition/stop', timeout_s=5)
        if not result.get('ok'):
            raise RuntimeError(result)
        return result
