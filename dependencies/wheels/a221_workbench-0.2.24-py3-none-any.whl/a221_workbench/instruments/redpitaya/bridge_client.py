"""HTTP client for the shared PyRPL bridge service."""

from __future__ import annotations


import json
from dataclasses import dataclass
from typing import Any, Mapping
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import build_opener, ProxyHandler

urlopen = build_opener(ProxyHandler({})).open


DEFAULT_FINE_SWEEP_FREQUENCY_HZ = 50.0
DEFAULT_FINE_SWEEP_AMPLITUDE_V = 1.0
DEFAULT_FINE_SCOPE_DURATION_S = 0.067108864


@dataclass(frozen=True)
class BridgeClient:
    base_url: str = "http://127.0.0.1:7870"
    timeout_s: float = 5.0

    @property
    def base(self) -> str:
        return self.base_url.rstrip("/")

    def request(
        self,
        path: str,
        params: Mapping[str, Any] | None = None,
        *,
        timeout_s: float | None = None,
        return_errors: bool = False,
    ) -> dict[str, Any]:
        url = self.base + (path if path.startswith("/") else f"/{path}")
        if params:
            clean = {key: value for key, value in params.items() if value is not None}
            if clean:
                url += "?" + urlencode(clean)
        try:
            with urlopen(url, timeout=self.timeout_s if timeout_s is None else timeout_s) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                payload = {"raw_body": raw}
            if not isinstance(payload, dict):
                payload = {"raw_body": raw}
            payload.setdefault("ok", False)
            payload.setdefault("error", f"HTTP {exc.code}: {exc.reason}")
            payload.update({"http_status": exc.code, "url": url})
            if return_errors:
                return payload
            raise RuntimeError(json.dumps(payload, ensure_ascii=False)) from exc
        except Exception as exc:
            if return_errors:
                return {"ok": False, "error": repr(exc), "url": url}
            raise
        if not isinstance(payload, dict):
            error = {"ok": False, "error": "bridge returned non-object JSON", "url": url}
            if return_errors:
                return error
            raise RuntimeError(error)
        return payload

    def health(self, *, timeout_s: float = 3.0, return_errors: bool = True) -> dict[str, Any]:
        return self.request("/health", timeout_s=timeout_s, return_errors=return_errors)

    def get(self, param: str, *, timeout_s: float | None = None, return_errors: bool = False) -> dict[str, Any]:
        return self.request("/get", {"param": param}, timeout_s=timeout_s, return_errors=return_errors)

    def set(
        self,
        param: str,
        value: Any,
        *,
        timeout_s: float | None = None,
        return_errors: bool = False,
    ) -> dict[str, Any]:
        return self.request(
            "/set",
            {"param": param, "value": str(value)},
            timeout_s=timeout_s,
            return_errors=return_errors,
        )

    def stop_acquisitions(self, *, return_errors: bool = False) -> dict[str, Any]:
        return self.request("/acquisition/stop", return_errors=return_errors)

    def set_many(self, entries: list[tuple[str, Any]], *, return_errors: bool = True) -> dict[str, Any]:
        steps: list[dict[str, Any]] = []
        ok = True
        for param, value in entries:
            result = self.set(param, value, return_errors=return_errors)
            steps.append({"param": param, "value": value, "result": result})
            ok = ok and bool(result.get("ok"))
        return {"ok": ok, "steps": steps}

    def safe_off(self) -> dict[str, Any]:
        return self.set_many(
            [
                ("pid0.p", 0),
                ("pid0.i", 0),
                ("pid0.output_direct", "off"),
                ("asg0.output_direct", "off"),
            ]
        )

    def configure_coupling_scope_inputs(self) -> dict[str, Any]:
        result = self.set_many([("scope.input1", "in1"), ("scope.input2", "out2")])
        return {
            **result,
            "message": "coupling power readout uses scope CH1=in1 and CH2=out2",
            "scope_ch1_input": "in1",
            "scope_ch2_input": "out2",
        }

    def restore_fine_sweep(
        self,
        *,
        frequency_hz: float = DEFAULT_FINE_SWEEP_FREQUENCY_HZ,
        amplitude_v: float = DEFAULT_FINE_SWEEP_AMPLITUDE_V,
        scope_duration_s: float = DEFAULT_FINE_SCOPE_DURATION_S,
    ) -> dict[str, Any]:
        stop = self.stop_acquisitions(return_errors=True)
        result = self.set_many(
            [
                ("pid0.p", 0),
                ("pid0.i", 0),
                ("pid0.output_direct", "off"),
                ("asg0.waveform", "ramp"),
                ("asg0.frequency", frequency_hz),
                ("asg0.amplitude", amplitude_v),
                ("asg0.offset", 0),
                ("asg0.output_direct", "out2"),
                ("asg1.waveform", "square"),
                ("asg1.frequency", frequency_hz),
                ("asg1.amplitude", 0.5),
                ("asg1.offset", 0),
                ("scope.input1", "in1"),
                ("scope.input2", "out2"),
                ("scope.trigger_source", "asg0"),
                ("scope.trigger_delay", 0),
                ("scope.duration", scope_duration_s),
                ("scope.rolling_mode", "false"),
            ]
        )
        continuous = self.set("scope.run_continuous", "true", return_errors=True)
        return {
            "ok": bool(result.get("ok")),
            "message": "lock sweep restored; acquisitions stopped, PID disabled, ASG ramp sent to out2",
            "sweep_frequency_hz": frequency_hz,
            "sweep_amplitude_v": amplitude_v,
            "scope_duration_s": scope_duration_s,
            "stop_acquisitions": stop,
            "steps": [*result["steps"], {"param": "scope.run_continuous", "value": "true", "result": continuous}],
        }
