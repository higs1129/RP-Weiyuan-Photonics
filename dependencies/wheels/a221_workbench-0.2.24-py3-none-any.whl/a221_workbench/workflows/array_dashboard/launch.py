"""Start the array dashboard with this checkout's configured Python."""
from pathlib import Path
import json
import os
import subprocess
import sys


def main():
    root = next((p for p in Path(__file__).resolve().parents
                 if (p / "workspace/a221_workbench").is_dir()), None)
    if root is None and os.environ.get("MEASUREMENT_WORKBENCH_ROOT"):
        root = Path(os.environ["MEASUREMENT_WORKBENCH_ROOT"]).expanduser().resolve()
    config_root = Path(os.environ["A221_CONFIG_HOME"]).expanduser() if os.environ.get("A221_CONFIG_HOME") else (
        root / "workspace/config" if root else Path.home() / ".config/a221-workbench")
    config = config_root / "redpitaya_microcavity_lock/runtime.local.json"
    python = os.environ.get("A221_RUNTIME_PYTHON") or os.environ.get("MICROCAVITY_RUNTIME_PYTHON")
    if not python and config.is_file():
        python = json.loads(config.read_text(encoding="utf-8-sig")).get("runtime_python")
    python = python or sys.executable
    env = dict(os.environ, PYTHONUTF8="1")
    if root is not None:
        env.update(MEASUREMENT_WORKBENCH_ROOT=str(root), PYTHONPATH=str(root / "workspace"))
    return subprocess.call([python, "-m",
                            "a221_workbench.workflows.array_dashboard.array_cavity_dashboard",
                            *sys.argv[1:]], cwd=root, env=env)


if __name__ == "__main__":
    raise SystemExit(main())
