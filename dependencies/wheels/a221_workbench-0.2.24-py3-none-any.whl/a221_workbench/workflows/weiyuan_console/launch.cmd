@echo off
setlocal
py -3 -X utf8 "%~dp0launch.py" %*
set "launch_exit=%errorlevel%"
if not "%launch_exit%"=="0" pause
exit /b %launch_exit%
