"""Open the Weiyuan console using this checkout's configured Python."""
from pathlib import Path
import json
import os
import subprocess
import sys


def main():
    root = next((p for p in Path(__file__).resolve().parents
                 if (p / "workspace/a221_workbench").is_dir()), None)
    if root is None and os.environ.get("MEASUREMENT_WORKBENCH_ROOT"):
        root = Path(os.environ["MEASUREMENT_WORKBENCH_ROOT"]).expanduser().resolve()
    config_root = Path(os.environ["A221_CONFIG_HOME"]).expanduser() if os.environ.get("A221_CONFIG_HOME") else (
        root / "workspace/config" if root else Path.home() / ".config/a221-workbench")
    config = config_root / "redpitaya_microcavity_lock/runtime.local.json"
    python = os.environ.get("A221_RUNTIME_PYTHON") or os.environ.get("MICROCAVITY_RUNTIME_PYTHON")
    if not python and config.is_file():
        python = json.loads(config.read_text(encoding="utf-8-sig")).get("runtime_python")
    python = python or sys.executable
    env = dict(os.environ, PYTHONUTF8="1")
    if root is not None:
        env.update(MEASUREMENT_WORKBENCH_ROOT=str(root), PYTHONPATH=str(root / "workspace"))
    print("Opening Weiyuan console. Keep this window open; press Ctrl+C to stop.", flush=True)
    try:
        return subprocess.call([python, "-X", "utf8", "-m",
                                "a221_workbench.workflows.weiyuan_console.server",
                                "--real", "--open-browser", *sys.argv[1:]], cwd=root, env=env)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
