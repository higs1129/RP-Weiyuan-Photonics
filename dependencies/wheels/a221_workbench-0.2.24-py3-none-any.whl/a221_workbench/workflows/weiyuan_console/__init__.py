"""Thin instrument UI and examples; instrument objects live in microcavity_core."""
