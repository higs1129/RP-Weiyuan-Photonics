"""Named compositions of device operations and single tasks."""
import subprocess
import sys

WORKFLOWS = {'restart-rp-bridge': 'a221_workbench.tasks.redpitaya.restart_bridge', 'large-scan': 'a221_workbench.workflows.large_scan.large_scan_flow', 'acquire-large-scan': 'a221_workbench.tasks.large_scan.acquire_large_scan', 'restore-fine-scan': 'a221_workbench.tasks.large_scan.restore_fine_scan_scope', 'summarize-die': 'a221_workbench.workflows.large_scan.summarize_die_large_scan', 'lock-current': 'a221_workbench.workflows.locking.current_mode_fast_lock', 'lock-best-q': 'a221_workbench.workflows.locking.lock_best_q_mode', 'lock-weiyuan': 'a221_workbench.workflows.locking.weiyuan_current_mode_lock', 'auto-coupling': 'a221_workbench.workflows.auto_coupling.monotonic_step_optimize_coupling', 'array-dashboard': 'a221_workbench.workflows.array_dashboard.array_cavity_dashboard', 'microcavity-control': 'a221_workbench.workflows.microcavity_control.panel', 'weiyuan-console': 'a221_workbench.workflows.weiyuan_console.server', 'plot-viewer': 'a221_workbench.workflows.plot_viewer.server'}

def run_workflow(name, arguments=(), *, python=None, cwd=None, check=True):
    if name not in WORKFLOWS:
        raise ValueError(f"Unknown workflow: {name}")
    return subprocess.run([str(python or sys.executable), "-m", WORKFLOWS[name], *map(str, arguments)], cwd=cwd, check=check)
