"""Thorlabs instrument readers."""

from .ted4015 import Ted4015Reader, Ted4015SetupError

__all__ = ["Ted4015Reader", "Ted4015SetupError"]
