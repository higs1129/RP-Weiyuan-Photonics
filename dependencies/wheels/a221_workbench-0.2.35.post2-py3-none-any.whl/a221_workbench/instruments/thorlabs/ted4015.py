"""Query-only TED4015 reader, Series 4000 SCPI reference V3.3.

No reset, error-queue read/clear, output command, sensor setting or remote/local
command is issued. MEAS queries select a measurement internally (CONF + READ),
but do not change the TEC source mode, setpoint or sensor calibration.
"""
from __future__ import annotations

import math
import threading
import time
from typing import Any


_QUERIES = frozenset(("*IDN?", "UNIT:TEMP?", "MEAS:TEMP?", "OUTP1?", "MEAS:CURR1?"))


def _number(raw: str) -> float:
    value = float(raw.strip())
    if not math.isfinite(value) or abs(value) >= 9.9e37:
        raise ValueError("Non-finite or SCPI invalid/overflow measurement")
    return value


def _temperature_c(raw: str, unit: str) -> float:
    value = _number(raw)
    unit = unit.strip().upper()
    if unit in ("C", "CEL", "CELSIUS"):
        return value
    if unit in ("F", "FAR", "FAHR", "FAHRENHEIT"):
        return (value - 32.0) * 5.0 / 9.0
    if unit in ("K", "KELV", "KELVIN"):
        return value - 273.15
    raise ValueError(f"Unknown temperature unit: {unit!r}; no Celsius assumption")


def _output_enabled(raw: str) -> bool:
    value = raw.strip()
    if value not in ("0", "1"):
        raise ValueError(f"Invalid output state: {value!r}; expected 0 or 1")
    return value == "1"


class Ted4015SetupError(RuntimeError):
    """Context entry failed; result retains the identity response and error."""

    def __init__(self, result: dict[str, Any]):
        super().__init__(result["error"])
        self.result = result


class Ted4015Reader:
    """Independent VISA instrument session; use from one acquisition worker.

    Construction performs no I/O. setup() opens and verifies identity; context
    entry calls setup() and raises Ted4015SetupError on failure. read_once()
    requires successful setup, returns partial data on failure, and never retries
    or reconnects. A transport error closes this instrument session to avoid
    assigning a late reply to a different query. Explicit setup() can reopen it.
    """

    def __init__(self, resource: str, serial: str, timeout_ms: int = 1000,
                 visa_backend: str = "@ivi"):
        if not isinstance(resource, str) or not resource.strip():
            raise ValueError("Explicit VISA resource is required")
        if not isinstance(serial, str) or not serial.strip():
            raise ValueError("Expected TED4015 serial is required")
        if isinstance(timeout_ms, bool) or not isinstance(timeout_ms, int) or not 1 <= timeout_ms <= 60000:
            raise ValueError("timeout_ms must be an integer in 1..60000")
        self.resource = resource.strip()
        self.serial = serial.strip()
        self.timeout_ms = timeout_ms
        self.visa_backend = visa_backend
        self._rm = None
        self._inst = None
        self._identity = None
        self._lock = threading.RLock()

    def _query(self, command: str, result: dict[str, Any]) -> str:
        if command not in _QUERIES:
            raise ValueError("Unsupported TED4015 query")
        timing = {"started_unix_ns": time.time_ns(), "started_perf_counter_ns": time.perf_counter_ns()}
        result["timing"][command] = timing
        result["raw"][command] = None
        try:
            raw = self._inst.query(command)
            result["raw"][command] = raw
            return raw
        except Exception as exc:
            result["errors"][command] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            timing.update(finished_unix_ns=time.time_ns(), finished_perf_counter_ns=time.perf_counter_ns())

    def _close_after_error(self, result: dict[str, Any]) -> None:
        try:
            self.close()
        except Exception as exc:
            result["errors"]["close"] = f"{type(exc).__name__}: {exc}"

    def setup(self) -> dict[str, Any]:
        """Open and query identity only; successful repeated calls reuse it."""
        with self._lock:
            result = {"ok": False, "identity": None, "raw": {}, "errors": {}, "timing": {}, "error": None}
            if self._identity is not None:
                return {**result, "ok": True, "identity": dict(self._identity)}
            try:
                import pyvisa

                # PyVISA shares a ResourceManager per backend. Close only our
                # instrument: closing the manager would also close a Tek session
                # in the same process. PyVISA owns manager cleanup at process exit.
                self._rm = pyvisa.ResourceManager(self.visa_backend)
                self._inst = self._rm.open_resource(self.resource, open_timeout=self.timeout_ms)
                self._inst.timeout = self.timeout_ms
                self._inst.read_termination = "\n"
                self._inst.write_termination = "\n"
                raw = self._query("*IDN?", result)
                fields = [part.strip() for part in raw.strip().split(",")]
                if len(fields) != 4:
                    raise ValueError("Malformed TED4015 identity response")
                manufacturer, model, serial, firmware = fields
                identity = dict(manufacturer=manufacturer, model=model, serial=serial, firmware=firmware, raw=raw)
                result["identity"] = identity
                if manufacturer.casefold() != "thorlabs" or model.upper() != "TED4015" or serial != self.serial:
                    raise ValueError(f"Expected Thorlabs TED4015 serial {self.serial}; got {raw.strip()!r}")
                if int(firmware.split("/", 1)[0].split(".", 1)[0]) < 2:
                    raise ValueError("TED4015 firmware >=2.0 required for this SCPI reader")
                self._identity = identity
                result["ok"] = True
            except Exception as exc:
                result["error"] = f"{type(exc).__name__}: {exc}"
                result["errors"].setdefault("setup", result["error"])
                self._close_after_error(result)
            return result

    def read_once(self) -> dict[str, Any]:
        """Read temperature in Celsius, TEC state and optional current in amperes.

        ok requires temperature and output state; a failed optional current query
        is retained in errors/error and leaves current_a=None. connected reports
        whether the session remains usable. Host query intervals are in timing;
        these are not instrument timestamps or simultaneous measurements.
        """
        with self._lock:
            result = dict(ok=False, temperature_c=None, output_enabled=None, current_a=None,
                          raw={}, errors={}, timing={}, error=None, connected=self._inst is not None)
            if self._identity is None or self._inst is None:
                result["error"] = "TED4015 is not ready; call setup() explicitly"
                return result
            parsers = (
                ("UNIT:TEMP?", None, None),
                ("MEAS:TEMP?", "temperature_c", lambda raw: _temperature_c(raw, result["raw"]["UNIT:TEMP?"])),
                ("OUTP1?", "output_enabled", _output_enabled),
                ("MEAS:CURR1?", "current_a", _number),
            )
            for command, key, parse in parsers:
                try:
                    raw = self._query(command, result)
                except Exception:
                    self._close_after_error(result)
                    break  # Never send another query after a transport failure.
                if parse is not None:
                    try:
                        result[key] = parse(raw)
                    except (ValueError, TypeError, AttributeError) as exc:
                        result["errors"][command] = f"{type(exc).__name__}: {exc}"
            result["ok"] = result["temperature_c"] is not None and result["output_enabled"] is not None
            result["connected"] = self._inst is not None
            result["error"] = "; ".join(f"{command}: {error}" for command, error in result["errors"].items()) or None
            return result

    def close(self) -> None:
        """Close only this instrument; never switch output or close shared VISA."""
        with self._lock:
            inst, self._inst = self._inst, None
            self._identity = None
            self._rm = None
            if inst is not None:
                inst.close()

    def __enter__(self) -> "Ted4015Reader":
        result = self.setup()
        if not result["ok"]:
            raise Ted4015SetupError(result)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is None:
            self.close()
        else:
            try:
                self.close()
            except Exception:
                pass  # Preserve the original acquisition exception.
