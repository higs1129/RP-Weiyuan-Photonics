"""One native PyRPL viewer sharing the bridge owner thread and acquisition RAM.

No second Pyrpl instance. Lock reference capture temporarily owns the same
hardware; native settings, displayed data and run intent are restored afterwards.
"""
from copy import deepcopy
import math


class NativeObservation:
    def __init__(self, pyrpl, excitation):
        self.p, self.excitation = pyrpl, excitation
        self.kind = None
        self.windows = {}
        self.presets = {}
        self.suspended = None
        self.saved = None
        self.excitation_token = None
        self.error = None

    def module(self, kind):
        return self.p.rp.scope if kind == 'scope' else self.p.spectrumanalyzer

    def snapshot(self, kind):
        m = self.module(kind)
        settings = deepcopy(m.setup_attributes)
        settings.pop('running_state', None)
        settings.pop('run_continuous', None)
        return dict(settings=settings, running=str(m.running_state),
                    data={k: deepcopy(getattr(m, k)) for k in
                          ('data_x', 'data_avg', 'current_avg', 'attributes_last_run') if hasattr(m, k)})

    def _stop(self):
        # Spectrum owns scope RAM while running; release it first.
        self.p.spectrumanalyzer.stop()
        self.p.rp.scope.stop()

    def _run(self, kind, mode):
        m = self.module(kind)
        if mode == 'continuous':
            m.continuous()
        elif mode == 'single':
            m.single_async()
        elif mode != 'stop':
            raise ValueError('请选择 continuous、single 或 stop')

    def _window(self, kind):
        if kind in self.windows:
            return self.windows[kind]
        from qtpy import QtWidgets
        QtWidgets.QApplication.instance().setQuitOnLastWindowClosed(False)
        owner = self
        class Window(QtWidgets.QWidget):
            def closeEvent(self, event):
                if owner.kind == kind:
                    if not owner._ui(owner.close):
                        event.ignore()
                        return
                event.accept()
        w = Window()
        w.setWindowTitle('RP*微源光子 · ' + ('Scope · ASG1 / IN2' if kind == 'scope' else 'Spectrum · IN2'))
        layout = QtWidgets.QVBoxLayout(w)
        w.notice = QtWidgets.QLabel()
        w.notice.setWordWrap(True)
        layout.addWidget(w.notice)
        stop_output = QtWidgets.QPushButton('停止激励输出')
        stop_output.clicked.connect(lambda: self._ui(self.stop_excitation))
        layout.addWidget(stop_output)
        w.viewer = self.module(kind)._create_widget()
        layout.addWidget(w.viewer)
        w.resize(1100, 760)
        self.windows[kind] = w
        if kind == 'scope':
            self._cursors(w)
        return w

    def _cursors(self, w):
        import pyqtgraph as pg
        from qtpy import QtWidgets
        plot = w.viewer.plot_item
        a = pg.InfiniteLine(pos=0, angle=90, movable=True, pen=pg.mkPen('#39d98a', width=2), label='A', labelOpts={'position': .95})
        b = pg.InfiniteLine(pos=.0001, angle=90, movable=True, pen=pg.mkPen('#ffc857', width=2), label='B', labelOpts={'position': .85})
        plot.addItem(a, ignoreBounds=True)
        plot.addItem(b, ignoreBounds=True)
        row = QtWidgets.QHBoxLayout()
        label = QtWidgets.QLabel()
        label.setWordWrap(True)
        def update(*args):
            if self.p.rp.scope.xy_mode:
                label.setText('XY 显示下横轴不是时间；请关闭 xy_mode 后测量 Δt。')
                return
            label.setText(f'tA = {a.value()*1e6:.6g} μs   tB = {b.value()*1e6:.6g} μs   '
                          f'Δt = {(b.value()-a.value())*1e6:.6g} μs\n'
                          '手动选取 ASG1 与 IN2 的对应位置；含 DAC/ADC、线缆等延迟，未校准 OUT1 物理发出时刻。')
        def center():
            lo, hi = plot.viewRange()[0]
            a.setValue(lo + (hi-lo)*.35)
            b.setValue(lo + (hi-lo)*.65)
        freeze = QtWidgets.QPushButton('冻结当前波形测时')
        freeze.clicked.connect(lambda: self._ui(lambda: self.control('stop')))
        reset = QtWidgets.QPushButton('游标移到当前视野')
        reset.clicked.connect(center)
        a.sigPositionChanged.connect(update)
        b.sigPositionChanged.connect(update)
        row.addWidget(freeze)
        row.addWidget(reset)
        row.addWidget(label, 1)
        w.layout().insertLayout(1, row)
        w.cursor_row = (freeze, reset, label)
        w.cursors = (a, b)
        w.update_cursors = update
        # Native edits (including XY mode) must not leave a stale time label.
        from qtpy import QtCore
        w.cursor_timer = QtCore.QTimer(w)
        w.cursor_timer.timeout.connect(update)
        w.cursor_timer.start(500)
        update()

    def _ui(self, operation):
        # Exceptions escaping a PyQt slot can terminate the shared backend.
        try:
            operation()
            return True
        except Exception as exc:
            self.error = str(exc)
            if self.kind in self.windows:
                self.windows[self.kind].notice.setText('操作未确认：' + self.error)
            return False

    def _gate_windows(self, enabled):
        for kind, w in self.windows.items():
            w.viewer.setEnabled(enabled)
            if hasattr(w, 'cursor_row'):
                for widget in w.cursor_row:
                    widget.setEnabled(enabled)
            w.notice.setText('仅显示此前波形 · 锁模/重锁正在获取新参考，完成后恢复观察配置。' if not enabled else
                            '与平台共用当前 PyRPL 后台；Scope / Spectrum 共用采集资源。关闭窗口会停止本观察及其激励。')

    def open(self, kind, settings=None, run='continuous'):
        if kind not in ('scope', 'spectrum') or run not in ('continuous', 'single', 'stop'):
            raise ValueError('Invalid native observation mode')
        if self.suspended:
            raise RuntimeError('正在锁模/重锁，原生观察暂不可更改')
        if str(self.p.networkanalyzer.running_state).startswith('running'):
            raise RuntimeError('网络分析仪正在使用采集资源，请先停止')
        allowed = {'duration', 'trigger_source'} if kind == 'scope' else {'span', 'trace_average'}
        settings = settings or {}
        if not isinstance(settings, dict) or set(settings)-allowed:
            raise ValueError('Invalid native observation settings')
        for key, value in settings.items():
            if key == 'trigger_source':
                if value not in ('asg1', 'immediately'):
                    raise ValueError('请选择 ASG1 同步或自由触发')
            elif isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError('观察参数须为正的有限数值')
        if 'duration' in settings and not 1e-6 <= settings['duration'] <= 8.589934592:
            raise ValueError('Scope 时长超出范围')
        if 'trace_average' in settings and (int(settings['trace_average']) != settings['trace_average'] or settings['trace_average'] > 100):
            raise ValueError('平均次数须为 1–100 的整数')
        if 'span' in settings and settings['span'] > 125e6:
            raise ValueError('频谱 Span 不能超过 125 MHz')
        if self.kind:
            self.presets[self.kind] = self.snapshot(self.kind)
        self._stop()
        if self.kind and self.kind != kind:
            self.stop_excitation()
            self.windows[self.kind].hide()
        m = self.module(kind)
        defaults = (dict(input1='asg1', input2='in2', duration=.016777216,
                         trigger_source='asg1', trigger_delay=0., rolling_mode=False,
                         ch1_active=True, ch2_active=True, xy_mode=False, trace_average=1)
                    if kind == 'scope' else dict(baseband=True, input1_baseband='in2',
                                                input2_baseband='in2', display_input1_baseband=True,
                                                display_input2_baseband=False, display_cross_amplitude=False,
                                                display_unit='dBm/Hz',
                                                span=100000., trace_average=1))
        config = dict(self.presets.get(kind, {}).get('settings', defaults))
        config.update(settings)
        config['run_continuous'] = False
        if kind == 'scope':
            config.update(input1='asg1', input2='in2', ch1_active=True, ch2_active=True, xy_mode=False)
        m.setup(**config)
        self.kind = kind
        self.error = None
        w = self._window(kind)
        self.p.hide_gui()
        self._gate_windows(True)
        w.showNormal()
        w.raise_()
        w.activateWindow()
        self._run(kind, run)
        return self.state()

    def control(self, run):
        if run not in ('continuous', 'single', 'stop'):
            raise ValueError('Invalid observation run mode')
        if self.suspended:
            raise RuntimeError('锁模/重锁中，请等待观察恢复')
        if not self.kind:
            raise RuntimeError('请先打开原生观察窗口')
        self.error = None
        self.module(self.kind).stop()
        self._run(self.kind, run)
        return self.state()

    def suspend(self, token):
        if not isinstance(token, str) or not token:
            raise ValueError('Missing suspension token')
        if self.suspended and self.suspended != token:
            raise RuntimeError('另一项操作正在占用原生观察')
        if not self.suspended:
            self.saved = self.snapshot(self.kind) if self.kind else None
            self.suspended = token
            # Freeze old displayed data: lock scans must not enter the response viewer.
            for kind, w in self.windows.items():
                self.module(kind)._signal_launcher.display_curve.disconnect(w.viewer.display_curve)
            if self.kind:
                self._stop()
            self._gate_windows(False)
        return self.state()

    def resume(self, token):
        if self.suspended != token:
            raise RuntimeError('原生观察占用标识不匹配；未恢复其他会话')
        if self.kind:
            self._stop()
        if self.kind and self.saved:
            m = self.module(self.kind)
            m.setup(**dict(self.saved['settings'], run_continuous=False))
            for key, value in self.saved['data'].items():
                setattr(m, key, value)
            running = self.saved['running']
            if running.startswith('paused'):
                m._running_state = running  # Native Resume buttons create a new task.
        else:
            running = 'stopped'
        for kind, w in self.windows.items():
            self.module(kind)._signal_launcher.display_curve.connect(w.viewer.display_curve)
        self.suspended = None
        self.saved = None
        self._gate_windows(True)
        if self.kind and running.startswith('running'):
            self._run(self.kind, 'single' if running == 'running_single' else 'continuous')
        return self.state()

    def stop_excitation(self):
        if self.excitation_token:
            token = self.excitation_token
            self.excitation.cancel(token)
            self.excitation.stop(token)
            self.excitation_token = None

    def close(self):
        self.stop_excitation()
        if self.kind:
            if not self.suspended:
                self.presets[self.kind] = self.snapshot(self.kind)
                self._stop()
            elif self.saved:
                self.presets[self.kind] = self.saved
            self.windows[self.kind].hide()
        self.kind = None
        self.saved = None  # Closing during relock must never reopen it afterwards.
        return self.state()

    def adopt_excitation(self, token):
        if self.kind == 'scope' and self.windows['scope'].isVisible():
            self.excitation_token = token

    def tick(self):
        # Qt timer callbacks must never propagate errors into the event loop.
        try:
            self._tick()
        except Exception as exc:
            self.error = str(exc)
            if self.kind in self.windows:
                self.windows[self.kind].notice.setText('观察状态未确认：' + self.error)

    def _tick(self):
        if self.kind and not self.suspended:
            module = self.module(self.kind)
            future = getattr(module, '_last_run', None)
            if future is not None and future.done() and not future.cancelled():
                failure = future.exception()
                if failure is not None and self.error != str(failure):
                    self.error = str(failure)
                    module.stop()
                    self.windows[self.kind].notice.setText('采集中断：' + self.error)
        if self.excitation_token:
            try:
                if not self.kind or not self.windows[self.kind].isVisible():
                    self.stop_excitation()
                elif not self.excitation.keepalive(self.excitation_token).get('active'):
                    self.excitation_token = None
            except Exception as exc:
                self.error = str(exc)
                self.excitation_token = None

    def state(self):
        m = self.module(self.kind) if self.kind else None
        return dict(ok=True, kind=self.kind, suspended=bool(self.suspended), error=self.error,
                    running=str(m.running_state) if m and not self.suspended else 'stopped',
                    armed=bool(m._trigger_armed and m.pretrig_ok) if self.kind == 'scope' and not self.suspended else False,
                    trigger_source=str(m.trigger_source) if self.kind == 'scope' and not self.suspended else None,
                    duration=float(m.duration) if self.kind == 'scope' and not self.suspended else None)

    def dispatch(self, body):
        action = body.get('action')
        if action == 'open':
            return self.open(body['kind'], body.get('settings'), body.get('run', 'continuous'))
        if action in ('suspend', 'resume'):
            return getattr(self, action)(body['token'])
        if action == 'run':
            return self.control(body['run'])
        if action == 'close':
            return self.close()
        if action == 'state':
            return self.state()
        raise ValueError('Unknown observation action')
