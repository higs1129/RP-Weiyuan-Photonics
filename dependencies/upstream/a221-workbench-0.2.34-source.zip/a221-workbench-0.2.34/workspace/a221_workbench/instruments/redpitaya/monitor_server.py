"""Reuse only a byte-verified PyRPL monitor binary, with upstream repair fallback."""
import hashlib
from pathlib import Path
import posixpath
import shlex


def verified_server(rp, binaries):
    """Read a hash through the existing SSH transport; never remount/write the SD."""
    remote = posixpath.join(rp.parameters['serverdirname'], rp.parameters['monitor_server_name'])
    command = 'test -x {0} && sha256sum -- {0}'.format(shlex.quote(remote))
    _, stdout, stderr = rp.ssh.ssh.exec_command(command, timeout=3)
    try:
        # Bounded command/output, independent of the interactive server shell.
        line = stdout.readline(512).strip()
        digest = line.split()[0] if line else ''
        return digest in {hashlib.sha256(p.read_bytes()).hexdigest() for p in binaries}
    finally:
        stdout.channel.close()


def patch_monitor_server_reuse():
    import pyrpl.redpitaya as module
    cls = module.RedPitaya
    original = cls.installserver
    if getattr(original, '_verified_reuse', False):
        return
    root = Path(module.__file__).parent / 'monitor_server'
    binaries = [root / name for name in ('monitor_server', 'monitor_server_0.95')]

    def install(self):
        first = not getattr(self, '_monitor_checked', False)
        self._monitor_checked = True
        # Later calls are upstream's start-failure recovery and must really install.
        if first and self.parameters.get('reloadserver'):
            try:
                if verified_server(self, binaries):
                    self.logger.info('Verified RP monitor_server matches bundled binary; skipping upload.')
                    return self.parameters['port']
            except Exception as exc:
                self.logger.info('Cannot verify RP monitor_server (%s); using normal installation.', type(exc).__name__)
        return original(self)

    install._verified_reuse = True
    cls.installserver = install
