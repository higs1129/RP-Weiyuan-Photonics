# 向 A221 Workbench 提出修改需求

外部项目在自己的任务中整理以下内容，再交由本项目 Agent 处理。无需先在共享源码上打补丁，也不要附带访问令牌或本机密钥。

```text
来源项目 / 使用场景：
安装包版本 / Python 版本：
调用的公开接口：
最小复现（优先合成数据）：
预期行为：
实际行为 / 错误：
建议修改：
对现有调用及科学计算口径的影响：
建议验证方式：
```

本项目 Agent 复现问题、修改唯一源码、完成相关验证后，交付新包及迁移说明。外部项目更新包版本并复核自己的实验结果；源码维护、安装更新和 GitHub 发布分别执行。

2026-11-19 微源短状态帧及按状态启动需求见 [weiyuan-compact-status-change.md](weiyuan-compact-status-change.md)。

2026-11-13 微源开关状态不可读时的参数操作需求见 [weiyuan-unknown-switches-change.md](weiyuan-unknown-switches-change.md)。

2026-11-03 微源平台的直连、多网卡发现与显式路径修复需求见 [rp-network-discovery-change.md](rp-network-discovery-change.md)。

2026-10-27 微源平台的后台会话退出和通信程序复用需求、接口与影响见 [rp-session-lifecycle-change.md](rp-session-lifecycle-change.md)。
