# TED4015 只读接口（0.2.33）

入口：`a221_workbench.instruments.thorlabs.Ted4015Reader(resource, serial, timeout_ms=1000, visa_backend='@ivi')`。

```python
from a221_workbench.instruments.thorlabs import Ted4015Reader

with Ted4015Reader(
    'USB0::0x1313::0x8048::M00693957::INSTR', 'M00693957'
) as reader:
    identity = reader.setup()  # 上下文已校验；重复 setup 不发送额外查询
    sample = reader.read_once()
```

构造不连接设备。`setup()` 返回 `ok/identity/raw/errors/timing/error`，校验厂商、TED4015 型号、指定序列号及固件主版本至少为 2。上下文入口自动 setup，失败抛 `Ted4015SetupError`，其 `result` 保留结构化失败信息。也可手动调用 setup 并检查 ok，最后 close。

## 查询与返回

命令依据 [Thorlabs Series 4000 SCPI V3.3 手册](https://www.thorlabs.com/software/MUC/4000_Series/Manual/Series4000_SPCI_Programmers_Reference_V3.3.pdf) §3.1.1、§3.3.6、§3.13.1、§3.19.1，以及 [TED4015 2.x 固件说明](https://www.thorlabs.com/software/MUC/4000_Series/Firmware/TED4000/Updating_the_TED4015_to_Firmware_V2.x.x.pdf) §4。固件 2.x 沿用 Series 4000 指令；TED 的 TEC 输出通道为 1，ITC 的 TEC 通道为 2，本接口仅接收 TED4015。

| 时机 | 查询 | 处理 |
| --- | --- | --- |
| setup | `*IDN?` | 身份校验 |
| 每次读取 | `UNIT:TEMP?` | 读取当前通信单位 |
| 每次读取 | `MEAS:TEMP?` | 实测传感器温度，本机将 C/F/K 换算成 °C |
| 每次读取 | `OUTP1?` | `0`/`1` 转为 False/True |
| 每次读取 | `MEAS:CURR1?` | 实测 TEC 电流，保留正负号，单位 A |

温度来自仪器现有传感器系数，不等于光学芯片温度；不重新标定。输出关闭仍读取温度，不将关闭状态视为无效，也不把电流直接假定为零。未知单位、非法输出状态、非有限值和 SCPI 无效/溢出数值返回错误及 None，不伪装成零。

`read_once()` 返回：

- `ok`：本次温度和输出状态均有效；电流是附加字段，电流失败可同时出现 `ok=True` 和非空 `error`。
- `temperature_c`、`output_enabled`、`current_a`：失败或尚未查询时为 None。
- `raw`：以命令为键的原始应答（保留终止符）；已尝试但没有应答时为 None；未执行的命令不出现。
- `errors`：以命令为键的传输/解析错误；`error` 为汇总字符串，无错误时 None。
- `timing`：每条查询的 `started_unix_ns/finished_unix_ns` 与 `started_perf_counter_ns/finished_perf_counter_ns`。可与同主机示波器记录关联，这是主机查询区间，不是仪器采样时刻；温度、状态、电流按顺序读取，并非同时测得。
- `connected`：当前 VISA 连接是否仍可使用。

每条查询使用有限 `timeout_ms`。传输错误后停止本轮剩余查询并关闭本仪器连接，避免迟到应答被误认成另一条查询的结果；不自动重试、不清缓冲或错误队列。调用方需要显式 setup 才会重新打开连接。收到完整应答但解析失败时保留原文，后续独立查询继续。

只有固定查询白名单，不提供任意 write/query 接口；不发 reset、clear、错误队列查询、远程锁定、输出开关、温度设定、传感器参数或控温模式设置。手册规定 MEAS 查询内部相当于 CONF+READ，会选择测量项目并取得新读数，不改变 TEC 源模式/设定或传感器系数。没有使用只取历史缓存的 FETCh 冒充新采样。

## 连接与验证

在独立采集线程中创建、setup、循环 read_once、close。读取器保留独立的仪器连接，并串行化自身调用。PyVISA 对同一 backend 共享 ResourceManager；关闭读取器只关闭自身仪器会话，管理器由 PyVISA 进程退出清理，避免中断同进程的 Tek 连接。其他消费者也不应在采集期间关闭这个共享管理器。

源码基于已有 0.2.32 增补至 0.2.33；本次只增加 TED 读取器和版本/说明，不改现有 SGM、TEC 输出、科学模型或采集默认动作。仓库外验证位于 `%TEMP%/a221-ted4015-reader/verify.py`，覆盖身份、查询白名单、单位、非有限值、TEC 关闭读温度、可选电流失败、超时停止、断连、资源关闭和上下文失败。所有 VISA 调用使用替身，无真实测量和实验记录写入。现场只读验证及实验面板接入由实验项目执行。

2026-10-22 已安装至 `C:/Users/W10/AppData/Local/MicrocavityControl/envs/pyrpl-0.9.8.0-py310`。元数据与实际模块版本均为 0.2.33，源码与安装版均通过上述 9 组离线检查；168 个安装包文件与 wheel 一致。wheel：`workspace/dist/a221_workbench-0.2.33-py3-none-any.whl`，SHA256 `965fe33faefe54a1b18feb17199867cdee31dc51f5b872a44203a3c55154cf8b`。旧 0.2.16 元数据收存在上述临时验证目录。未停止正在运行的进程；消费端须重开 Python 后端加载新包。任务分支 `codex/ted4015-reader`，未提交或推送。
