# 0.2.33 实际模块接口

0.2.33 新增 `instruments.thorlabs.Ted4015Reader`，只查询实际传感器温度、TEC 输出状态和电流，校验型号/序列号，读取当前单位并在本机换算摄氏度。固定查询白名单，无输出或传感器设置入口；详见 [TED4015 读取接口](ted4015-reader.md)。既有功能保留。

0.2.22 修改微源守护的默认重锁动作：持续失锁或捕获超时后，先关闭反馈，按锁定前实际读回的 ASG 波形、频率、幅度、偏置和触发设置重新扫描 IN1 / OUT2，重新计算基线、谷底、目标锁点及判定阈值，再从既定 ival 捕获。锁定比例、P/I、输出限幅、激光器温度与电流不变；目标仍为 `谷底 + fraction × (基线 − 谷底)`。每次重试都采集新参考，不沿用之前的锁点。缺少完整凹陷、存在多个完整凹陷或参考质量不足时关闭扫描与反馈，按重试间隔重新扫描；采集/通信异常停止本轮守护并报告错误。单纯监测读回失败仍标为未知，不据此盲目重扫。

连续采集按帧释放 RP 采集资源，重扫期间门控关闭，不交付跨越失锁/重锁的测量帧；锁定重新确认后，原连续采集会话恢复自身通道、触发及采集设置。停止守护仍等待工作线程结束并关闭反馈，避免重扫后发生迟到的 PID 接管。停止守护、暂停采集后需重开微源控制台进程以加载本次后端修改，仅刷新网页不生效。

0.2.22 的仓库外离线验证覆盖新参考目标与阈值更新、捕获超时重扫、平坦/多模式参考拒绝、扫描读取失败关闭输出、取消重扫不再次接管、网络监测失败不重扫、等待采集资源，以及连续采集跨状态帧丢弃和恢复原配置，共 9 项通过。验证使用合成模式与内存设备替身，未连接真实仪器、未执行测量或改变正在运行的守护。

0.2.21 压缩微源控制台公共页头，连接、RP 后台重启与 PyRPL 显隐按钮统一移到“仪器连接”页，网络与串口高级检查放在该页末尾。各页顶部保留连接灯和锁定状态。切换左侧功能时回到页面顶部；图形按窗口高度调整显示区域，详细采集、坐标和保存设置折叠。测量初始化在宽屏默认将温度、电流调节展开在波形右侧，收起后波形占满宽度；窄屏将调节放到波形之后，默认折叠。显示现有读回及其时间，未提交的输入在页面切换时保留，不自动读取或写入激光器。已有设备指令、锁定逻辑、科学模型、单位和原始数据不变。此次仅前端布局与交互更新，暂停采集后 Ctrl+F5 即可加载，无需重启 RP 后台。

0.2.20 修复 RP 百兆开机服务执行早于 PHY 初始化、返回成功但设置随后被覆盖的问题。服务在 networkd 后等待网卡/PHY 就绪再应用并读回百兆协商能力。见 [新 RP 自动准备](rp-auto-setup.md)。

微源控制台每 60 秒尝试一次只读连接检查，首页与各页顶部共用 RP / 微源指示灯，点击顶部指示灯进入仪器连接页。空闲时确认原 RP 后台身份并读取反馈状态，微源只读一个模式寄存器；不重新解析部署、不重启、不切模式或修改输出。采集/锁定中复用最近的 RP 数据，串口检查延后；未连接的设备不自动启动。同一控制台多个标签共享后端节流，检查不排队叠加。绿色表示近期通过、红色表示失败、黄色表示延后/超过 90 秒未确认、灰色表示未连接，悬停显示最后检查时间及原因。连接监测后端更新需重开控制台 Python 进程。

微源控制台波形图下的“坐标轴范围”支持横轴、纵轴上下限，单轴两项留空表示自动范围。左键左右拖动缩放横轴、上下拖动缩放纵轴；Shift + 左键拖动平移。右键不处理，避免与浏览器手势冲突；触屏保留页面滑动，用数字输入调整范围。“恢复自动范围”重新适配完整波形。手动范围在连续帧刷新和当前网页内切换页面时保留，刷新网页后恢复自动；只改变显示，不改变设备采集参数或导出的数据。

0.2.21 离线浏览器验证覆盖 1280×720、1366×768、1920×1080 的全部功能页，确认核心波形与宽屏激光器调节在首屏可见，另检查 390×844 窄屏无横向溢出。校验左键缩放、Shift 平移、右键不改范围、连续刷新和页面切换保留范围、收起侧栏重绘、原始数据不变、未提交输入保留、移动后按钮只绑定一次以及一分钟连接检查。所有设备 API 使用仓库外离线固定响应，无真实测量或设备设置。

微源控制台的“恢复扫频”设置示波器为 IN1 / ASG0、ASG0 触发方式为 immediately、示波器触发源为 ASG0。“测量初始化”的未锁定连续运行和单次采集沿用 IN1 / ASG0 与 ASG0 触发；锁定后采集及独立“时域观察”使用 IN1 / IN2 与 immediately 触发。采集入口只配置示波器，不改 ASG/PID 输出参数。修改后需重开控制台进程，单独刷新网页不会更新后台逻辑。

0.2.19 补上微源控制台普通“连接并启动”的一次性恢复：通过身份检查后，只读探测明确报连接关闭或重置时，复用共用重启任务清理旧 PyRPL，再验证新后台。健康后台直接复用，超时及身份冲突不触发自动结束进程；重建后 RP 输出关闭。

0.2.18 在微源控制台增加“重启 RP 后台”：调用共用重启任务核验并退出旧后台，必要时定向结束，端口释放后才启动新实例。重启完成后确认 RP 输出关闭，不执行激光器启动。见 [RP 后台重启](rp-bridge-restart.md)。

0.2.17 在微源控制台的显式连接流程中自动发现 RP、通过 CON 恢复已核验板卡的百兆网络，并按需安装开机 UART 服务。普通地址解析保持只读；不会在采集循环中切速或重发激光器设置。使用条件、持久配置与撤销方法见 [新 RP 自动准备](rp-auto-setup.md)。

0.2.16 区分 SGM 提交前失败与写入结果未知；新增 `instruments.sgm5348.lifecycle.ensure_sgm_service`。已启用自动恢复时，仅明确 TCP 拒绝连接且尚未提交电压，才在当前核验地址启动已部署服务一次；随后重新校验再提交，禁止 POST 重发及旧 IP/SSH 写电压回退。见 [SGM 服务生命周期](sgm-service-lifecycle.md)。

0.2.15 修复明确 RP 身份相同但 DHCP 地址改变时的旧后台重启识别；保留进程／HTTP一致性与新地址MAC核验。普通启动保留RP身份，旧连接不会因此自动重启或被视为有效。见 [RP 显式重启](rp-bridge-restart.md)。

0.2.14 在 SGM 共享客户端缓存已核验 RP 地址，正常后续写入跳过重复 hostname 解析，每次仍核验健康身份和配置；仅缓存地址的提交前传输故障可重新发现一次，POST 开始后不重发。见 [SGM 地址缓存](sgm-address-cache.md)。

0.2.13 修正 `refine_manual_dip` 在有噪声肩部提示处误选噪声谷的问题：轻微平滑与显著性门限仅定位最近候选，再在其盆地内返回原始最低采样。参数/原字段兼容，旧 MZI 拟合和采集入口不变；门限与验证见 [人工辅助热调谐](manual-thermal.md)。

0.2.12 新增显式 `tasks.analysis.manual_thermal.refine_manual_dip`，将大概提示精修为窗口内最近局部 dip 的原始最低采样；原 MZI 人工拟合入口不变。合同见 [人工辅助热调谐](manual-thermal.md)。

0.2.11 增加仅采集的热调谐扫描 `analyze=False` 和离线 `tasks.analysis.manual_thermal.analyze_manual_thermal`。合同、单位和离线验证见 [人工辅助热调谐](manual-thermal.md)。原自动缺省行为不变。

代码只有设备、单项任务、组合流程三类。以下都是实际实现位置；旧 Python 包名和转发文件已移除。

| 用途 | 模块 |
| --- | --- |
| TOPTICA 串口/TCP | `a221_workbench.instruments.toptica` |
| RP、示波器、MDT、SGM、微源 | `a221_workbench.instruments.<设备>` |
| 独立大扫采集 | `a221_workbench.tasks.large_scan.acquire_large_scan` |
| 共用细扫恢复 | `a221_workbench.tasks.large_scan.restore_fine_scan_scope` |
| 数据处理、色散、Q | `a221_workbench.tasks.analysis.large_scan` 下对应模块 |
| 光学/机械 Q 原语 | `a221_workbench.tasks.analysis.optical_q` / `mechanical_q` |
| 卡片、交互 Q 报告 | `a221_workbench.tasks.large_scan.write_cavity_card` / `write_interactive_q_review` |
| 完整大扫 | `a221_workbench.workflows.large_scan.large_scan_flow` |
| 阵列界面和复合流程 | `a221_workbench.workflows.array_dashboard` |
| 锁定、耦合、热调谐 | `a221_workbench.workflows.locking` / `auto_coupling` / `thermal_tuning` |

```python
from a221_workbench.tasks.large_scan.acquire_large_scan import AcquisitionOptions, acquire_scan
from a221_workbench.tasks.large_scan.restore_fine_scan_scope import RestoreOptions, restore_fine_scan
from a221_workbench.tasks.analysis.large_scan.process_large_scan import ProcessOptions, process_scan

plan = acquire_scan(AcquisitionOptions(
    output_dir="D:/my_experiment/scan_001", sample_id="my_sample",
    dry_run=True,  # 扫描前、恢复细扫后默认各执行一次 SMILE 关→开
))
restore_plan = restore_fine_scan(RestoreOptions(dry_run=True))
# 离线处理已有数据；请填写本次实际标定参数：
# summary = process_scan(ProcessOptions(data_path="D:/my_experiment/scan_001/raw.npz",
#     output_dir="D:/my_experiment/scan_001/processed", mzi_d1_mhz=40.44357))
```

各任务的 CLI 只解析参数，再调用同一个函数。完整组合流程可使用：

```python
from a221_workbench.workflows import run_workflow
run_workflow("large-scan", ["--help"])
```

或 `python -m a221_workbench large-scan --help`。命令名是实际流程选择，不提供旧 Python 导入路径。

完整大扫和独立采集均默认执行前/后 SMILE 关开，无需额外参数。顺序为记录初始波长、移动到大扫起点、SMILE 关→开、采集、返回初始波长、恢复细扫 ARC 与示波器设置、再次 SMILE 关→开。采集自动调用共用恢复，独立恢复调用同一函数。恢复 TOPTICA/VISA 状态不等于准备 RP 扫描源；RP 由组合流程管理。失败会返回错误，不保证硬件已恢复。

原 `--array-preanalysis-only` 的实际阵列分析包含 Q 计算，本版修正帮助说明，保留参数行为；该模式跳过的是完整单腔卡片和交互报告链。

配置放 `workspace/config/<原设备或应用名>/`，设置 `A221_CONFIG_HOME` 时从指定配置根读取。独立安装包可通过 `MEASUREMENT_WORKBENCH_ROOT` 指向工作台配置根。实验数据根仍为 `DAILY_NOTE_DATA_ROOT` 或显式路径，未搬迁。

```powershell
python -m pip wheel --no-deps --wheel-dir workspace/dist ./workspace
python -m pip install workspace/dist/a221_workbench-0.2.18-py3-none-any.whl
```

0.2.0 删除了旧导入路径；0.2.1 整理根目录并将阵列专用启动器移入 `workspace/a221_workbench/workflows/array_dashboard/`；0.2.2 将独立采集的前/后 SMILE 关开默认值改为开启。改动前备份与离线核对材料保存在仓库外的 Codex backups 目录，没有保留测试代码或兼容转发以维持旧导入。

0.2.3 增加共用的 RP 后台显式重启接口、命令行与 CMD 入口，dashboard 重启调用同一实现；新增 psutil 依赖。详见 [RP 后台重启](rp-bridge-restart.md)。普通 `BridgeRuntime.ensure()` 的复用行为不变。

0.2.7 按用户要求恢复自动耦合原读数方式：`a221_workbench.tasks.coupling.readout.read_overlay(bridge)` 只执行一次 `GET /get?param=scope.active_means_v`，读取 GUI 持续刷新的文本，再由原解析器提取 `P inst`。不调用 `read_power`、`scope.single` 或任何同步采集 fallback。GUI 字段不可用时按原方式报错，由现场准备 GUI 读数。

单调步进耦合恢复 `read_overlay(args.bridge)`，移除新增的 `--power-zero-offset` 参数。暗偏压由消费者启动前通过原 GUI 零点字段一次设置，自动耦合不再二次扣除。dashboard 两遍流程及参数、0.2.6 的 pyserial 导入修复均保留。

`read_power(bridge, *, timeout_s=3.0, zero_offsets_v=None)` 保留为显式单帧采集 API，仅供调用者明确请求单帧时使用，自动耦合不走此接口。本次仅恢复客户端代码，未操作仪器、GUI 配置或运行中的服务。

## 显式封装接线（0.2.8）

实验 config 可声明腔号到 PCB OUT 标签的逐路接线，不修改芯片设计的 `electrode_to_cavity` 或电极接触记录：

```python
config.update(
    sgm_pcb_map="wirebond16",
    sgm_cavity_to_out={
        "c1": 3, "c2": 2, "c3": 1, "c4": 0,
        "c5": 7, "c6": 6, "c7": 5, "c8": 4,
        "c9": 11, "c10": 10, "c11": 9, "c12": 8,
        "c13": 15, "c14": 14, "c15": 13, "c16": 12,
    },
    sgm_enabled_cavities=[f"c{i}" for i in range(1, 17)],
)
```

`sgm_cavity_to_out` 的值必须是互不重复的整数 0..15（不接受布尔、字符串或小数），腔号必须存在于设计电极表。允许部分映射；未列出的腔禁用，不回退到旧 E 序号推算。

`sgm_enabled_cavities` 可省略或设为 `None`，此时仍按原接触记录判断是否可用。显式列表表示用户允许这些已映射通道参与轮询和重构，替代接触状态作为可用性判据；空列表表示全部禁用。它不证明电阻已测或接触良好，也不修改这些记录。列表不能重复、不能引用未映射的腔，且必须配合显式映射使用。

两项均未声明或为 `None` 时，完全沿用 `e1_probe + E 序号 - 1` 和原接触判据。`tasks.array_records.load_electrode_record` 在内存中应用映射；物理 `electrode` 保留，显式模式下 `probe=OUT+1` 是给现有消费者使用的通道标签，不代表改写物理 E 编号。返回行的 `routing_source` 与 `enabled_by_config` 标明配置来源，不写回实验文件。

`tasks.array_records.sgm_entry_from_electrode` 是共用路由和可用性解析器；`quick_probe.build_thermal_auto_assignment_plan` 与 `comb_measurement.sgm_entries_by_cavity` 都调用它。显式模式的条目还返回 `availability_source`，区分 `sgm_enabled_cavities` 使用声明和 `contact_status` 接触记录。参数校验在生成计划时完成，早于设备连接和输出写入。原热归属编码顺序、扫压、拟合和重构策略不变。

`sgm_pcb_map` 是另一层 DAC VOUT→PCB OUT 映射。新板必须显式选 `wirebond16`，其上/下片 VOUT1..8 分别对应 `(3,2,1,0,7,6,5,4)` / `(11,10,9,8,15,14,13,12)`。上述腔号映射直接使用 PCB OUT 标签，不能再做一次倒序。本次不改变全局 `legacy16` 默认值，也不修改或重启板端服务。

## 阵列分族深度阈值（0.2.9）

Dashboard 请求 body 或实验 config 可设置 `array_min_depth=0.1`。`instrument_backend.large_scan_command(body, args)` 优先使用 body 中非 `None` 的值，再使用 `args.array_min_depth`；`instrument_runtime.backend_args(config)` 将配置传入该属性。重构后复扫的 `comb_measurement.run_assignment_large_scan(config, payload, ...)` 同样优先使用 payload，再使用 config。

两条入口都传递 `--array-min-depth 0.1` 给 `large_scan_flow`，最终进入已有的 `ArrayOptions.min_depth`。数值必须有限且满足 `0 < x < 1`；未指定或为 `None` 时仍为 0.2。只影响阵列 FSR/分族分析采用的凹陷深度门槛，不改变找峰、拟合、重构算法或其他阈值。

从已有 raw 重分析时，在原大扫命令上使用 `--array-preanalysis-only --resume-existing-raw --array-min-depth 0.1`；Dashboard body 对应 `array_die_scan=True, mode="resume", array_min_depth=0.1`。加 `--dry-run` 可仅检查计划，返回的 `commands.array_min_depth` 显示所用阈值。此版本仅补齐参数透传，没有执行真实 raw 分析或仪器操作。

## 当前 FSR 标定取消（0.2.10）

消费端继续调用 `comb_measurement.CURRENT_FSR_CANCEL_EVENT.set()` 请求停止。该 Event 保留首次请求时间，重复 set 幂等；`run_current_fsr_probe_assignment(..., progress_callback=...)` 可接收各子步骤进度，原 `progress.json` 也继续更新。最终取消结果含 `cancel_requested_at`、`cancel_to_finish_s`、`recovery`、`recovery_required`，另保存 `cancellation.json`。清零/恢复未确认成功时 `ok=False`，不再无条件报告全零。

取消检查覆盖示波器设置命令之间、SGM 解析地址/健康检查之后、每次采样、电压点、分析和 family 的边界。已经开始的电压 POST 同步等待完成或超时报错，随后才进入收尾；不会遗留本地后台电压写线程。前次写入结果未知时不重发，也不启动可能与其交错的清零，报告需要核对。恢复时不重启板端服务，身份、基准电压及 PCB 映射校验保留。

采集 worker 响应最长等待 180 秒，期间每 0.1 秒检查取消；取消可终止本次创建的 worker。正常关闭响应限 3 秒，退出等待限 2 秒，必要时 terminate/kill 各等待最多 2 秒。只处理本流程持有的子进程，不终止 RP 服务、GUI 或其它任务。直接 VISA/HTTP/地址解析中的单次调用仍需返回或超时，不承诺所有阶段固定秒数内结束。

快速轮询用现有 TEK 连接收尾；正常采集 worker 也使用已有连接恢复 continuous，取消中断 worker 后才按需重新连接恢复。内层收尾结果向外层传递，每次取消不重复清零/恢复。轮询方法、采样数、扫压步长、帧格式、拟合算法及正常电压写入性能路径均未更改。
