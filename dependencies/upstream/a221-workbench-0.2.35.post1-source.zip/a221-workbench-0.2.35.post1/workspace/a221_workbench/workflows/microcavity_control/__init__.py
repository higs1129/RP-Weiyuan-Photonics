"""Single-cavity control interface."""
