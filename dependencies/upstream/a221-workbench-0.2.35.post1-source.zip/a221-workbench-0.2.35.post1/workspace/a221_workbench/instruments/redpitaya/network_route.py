"""Explicit, previewable IPv4LL host-route repair. Never called by discovery."""
import base64
import ipaddress
import json
from pathlib import Path
import subprocess
import tempfile
import uuid

from .network import rp_identity
from .network_diagnostics import local_interfaces


def plan(report, target, interface_index):
    target = str(ipaddress.IPv4Address(target))
    identity = rp_identity(report.get('host', ''))
    if not identity or not ipaddress.ip_address(target).is_link_local:
        raise ValueError('自动路径修复仅适用于已发现的 RP 169.254 地址')
    candidate = next((c for c in report.get('candidates', []) if c['address'] == target), None)
    if not candidate:
        raise ValueError('目标不在本次设备发现结果中，请重新查找')
    rows = [r for r in report['interfaces'] if r['index'] == int(interface_index)
            and r.get('physical') and r.get('state') == 'Connected'
            and ipaddress.ip_address(r['address']).is_link_local and r.get('guid')]
    if len(rows) != 1:
        raise ValueError('请选择有唯一 169.254 地址的已连接物理网卡；其他配置请人工核对')
    row = rows[0]
    if target == row['address'] or target in ('169.254.0.0', '169.254.255.255'):
        raise ValueError('目标与电脑地址冲突或无效')
    guid = str(uuid.UUID(row['guid'].strip('{}')))
    return {'host': report['host'], 'identity': identity, 'target': target, 'destination': target + '/32',
            'index': row['index'], 'guid': guid, 'source': row['address'], 'prefix': row['prefix'],
            'interface': row['name'], 'metric': 1,
            'summary': f"仅为 {target} 添加经 {row['name']}（{row['address']}/{row['prefix']}）的临时直连路由；"
                       '不改 IP、掩码、网关、DNS 或 RP。需要管理员确认；身份/SSH 验证失败则回滚，成功后有效至电脑重启。'}


_SCRIPT = r'''
$ErrorActionPreference='Stop'
$env:PSModulePath="$PSHOME\Modules;"+$env:PSModulePath
$plan=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__PLAN__')) | ConvertFrom-Json
$created=$null
$result=@{ok=$false; error='Repair did not complete'}
try {
 $nic=Get-NetAdapter -InterfaceIndex $plan.index -ErrorAction Stop
 if (!$nic.HardwareInterface -or $nic.Status -ne 'Up' -or ([guid]$nic.InterfaceGuid -ne [guid]$plan.guid)) {throw 'Adapter changed; discover again'}
 $addresses=@(Get-NetIPAddress -InterfaceIndex $plan.index -AddressFamily IPv4 -ErrorAction Stop)
 if (!($addresses | Where-Object {$_.IPAddress -eq $plan.source -and $_.PrefixLength -eq $plan.prefix})) {throw 'Adapter address changed; discover again'}
 $existing=@(Get-NetRoute -AddressFamily IPv4 -PolicyStore ActiveStore | Where-Object DestinationPrefix -eq $plan.destination)
 if ($existing.Count) {throw 'An exact host route already exists; no existing route was changed'}
 Add-Type -TypeDefinition @'
using System;
using System.Net;
using System.Runtime.InteropServices;
public static class RpRouteCheck {
 [DllImport("iphlpapi.dll")] static extern uint SendARP(uint destination, uint source, byte[] mac, ref uint length);
 [DllImport("iphlpapi.dll")] static extern uint GetBestInterface(uint destination, out uint index);
 public static string Mac(string address) {
  byte[] mac=new byte[8]; uint length=6;
  uint result=SendARP(BitConverter.ToUInt32(IPAddress.Parse(address).GetAddressBytes(),0),0,mac,ref length);
  return result==0 && length==6 ? BitConverter.ToString(mac,0,6).Replace("-","").ToLowerInvariant() : "";
 }
 public static uint Route(string address) {
  uint index; return GetBestInterface(BitConverter.ToUInt32(IPAddress.Parse(address).GetAddressBytes(),0),out index)==0 ? index : 0;
 }
}
'@
 $created=New-NetRoute -DestinationPrefix $plan.destination -InterfaceIndex $plan.index -NextHop '0.0.0.0' -RouteMetric $plan.metric -PolicyStore ActiveStore -ErrorAction Stop
 if ([RpRouteCheck]::Route($plan.target) -ne $plan.index) {throw 'The selected adapter is not the active route'}
 $mac=[RpRouteCheck]::Mac($plan.target)
 if ($mac.Length -ne 12 -or !$mac.EndsWith($plan.identity)) {throw 'RP MAC identity did not match'}
 $client=[Net.Sockets.TcpClient]::new()
 try {
  $pending=$client.BeginConnect($plan.target,22,$null,$null)
  if (!$pending.AsyncWaitHandle.WaitOne(2000)) {throw 'SSH connection timed out'}
  $client.EndConnect($pending)
 } finally {$client.Dispose()}
 $result=@{ok=$true; address=$plan.target; interface=$plan.interface; mac=$mac; temporary=$true}
} catch {
 $result=@{ok=$false; error=$_.Exception.Message}
} finally {
 if (!$result.ok -and $null -ne $created) {
  try {$created | Remove-NetRoute -Confirm:$false -ErrorAction Stop; $result.rolled_back=$true}
  catch {$result.rollback_error=$_.Exception.Message}
 }
 $result | ConvertTo-Json -Compress | Set-Content -LiteralPath '__RESULT__' -Encoding UTF8
}
'''


def repair_script(preview, result_path):
    encoded = base64.b64encode(json.dumps(preview).encode('utf-8')).decode('ascii')
    return _SCRIPT.replace('__PLAN__', encoded).replace('__RESULT__', str(result_path).replace("'", "''"))


def apply(preview, state_dir):
    # Recheck the snapshot before requesting elevation. The elevated helper checks again.
    current = next((r for r in local_interfaces() if r['index'] == preview['index']
                    and r.get('physical') and r.get('state') == 'Connected'
                    and r['address'] == preview['source'] and r['prefix'] == preview['prefix']
                    and str(r.get('guid', '')).strip('{}').lower() == preview['guid']), None)
    if not current:
        raise RuntimeError('网卡状态已变化，请重新发现并预览；未修改网络')
    Path(state_dir).mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='route-', dir=state_dir) as directory:
        result_path = Path(directory) / 'result.json'
        script_path = Path(directory) / 'repair.ps1'
        script_path.write_text(repair_script(preview, result_path), encoding='utf-8-sig')
        # Use -EncodedCommand only for this fixed launcher; no shell user-text interpolation.
        script = str(script_path).replace("'", "''")
        launcher = "$ErrorActionPreference='Stop'; $p=Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -Wait -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','\"" + script + "\"'); exit $p.ExitCode"
        encoded = base64.b64encode(launcher.encode('utf-16-le')).decode('ascii')
        try:
            subprocess.run(['powershell.exe', '-NoProfile', '-EncodedCommand', encoded],
                           capture_output=True, timeout=180,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError('管理员修复等待超时，状态尚未确认；请关闭仍待确认的提示并重新查找 RP，勿重复执行旧预览') from exc
        if not result_path.exists():
            raise RuntimeError('网络修复未执行或管理员确认被取消；请重新发现核对当前状态')
        result = json.loads(result_path.read_text(encoding='utf-8-sig'))
        if not result.get('ok'):
            raise RuntimeError('路径修复失败：' + result.get('error', '') +
                               ('；已撤销本次路由' if result.get('rolled_back') else '') +
                               ('；回滚失败，请检查路由：' + result['rollback_error'] if result.get('rollback_error') else ''))
        return result
