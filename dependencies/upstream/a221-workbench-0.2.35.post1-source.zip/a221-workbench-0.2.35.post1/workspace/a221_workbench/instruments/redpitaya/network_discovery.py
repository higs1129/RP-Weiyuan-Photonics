"""Read-only, interface-aware IPv4 discovery; an advertisement is not identity proof."""
from concurrent.futures import ThreadPoolExecutor
import ctypes
import ipaddress
import secrets
import socket
import struct
import time

from .network import (_active_mac, _neighbors, _local_scan_addresses, _probe,
                      identity_matches, rp_identity)
from .network_diagnostics import local_interfaces


def usable_address(value):
    try:
        address = ipaddress.IPv4Address(value)
        return not (address.is_unspecified or address.is_loopback or address.is_multicast
                    or int(address) >= 0xf0000000 or str(address) == '255.255.255.255')
    except (ValueError, TypeError):
        return False


def _dns_name(packet, offset):
    labels, visited, end = [], set(), None
    while True:
        if offset in visited or offset >= len(packet) or len(visited) > 128:
            raise ValueError('Invalid DNS name')
        visited.add(offset)
        size = packet[offset]
        if size & 0xc0 == 0xc0:
            if offset + 1 >= len(packet):
                raise ValueError('Truncated DNS pointer')
            end = end if end is not None else offset + 2
            offset = ((size & 0x3f) << 8) | packet[offset + 1]
            continue
        if size & 0xc0 or offset + 1 + size > len(packet):
            raise ValueError('Invalid DNS label')
        offset += 1
        if not size:
            return '.'.join(labels).lower(), end if end is not None else offset
        labels.append(packet[offset:offset + size].decode('ascii'))
        offset += size


def _answers(packet, name, query_id):
    """Accept only live IN/A answers for the exact queried name and transaction."""
    found = set()
    try:
        ident, flags, questions, answers, authority, additional = struct.unpack_from('!6H', packet)
        if ident != query_id or not flags & 0x8000 or flags & 0x020f:
            return found
        if questions + answers + authority + additional > 256:
            return found
        offset = 12
        for _ in range(questions):
            _, offset = _dns_name(packet, offset)
            offset += 4
        for _ in range(answers + authority + additional):
            owner, offset = _dns_name(packet, offset)
            kind, cls, ttl, length = struct.unpack_from('!HHIH', packet, offset)
            offset += 10
            if offset + length > len(packet):
                raise ValueError('Truncated DNS record')
            if owner == name.lower() and kind == 1 and cls & 0x7fff == 1 and ttl and length == 4:
                address = socket.inet_ntoa(packet[offset:offset + 4])
                if usable_address(address):
                    found.add(address)
            offset += length
    except (ValueError, UnicodeError, struct.error):
        return set()
    return found


def _mdns(host, interface):
    # RFC 6762 legacy unicast response: ephemeral source port, echoed transaction ID.
    # Bind both the local address and outgoing multicast interface (VPN-safe).
    name = 'rp-' + rp_identity(host)[-6:] + '.local'
    ident = secrets.randbelow(65535) + 1
    question = b''.join(bytes([len(label)]) + label.encode('ascii') for label in name.split('.')) + b'\0'
    packet = struct.pack('!6H', ident, 0, 1, 0, 0, 0) + question + struct.pack('!HH', 1, 1)
    found = set()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as channel:
            channel.bind((interface['address'], 0))
            channel.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(interface['address']))
            channel.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
            # Retry once, within a fixed receive window, without occupying port 5353.
            for _ in range(2):
                channel.sendto(packet, ('224.0.0.251', 5353))
                deadline = time.monotonic() + .8
                while time.monotonic() < deadline:
                    channel.settimeout(max(.001, deadline - time.monotonic()))
                    try:
                        data, peer = channel.recvfrom(9000)
                    except socket.timeout:
                        break
                    if peer[1] == 5353:
                        found.update(_answers(data, name, ident))
        return {'addresses': sorted(found)[:16], 'interface': interface['index']}
    except OSError as exc:
        return {'addresses': [], 'interface': interface['index'], 'error': str(exc)}


def route_index(address):
    index = ctypes.c_ulong()
    result = ctypes.windll.iphlpapi.GetBestInterface(
        ctypes.c_ulong(int.from_bytes(socket.inet_aton(address), 'little')), ctypes.byref(index))
    return int(index.value) if result == 0 else None


def _tcp(address, source=None):
    try:
        with socket.socket() as channel:
            channel.settimeout(.6)
            if source:
                channel.bind((source, 0))
            channel.connect((address, 22))
        return True
    except OSError:
        return False


def _check(host, candidate, interface):
    target, source = candidate['address'], interface['address']
    same = ipaddress.ip_address(target) in ipaddress.ip_network(f"{source}/{interface['prefix']}", strict=False)
    check = {'target': target, 'source': source, 'interface': interface['name'],
             'index': interface['index'], 'same_subnet': same, 'mac_matches': False,
             'ssh_reachable': False, 'ready': False}
    try:
        check['route_index'] = route_index(target)
        # Do not ARP through a gateway for an off-subnet advertised address.
        if same or check['route_index'] == interface['index']:
            mac = _active_mac(target, source)
            check.update(mac=mac, mac_matches=identity_matches(host, mac))
            if check['mac_matches']:
                check['ssh_reachable'] = _tcp(target, source)
                check['ready'] = bool(check['route_index'] == interface['index']
                                      and check['ssh_reachable']
                                      and identity_matches(host, _active_mac(target))
                                      and _tcp(target))
    except OSError as exc:
        check['error'] = str(exc)
    check['reason'] = ('身份与通信已核验' if check['ready'] else
                       '网段不匹配' if not same else
                       '系统路由指向其他网卡' if check.get('route_index') != interface['index'] else
                       '尚未核验到匹配的 MAC' if not check['mac_matches'] else 'SSH 服务不可达')
    return check


def _serial_inventory():
    from serial.tools import list_ports
    return [{'port': p.device, 'description': p.description,
             'vid': p.vid, 'pid': p.pid, 'console_candidate': p.vid == 0x0403 and p.pid == 0x6015}
            for p in list_ports.comports()]


def discover(host, *, addresses=None, scan=True, use_console=False, console_port=None, board=None):
    if not rp_identity(host):
        raise ValueError('设备发现需要 RP 标签名称，例如 RP-f0fb33；IP 可直接用于连接')
    report = {'host': host, 'read_only': True, 'board': board, 'interfaces': [],
              'checks': [], 'candidates': [], 'ready_addresses': [], 'advice': [], 'errors': []}
    candidates = {}

    def add(address, origin, index=None, mac=None):
        if not usable_address(address) or (address not in candidates and len(candidates) >= 16):
            return
        item = candidates.setdefault(address, {'address': address, 'sources': [], 'interfaces': []})
        if origin not in item['sources']:
            item['sources'].append(origin)
        if index is not None and index not in item['interfaces']:
            item['interfaces'].append(index)
        if mac and identity_matches(host, mac):
            item['reported_mac'] = mac

    try:
        report['interfaces'] = [row for row in local_interfaces() if usable_address(row['address'])]
    except Exception as exc:
        report['errors'].append('读取网卡失败：' + str(exc))
    active = [row for row in report['interfaces'] if row.get('physical') and row.get('state') == 'Connected'][:8]
    if addresses is None:
        try:
            name = 'rp-' + rp_identity(host)[-6:] + '.local'
            addresses = {item[4][0] for item in socket.getaddrinfo(name, None, socket.AF_INET, socket.SOCK_STREAM)}
        except OSError:
            addresses = ()
    for address in addresses:
        add(address, '系统名称解析')
    if active:
        with ThreadPoolExecutor(max_workers=8) as pool:
            report['mdns'] = list(pool.map(lambda row: _mdns(host, row), active))
        for result in report['mdns']:
            for address in result['addresses']:
                add(address, 'mDNS', result['interface'])
            if result.get('error'):
                report['errors'].append(f"网卡 {result['interface']} mDNS：{result['error']}")

    def neighbors():
        try:
            for row in _neighbors():
                if identity_matches(host, row.get('LinkLayerAddress', '')):
                    add(row['IPAddress'], '邻居表（需重新验证）', row.get('InterfaceIndex'), row['LinkLayerAddress'])
        except Exception as exc:
            report['errors'].append('邻居表：' + str(exc))

    neighbors()
    if not candidates and scan and active:
        try:
            # Bounded fallback: own /24 only, including IPv4LL; never sweep an entire /16.
            with ThreadPoolExecutor(max_workers=32) as pool:
                list(pool.map(_probe, _local_scan_addresses()[:1024]))
            neighbors()
        except Exception as exc:
            report['errors'].append('有限地址探测：' + str(exc))

    def check_paths():
        pairs = [(item, row) for item in candidates.values() for row in active
                 if ('CON' in item['sources'] or not item['interfaces'] or row['index'] in item['interfaces'])][:32]
        with ThreadPoolExecutor(max_workers=8) as pool:
            report['checks'] = list(pool.map(lambda pair: _check(host, *pair), pairs))
        report['ready_addresses'] = sorted({c['target'] for c in report['checks'] if c['ready']})

    if board and identity_matches(host, board.get('mac', '')):
        for address in board.get('addresses', []):
            add(address, 'CON', mac=board['mac'])
    check_paths()
    if use_console and not report['ready_addresses'] and not board:
        try:
            from .network_recovery import Console, SNAPSHOT
            report['console_ports'] = _serial_inventory()
            with Console(host, console_port) as console:
                board = console.run(SNAPSHOT)
                if not identity_matches(host, board.get('mac', '')):
                    raise RuntimeError('CON 中的设备 MAC 与目标 RP 不匹配')
                report['board'] = board
                report['console_port'] = console.port
                for address in board.get('addresses', []):
                    add(address, 'CON', mac=board['mac'])
            check_paths()
        except Exception as exc:
            report['console_error'] = str(exc)
    report['candidates'] = list(candidates.values())
    for row in report['interfaces']:
        subnet = ipaddress.ip_network(f"{row['address']}/{row['prefix']}", strict=False)
        row['rp_same_subnet'] = any(ipaddress.ip_address(ip) in subnet for ip in candidates)
    ready = report['ready_addresses']
    report['status'] = 'ready' if len(ready) == 1 else 'ambiguous' if ready else 'found_unreachable' if candidates else 'not_found'
    report['summary'] = {'ready': '已找到 RP，身份与当前通信路径已核验',
                         'ambiguous': '发现多个通过验证的地址，请明确填写目标 IP，未自动选择',
                         'found_unreachable': '发现 RP 地址线索，但当前网络路径未通过身份与通信验证',
                         'not_found': '尚未发现目标 RP；这不代表设备未供电或没有 IP'}[report['status']]
    if not ready:
        report['advice'].append('确认 RP 与所选物理网卡位于同一局域网；普通交换机不提供 DHCP，隔离端口也可能阻止发现。')
        if any(ipaddress.ip_address(row['address']).is_link_local and int(row['prefix']) != 16 for row in active):
            report['advice'].append('有线自动地址存在非 /16 掩码，可能无法访问其他 169.254 地址；可先预览到这台 RP 的临时路径修复。')
        report['advice'].append('发现地址不等于可以通信。多网卡/VPN 的实际路由、MAC 身份和 SSH 都需验证；未发现时保留 CON 连接重试。')
    report['detail'] = '\n'.join(report['errors'] + ([report['console_error']] if report.get('console_error') else []))
    return report


def main():
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True)
    parser.add_argument('--console-port')
    args = parser.parse_args()
    try:
        result = {'ok': True, 'diagnostics': discover(args.host, use_console=True, console_port=args.console_port)}
    except Exception as exc:
        result = {'ok': False, 'error': str(exc)}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
