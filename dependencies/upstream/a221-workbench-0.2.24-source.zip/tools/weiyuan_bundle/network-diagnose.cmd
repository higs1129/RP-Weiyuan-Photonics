@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0network_diagnose.ps1" %*
pause
