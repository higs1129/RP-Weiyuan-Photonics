"""Install one pinned console environment, preserving configuration and rollback."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, data):
    temporary = path.with_suffix('.new')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temporary, path)


@contextmanager
def exclusive(path):
    import msvcrt
    with path.open('a+b') as handle:
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            raise RuntimeError('Another console/installer is running. Close it before continuing.') from exc
        try:
            yield
        finally:
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


def verify(bundle, manifest):
    for item in manifest['files']:
        path = (bundle / item['path']).resolve()
        if not path.is_relative_to(bundle) or not path.is_file():
            raise RuntimeError('Missing package file: ' + item['path'])
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            raise RuntimeError('Package checksum failed: ' + item['path'])


def env_python(env, home):
    path = Path(env).resolve()
    if not path.is_relative_to(home / 'envs'):
        raise RuntimeError('Environment pointer is outside the application directory')
    return path / 'Scripts/python.exe'


def checked(command, log):
    command = [str(x) for x in command]
    if command[0].lower().endswith('python.exe') and '-X' not in command:
        command[1:1] = ['-X', 'utf8']
    with log.open('a', encoding='utf-8') as output:
        output.write('Running: ' + json.dumps(command, ensure_ascii=False) + '\n'); output.flush()
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise RuntimeError('Operation failed (exit ' + str(result.returncode) + '); see ' + str(log))


def probe(python, bundle, log, manifest_path=None):
    checked([python, '-I', '-X', 'utf8', bundle / 'install/probe.py', manifest_path or bundle / 'manifest.json'], log)
    checked([python, '-I', '-m', 'pip', 'check'], log)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--home', type=Path, required=True)
    parser.add_argument('--mode', choices=['setup','launch','diagnose','repair','rollback'], required=True)
    args = parser.parse_args()
    bundle, home = args.bundle.resolve(), args.home.resolve()
    home.mkdir(parents=True, exist_ok=True)
    (home / 'logs').mkdir(exist_ok=True)
    log = home / 'logs' / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + args.mode + '.log')
    manifest = read(bundle / 'manifest.json')
    verify(bundle, manifest)
    config = read(bundle / 'config.json')
    installed = {}
    for name in ('pyrpl', 'PyQt5', 'numpy', 'a221-workbench'):
        try:
            installed[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            installed[name] = None
    inventory = {'python': sys.executable, 'detected_packages': installed}
    log.write_text(json.dumps(inventory, ensure_ascii=False) + '\n', encoding='utf-8')
    print('Existing PyRPL: ' + str(installed['pyrpl'] or 'not installed') + '; application dependencies use an isolated environment.', flush=True)
    # The same validation code ships in the application and in the bootstrap.
    sys.path.insert(0, str(bundle / 'install'))
    from configuration import configured_host, spectrum_correction, input_ranges
    configured_host(config)
    spectrum_correction(config)
    input_ranges(config)
    stamp = hashlib.sha256((bundle / 'manifest.json').read_bytes()).hexdigest()
    current_file, previous_file = home / 'current.json', home / 'previous.json'
    os.environ['PYTHONNOUSERSITE'] = '1'
    os.environ.pop('PYTHONPATH', None)
    os.environ.pop('PYTHONHOME', None)
    os.environ['A221_CONFIG_HOME'] = str(home / 'config')
    os.environ['DAILY_NOTE_DATA_ROOT'] = str(home / 'data')
    os.environ['PYRPL_USER_DIR'] = str(home / 'pyrpl')
    with exclusive(home / 'application.lock'):
        current = read(current_file) if current_file.exists() else None
        if args.mode == 'diagnose':
            if not current:
                raise RuntimeError('No installed environment. Run setup.cmd.')
            python = env_python(current['env'], home)
            probe(python, bundle, log, Path(current['env']) / 'bundle-manifest.json')
            checked([python, '-I', '-m', 'serial.tools.list_ports', '-v'], log)
            print('Environment and Qt OK. RP / laser were not contacted.\nReport: ' + str(log))
            return
        if args.mode == 'rollback':
            if not previous_file.exists():
                raise RuntimeError('No previous validated environment is available.')
            previous = read(previous_file)
            python = env_python(previous['env'], home)
            probe(python, bundle, log, Path(previous['env']) / 'bundle-manifest.json')
            save(current_file, {**previous, 'rollback': True})
            if current:
                save(previous_file, current)
            print('Previous environment restored. config.json was preserved.')
            return
        # Launch honors a deliberate rollback; setup upgrades to this bundle.
        needs_install = not current or args.mode == 'repair' or (
            current.get('bundle') != stamp and (args.mode == 'setup' or not current.get('rollback')))
        if needs_install:
            target = home / 'envs' / (manifest['version'] + '-' + uuid.uuid4().hex[:8])
            target.parent.mkdir(exist_ok=True)
            print('Creating isolated environment: ' + str(target), flush=True)
            checked([sys.executable, '-I', '-m', 'venv', target], log)
            python = env_python(target, home)
            checked([python, '-I', '-m', 'pip', 'install', '--disable-pip-version-check', '--no-index',
                     '--find-links', bundle / 'wheels', '-r', bundle / 'requirements.lock'], log)
            probe(python, bundle, log)
            save(target / 'bundle-manifest.json', manifest)
            replacement = {'env': str(target), 'version': manifest['version'], 'bundle': stamp}
            if current:
                save(previous_file, current)
            save(current_file, replacement)
            current = replacement
        python = env_python(current['env'], home)
        if args.mode != 'launch':
            if not needs_install:
                probe(python, bundle, log, Path(current['env']) / 'bundle-manifest.json')
            print('Setup complete. Edit config.json, then run launch.cmd.\nLog: ' + str(log))
            return
        probe(python, bundle, log, Path(current['env']) / 'bundle-manifest.json')
        os.environ['A221_RUNTIME_PYTHON'] = str(python)
        # A portable config never uses the originating computer's PyRPL path.
        if config.get('pyrpl_python'):
            raise ValueError('For this bundle set pyrpl_python to null; the validated environment is automatic.')
        print('Starting console ' + current['version'] + '. Hardware connection remains explicit.', flush=True)
        code = subprocess.call([str(python), '-X', 'utf8', '-m',
                                'a221_workbench.workflows.weiyuan_console.server', '--real',
                                '--config', str(bundle / 'config.json'), '--open-browser'], cwd=home)
        if code:
            raise RuntimeError('Console exited with code ' + str(code))


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(1)
