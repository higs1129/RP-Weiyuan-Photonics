@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pair_existing_uart.ps1" %*
pause
