"""Offline environment validation. Never creates a PyRPL or instrument instance."""
import importlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import struct
import sys
import faulthandler

faulthandler.enable()
faulthandler.dump_traceback_later(60, exit=True)

os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['QT_LOGGING_TO_CONSOLE'] = '1'
from a221_workbench.instruments.redpitaya.qt_runtime import prepare_qt_plugins
prepare_qt_plugins()
assert sys.version_info[:2] == (3, 10) and struct.calcsize('P') == 8, 'Python 3.10 x64 required'
manifest = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
versions = {}
for name, expected in manifest['packages'].items():
    actual = metadata.version(name)
    assert actual == expected, f'{name}: expected {expected}, got {actual}'
    versions[name] = actual
for name in ('numpy', 'scipy', 'matplotlib', 'paramiko', 'serial', 'psutil', 'pyvisa',
             'pyrpl', 'qasync', 'pyqtgraph', 'a221_workbench.workflows.weiyuan_console.server',
             'a221_workbench.instruments.redpitaya.pyrpl_backend'):
    print('Importing ' + name, flush=True)
    importlib.import_module(name)
from qtpy.QtWidgets import QApplication, QWidget
app = QApplication.instance() or QApplication([])
print('Rendering Qt widget', flush=True)
widget = QWidget()
widget.resize(100, 50)
assert not widget.grab().isNull(), 'Qt rendering failed'
widget.close()
from a221_workbench.workflows.weiyuan_console.server import STATIC
assert (STATIC / 'brand/iop-apc.png').is_file()
import a221_workbench.instruments.redpitaya as rp
assert Path(rp.__file__).with_name('console_startup.yml').is_file()
print(json.dumps({'ok': True, 'python': sys.version.split()[0], 'packages': versions}))
faulthandler.cancel_dump_traceback_later()
