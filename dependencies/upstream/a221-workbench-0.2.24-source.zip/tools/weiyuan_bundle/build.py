"""Build an offline Windows bundle from pre-fetched, version-pinned assets."""
from concurrent.futures import ThreadPoolExecutor
from email.parser import BytesParser
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from urllib.request import build_opener, ProxyHandler
import zipfile

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
CACHE = WORKSPACE / 'dist/weiyuan-cache'
VERSION = '0.2.24'
DEST = WORKSPACE / 'dist' / ('A221-Weiyuan-' + VERSION + '-win64')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, relative):
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def wheel_info(path):
    with zipfile.ZipFile(path) as wheel:
        meta = BytesParser().parsebytes(wheel.read(next(n for n in wheel.namelist() if n.endswith('.dist-info/METADATA'))))
        name, version = meta['Name'], meta['Version']
    url = None
    if name not in ('a221-workbench', 'pyrpl'):
        metadata_path = CACHE / 'metadata' / (name + '-' + version + '.json')
        if not metadata_path.exists():
            with build_opener(ProxyHandler({})).open(f'https://pypi.org/pypi/{name}/{version}/json', timeout=30) as response:
                release = json.load(response)
            metadata_path.parent.mkdir(exist_ok=True)
            metadata_path.write_text(json.dumps(release), encoding='utf-8')
        release = json.loads(metadata_path.read_text(encoding='utf-8'))
        entry = next(item for item in release['urls'] if item['filename'] == path.name)
        assert sha(path) == entry['digests']['sha256'], 'PyPI hash mismatch: ' + path.name
        url = entry['url']
    return path, name, version, url


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    # Build in a fresh directory: no stale egg-info, caches or machine config.
    import tempfile
    with tempfile.TemporaryDirectory(prefix='a221-build-') as staging:
        source = Path(staging)
        shutil.copy2(WORKSPACE / 'pyproject.toml', source / 'pyproject.toml')
        shutil.copytree(WORKSPACE / 'a221_workbench', source / 'a221_workbench',
                        ignore=shutil.ignore_patterns('__pycache__','*.pyc','.runtime'))
        subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-deps', '--wheel-dir',
                        str(source / 'wheel'), str(source)], check=True)
        wheel = next((source / 'wheel').glob('a221_workbench-*.whl'))
        copy(wheel, 'wheels/' + wheel.name)
        with zipfile.ZipFile(DEST / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for file in sorted((source / 'a221_workbench').rglob('*')):
                if file.is_file():
                    archive.write(file, str(file.relative_to(source)))
            archive.write(source / 'pyproject.toml', 'pyproject.toml')
            for file in HERE.iterdir():
                if file.is_file():
                    archive.write(file, 'tools/weiyuan_bundle/' + file.name)
    urls = {}
    packages = {'a221-workbench': VERSION}
    pins = dict(line.strip().split('==') for line in (CACHE / 'runtime-pins.txt').read_text().splitlines() if line.strip())
    pins['pyrpl'] = '0.9.8.0'
    wheels = list(CACHE.glob('wheels/*.whl'))
    with ThreadPoolExecutor(max_workers=6) as pool:
        for path, name, version, url in pool.map(wheel_info, wheels):
            if name == 'a221-workbench':
                continue
            assert pins.get(name) == version, (name, version)
            copy(path, 'wheels/' + path.name)
            packages[name] = version
            urls['wheels/' + path.name] = url
    assert set(pins) <= set(packages), 'Missing pinned wheels'
    copy(CACHE / 'python-3.10.11-amd64.exe', 'runtime/python-3.10.11-amd64.exe')
    urls['runtime/python-3.10.11-amd64.exe'] = 'https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe'
    copy(CACHE / 'pyrpl-source.zip', 'upstream/pyrpl-source.zip')
    urls['upstream/pyrpl-source.zip'] = 'https://github.com/pyrpl-fpga/pyrpl/archive/81beee5cf5e3651e66b5dec5103a355fca07fa30.zip'
    for file in (CACHE / 'ftdi').rglob('*'):
        if file.is_file():
            copy(file, Path('drivers') / file.relative_to(CACHE / 'ftdi'))
    for name in ('bootstrap.ps1', 'installer.py', 'probe.py'):
        copy(HERE / name, 'install/' + name)
    # PowerShell 5.1 needs a BOM for non-ASCII paths/messages in future edits.
    ps = DEST / 'install/bootstrap.ps1'
    ps.write_text(ps.read_text(encoding='utf-8-sig'), encoding='utf-8-sig')
    copy(WORKSPACE / 'a221_workbench/workflows/weiyuan_console/configuration.py', 'install/configuration.py')
    if not (DEST / 'config.json').exists():
        copy(HERE / 'config.example.json', 'config.json')
    copy(HERE / 'config.example.json', 'config.example.json')
    copy(WORKSPACE.parent / 'docs/weiyuan-package.md', 'README.md')
    copy(WORKSPACE.parent / 'docs/console-branding.md', 'docs/branding.md')
    copy(WORKSPACE.parent / 'docs/weiyuan-package-validation.md', 'docs/validation.md')
    for mode in ('launch', 'setup', 'diagnose', 'repair', 'rollback', 'driver'):
        name = 'install-con-driver' if mode == 'driver' else mode
        (DEST / (name + '.cmd')).write_text('@echo off\r\nsetlocal\r\n'
            'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install\\bootstrap.ps1" -Mode ' + mode + '\r\n'
            'set "result=%errorlevel%"\r\nif not "%result%"=="0" pause\r\nexit /b %result%\r\n', encoding='ascii')
    (DEST / 'requirements.lock').write_text('\n'.join(f'{name}=={version}' for name, version in sorted(packages.items())) + '\n')
    # Keep upstream license notices available without installing the wheels.
    for path in (DEST / 'wheels').glob('*.whl'):
        with zipfile.ZipFile(path) as wheel:
            for name in wheel.namelist():
                if not name.endswith('/') and any(token in Path(name).name.lower() for token in ('license','copying','notice')):
                    target = DEST / 'licenses' / path.stem / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(wheel.read(name))
    (DEST / 'PROVENANCE.json').write_text(json.dumps({
        'application': VERSION, 'python': '3.10.11 (Python Software Foundation signed installer)',
        'pyrpl_commit': '81beee5cf5e3651e66b5dec5103a355fca07fa30',
        'pyrpl_source_sha256': sha(CACHE / 'pyrpl-source.zip'),
        'drivers': 'FTDI 2.12.36.20; original signed ftdibus and ftdiport packages exported from Windows driver store, no device settings',
        'driver_reference': 'https://ftdichip.com/drivers/vcp-drivers/',
        'packages': packages}, ensure_ascii=False, indent=2), encoding='utf-8')
    files = []
    for file in sorted(DEST.rglob('*')):
        relative = file.relative_to(DEST).as_posix()
        if file.is_file() and relative not in ('config.json','manifest.json') and '__pycache__' not in file.parts:
            files.append({'path': relative, 'sha256': sha(file), 'url': urls.get(relative)})
    (DEST / 'manifest.json').write_text(json.dumps({'version': VERSION, 'packages': packages, 'files': files}, indent=2), encoding='utf-8')
    archive_path = Path(str(DEST) + '.zip')
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(DEST.rglob('*')):
            if file.is_file() and '__pycache__' not in file.parts:
                archive.write(file, str(Path(DEST.name) / file.relative_to(DEST)))
    archive_path.with_suffix('.zip.sha256').write_text(sha(archive_path) + '  ' + archive_path.name + '\n')
    print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path)}))


if __name__ == '__main__':
    main()
