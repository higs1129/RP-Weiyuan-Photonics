"""Process, JSON, and local-runtime helpers shared by measurement frontends."""

from __future__ import annotations


import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any
from a221_workbench.instruments.toptica.runtime import expand_optional_path, python_has_module


def parse_last_json_object(stdout: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    for index, char in reversed(list(enumerate(stdout))):
        if char != "{":
            continue
        try:
            payload, end = decoder.raw_decode(stdout[index:].lstrip())
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict) and not stdout[index:].lstrip()[end:].strip():
            return payload
    return None


def terminate_process_tree(process: subprocess.Popen[Any], *, timeout_s: float = 8.0) -> dict[str, Any]:
    if process.poll() is not None:
        return {"ok": True, "pid": process.pid, "already_stopped": True}
    try:
        if sys.platform.startswith("win"):
            completed = subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                text=True,
                capture_output=True,
                timeout=timeout_s,
                check=False,
            )
            return {
                "ok": completed.returncode == 0 or process.poll() is not None,
                "pid": process.pid,
                "returncode": completed.returncode,
                "stdout_tail": completed.stdout[-1000:],
                "stderr_tail": completed.stderr[-1000:],
            }
        process.terminate()
        try:
            process.wait(timeout=min(timeout_s, 3.0))
        except subprocess.TimeoutExpired:
            process.kill()
        return {"ok": process.poll() is not None, "pid": process.pid}
    except Exception as exc:
        return {"ok": False, "pid": process.pid, "error": repr(exc)}


def write_json_atomic(
    path: Path,
    payload: Any,
    *,
    retries: int = 25,
    delay_s: float = 0.025,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    last_error: OSError | None = None
    for attempt in range(max(1, retries)):
        temp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                newline="\n",
                prefix=f".{path.name}.",
                suffix=".tmp",
                dir=path.parent,
                delete=False,
            ) as handle:
                handle.write(text)
                temp_path = Path(handle.name)
            os.replace(temp_path, path)
            return
        except OSError as exc:
            last_error = exc
            if temp_path is not None:
                try:
                    temp_path.unlink(missing_ok=True)
                except OSError:
                    pass
            if attempt + 1 < max(1, retries):
                time.sleep(delay_s)
    if last_error is not None:
        raise last_error


def read_json_retry(path: Path, *, retries: int = 5, delay_s: float = 0.02) -> Any:
    last_error: Exception | None = None
    for attempt in range(max(1, retries)):
        try:
            return json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt + 1 < max(1, retries):
                time.sleep(delay_s)
    if last_error is not None:
        raise last_error
    raise RuntimeError(f"Could not read JSON: {path}")
