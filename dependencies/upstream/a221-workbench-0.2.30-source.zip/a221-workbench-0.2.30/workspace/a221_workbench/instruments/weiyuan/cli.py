"""Compatibility entry point; implementation lives in instruments.weiyuan."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.weiyuan'

from a221_workbench._shared.paths import module_file, project_root

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from a221_workbench.instruments.weiyuan import *  # preserve existing driver imports


def read_status(port: str, *, slave: int = 1) -> dict[str, Any]:
    with WeiyuanLaser(port=port, slave=slave) as laser:
        return laser.read_status()


def write_temperature(port: str, value_c: float, *, slave: int = 1) -> dict[str, Any]:
    with WeiyuanLaser(port=port, slave=slave) as laser:
        laser.set_temperature_c(value_c)
        return laser.read_status()


def write_current(port: str, value_ma: float, *, slave: int = 1) -> dict[str, Any]:
    with WeiyuanLaser(port=port, slave=slave) as laser:
        laser.set_current_ma(value_ma)
        return laser.read_status()


def write_initial_current(port: str, *, value_ma: float = 260.0, slave: int = 1) -> dict[str, Any]:
    return write_current(port, value_ma, slave=slave)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["status", "set-temp", "set-current", "set-initial-current", "tec-on", "tec-off", "ld-on", "ld-off"])
    parser.add_argument("--port", default="COM5")
    parser.add_argument("--slave", type=int, default=1)
    parser.add_argument("--value", type=float)
    args = parser.parse_args()

    with WeiyuanLaser(port=args.port, slave=args.slave) as laser:
        if args.action == "status":
            result = laser.read_status()
        elif args.action == "set-temp":
            if args.value is None:
                raise SystemExit("--value is required")
            laser.set_temperature_c(args.value)
            result = laser.read_status()
        elif args.action == "set-current":
            if args.value is None:
                raise SystemExit("--value is required")
            laser.set_current_ma(args.value)
            result = laser.read_status()
        elif args.action == "set-initial-current":
            laser.set_current_ma(260.0 if args.value is None else args.value)
            result = laser.read_status()
        elif args.action == "tec-on":
            laser.set_tec_enabled(True)
            result = laser.read_status()
        elif args.action == "tec-off":
            laser.set_tec_enabled(False)
            result = laser.read_status()
        elif args.action == "ld-on":
            laser.set_ld_enabled(True)
            result = laser.read_status()
        elif args.action == "ld-off":
            laser.set_ld_enabled(False)
            result = laser.read_status()
        else:
            raise AssertionError(args.action)

    print(json.dumps({"ok": True, "weiyuan": result}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
