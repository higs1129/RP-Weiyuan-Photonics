from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import math
import time
from ..transports import SerialTransport
from .protocol import *

class LaserWriteNotSent(RuntimeError):
    """A prerequisite read failed before the setpoint command was sent."""

@dataclass
class WeiyuanLaser:
    port: str = "COM5"
    slave: int = 1
    baudrate: int = 9600
    timeout_s: float = 0.8
    transport: Any = None

    def __post_init__(self) -> None:
        if not 1 <= self.slave <= 255:
            raise ValueError("slave must be 1..255")
        if self.transport is None:
            self.transport = SerialTransport(self.port, baudrate=self.baudrate, timeout_s=self.timeout_s)

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def open(self):
        self.transport.open()

    def close(self):
        self.transport.close()

    def exchange(self, frame: bytes, expected_min_len: int) -> bytes:
        response = self.transport.exchange(frame, expected_min_len)
        if len(response) != expected_min_len:
            raise IOError("Unexpected reply length")
        validate_crc(response)
        if self.slave != 255 and response[0] != self.slave:
            raise RuntimeError(f"Unexpected slave id {response[0]}, expected {self.slave}")
        return response

    def _read_exchange(self, frame: bytes, expected_length: int) -> bytes:
        # Only read commands reach here. A lost read may be repeated once;
        # an uncertain write echo must never cause an automatic second write.
        try:
            return self.exchange(frame, expected_length)
        except TimeoutError:
            time.sleep(0.05)
            return self.exchange(frame, expected_length)

    def read_data(self, register: int, length: int) -> bytes:
        payload = bytes([self.slave, FUNC_READ_DATA]) + register.to_bytes(2, "big") + length.to_bytes(2, "big")
        response = self._read_exchange(append_crc(payload), 6 + length + 2)
        if response[1] != FUNC_READ_DATA or int.from_bytes(response[2:4], "big") != register:
            raise RuntimeError(f"Unexpected read response: {response.hex(' ')}")
        returned_length = int.from_bytes(response[4:6], "big")
        if returned_length != length:
            raise RuntimeError(f"Unexpected read length {returned_length}, expected {length}: {response.hex(' ')}")
        return response[6 : 6 + length]

    def write_data(self, register: int, data: bytes) -> bytes:
        payload = (
            bytes([self.slave, FUNC_WRITE_DATA])
            + register.to_bytes(2, "big")
            + len(data).to_bytes(2, "big")
            + data
        )
        response = self.exchange(append_crc(payload), expected_min_len=6 + len(data) + 2)
        if response[:-2] != payload:
            raise RuntimeError(f"Unexpected write echo: sent={payload.hex(' ')}, response={response.hex(' ')}")
        return response

    def read_state_value(self, state_register: int) -> int:
        payload = bytes([self.slave, FUNC_READ_STATE]) + state_register.to_bytes(2, "big") + (1).to_bytes(2, "big")
        response = self._read_exchange(append_crc(payload), 8)
        if response[1] != FUNC_READ_STATE:
            raise RuntimeError(f"Unexpected state response: {response.hex(' ')}")
        return int.from_bytes(response[4:6], "big")

    def write_state_value(self, state_register: int, enabled: bool) -> bytes:
        if self.read_mode() != 1:
            raise RuntimeError("Protocol V1.2 allows TEC/LD switching only in debug mode; mode was not changed")
        value = 1 if enabled else 0
        payload = bytes([self.slave, FUNC_WRITE_STATE]) + state_register.to_bytes(2, "big") + value.to_bytes(2, "big")
        response = self.exchange(append_crc(payload), expected_min_len=8)
        if response[:-2] != payload:
            raise RuntimeError(f"Unexpected state write echo: sent={payload.hex(' ')}, response={response.hex(' ')}")
        return response

    def read_float(self, register: int) -> float:
        return payload_to_float(self.read_data(register, 4))

    def write_float(self, register: int, value: float) -> None:
        if not math.isfinite(value):
            raise ValueError("Value must be finite")
        self.write_data(register, float_to_payload(value))

    def read_mode(self) -> int:
        data = self.read_data(REG_MODE, 1)
        return int(data[0])

    def write_mode(self, mode: int) -> None:
        if mode not in {0, 1}:
            raise ValueError("mode must be 0 (run) or 1 (debug)")
        self.write_data(REG_MODE, bytes([mode]))

    def read_status(self) -> dict[str, Any]:
        tec_state_value = self.read_state_value(STATE_TEC)
        ld_state_value = self.read_state_value(STATE_LD)
        mode = self.read_mode()
        tec_set_run = self.read_float(REG_TEC_SET_RUN)
        ld_set_run = self.read_float(REG_LD_SET_RUN)
        tec_set_debug = self.read_float(REG_TEC_SET_DEBUG)
        ld_set_debug = self.read_float(REG_LD_SET_DEBUG)
        return {
            "port": getattr(self.transport, 'port', None),
            "service_url": getattr(self.transport, 'base_url', None),
            "slave": self.slave,
            "mode": mode,
            "mode_label": "debug" if mode == 1 else "run",
            "module_temp_c": self.read_float(REG_MODULE_TEMP),
            "tec_temp_c": self.read_float(REG_TEC_TEMP),
            "ld_current_actual_ma": self.read_float(REG_LD_CURRENT),
            "tec_set_temp_c": tec_set_debug if mode == 1 else tec_set_run,
            "ld_set_current_ma": ld_set_debug if mode == 1 else ld_set_run,
            "tec_set_temp_run_c": tec_set_run,
            "ld_set_current_run_ma": ld_set_run,
            "tec_set_temp_debug_c": tec_set_debug,
            "ld_set_current_debug_ma": ld_set_debug,
            "tec_enabled": bool(tec_state_value & 0x0002),
            "ld_enabled": bool(ld_state_value & 0x0004),
            "raw_state": {
                "tec": tec_state_value,
                "ld": ld_state_value,
            },
        }

    def set_temperature_c(self, value: float, *, debug: bool | None = None) -> None:
        try:
            use_debug = self.read_mode() == 1 if debug is None else debug
        except Exception as exc:
            raise LaserWriteNotSent('读取控制模式失败，未发送温度设置。' + str(exc)) from exc
        self.write_float(REG_TEC_SET_DEBUG if use_debug else REG_TEC_SET_RUN, value)

    def set_current_ma(self, value: float, *, debug: bool | None = None) -> None:
        try:
            use_debug = self.read_mode() == 1 if debug is None else debug
        except Exception as exc:
            raise LaserWriteNotSent('读取控制模式失败，未发送电流设置。' + str(exc)) from exc
        self.write_float(REG_LD_SET_DEBUG if use_debug else REG_LD_SET_RUN, value)

    def set_tec_enabled(self, enabled: bool) -> None:
        self.write_state_value(STATE_TEC, enabled)

    def set_ld_enabled(self, enabled: bool) -> None:
        self.write_state_value(STATE_LD, enabled)
