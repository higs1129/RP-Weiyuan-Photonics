"""Serial adapter for the Weiyuan Photonics laser controller.

The controller uses a small Modbus-like protocol documented in
``稳频通信协议V1.2.pdf``: 9600 8N1, function 0x03/0x10 for data registers,
function 0x01/0x05 for state registers, IEEE754 big-endian floats, and
CRC16 with low byte first.
"""

from __future__ import annotations


import struct
from dataclasses import dataclass
from typing import Any

import math


FUNC_READ_DATA = 0x03
FUNC_WRITE_DATA = 0x10
FUNC_READ_STATE = 0x01
FUNC_WRITE_STATE = 0x05

REG_SN = 0x0018
REG_TEC_SET_RUN = 0x004A
REG_LD_SET_RUN = 0x006A
REG_TEC_SET_DEBUG = 0x0072
REG_LD_SET_DEBUG = 0x0076
REG_MODULE_TEMP = 0x007A
REG_TEC_TEMP = 0x007E
REG_LD_CURRENT = 0x0082
REG_MODE = 0x008E

STATE_TEC = 0x0001
STATE_LD = 0x0002


def crc16_modbus(payload: bytes) -> int:
    crc = 0xFFFF
    for byte in payload:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc & 0xFFFF


def append_crc(payload: bytes) -> bytes:
    crc = crc16_modbus(payload)
    return payload + bytes([crc & 0xFF, (crc >> 8) & 0xFF])


def validate_crc(frame: bytes) -> None:
    if len(frame) < 4:
        raise RuntimeError(f"Response too short: {frame.hex(' ')}")
    expected = crc16_modbus(frame[:-2])
    got = frame[-2] | (frame[-1] << 8)
    if got != expected:
        raise RuntimeError(f"CRC mismatch: got 0x{got:04x}, expected 0x{expected:04x}, frame={frame.hex(' ')}")


def float_to_payload(value: float) -> bytes:
    return struct.pack(">f", float(value))


def payload_to_float(payload: bytes) -> float:
    if len(payload) != 4:
        raise RuntimeError(f"Expected 4-byte float payload, got {len(payload)} bytes")
    return float(struct.unpack(">f", payload)[0])
