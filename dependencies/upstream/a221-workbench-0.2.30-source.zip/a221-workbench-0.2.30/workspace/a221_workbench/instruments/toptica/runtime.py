from __future__ import annotations
import os
import subprocess
from pathlib import Path
from typing import Any

def expand_optional_path(value: Any) -> Path | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    expanded = os.path.expanduser(os.path.expandvars(raw))
    if "%" in expanded:
        return None
    return Path(expanded)

def python_has_module(python_exe: Path, module_name: str, *, timeout_s: float = 5.0) -> bool:
    try:
        completed = subprocess.run(
            [
                str(python_exe),
                "-c",
                f"import importlib.util, sys; sys.exit(0 if importlib.util.find_spec({module_name!r}) else 1)",
            ],
            text=True,
            capture_output=True,
            timeout=timeout_s,
            check=False,
        )
    except Exception:
        return False
    return completed.returncode == 0
