from __future__ import annotations
from .service_client import _run_toptica_tcp_action, worker_args_to_payload, _resolve_toptica_python as resolve_toptica_python
from a221_workbench._shared.paths import module_file, project_root
import json
import math
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen
from .serial_scan import TopticaDlcPro
from .runtime import expand_optional_path as core_expand_optional_path, python_has_module as core_python_has_module

TOPTICA_TCP_WORKER = module_file('a221_workbench.instruments.toptica.tcp_worker')
TOPTICA_TCP_SERVICE_HOST = "127.0.0.1"
TOPTICA_TCP_SERVICE_PORT = 7891


def expand_optional_path(value: str | Path | None) -> Path | None:
    return core_expand_optional_path(value)


def python_has_module(python_exe: Path, module_name: str) -> bool:
    return core_python_has_module(python_exe, module_name)


class TcpTopticaDlcPro:
    MOTOR_CONTROL_SMILE_PARAM = TopticaDlcPro.MOTOR_CONTROL_SMILE_PARAM

    def __init__(self, host: str, *, toptica_python: str | Path | None = None) -> None:
        self.host = str(host).strip()
        if not self.host:
            raise ValueError("TOPTICA TCP connection requires --laser-host")
        self._python = resolve_toptica_python(toptica_python)
        self._service_base = f"http://{TOPTICA_TCP_SERVICE_HOST}:{TOPTICA_TCP_SERVICE_PORT}"

    def _run(self, action: str, extra=None, *, timeout_s: float = 15.0):
        payload = worker_args_to_payload(action, extra)
        result = _run_toptica_tcp_action(self.host, action, payload, extra=extra,
                                         timeout_s=timeout_s, python_exe=self._python)
        result.setdefault("worker_python", str(self._python))
        return result

    def close(self) -> None:
        return None


    def wavelength_nm(self) -> float:
        return float(self._run("read_wavelength")["wavelength_nm"])

    def _read_pc(self) -> dict[str, Any]:
        return self._run("read_pc")

    def pc_voltage_set_v(self) -> float:
        return float(self._read_pc()["voltage_set"])

    def pc_voltage_act_v(self) -> float:
        return float(self._read_pc()["voltage_act"])

    def set_pc_voltage_v(self, voltage_v: float) -> None:
        self._run("set_pc_voltage", ["--pc-voltage-v", f"{float(voltage_v):.9g}"])

    def set_wavelength_nm(self, wavelength_nm: float) -> None:
        self._run("set_wavelength", ["--target-nm", f"{float(wavelength_nm):.9f}"])

    def move_to_wavelength(self, wavelength_nm: float, timeout_s: float, tolerance_nm: float = 0.01) -> None:
        payload = self._run(
            "move_to_wavelength",
            [
                "--target-nm",
                f"{float(wavelength_nm):.9f}",
                "--timeout-s",
                f"{float(timeout_s):.6g}",
                "--tolerance-nm",
                f"{float(tolerance_nm):.6g}",
            ],
            timeout_s=float(timeout_s) + 15.0,
        )
        if not payload.get("ok"):
            raise TimeoutError(
                f"Laser did not reach {wavelength_nm:.3f} nm within {timeout_s:.1f} s; "
                f"last readback was {payload.get('after_read_nm')} nm."
            )

    def configure_wide_scan(self, start_nm: float, stop_nm: float, speed_nm_s: float) -> None:
        self._run(
            "configure_wide_scan",
            [
                "--start-nm",
                f"{float(start_nm):.9f}",
                "--stop-nm",
                f"{float(stop_nm):.9f}",
                "--speed-nm-s",
                f"{float(speed_nm_s):.9f}",
            ],
        )

    def start_wide_scan(self) -> str | None:
        return str(self._run("start_wide_scan", timeout_s=10.0).get("response", "started"))

    def stop_wide_scan(self) -> str | None:
        return str(self._run("stop_wide_scan", timeout_s=10.0).get("response", "stopped"))

    def set_arc_factor_enabled(self, enabled: bool) -> None:
        self._run("set_arc_enabled", ["--enabled" if enabled else "--no-enabled"])

    def set_arc_factor(self, factor_v_per_v: float) -> None:
        self._run("set_arc_factor", ["--factor-v-per-v", f"{float(factor_v_per_v):.9g}"])

    def configure_fine_scan_arc_factor(self, factor_v_per_v: float = 25.0) -> None:
        self._run("configure_fine_scan_arc", ["--factor-v-per-v", f"{float(factor_v_per_v):.9g}"])

    def set_emission_enabled(self, enabled: bool) -> None:
        self._run("set_emission_enabled", ["--enabled" if enabled else "--no-enabled"])

    def cycle_motor_control_smile(self) -> dict[str, Any]:
        return self._run("cycle_smile", ["--readback"])
