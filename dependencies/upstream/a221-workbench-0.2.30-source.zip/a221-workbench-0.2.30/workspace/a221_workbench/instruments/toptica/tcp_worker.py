"""TOPTICA DLC PRO TCP worker and local persistent service.

The measurement runtime has pyvisa/numpy but not the TOPTICA SDK on this bench,
so higher-level scripts call this worker for laser TCP operations while keeping
scope acquisition in the measurement runtime.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.toptica'

#!/usr/bin/env python3


import argparse
import json
import math
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace
from typing import Any
from urllib.parse import urlparse


MOTOR_CONTROL_SMILE_PARAM = "laser1:ctl:mode-control:loop-enabled"
DEFAULT_SERVICE_HOST = "127.0.0.1"
DEFAULT_SERVICE_PORT = 7891
DEFAULT_SMILE_OFF_SETTLE_S = 1.0
DEFAULT_SMILE_ON_SETTLE_S = 1.0


def finite_float(value: float | None, name: str) -> float:
    if value is None or not math.isfinite(float(value)):
        raise ValueError(f"{name} is required")
    return float(value)


def read_pc_payload(dlc: Any, host: str) -> dict[str, Any]:
    pc = dlc.laser1.dl.pc
    payload: dict[str, Any] = {
        "connection": "tcp",
        "host": host,
        "voltage_set": float(pc.voltage_set.get()),
        "voltage_act": float(pc.voltage_act.get()),
        "arc_factor": float(pc.external_input.factor.get()),
    }
    for name, getter in (
        ("voltage_min", lambda: pc.voltage_min.get()),
        ("voltage_max", lambda: pc.voltage_max.get()),
        ("pc_enabled", lambda: pc.enabled.get()),
        ("arc_enabled", lambda: pc.external_input.enabled.get()),
    ):
        try:
            value = getter()
        except Exception:
            continue
        payload[name] = bool(value) if isinstance(value, bool) else value
    return payload


def move_to_wavelength(dlc: Any, target_nm: float, timeout_s: float, tolerance_nm: float) -> dict[str, Any]:
    ctl = dlc.laser1.ctl
    before_nm = float(ctl.wavelength_act.get())
    ctl.wavelength_set.set(float(target_nm))
    deadline = time.monotonic() + float(timeout_s)
    readback_nm = before_nm
    samples = 0
    while time.monotonic() < deadline:
        readback_nm = float(ctl.wavelength_act.get())
        samples += 1
        if abs(readback_nm - target_nm) <= tolerance_nm:
            break
        time.sleep(1.0)
    ok = abs(readback_nm - target_nm) <= tolerance_nm
    return {
        "ok": ok,
        "target_nm": target_nm,
        "tolerance_nm": tolerance_nm,
        "before_nm": before_nm,
        "after_read_nm": readback_nm,
        "samples": samples,
    }


def cycle_motor_control_smile(
    dlc: Any,
    *,
    readback: bool,
    off_settle_s: float = DEFAULT_SMILE_OFF_SETTLE_S,
    on_settle_s: float = DEFAULT_SMILE_ON_SETTLE_S,
) -> dict[str, Any]:
    control = dlc.laser1.ctl.mode_control.loop_enabled
    before: bool | str = "not_read_fast_cycle"
    if readback:
        before = bool(control.get())
    off_settle_s = max(0.0, float(off_settle_s))
    on_settle_s = max(0.0, float(on_settle_s))
    control.set(False)
    time.sleep(off_settle_s)
    control.set(True)
    time.sleep(on_settle_s)
    after_on: bool | str = "not_read_fast_cycle"
    if readback:
        after_on = bool(control.get())
    return {
        "ok": bool(after_on) if isinstance(after_on, bool) else True,
        "param": MOTOR_CONTROL_SMILE_PARAM,
        "before": before,
        "after_off": "not_read_fast_cycle",
        "after_on": after_on,
        "off_settle_s": off_settle_s,
        "on_settle_s": on_settle_s,
    }


def action_payload(dlc: Any, args: argparse.Namespace | SimpleNamespace) -> dict[str, Any]:
    action = args.action
    host = str(args.host)
    if action == "read_wavelength":
        return {"ok": True, "connection": "tcp", "host": host, "wavelength_nm": float(dlc.laser1.ctl.wavelength_act.get())}
    if action == "read_pc":
        return {"ok": True, **read_pc_payload(dlc, host)}
    if action == "read_arc_factor":
        return {
            "ok": True,
            "connection": "tcp",
            "host": host,
            "system_type": dlc.system_type.get(),
            "serial_number": dlc.serial_number.get(),
            "fw_ver": dlc.fw_ver.get(),
            "system_health_txt": dlc.system_health_txt.get(),
            "emission": bool(dlc.emission.get()),
            "arc_factor": float(dlc.laser1.dl.pc.external_input.factor.get()),
            "arc_enabled": bool(dlc.laser1.dl.pc.external_input.enabled.get()),
            "arc_signal": int(dlc.laser1.dl.pc.external_input.signal.get()),
        }
    if action == "set_pc_voltage":
        target_v = finite_float(args.pc_voltage_v, "--pc-voltage-v")
        pc = dlc.laser1.dl.pc
        pc.voltage_set.set(target_v)
        if args.readback:
            return {"ok": True, "target_v": target_v, **read_pc_payload(dlc, host)}
        return {"ok": True, "connection": "tcp", "host": host, "target_v": target_v}
    if action == "set_wavelength":
        target_nm = finite_float(args.target_nm, "--target-nm")
        dlc.laser1.ctl.wavelength_set.set(target_nm)
        return {"ok": True, "connection": "tcp", "host": host, "target_nm": target_nm}
    if action == "move_to_wavelength":
        target_nm = finite_float(args.target_nm, "--target-nm")
        result = move_to_wavelength(dlc, target_nm, args.timeout_s, args.tolerance_nm)
        return {"connection": "tcp", "host": host, **result}
    if action == "configure_wide_scan":
        start_nm = finite_float(args.start_nm, "--start-nm")
        stop_nm = finite_float(args.stop_nm, "--stop-nm")
        speed_nm_s = finite_float(args.speed_nm_s, "--speed-nm-s")
        wide_scan = dlc.laser1.wide_scan
        wide_scan.output_channel.set(79)
        wide_scan.scan_begin.set(start_nm)
        wide_scan.scan_end.set(stop_nm)
        wide_scan.speed.set(speed_nm_s)
        return {
            "ok": True,
            "connection": "tcp",
            "host": host,
            "output_channel": 79,
            "start_nm": start_nm,
            "stop_nm": stop_nm,
            "speed_nm_s": speed_nm_s,
        }
    if action == "start_wide_scan":
        dlc.laser1.wide_scan.start()
        return {"ok": True, "connection": "tcp", "host": host, "response": "started"}
    if action == "stop_wide_scan":
        dlc.laser1.wide_scan.stop()
        return {"ok": True, "connection": "tcp", "host": host, "response": "stopped"}
    if action == "set_arc_enabled":
        dlc.laser1.dl.pc.external_input.enabled.set(bool(args.enabled))
        return {"ok": True, "connection": "tcp", "host": host, "enabled": bool(args.enabled)}
    if action == "set_arc_factor":
        factor = finite_float(args.factor_v_per_v, "--factor-v-per-v")
        dlc.laser1.dl.pc.external_input.factor.set(factor)
        return {"ok": True, "connection": "tcp", "host": host, "factor_v_per_v": factor}
    if action == "configure_fine_scan_arc":
        factor = finite_float(args.factor_v_per_v, "--factor-v-per-v")
        pc = dlc.laser1.dl.pc
        pc.external_input.factor.set(factor)
        pc.external_input.enabled.set(True)
        return {"ok": True, "connection": "tcp", "host": host, "factor_v_per_v": factor, "enabled": True}
    if action == "set_emission_enabled":
        dlc.laser1.dl.cc.enabled.set(bool(args.enabled))
        return {"ok": True, "connection": "tcp", "host": host, "enabled": bool(args.enabled)}
    if action == "read_buzzer_on_connection":
        enabled = bool(dlc.buzzer.sounds.on_connection.get())
        return {
            "ok": True,
            "connection": "tcp",
            "host": host,
            "param": "buzzer:sounds:on-connection",
            "enabled": enabled,
        }
    if action == "set_buzzer_on_connection":
        control = dlc.buzzer.sounds.on_connection
        before = bool(control.get())
        target = bool(args.enabled)
        control.set(target)
        saved = False
        if bool(args.save):
            dlc.buzzer.save()
            saved = True
        after = bool(control.get()) if bool(args.readback) else "not_read"
        return {
            "ok": bool(after) == target if isinstance(after, bool) else True,
            "connection": "tcp",
            "host": host,
            "param": "buzzer:sounds:on-connection",
            "before": before,
            "written": target,
            "after": after,
            "saved": saved,
        }
    if action == "cycle_smile":
        return {
            "connection": "tcp",
            "host": host,
            **cycle_motor_control_smile(
                dlc,
                readback=args.readback,
                off_settle_s=args.smile_off_settle_s,
                on_settle_s=args.smile_on_settle_s,
            ),
        }
    if action == "fast_thermal_move":
        target_nm = finite_float(args.target_nm, "--target-nm")
        pc_voltage_v = finite_float(args.pc_voltage_v, "--pc-voltage-v")
        dlc.laser1.dl.pc.voltage_set.set(pc_voltage_v)
        move = move_to_wavelength(dlc, target_nm, args.timeout_s, args.tolerance_nm)
        if not move.get("ok"):
            return {"connection": "tcp", "host": host, "ok": False, "wavelength_move": move}
        smile = cycle_motor_control_smile(
            dlc,
            readback=False,
            off_settle_s=args.smile_off_settle_s,
            on_settle_s=args.smile_on_settle_s,
        )
        return {
            "ok": bool(smile.get("ok")),
            "connection": "tcp",
            "host": host,
            "pc_voltage": {"target_v": pc_voltage_v, "readback": "not_read_fast_move"},
            "wavelength_move": move,
            "motor_control_smile": smile,
            "remote_control_modified": False,
        }
    if action == "fast_wavelength_move":
        target_nm = finite_float(args.target_nm, "--target-nm")
        move = move_to_wavelength(dlc, target_nm, args.timeout_s, args.tolerance_nm)
        if not move.get("ok"):
            return {"connection": "tcp", "host": host, "ok": False, "wavelength_move": move}
        smile = cycle_motor_control_smile(
            dlc,
            readback=False,
            off_settle_s=args.smile_off_settle_s,
            on_settle_s=args.smile_on_settle_s,
        )
        return {
            "ok": bool(smile.get("ok")),
            "connection": "tcp",
            "host": host,
            "pc_voltage": {"skipped": True, "reason": "selected mode move does not modify PC voltage"},
            "wavelength_move": move,
            "motor_control_smile": smile,
            "remote_control_modified": False,
        }
    raise ValueError(f"unknown action: {action}")


def run_action(args: argparse.Namespace) -> dict[str, Any]:
    from toptica.lasersdk.dlcpro.v2_5_3 import DLCpro, NetworkConnection

    with DLCpro(NetworkConnection(args.host)) as dlc:
        return action_payload(dlc, args)


class TopticaServiceState:
    def __init__(self, host: str) -> None:
        self.host = host
        self.started_at = time.time()
        self._dlc: Any | None = None
        self._lock = threading.Lock()

    def close(self) -> None:
        with self._lock:
            if self._dlc is not None:
                try:
                    self._dlc.close()
                except Exception:
                    pass
                self._dlc = None

    def _connect(self) -> Any:
        from toptica.lasersdk.dlcpro.v2_5_3 import DLCpro, NetworkConnection

        dlc = DLCpro(NetworkConnection(self.host))
        dlc.open()
        return dlc

    def _laser(self) -> Any:
        if self._dlc is None:
            self._dlc = self._connect()
        return self._dlc

    def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            args = namespace_from_payload({"host": self.host, **payload})
            try:
                return action_payload(self._laser(), args)
            except Exception:
                if self._dlc is not None:
                    try:
                        self._dlc.close()
                    except Exception:
                        pass
                    self._dlc = None
                return action_payload(self._laser(), args)


def namespace_from_payload(payload: dict[str, Any]) -> SimpleNamespace:
    defaults = {
        "action": "",
        "host": "",
        "target_nm": None,
        "start_nm": None,
        "stop_nm": None,
        "speed_nm_s": None,
        "pc_voltage_v": None,
        "factor_v_per_v": None,
        "timeout_s": 90.0,
        "tolerance_nm": 0.01,
        "enabled": True,
        "readback": False,
        "save": True,
        "smile_off_settle_s": DEFAULT_SMILE_OFF_SETTLE_S,
        "smile_on_settle_s": DEFAULT_SMILE_ON_SETTLE_S,
    }
    defaults.update(payload)
    return SimpleNamespace(**defaults)


def make_handler(state: TopticaServiceState) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        server_version = "TopticaTcpService/1.0"

        def log_message(self, format: str, *args: Any) -> None:
            if os.environ.get("TOPTICA_TCP_SERVICE_VERBOSE") == "1":
                super().log_message(format, *args)

        def _json(self, status: int, payload: dict[str, Any]) -> None:
            data = json.dumps(payload, indent=2, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _read_json(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0") or "0")
            if length <= 0:
                return {}
            raw = self.rfile.read(length).decode("utf-8")
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError("request body must be a JSON object")
            return payload

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path != "/health":
                self._json(404, {"ok": False, "error": "not found"})
                return
            self._json(
                200,
                {
                    "ok": True,
                    "service": "toptica_tcp",
                    "host": state.host,
                    "pid": os.getpid(),
                    "started_at": state.started_at,
                    "uptime_s": time.time() - state.started_at,
                    "connected": state._dlc is not None,
                },
            )

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path == "/shutdown":
                self._json(200, {"ok": True, "message": "shutdown requested", "pid": os.getpid()})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if parsed.path != "/action":
                self._json(404, {"ok": False, "error": "not found"})
                return
            started = time.time()
            try:
                body = self._read_json()
                result = state.run(body)
                result.setdefault("ok", True)
                result.update(
                    {
                        "service": "toptica_tcp",
                        "service_pid": os.getpid(),
                        "service_uptime_s": time.time() - state.started_at,
                        "elapsed_s": time.time() - started,
                    }
                )
                self._json(200 if result.get("ok") else 400, result)
            except Exception as exc:
                self._json(
                    400,
                    {
                        "ok": False,
                        "error": repr(exc),
                        "service": "toptica_tcp",
                        "service_pid": os.getpid(),
                        "elapsed_s": time.time() - started,
                    },
                )

    return Handler


def serve(args: argparse.Namespace) -> int:
    state = TopticaServiceState(args.host)
    server = ThreadingHTTPServer((args.listen_host, args.listen_port), make_handler(state))
    try:
        print(
            json.dumps(
                {
                    "ok": True,
                    "service": "toptica_tcp",
                    "host": args.host,
                    "listen_host": args.listen_host,
                    "listen_port": args.listen_port,
                    "pid": os.getpid(),
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        server.serve_forever()
    finally:
        state.close()
        server.server_close()
    return 0


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--serve", action="store_true")
    parser.add_argument("--listen-host", default=DEFAULT_SERVICE_HOST)
    parser.add_argument("--listen-port", type=int, default=DEFAULT_SERVICE_PORT)
    parser.add_argument("--action", default="")
    parser.add_argument("--host", required=True)
    parser.add_argument("--target-nm", type=float, default=None)
    parser.add_argument("--start-nm", type=float, default=None)
    parser.add_argument("--stop-nm", type=float, default=None)
    parser.add_argument("--speed-nm-s", type=float, default=None)
    parser.add_argument("--pc-voltage-v", type=float, default=None)
    parser.add_argument("--factor-v-per-v", type=float, default=None)
    parser.add_argument("--timeout-s", type=float, default=90.0)
    parser.add_argument("--tolerance-nm", type=float, default=0.01)
    parser.add_argument("--enabled", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--readback", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--save", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--smile-off-settle-s", type=float, default=DEFAULT_SMILE_OFF_SETTLE_S)
    parser.add_argument("--smile-on-settle-s", type=float, default=DEFAULT_SMILE_ON_SETTLE_S)
    args = parser.parse_args(argv)
    if not args.serve and not args.action:
        parser.error("--action is required unless --serve is used")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.serve:
        return serve(args)
    try:
        payload = run_action(args)
    except Exception as exc:
        payload = {"ok": False, "error": repr(exc), "action": args.action, "host": args.host}
        print(json.dumps(payload, indent=2, ensure_ascii=False), flush=True)
        return 1
    print(json.dumps(payload, indent=2, ensure_ascii=False), flush=True)
    return 0 if payload.get("ok", True) else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
