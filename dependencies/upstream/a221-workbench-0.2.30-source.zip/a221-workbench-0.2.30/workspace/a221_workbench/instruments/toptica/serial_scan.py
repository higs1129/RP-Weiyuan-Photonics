from __future__ import annotations
import math
import time

class TopticaDlcPro:
    MOTOR_CONTROL_SMILE_PARAM = "laser1:ctl:mode-control:loop-enabled"

    def __init__(self, port: str, timeout_s: float = 2.0) -> None:
        try:
            import serial  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Missing dependency pyserial. Install with: python -m pip install pyserial"
            ) from exc

        self._serial = serial.Serial(port, baudrate=115200, timeout=timeout_s)

    def close(self) -> None:
        if self._serial and self._serial.is_open:
            self._serial.close()

    def query(self, command: str, *, timeout_s: float | None = None) -> str:
        command_clean = command.strip()
        if not command.endswith("\r\n"):
            command += "\r\n"
        self._serial.reset_input_buffer()
        self._serial.write(command.encode("ascii"))
        deadline = time.monotonic() + float(timeout_s if timeout_s is not None else self._serial.timeout or 2.0)
        responses: list[str] = []
        while time.monotonic() < deadline:
            line = self._serial.readline().decode("ascii", errors="replace").strip()
            if not line:
                continue
            if line == ">" or line.startswith(">"):
                if responses:
                    break
                continue
            if line == command_clean or command_clean in line:
                continue
            responses.append(line)
        if not responses:
            raise TimeoutError(f"No TOPTICA response for command: {command_clean}")
        return responses[-1]

    def get(self, name: str) -> str:
        return self.query(f"(param-ref '{name})")

    def set(self, expression: str) -> str:
        response = self.query(f"(param-set! '{expression})")
        if response.startswith("Error:"):
            raise RuntimeError(f"TOPTICA param-set failed for {expression!r}: {response}")
        return response

    def command(self, expression: str, *, timeout_s: float | None = None, allow_no_response: bool = False) -> str | None:
        try:
            return self.query(f"(exec '{expression})", timeout_s=timeout_s)
        except TimeoutError:
            if allow_no_response:
                return None
            raise

    def wavelength_nm(self) -> float:
        return float(self.get("laser1:ctl:wavelength-act"))

    def pc_voltage_set_v(self) -> float:
        return float(self.get("laser1:dl:pc:voltage-set"))

    def pc_voltage_act_v(self) -> float:
        return float(self.get("laser1:dl:pc:voltage-act"))

    def set_pc_voltage_v(self, voltage_v: float) -> None:
        self.set(f"laser1:dl:pc:voltage-set {voltage_v:.9g}")

    def set_wavelength_nm(self, wavelength_nm: float) -> None:
        self.set(f"laser1:ctl:wavelength-set {wavelength_nm:.9f}")

    def move_to_wavelength(self, wavelength_nm: float, timeout_s: float, tolerance_nm: float = 0.01) -> None:
        self.set_wavelength_nm(wavelength_nm)
        deadline = time.monotonic() + timeout_s
        last = math.nan
        while time.monotonic() < deadline:
            last = self.wavelength_nm()
            if abs(last - wavelength_nm) <= tolerance_nm:
                return
            time.sleep(1.0)
        raise TimeoutError(
            f"Laser did not reach {wavelength_nm:.3f} nm within {timeout_s:.1f} s; "
            f"last readback was {last:.6g} nm."
        )

    def configure_wide_scan(self, start_nm: float, stop_nm: float, speed_nm_s: float) -> None:
        self.set("laser1:wide-scan:output-channel 79")
        self.set(f"laser1:wide-scan:scan-begin {start_nm:.9f}")
        self.set(f"laser1:wide-scan:scan-end {stop_nm:.9f}")
        self.set(f"laser1:wide-scan:speed {speed_nm_s:.9f}")

    def start_wide_scan(self) -> str | None:
        # DLC PRO may not return a prompt while the wide scan is being launched.
        # The oscilloscope trigger/readback gates below still validate whether
        # the scan really produced usable data.
        return self.command("laser1:wide-scan:start", timeout_s=3.0, allow_no_response=True)

    def stop_wide_scan(self) -> str | None:
        return self.command("laser1:wide-scan:stop", timeout_s=3.0, allow_no_response=True)

    def set_arc_factor_enabled(self, enabled: bool) -> None:
        self.set(f"laser1:dl:pc:external-input:enabled {'#t' if enabled else '#f'}")

    def set_arc_factor(self, factor_v_per_v: float) -> None:
        self.set(f"laser1:dl:pc:external-input:factor {factor_v_per_v:.9g}")

    def configure_fine_scan_arc_factor(self, factor_v_per_v: float = 25.0) -> None:
        self.set_arc_factor(factor_v_per_v)
        self.set_arc_factor_enabled(True)

    def set_emission_enabled(self, enabled: bool) -> None:
        self.set(f"laser1:dl:cc:enabled {'#t' if enabled else '#f'}")

    def set_motor_control_smile_enabled(self, enabled: bool) -> None:
        self.set(f"{self.MOTOR_CONTROL_SMILE_PARAM} {'#t' if enabled else '#f'}")

    def cycle_motor_control_smile(self) -> dict[str, str]:
        before = self.get(self.MOTOR_CONTROL_SMILE_PARAM)
        self.set_motor_control_smile_enabled(False)
        self.set_motor_control_smile_enabled(True)
        after_on = self.get(self.MOTOR_CONTROL_SMILE_PARAM)
        return {
            "param": self.MOTOR_CONTROL_SMILE_PARAM,
            "before": before,
            "after_off": "not_read_fast_cycle",
            "after_on": after_on,
        }
