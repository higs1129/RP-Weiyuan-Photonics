"""One TOPTICA TCP service client, shared by scan and individual commands."""
from __future__ import annotations
import json, os, subprocess, sys, tempfile, time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from .runtime import expand_optional_path as _expand_optional_path, python_has_module as _python_has_module
TOPTICA_TCP_WORKER = Path(__file__).with_name("tcp_worker.py")
TOPTICA_TCP_SERVICE_HOST = "127.0.0.1"
TOPTICA_TCP_SERVICE_PORT = 7891

def _resolve_toptica_python(configured: str | Path | None = None) -> Path:
    candidates: list[Path] = []
    for raw in (
        configured,
        sys.executable,
        os.environ.get("TOPTICA_PYTHON_EXE"),
        Path.home() / "python311_embed" / "python.exe",
        Path.home() / "toptica_lasersdk_venv" / "Scripts" / "python.exe",
    ):
        path = _expand_optional_path(raw)
        if path is not None and path.exists() and path not in candidates:
            candidates.append(path)
    for path in candidates:
        if _python_has_module(path, "toptica"):
            return path
    tried = ", ".join(str(path) for path in candidates) or "<none>"
    raise RuntimeError(f"No Python with TOPTICA SDK found for TCP laser control. Tried: {tried}")


def _parse_http_json(data: bytes) -> dict[str, Any]:
    payload = json.loads(data.decode("utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError("TOPTICA TCP service returned non-object JSON")
    return payload


def _parse_worker_json(stdout: str) -> dict[str, Any]:
    for start in (idx for idx, char in reversed(list(enumerate(stdout))) if char == "{"):
        try:
            payload = json.loads(stdout[start:].strip())
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            return payload
    raise RuntimeError(f"TOPTICA TCP worker did not return JSON. stdout tail={stdout[-1000:]!r}")


def _service_base() -> str:
    return f"http://{TOPTICA_TCP_SERVICE_HOST}:{TOPTICA_TCP_SERVICE_PORT}"


def _service_json(
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    *,
    timeout_s: float = 3.0,
) -> dict[str, Any]:
    data = None
    headers: dict[str, str] = {}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = Request(f"{_service_base()}{path}", data=data, headers=headers, method=method)
    try:
        with urlopen(request, timeout=timeout_s) as response:
            return _parse_http_json(response.read())
    except HTTPError as exc:
        body = exc.read()
        try:
            detail: object = _parse_http_json(body)
        except Exception:
            detail = body.decode("utf-8", errors="replace")
        raise RuntimeError(detail) from exc


def _service_health() -> dict[str, Any] | None:
    try:
        return _service_json("GET", "/health", timeout_s=0.5)
    except Exception:
        return None


def _shutdown_service() -> None:
    try:
        _service_json("POST", "/shutdown", {}, timeout_s=1.0)
    except Exception:
        return
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        if _service_health() is None:
            return
        time.sleep(0.1)


def _start_service(host: str, *, python_exe: str | Path | None = None) -> None:
    resolved_python = _resolve_toptica_python(python_exe)
    log_path = Path(tempfile.gettempdir()) / f"toptica_tcp_service_{TOPTICA_TCP_SERVICE_PORT}.log"
    log_handle = log_path.open("a", encoding="utf-8", errors="replace")
    creationflags = 0
    if sys.platform.startswith("win"):
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP | getattr(subprocess, "DETACHED_PROCESS", 0)
    try:
        subprocess.Popen(
            [
                str(resolved_python),
                str(TOPTICA_TCP_WORKER),
                "--serve",
                "--host",
                host,
                "--listen-host",
                TOPTICA_TCP_SERVICE_HOST,
                "--listen-port",
                str(TOPTICA_TCP_SERVICE_PORT),
            ],
            cwd=str(TOPTICA_TCP_WORKER.parent),
            stdout=log_handle,
            stderr=log_handle,
            stdin=subprocess.DEVNULL,
            close_fds=False,
            creationflags=creationflags,
        )
    finally:
        log_handle.close()


def _ensure_toptica_tcp_service(
    host: str,
    *,
    python_exe: str | Path | None = None,
) -> dict[str, Any]:
    health = _service_health()
    if health and health.get("ok") and str(health.get("host")) == host:
        return health
    if health and health.get("ok") and str(health.get("host")) != host:
        _shutdown_service()
    _start_service(host, python_exe=python_exe)
    deadline = time.monotonic() + 8.0
    last: dict[str, Any] | None = None
    while time.monotonic() < deadline:
        health = _service_health()
        if health:
            last = health
            if health.get("ok") and str(health.get("host")) == host:
                return health
        time.sleep(0.15)
    raise RuntimeError(f"TOPTICA TCP service did not become ready; last health={last!r}")


def _run_toptica_tcp_worker(
    host: str,
    action: str,
    extra: list[str] | None,
    *,
    timeout_s: float,
    python_exe: str | Path | None = None,
) -> dict[str, Any]:
    resolved_python = _resolve_toptica_python(python_exe)
    command = [
        str(resolved_python),
        str(TOPTICA_TCP_WORKER),
        "--action",
        action,
        "--host",
        host,
    ]
    if extra:
        command.extend(extra)
    proc = subprocess.run(command, text=True, capture_output=True, timeout=timeout_s, check=False)
    payload: dict[str, Any] | None = None
    try:
        payload = _parse_worker_json(proc.stdout)
    except Exception:
        payload = None
    if proc.returncode != 0 or payload is None or not payload.get("ok", False):
        detail = payload if payload is not None else {
            "stdout_tail": proc.stdout[-1200:],
            "stderr_tail": proc.stderr[-1200:],
        }
        raise RuntimeError(f"TOPTICA TCP worker action {action!r} failed: {detail!r}")
    payload.setdefault("worker_python", str(resolved_python))
    payload.setdefault("service_fallback", True)
    return payload


def _run_toptica_tcp_action(
    host: str,
    action: str,
    payload: dict[str, Any] | None = None,
    *,
    extra: list[str] | None = None,
    timeout_s: float = 15.0,
    python_exe: str | Path | None = None,
) -> dict[str, Any]:
    try:
        health = _ensure_toptica_tcp_service(host, python_exe=python_exe)
        body = {"action": action, "host": host, **(payload or {})}
        result = _service_json("POST", "/action", body, timeout_s=timeout_s)
        result.setdefault("service_base", _service_base())
        result.setdefault("service_pid", health.get("pid"))
        return result
    except Exception as service_exc:
        result = _run_toptica_tcp_worker(
            host,
            action,
            extra,
            timeout_s=timeout_s,
            python_exe=python_exe,
        )
        result.setdefault("service_error", repr(service_exc))
        return result


def worker_args_to_payload(action: str, extra: list[str] | None) -> dict[str, Any]:
    """Translate legacy worker CLI options to the persistent-service payload."""
    payload: dict[str, Any] = {"action": action}
    key_map = {
        "--target-nm": ("target_nm", float),
        "--start-nm": ("start_nm", float),
        "--stop-nm": ("stop_nm", float),
        "--speed-nm-s": ("speed_nm_s", float),
        "--pc-voltage-v": ("pc_voltage_v", float),
        "--factor-v-per-v": ("factor_v_per_v", float),
        "--timeout-s": ("timeout_s", float),
        "--tolerance-nm": ("tolerance_nm", float),
        "--smile-off-settle-s": ("smile_off_settle_s", float),
        "--smile-on-settle-s": ("smile_on_settle_s", float),
    }
    args = list(extra or [])
    index = 0
    while index < len(args):
        item = args[index]
        if item in {"--enabled", "--readback", "--save"}:
            payload[item[2:].replace("-", "_")] = True
            index += 1
            continue
        if item in {"--no-enabled", "--no-readback", "--no-save"}:
            payload[item[5:].replace("-", "_")] = False
            index += 1
            continue
        if item == "--host":
            index += 2
            continue
        if item in key_map:
            if index + 1 >= len(args):
                raise ValueError(f"Missing value after {item}")
            key, caster = key_map[item]
            payload[key] = caster(args[index + 1])
            index += 2
            continue
        raise ValueError(f"Unsupported TOPTICA worker argument: {item}")
    return payload
