"""Small TOPTICA connection adapter shared by dashboard lock helpers."""

from __future__ import annotations
from .service_client import _run_toptica_tcp_action, worker_args_to_payload, _resolve_toptica_python
from a221_workbench._shared.paths import module_file, project_root


import json
import math
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError
from urllib.request import Request, urlopen


TOPTICA_TCP_WORKER = module_file('a221_workbench.instruments.toptica.tcp_worker')
TOPTICA_TCP_SERVICE_HOST = "127.0.0.1"
TOPTICA_TCP_SERVICE_PORT = 7891


def run_tcp_action(
    *,
    host: str,
    action: str,
    payload: dict[str, Any] | None = None,
    extra: list[str] | None = None,
    timeout_s: float = 15.0,
    python_exe: str | Path | None = None,
) -> dict[str, Any]:
    """Run one action through the shared persistent TOPTICA TCP service."""
    clean_extra: list[str] = []
    index = 0
    for item in extra or []:
        if index:
            index -= 1
            continue
        if item == "--host":
            index = 1
            continue
        clean_extra.append(item)
    return _run_toptica_tcp_action(
        host,
        action,
        payload,
        extra=clean_extra,
        timeout_s=timeout_s,
        python_exe=python_exe,
    )


from .serial_scan import TopticaDlcPro


class SerialTopticaSession:
    """Reuse one TOPTICA serial connection for a short control run."""

    def __init__(self, port: str, host: str = "", timeout_s: float = 0.25) -> None:
        self.port = port
        self.host = host
        self.timeout_s = timeout_s
        self._laser: Any | None = None

    def __enter__(self) -> "SerialTopticaSession":
        self._laser = TopticaDlcPro(self.port, timeout_s=self.timeout_s)
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    @property
    def laser(self) -> Any:
        if self._laser is None:
            raise RuntimeError("Serial TOPTICA session is not open")
        return self._laser

    def close(self) -> None:
        if self._laser is not None:
            self._laser.close()
            self._laser = None

    def read_pc(self, *, full: bool = True) -> dict[str, float | bool | str]:
        result: dict[str, float | bool | str] = {
            "connection": "serial",
            "port": self.port,
            "voltage_set": self.laser.pc_voltage_set_v(),
            "arc_factor": float(self.laser.get("laser1:dl:pc:external-input:factor")),
        }
        if full:
            result.update(
                {
                    "voltage_act": self.laser.pc_voltage_act_v(),
                    "pc_enabled": True,
                }
            )
        return result

    def write_pc_voltage(self, value: float, *, readback: str = "minimal") -> dict[str, float | bool | str]:
        self.laser.set_pc_voltage_v(float(value))
        time.sleep(0.5)
        if readback == "none":
            return {"connection": "serial", "port": self.port, "voltage_set": float(value)}
        return self.read_pc(full=(readback == "full"))

    def write_arc_factor(self, value: float, *, readback: str = "minimal") -> dict[str, float | bool | str]:
        self.laser.configure_fine_scan_arc_factor(float(value))
        time.sleep(0.4)
        if readback == "none":
            return {"connection": "serial", "port": self.port, "arc_factor": float(value)}
        return self.read_pc(full=(readback == "full"))

    def read_arc_factor(self) -> dict[str, float | bool | str]:
        return {
            "connection": "serial",
            "port": self.port,
            "arc_factor": float(self.laser.get("laser1:dl:pc:external-input:factor")),
            "arc_enabled": self.laser.get("laser1:dl:pc:external-input:enabled"),
        }


def read_pc(*, connection: str, host: str, port: str) -> dict[str, float | bool | str]:
    if connection == "serial":
        with SerialTopticaSession(port=port, host=host) as session:
            return session.read_pc(full=True)

    return _run_toptica_tcp_action(host, "read_pc", timeout_s=8.0)  # type: ignore[return-value]


def read_arc_factor(*, connection: str, host: str, port: str) -> dict[str, float | bool | str]:
    if connection == "serial":
        with SerialTopticaSession(port=port, host=host) as session:
            return session.read_arc_factor()

    return _run_toptica_tcp_action(host, "read_arc_factor", timeout_s=8.0)  # type: ignore[return-value]


def write_pc_voltage(
    *, connection: str, host: str, port: str, value: float, readback: str = "full"
) -> dict[str, float | bool | str]:
    if connection == "serial":
        with SerialTopticaSession(port=port, host=host) as session:
            return session.write_pc_voltage(float(value), readback=readback)

    should_readback = readback != "none"
    return _run_toptica_tcp_action(
        host,
        "set_pc_voltage",
        {"pc_voltage_v": float(value), "readback": should_readback},
        extra=["--pc-voltage-v", f"{float(value):.9g}"] + (["--readback"] if should_readback else []),
        timeout_s=8.0,
    )  # type: ignore[return-value]


def write_arc_factor(
    *, connection: str, host: str, port: str, value: float
) -> dict[str, float | bool | str]:
    if connection == "serial":
        with SerialTopticaSession(port=port, host=host) as session:
            return session.write_arc_factor(float(value), readback="full")

    _run_toptica_tcp_action(
        host,
        "set_arc_factor",
        {"factor_v_per_v": float(value)},
        extra=["--factor-v-per-v", f"{float(value):.9g}"],
        timeout_s=8.0,
    )
    return read_pc(connection=connection, host=host, port=port)


def move_to_wavelength(
    *,
    connection: str,
    host: str,
    port: str,
    target_nm: float,
    timeout_s: float,
    tolerance_nm: float,
) -> dict[str, object]:
    if connection == "serial":
        laser = TopticaDlcPro(port)
        try:
            before = laser.wavelength_nm()
            laser.move_to_wavelength(float(target_nm), timeout_s, tolerance_nm)
            readback = laser.wavelength_nm()
            after_set = float(target_nm)
        finally:
            laser.close()
        ok = abs(readback - target_nm) <= tolerance_nm
        return {
            "ok": ok,
            "connection": "serial",
            "port": port,
            "target_nm": target_nm,
            "tolerance_nm": tolerance_nm,
            "before_nm": before,
            "after_set_nm": after_set,
            "after_read_nm": readback,
        }

    result = _run_toptica_tcp_action(
        host,
        "move_to_wavelength",
        {
            "target_nm": float(target_nm),
            "timeout_s": float(timeout_s),
            "tolerance_nm": float(tolerance_nm),
        },
        extra=[
            "--target-nm",
            f"{float(target_nm):.9f}",
            "--timeout-s",
            f"{float(timeout_s):.6g}",
            "--tolerance-nm",
            f"{float(tolerance_nm):.6g}",
        ],
        timeout_s=float(timeout_s) + 15.0,
    )
    before = float(result.get("before_nm", float("nan")))
    readback = float(result.get("after_read_nm", before))
    ok = bool(result.get("ok")) and abs(readback - target_nm) <= tolerance_nm
    return {
        "ok": ok,
        "connection": "tcp",
        "host": host,
        "target_nm": target_nm,
        "tolerance_nm": tolerance_nm,
        "before_nm": before,
        "after_set_nm": target_nm,
        "after_read_nm": readback,
        "samples": result.get("samples", 0),
        "service_pid": result.get("service_pid"),
        "service_fallback": result.get("service_fallback", False),
    }
