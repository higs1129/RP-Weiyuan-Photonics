from __future__ import annotations
from pathlib import Path
from .serial_scan import TopticaDlcPro
from .tcp_scan import TcpTopticaDlcPro

def create_laser(
    laser_connection: str,
    laser_port: str,
    *,
    laser_host: str = "",
    toptica_python: str | Path | None = None,
) -> TopticaDlcPro | TcpTopticaDlcPro:
    if laser_connection == "serial":
        return TopticaDlcPro(laser_port)
    if laser_connection == "tcp":
        return TcpTopticaDlcPro(laser_host, toptica_python=toptica_python)
    raise ValueError(f"Unsupported TOPTICA laser connection: {laser_connection}")
