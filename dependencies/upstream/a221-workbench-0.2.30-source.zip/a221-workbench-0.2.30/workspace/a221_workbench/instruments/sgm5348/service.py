"""Small HTTP service for low-latency SGM5348 writes on Red Pitaya.

Run this script in the same directory as sgm5348_redpitaya.py on the RP.
It keeps Python and the SGM5348 mapping loaded, so dashboard writes only pay
for one HTTP request plus the SPI refresh.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.sgm5348'


import argparse
import json
import math
import os
import re
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


def parse_outputs(payload: dict[str, Any]) -> dict[int, float]:
    outputs_raw = payload.get("outputs_v")
    if not isinstance(outputs_raw, dict):
        raise ValueError("payload must contain outputs_v object")
    outputs: dict[int, float] = {}
    for key, value in outputs_raw.items():
        text = str(key)
        if text.startswith("out"):
            text = text[3:]
        out = int(text)
        if out < 0 or out > 15:
            raise ValueError(f"out must be 0..15, got out{out}")
        outputs[out] = float(value)
    from sgm5348_redpitaya import normalize_voltages
    return normalize_voltages(outputs)


def result_payload(result: Any, *, elapsed_s: float, outputs: dict[int, float]) -> dict[str, Any]:
    return {
        "ok": True,
        "elapsed_s": elapsed_s,
        "spi_elapsed_ms": float(result.elapsed_s) * 1000.0,
        "frame_count": len(result.frames),
        "outputs_v": {f"out{out}": voltage for out, voltage in sorted(outputs.items())},
    }


def board_metadata(vref: float) -> dict[str, Any]:
    # Read identity from the board, never infer it from a requested hostname.
    with open('/sys/class/net/eth0/address') as stream:
        mac = stream.read().strip().lower()
    return dict(hostname=socket.gethostname(), mac_address=mac,
                vref_v=vref, write_contract='identity-vref-v1')


PCB_OUTPUT_ORDERS = {
    # VOUT1..VOUT8 -> physical OUT label, separately for U1 and U2.
    # legacy16: original RP driver, read from RP-F0F1BF on 2026-09-14.
    'legacy16': ((0, 1, 2, 3, 4, 5, 6, 7), (8, 11, 10, 9, 15, 14, 13, 12)),
    # wirebond16: user's new PCB DAC output mapping table.
    'wirebond16': ((3, 2, 1, 0, 7, 6, 5, 4), (11, 10, 9, 8, 15, 14, 13, 12)),
}


def pcb_output_map(profile):
    """Select an explicit PCB revision without changing the board driver's map."""
    from sgm5348_redpitaya import DacTarget
    return {out: DacTarget(chip, channel)
            for chip, order in zip(('U1', 'U2'), PCB_OUTPUT_ORDERS[profile])
            for channel, out in enumerate(order, 1)}


def validate_request_target(payload, metadata):
    expected = str(payload.get('expected_device_id', ''))
    match = re.fullmatch(r'rp-([0-9a-f]{6}|[0-9a-f]{12})(?:\.local)?\.?', expected, re.I)
    mac = metadata.get('mac_address', '').replace(':', '').replace('-', '').lower()
    if not match or not re.fullmatch(r'[0-9a-f]{12}', mac) or not mac.endswith(match.group(1).lower()):
        raise ValueError('expected_device_id missing or does not match this RP; no write')
    expected_vref = float(payload.get('expected_vref_v', float('nan')))
    if not math.isfinite(expected_vref) or not math.isclose(expected_vref, metadata['vref_v'], rel_tol=0, abs_tol=1e-9):
        raise ValueError('expected_vref_v missing or does not match service configuration; no write')
    if payload.get('expected_pcb_map') and payload['expected_pcb_map'] != metadata.get('pcb_map'):
        raise ValueError('expected_pcb_map does not match service configuration; no write')


def build_handler(chain: Any, *, token: str, include_wtm: bool, metadata: dict):
    write_lock = threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        server_version = "Sgm5348HttpService/0.1"

        def send_json(self, payload: dict[str, Any], status: int = 200) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def check_token(self) -> bool:
            if not token:
                return True
            supplied = self.headers.get("X-SGM-Token", "")
            return supplied == token

        def do_GET(self) -> None:
            if self.path.rstrip("/") == "/health":
                self.send_json(
                    {
                        "ok": True,
                        "service": "sgm5348",
                        "include_wtm": include_wtm,
                        **metadata,
                        "rate_estimate": chain.refresh_estimate(include_wtm=include_wtm),
                    }
                )
                return
            self.send_json({"ok": False, "error": "not found"}, status=404)

        def do_POST(self) -> None:
            if self.path.rstrip("/") != "/apply":
                self.send_json({"ok": False, "error": "not found"}, status=404)
                return
            if not self.check_token():
                self.send_json({"ok": False, "error": "unauthorized"}, status=401)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("payload must be a JSON object")
                validate_request_target(payload, metadata)
                outputs = parse_outputs(payload)
                if any(not math.isfinite(value) for value in outputs.values()):
                    raise ValueError('output voltage must be finite')
                started = time.perf_counter()
                with write_lock:
                    result = chain.apply_voltages(outputs, include_wtm=include_wtm)
                self.send_json(result_payload(result, elapsed_s=time.perf_counter() - started, outputs=outputs))
            except Exception as exc:
                self.send_json({"ok": False, "error": repr(exc)}, status=400)

        def log_message(self, fmt: str, *args: Any) -> None:
            timestamp = time.strftime("%H:%M:%S")
            print(f"[{timestamp}] {fmt % args}", flush=True)

    return Handler


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8091)
    parser.add_argument("--token", default=os.environ.get("SGM5348_SERVICE_TOKEN", ""))
    parser.add_argument("--device", default="/dev/spidev1.0")
    parser.add_argument("--speed", type=int, default=500_000)
    parser.add_argument("--mode", type=int, default=1)
    parser.add_argument("--vref", type=float, required=True, help='Actual PCB reference voltage; no implicit default')
    parser.add_argument('--pcb-map', choices=tuple(PCB_OUTPUT_ORDERS), required=True,
                        help='Explicit PCB output labels: existing driver or 2026 wire-bond board')
    parser.add_argument("--max-voltage", type=float, default=1.0)
    parser.add_argument("--no-wtm", action="store_true")
    args = parser.parse_args()
    if not math.isfinite(args.vref) or args.vref <= 0:
        parser.error('--vref must be finite and positive')
    metadata = board_metadata(args.vref)

    from sgm5348_redpitaya import Sgm5348Chain
    chain = Sgm5348Chain(
        device=args.device,
        mode=args.mode,
        speed_hz=args.speed,
        vref=args.vref,
        max_voltage=args.max_voltage,
        output_map=pcb_output_map(args.pcb_map),
    )
    metadata['pcb_map'] = args.pcb_map
    metadata['output_mapping'] = {f'out{out}': f'{target.chip} VOUT{target.channel}'
                                  for out, target in sorted(chain.output_map.items())}
    include_wtm = not args.no_wtm
    server = ThreadingHTTPServer((args.host, args.port), build_handler(chain, token=args.token, include_wtm=include_wtm, metadata=metadata))
    print(f"SGM5348 HTTP service listening on http://{args.host}:{args.port}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
