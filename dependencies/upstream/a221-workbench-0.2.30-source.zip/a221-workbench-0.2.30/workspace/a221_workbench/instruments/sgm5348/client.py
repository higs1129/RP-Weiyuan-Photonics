from __future__ import annotations
import http.client
import json
import math
import threading
import time
from typing import Any, Callable
from urllib.parse import urlparse
from ..redpitaya.network import identity_matches, resolve_host, rp_identity


# Only addresses that passed this service's health/identity/configuration
# checks are cached. Health and POST target checks still run on every write.
_VERIFIED_ADDRESSES: dict[tuple, str] = {}
_VERIFIED_ADDRESSES_LOCK = threading.Lock()


def _discard_verified_address(key, address):
    with _VERIFIED_ADDRESSES_LOCK:
        if _VERIFIED_ADDRESSES.get(key) == address:
            _VERIFIED_ADDRESSES.pop(key, None)


def expected_rp(config):
    """Identity wins over a saved numeric URL. A separate SGM RP can be explicit."""
    for key in ('sgm_device_id', 'sgm_ssh_host', 'rp_device_id', 'rp_hostname'):
        value = str(config.get(key) or '').strip()
        if rp_identity(value):
            return value
    host = urlparse(str(config.get('sgm_service_url') or '')).hostname or ''
    return host if rp_identity(host) else ''


def validate_health(health, expected, vref):
    if not health.get('ok') or health.get('service') != 'sgm5348':
        raise RuntimeError('目标没有返回 SGM 服务身份')
    if not identity_matches(expected, health.get('mac_address', '')):
        raise RuntimeError('SGM 设备 MAC 不匹配或旧服务未报告身份；未写入，请核对板端服务版本')
    actual = float(health.get('vref_v', float('nan')))
    if not math.isfinite(actual) or not math.isclose(actual, vref, abs_tol=1e-9, rel_tol=0):
        raise RuntimeError(f'SGM 基准配置不匹配：期望 {vref:g} V，服务报告 {actual} V；未写入')
    if health.get('write_contract') != 'identity-vref-v1':
        raise RuntimeError('SGM 服务不支持写入时身份/基准校验；请更新板端服务，未写入')

def apply_sgm_via_service(
    config: dict[str, Any], state_payload: dict[str, Any], *, check_cancel: Callable[[], None] | None = None,
) -> dict[str, Any] | None:
    if check_cancel is not None:
        check_cancel()
    base = str(config.get("sgm_service_url") or "").strip().rstrip("/")
    if not base and expected_rp(config):
        base = f'http://{expected_rp(config)}:8091'
    if not base:
        return None
    started = time.time()
    headers = {"Content-Type": "application/json"}
    token = str(config.get("sgm_service_token") or "").strip()
    if token:
        headers["X-SGM-Token"] = token
    timeout_s = float(config.get("sgm_service_timeout_s") or 1.5)
    parsed = urlparse(base)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError(f"invalid sgm_service_url: {base}")
    path = (parsed.path.rstrip("/") or "") + "/apply"
    expected = expected_rp(config)
    connection = None
    effective_url = base
    stage = 'pre_write'
    failure_kind = 'configuration'
    service_missing = False
    health_phase = None
    cache_key = None
    address = parsed.hostname
    cache_hit = False
    rediscovered = False
    try:
        body_payload = dict(state_payload)
        if expected:
            vref = float(config.get('sgm_vref_v', 2.048))
            if not math.isfinite(vref) or vref <= 0:
                raise ValueError('sgm_vref_v must be finite and positive')
            # SGM is a local HTTP service. Do not replace a TLS hostname with an
            # IP (that would invalidate certificate hostname verification).
            if parsed.scheme != 'http':
                raise ValueError('RP identity discovery currently requires the local HTTP SGM service')
            expected_map = config.get('sgm_pcb_map')
            cache_key = (rp_identity(expected), parsed.scheme, parsed.port or 80,
                         parsed.path.rstrip('/'), vref, expected_map)
            with _VERIFIED_ADDRESSES_LOCK:
                cached_address = _VERIFIED_ADDRESSES.get(cache_key)
            cache_hit = cached_address is not None
            if cache_hit:
                address = cached_address
            else:
                stage = 'resolve'
                failure_kind = 'address_discovery'
                _, address = resolve_host(expected)
        connection_class = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
        if expected:
            # Retry only a transport failure while connecting/reading GET
            # health at a cached address. No POST exists inside this loop.
            for attempt in range(2 if cache_hit else 1):
                effective_url = parsed._replace(netloc=f'{address}:{parsed.port or 80}').geturl().rstrip('/')
                if check_cancel is not None:
                    check_cancel()
                stage = 'health'
                failure_kind = 'health_transport'
                health_phase = 'connect'
                try:
                    # Windows may take ~2 s to report a refused connection.
                    # Keep this distinct from the configured HTTP read timeout.
                    connection = connection_class(address, parsed.port, timeout=max(3.0, timeout_s))
                    connection.connect()
                    connection.timeout = timeout_s
                    connection.sock.settimeout(timeout_s)
                    health_phase = 'read'
                    connection.request('GET', (parsed.path.rstrip('/') or '') + '/health')
                    response = connection.getresponse()
                    health_text = response.read().decode('utf-8')
                except (OSError, http.client.HTTPException) as exc:
                    service_missing = health_phase == 'connect' and (
                        isinstance(exc, ConnectionRefusedError) or getattr(exc, 'errno', None) in (111, 10061))
                    _discard_verified_address(cache_key, address)
                    if not cache_hit or attempt != 0:
                        raise
                    if connection is not None:
                        connection.close()
                        connection = None
                    if check_cancel is not None:
                        check_cancel()
                    stage = 'resolve'
                    failure_kind = 'address_discovery'
                    service_missing = False
                    # Resolve the identity afresh; never use the configured
                    # numeric URL as a fallback for a failed discovery.
                    rediscovered = True
                    _, address = resolve_host(expected)
                    continue
                break
            failure_kind = 'health_validation'
            health_phase = 'validate'
            service_missing = False
            if response.status != 200:
                raise RuntimeError(f'SGM health HTTP {response.status}')
            health = json.loads(health_text)
            validate_health(health, expected, vref)
            if expected_map and health.get('pcb_map') != expected_map:
                raise RuntimeError('SGM PCB 输出映射不匹配；未写入')
            with _VERIFIED_ADDRESSES_LOCK:
                _VERIFIED_ADDRESSES[cache_key] = address
            body_payload.update(expected_device_id=expected, expected_vref_v=vref)
            if expected_map:
                body_payload['expected_pcb_map'] = expected_map
        else:
            if check_cancel is not None:
                check_cancel()
            connection = connection_class(address, parsed.port, timeout=timeout_s)
        stage = 'pre_write'
        failure_kind = 'request_preparation'
        body = json.dumps(body_payload, ensure_ascii=False).encode('utf-8')
        if check_cancel is not None:
            check_cancel()
        # Once POST starts, finish this synchronous request before any cleanup.
        stage = 'write'
        failure_kind = 'write_or_response'
        connection.request("POST", path, body=body, headers=headers)
        response = connection.getresponse()
        text = response.read().decode("utf-8", errors="replace")
        if response.status >= 400:
            raise RuntimeError(f"HTTP {response.status}: {text[:500]}")
        payload = json.loads(text) if text.strip() else {}
        if not isinstance(payload, dict):
            raise ValueError(f"SGM service returned non-object JSON: {text[:200]}")
        if payload.get("ok") is not True:
            raise RuntimeError(payload.get("error") or payload)
        return {
            "ok": True,
            "url": effective_url,
            "expected_device_id": expected,
            "stage": 'complete',
            "post_started": True,
            "address_cache_hit": cache_hit,
            "address_rediscovered": rediscovered,
            "elapsed_s": time.time() - started,
            "response": payload,
        }
    except Exception as exc:
        if cache_key is not None:
            _discard_verified_address(cache_key, address)
        if stage != 'write' and check_cancel is not None:
            check_cancel()
        return {
            "ok": False,
            "url": effective_url,
            "stage": stage,
            "failure_kind": failure_kind,
            "health_phase": health_phase,
            "post_started": stage == 'write',
            "no_retry": bool(expected) or stage == 'write',
            "outcome_unknown": stage == 'write',
            "service_recovery_allowed": bool(expected) and stage == 'health' and service_missing,
            "recovery_action": 'start_missing_service' if expected and stage == 'health' and service_missing else None,
            "address_cache_hit": cache_hit,
            "address_rediscovered": rediscovered,
            "elapsed_s": time.time() - started,
            "error": repr(exc),
        }
    finally:
        if connection is not None:
            connection.close()


class Sgm5348:
    """HTTP client with verified address reuse; voltage POST is never retried."""
    def __init__(self, service_url, *, token='', timeout_s=1.5, vref=2.048, port=8091, pcb_map=None):
        device_id = service_url if rp_identity(service_url) else ''
        if device_id:
            service_url = f'http://{device_id}:{int(port)}'
        self.config = dict(sgm_service_url=service_url, sgm_service_token=token,
                           sgm_service_timeout_s=timeout_s, sgm_device_id=device_id,
                           sgm_vref_v=vref, sgm_pcb_map=pcb_map)

    def apply_voltages(self, outputs_v):
        result = apply_sgm_via_service(self.config, {'outputs_v': outputs_v})
        if result is None or not result['ok']:
            raise RuntimeError(result or 'SGM service URL is required')
        return result
