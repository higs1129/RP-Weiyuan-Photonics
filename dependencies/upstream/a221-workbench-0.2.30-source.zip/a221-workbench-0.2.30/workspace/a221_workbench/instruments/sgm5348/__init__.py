from .client import Sgm5348, apply_sgm_via_service
