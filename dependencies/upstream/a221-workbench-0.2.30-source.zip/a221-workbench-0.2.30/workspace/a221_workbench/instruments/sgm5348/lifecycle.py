"""Ensure an already deployed, identity-checked SGM HTTP service is available.

SSH is used only for service management, never as a voltage-write fallback.
"""
from __future__ import annotations

import http.client
import json
import math
import os
from pathlib import Path
import shlex
import time
from urllib.parse import urlparse

from .client import expected_rp, validate_health
from ..redpitaya.network import identity_matches, resolve_host
from ..._shared.paths import configuration_dir


# Sent through stdin; credentials/token are never placed in shell arguments.
# No upload, kill, or voltage operation. A present or starting service is not
# replaced. The caller always rechecks HTTP identity/configuration afterwards.
_START_DEPLOYED = r'''
import fcntl, json, os, socket, subprocess, sys
from pathlib import Path
p = json.load(sys.stdin)
try:
    mac = Path('/sys/class/net/eth0/address').read_text().strip().lower()
    expected = p['expected_mac_suffix']
    if not mac.replace(':', '').endswith(expected):
        raise RuntimeError('Remote board MAC mismatch; no service started')
    lock = open('/tmp/a221-sgm-start-%d.lock' % p['port'], 'a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for table in ('/proc/net/tcp', '/proc/net/tcp6'):
        if not Path(table).exists():
            continue
        for line in Path(table).read_text().splitlines()[1:]:
            fields = line.split()
            if fields[3] == '0A' and int(fields[1].rsplit(':', 1)[1], 16) == p['port']:
                raise RuntimeError('Service port already occupied; no process stopped or started')
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            args = (entry / 'cmdline').read_bytes().split(b'\0')
        except FileNotFoundError:
            continue
        # Be conservative about a not-yet-listening instance of the deployed
        # program; do not start another copy or try to kill it.
        if any(a.rsplit(b'/', 1)[-1] == b'sgm5348_http_service.py' or a.endswith(b'/a221_workbench/instruments/sgm5348/service.py') for a in args) or b'a221_workbench.instruments.sgm5348.service' in args:
            raise RuntimeError('An existing service process may still be starting; no duplicate started')
    directory = Path(p['remote_dir'])
    script = directory / 'sgm5348_http_service.py'
    driver = directory / 'sgm5348_redpitaya.py'
    if not script.is_file() or not driver.is_file():
        raise RuntimeError('Deployed SGM service/driver missing; explicit deployment required')
    source = script.read_text()
    if not all(marker in source for marker in ('identity-vref-v1', 'expected_pcb_map', '--vref', '--pcb-map')):
        raise RuntimeError('Deployed service lacks identity/vref/map contract; explicit update required')
    env = dict(os.environ)
    env['SGM5348_SERVICE_TOKEN'] = p['token']
    command = [sys.executable, str(script), '--host', '0.0.0.0', '--port', str(p['port']),
               '--vref', str(p['vref']), '--pcb-map', p['pcb_map'], '--max-voltage', str(p['max_voltage'])]
    with open(p['log_path'], 'ab', buffering=0) as log:
        child = subprocess.Popen(command, cwd=str(directory), env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(ok=True, start_requested=True, pid=child.pid, mac_address=mac, log_path=p['log_path'])))
except Exception as exc:
    print(json.dumps(dict(ok=False, start_requested=False, error=str(exc))))
'''


class _MissingService(ConnectionRefusedError):
    pass


def _health(address, parsed, expected, vref, pcb_map, timeout):
    connection = http.client.HTTPConnection(address, parsed.port or 80, timeout=max(3., timeout))
    try:
        try:
            connection.connect()
        except ConnectionRefusedError as exc:
            raise _MissingService('SGM TCP connection refused') from exc
        connection.timeout = timeout
        connection.sock.settimeout(timeout)
        connection.request('GET', parsed.path.rstrip('/') + '/health')
        response = connection.getresponse()
        raw = response.read()
        if response.status != 200:
            raise RuntimeError(f'SGM health HTTP {response.status}; no service replacement allowed')
        health = json.loads(raw.decode('utf-8'))
        validate_health(health, expected, vref)
        if health.get('pcb_map') != pcb_map:
            raise RuntimeError('SGM PCB map mismatch; no service replacement allowed')
        return health
    finally:
        connection.close()


def _start_deployed(config, address, expected, parsed, vref, pcb_map):
    import paramiko
    from ..redpitaya.network import rp_identity

    maximum = float(config.get('sgm_max_voltage_v') or 1.0)
    if not math.isfinite(maximum) or maximum <= 0:
        raise ValueError('sgm_max_voltage_v must be finite and positive')
    port = parsed.port or 80
    remote_dir = str(config.get('sgm_remote_dir') or '/root/sgm5348_control').strip()
    if not remote_dir.startswith('/'):
        raise ValueError('sgm_remote_dir must be an absolute board path')
    keys = Path(config.get('sgm_ssh_known_hosts') or
                configuration_dir('redpitaya_microcavity_lock') / '.runtime/sgm_known_hosts')
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    if keys.exists():
        client.load_host_keys(str(keys))
    # Same first-contact policy as existing RP UART management. The address
    # has just been discovered by RP identity/MAC; known host-key conflicts
    # remain errors, and remote MAC is checked before any management action.
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    password = config.get('sgm_ssh_password', config.get('rp_ssh_password', os.environ.get('RP_SSH_PASSWORD', 'root')))
    try:
        try:
            client.connect(address, port=int(config.get('sgm_ssh_port') or 22),
                           username=str(config.get('sgm_ssh_user') or 'root'), password=password,
                           key_filename=config.get('sgm_ssh_key_filename') or None,
                           timeout=5, auth_timeout=5, banner_timeout=5,
                           look_for_keys=True, allow_agent=True)
        except paramiko.AuthenticationException as exc:
            raise RuntimeError('SGM service management SSH authentication failed; configure sgm_ssh_password/key or RP_SSH_PASSWORD; no service started') from exc
        except paramiko.BadHostKeyException as exc:
            raise RuntimeError('SGM service management SSH host key mismatch; no service started') from exc
        # Read the MAC independently before sending even the start request.
        _, stdout, _ = client.exec_command('cat /sys/class/net/eth0/address', timeout=5)
        mac = stdout.read().decode('ascii').strip()
        if not identity_matches(expected, mac):
            raise RuntimeError('SGM service management remote MAC mismatch; no service started')
        keys.parent.mkdir(parents=True, exist_ok=True)
        client.save_host_keys(str(keys))
        stdin, stdout, stderr = client.exec_command('python3 -c ' + shlex.quote(_START_DEPLOYED), timeout=8)
        request = dict(expected_mac_suffix=rp_identity(expected), port=port, remote_dir=remote_dir,
                       vref=vref, pcb_map=pcb_map, max_voltage=maximum,
                       token=str(config.get('sgm_service_token') or ''),
                       log_path=f'/tmp/sgm5348_http_service_{port}.log')
        stdin.write(json.dumps(request))
        stdin.flush()
        stdin.channel.shutdown_write()
        raw = stdout.read().decode('utf-8')
        # Do not copy stderr or the request into a result: they may contain
        # credentials if a remote shell or third-party tool echoes input.
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise RuntimeError('Invalid service management response; start state unknown, not retried')
        return result
    finally:
        client.close()


def ensure_sgm_service(config, *, allow_start=False, check_cancel=None, timeout_s=8.0):
    """Verify current service; explicitly allow starting a missing deployment.

    No voltage is sent, no running service is killed, and no files are uploaded.
    Only ConnectionRefused permits a start. Timeout/invalid health fail closed.
    A start request is attempted at most once, even if its outcome is unknown.
    """
    result = dict(ok=False, stage='preflight', start_requested=False, voltage_post_started=False)
    def cancelled():
        if check_cancel is not None:
            check_cancel()
    try:
        cancelled()
        expected = expected_rp(config)
        parsed = urlparse(str(config.get('sgm_service_url') or f'http://{expected}:8091'))
        vref = float(config.get('sgm_vref_v', 2.048))
        pcb_map = config.get('sgm_pcb_map')
        if not expected or parsed.scheme != 'http' or not parsed.hostname:
            raise ValueError('Service management requires explicit RP identity and local HTTP service')
        if not math.isfinite(vref) or vref <= 0 or pcb_map not in ('wirebond16', 'legacy16'):
            raise ValueError('Service management requires positive vref and explicit supported PCB map')
        if not 0 < timeout_s <= 60:
            raise ValueError('timeout_s must be in (0, 60]')
        result.update(stage='resolve', expected_device_id=expected)
        _, address = resolve_host(expected)
        result.update(address=address, url=parsed._replace(netloc=f'{address}:{parsed.port or 80}').geturl(), stage='health')
        cancelled()
        try:
            health = _health(address, parsed, expected, vref, pcb_map, min(2., timeout_s))
        except _MissingService:
            if not allow_start:
                raise RuntimeError('SGM service is not listening; explicit allow_start=True is required')
        else:
            return {**result, 'ok': True, 'stage': 'ready', 'health': health}
        cancelled()
        result['stage'] = 'service_start'
        # None means management was attempted but its outcome is not yet known.
        result['start_requested'] = None
        start = _start_deployed(config, address, expected, parsed, vref, pcb_map)
        result.update(service_start=start, start_requested=start.get('start_requested'))
        if not start.get('ok'):
            raise RuntimeError(start.get('error') or 'Service start failed')
        result['stage'] = 'verify_health'
        deadline = time.monotonic() + timeout_s
        while True:
            cancelled()
            try:
                health = _health(address, parsed, expected, vref, pcb_map, min(1., timeout_s))
                return {**result, 'ok': True, 'stage': 'ready', 'health': health}
            except _MissingService:
                if time.monotonic() >= deadline:
                    raise RuntimeError('Started SGM service did not become ready; inspect board log, no second start attempted')
                time.sleep(.1)
    except Exception as exc:
        cancelled()
        result['error'] = str(exc)
        return result
