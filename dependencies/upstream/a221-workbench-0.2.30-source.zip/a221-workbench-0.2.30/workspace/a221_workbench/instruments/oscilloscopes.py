from __future__ import annotations
import math
import time
from typing import Any

from .tektronix import TektronixMso6
from .rohde_schwarz import RohdeSchwarzRte

def create_scope(
    scope_type: str,
    resource: str,
    *,
    visa_backend: str = "@py",
    timeout_ms: int = 120000,
) -> RohdeSchwarzRte | TektronixMso6:
    constructors = {
        "rs_rte": RohdeSchwarzRte,
        "tektronix_mso66b": TektronixMso6,
    }
    constructor = constructors.get(scope_type)
    if constructor is None:
        raise ValueError(f"Unsupported scope type: {scope_type}")

    attempts = 3 if scope_type == "tektronix_mso66b" else 1
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return constructor(resource, visa_backend=visa_backend, timeout_ms=timeout_ms)
        except Exception as exc:
            last_error = exc
            if attempt >= attempts:
                break
            time.sleep(0.8 * attempt)
    raise RuntimeError(
        f"Could not open {scope_type} scope resource {resource!r} after {attempts} attempt(s): {last_error!r}"
    ) from last_error
