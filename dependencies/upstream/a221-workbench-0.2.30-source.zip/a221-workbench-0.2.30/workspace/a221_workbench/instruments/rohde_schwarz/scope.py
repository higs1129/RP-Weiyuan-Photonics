from __future__ import annotations
import math
import time
from typing import Any

def build_time_axis(n: int, sample_rate_hz: float) -> list[float]:
    dt = 1.0 / sample_rate_hz
    return [i * dt for i in range(n)]

class RohdeSchwarzRte:
    def __init__(self, resource: str, visa_backend: str = "@py", timeout_ms: int = 120000) -> None:
        try:
            import pyvisa  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Missing dependency pyvisa. Install with: python -m pip install pyvisa"
            ) from exc

        self._rm = pyvisa.ResourceManager(visa_backend)
        self._inst = self._rm.open_resource(resource)
        self._inst.timeout = timeout_ms
        self._inst.chunk_size = 1024 * 1024
        if "SOCKET" in resource.upper():
            self._inst.read_termination = "\n"
            self._inst.write_termination = "\n"

    def close(self) -> None:
        try:
            self._inst.close()
        finally:
            self._rm.close()

    def write(self, command: str) -> None:
        self._inst.write(command)

    def query(self, command: str) -> str:
        return str(self._inst.query(command)).strip()

    def idn(self) -> str:
        return self.query("*IDN?")

    def opc(self) -> None:
        self.query("*OPC?")

    def stop(self) -> None:
        self.write("STOP")

    def run(self) -> None:
        self.write("RUN")

    def single(self) -> None:
        self.write("SING")

    def configure_large_scan(
        self,
        *,
        record_seconds: float,
        sample_rate_hz: float,
        trigger_channel: int,
        trigger_level_v: float,
        trigger_slope: str,
        trans_channel: int,
        mzi_channel: int,
        aux_mzi_channel: int | None = None,
        save_transmission: bool = True,
        save_trigger: bool,
    ) -> None:
        channels_to_enable = {mzi_channel}
        if save_transmission:
            channels_to_enable.add(trans_channel)
        if aux_mzi_channel is not None:
            channels_to_enable.add(aux_mzi_channel)
        if save_trigger:
            channels_to_enable.add(trigger_channel)
        for channel in range(1, 5):
            state = "ON" if channel in channels_to_enable else "OFF"
            self.write(f"CHANnel{channel}:STATe {state}")

        self.write(f"TRIGger:SOURce:SELect CHAN{trigger_channel}")
        self.write("TRIGger:MODE NORMal")
        self.write(f"TRIGger:LEVel{trigger_channel}:VALue {trigger_level_v:.9g}")
        self.write(f"TRIGger:EDGE:SLOPe {trigger_slope.upper()}")
        self.write(f"TIMebase:SCALe {record_seconds / 10.0:.9g}")
        self.write(f"ACQuire:SRReal {sample_rate_hz:.9g}")
        self.write(f"ACQuire:POINts:VALue {int(round(record_seconds * sample_rate_hz))}")
        self.write("TIMebase:REFerence 50")
        self.write("TIMebase:HORizontal:POSition 0")
        self.write("FORMat:DATA REAL,32")
        self.write("FORMat:BORDer LSBF")
        self.opc()

    def configure_fine_scan_idle(
        self,
        *,
        trigger_channel: int = 4,
        trigger_level_v: float = 0.0,
        trigger_slope: str = "negative",
        trigger_mode: str = "auto",
        time_scale_s_per_div: float = 1e-3,
        horizontal_delay_s: float | None = None,
    ) -> None:
        self.stop()
        self.write("CHANnel1:STATe OFF")
        self.write(f"CHANnel{trigger_channel}:STATe ON")
        self.write(f"TRIGger:SOURce:SELect CHAN{trigger_channel}")
        self.write(f"TRIGger:MODE {trigger_mode.upper()}")
        self.write(f"TRIGger:LEVel{trigger_channel}:VALue {trigger_level_v:.9g}")
        self.write(f"TRIGger:EDGE:SLOPe {trigger_slope.upper()}")
        self.write("TIMebase:HORizontal:POSition 0")
        self.write(f"TIMebase:SCALe {time_scale_s_per_div:.9g}")
        self.run()
        self.opc()

    def read_channel(self, channel: int) -> tuple[list[float], list[float], dict[str, float]]:
        chan = f"CHAN{channel}"
        self.write("FORMat:DATA REAL,32")
        self.write("FORMat:BORDer LSBF")
        self.write(f"{chan}:DATA:POINts MAX")
        header_raw = self.query(f"{chan}:DATA:HEAD?")
        values = self._inst.query_binary_values(
            f"{chan}:DATA?",
            datatype="f",
            is_big_endian=False,
            expect_termination=False,
            container=list,
        )
        sample_rate = float(self.query("ACQuire:SRATe?"))
        values = [float(v) for v in values]
        header_parts = [float(part) for part in header_raw.replace(";", ",").split(",") if part.strip()]
        if len(header_parts) >= 3:
            x_start, x_stop, header_points = header_parts[:3]
            if len(values) > 1:
                step = (x_stop - x_start) / (len(values) - 1)
                time_axis = [x_start + i * step for i in range(len(values))]
            else:
                time_axis = [x_start]
        else:
            x_start = 0.0
            x_stop = (len(values) - 1) / sample_rate if values else 0.0
            header_points = float(len(values))
            time_axis = build_time_axis(len(values), sample_rate)
        header = {
            "x_start_s": x_start,
            "x_stop_s": x_stop,
            "header_points": header_points,
            "sample_rate_hz": sample_rate,
            "raw": header_raw,
        }
        return time_axis, values, header
