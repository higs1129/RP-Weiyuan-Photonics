from __future__ import annotations
import uuid
from .parameters import Parameters
from .capture import Capture

class Acquisition(Parameters):
    def __init__(self, rp, prefix):
        allowed = {'input1', 'input2', 'duration', 'trigger_source', 'trigger_delay', 'rolling_mode'} if prefix == 'scope' else {
            'span', 'trace_average', 'window', 'baseband', 'input1_baseband', 'input2_baseband'}
        super().__init__(rp, prefix, allowed)

    def acquire(self, *, settings=None, timeout_s=20):
        if not 0 < timeout_s <= 300:
            raise ValueError('timeout_s must be in (0, 300]')
        kind = 'scope' if self.prefix == 'scope' else 'spectrum'
        with self.rp.operation():
            if settings:
                self.configure(**settings)
            payload = self.rp.request('/' + kind + '/single', {
                'tag': uuid.uuid4().hex, 'timeout': timeout_s,
                'inline': 'true', 'max_points': 1000000, 'plot': 'false',
                'save': 'false', 'save_npz': 'false', 'save_csv': 'false',
            }, timeout_s=timeout_s + 5)
            return Capture(kind, payload, self.rp.host)
