"""ASG1-only excitation, run on the bridge's Qt owner thread.

PyRPL 0.9.8's trigger_source.__set__ rebuilds the waveform. Its descriptor
set_value writes the masked register without _setup, preserving custom data.
"""
from __future__ import annotations
import math
import threading
import time
import uuid
from .capture import Capture
from .output_safety import OUTPUT_MODULES


def burst_capture_plan(frequency, cycles):
    """Smallest supported 16k window covering a centered burst plus 25% tail.

    Keep t=0 centered: half the window is pretrigger, half posttrigger.
    The plan is for a packet response, not for displaying the entire repeat gap.
    """
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in (frequency, cycles)):
        raise ValueError('频率和周期数须为有限数值')
    # Allow one ASG frequency-register LSB around the public 1 Hz..1 MHz
    # limits when planning from the hardware readback (requests validate below).
    if not .999 <= frequency <= 1000001 or not 1 <= cycles <= 100000 or int(cycles) != cycles or cycles / frequency > 2.001:
        raise ValueError('burst 频率、周期数或包时长超出范围')
    packet = cycles / frequency
    base = 16384 / 125e6
    decimation = next(d for d in (2**i for i in range(17)) if base * d >= 2.5 * packet)
    fs = 125e6 / decimation
    points = fs / frequency
    return dict(duration=base * decimation, packet_duration=packet, decimation=decimation,
                sample_rate_hz=fs, samples_per_cycle=points,
                warning='每周期采样点少于 10；请减少每包周期数以兼顾整包显示与波形细节' if points < 10 else '')


def validate(settings):
    if not isinstance(settings, dict):
        raise ValueError('激励设置必须是对象')
    allowed = {'mode', 'waveform', 'frequency', 'amplitude', 'offset', 'cycles', 'duration', 'samples', 'observe', 'burst_period', 'auto_duration'}
    if set(settings) - allowed:
        raise ValueError('未知激励参数')
    result = dict(mode='burst', waveform='sin', frequency=1000., amplitude=.1,
                  offset=0., cycles=5, duration=.04, observe=False, burst_period=.1, auto_duration=False)
    result.update(settings)
    if not isinstance(result['observe'], bool) or not isinstance(result['auto_duration'], bool):
        raise ValueError('observe 和 auto_duration 必须为布尔值')
    if result['mode'] not in ('continuous', 'burst', 'periodic_burst'):
        raise ValueError('请选择连续波、单次 burst 或周期 burst')
    if result['observe'] and result['mode'] != 'burst':
        raise ValueError('同步采集一帧仅用于单次 burst；周期 burst 请使用连续观察')
    if result['waveform'] not in ('sin', 'square', 'triangle', 'sawtooth', 'custom'):
        raise ValueError('不支持的波形')
    for key, low, high in [('frequency', 1., 1e6), ('amplitude', .0002, 1.),
                           ('offset', -1., 1.), ('cycles', 1, 100000), ('duration', 1e-6, 8.589934592),
                           ('burst_period', 2e-6, 3600.)]:
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError(f'{key} 必须在 {low:g}–{high:g} 之间')
    if int(result['cycles']) != result['cycles']:
        raise ValueError('burst 周期数必须是整数')
    result['cycles'] = int(result['cycles'])
    if abs(result['offset']) + result['amplitude'] > 1:
        raise ValueError('|偏置| + 峰值幅度不能超过 1 V')
    if result['mode'] != 'continuous' and result['cycles'] / result['frequency'] > 2:
        raise ValueError('单次 burst 总时长不能超过 2 秒')
    if result['mode'] == 'periodic_burst' and result['burst_period'] - result['cycles'] / result['frequency'] < 1e-6:
        raise ValueError('整包重复周期须大于包内时长（周期数 / 频率），并至少留出 1 μs 间隔')
    if result['waveform'] == 'custom':
        samples = result.get('samples')
        if not isinstance(samples, list) or not 2 <= len(samples) <= 16384:
            raise ValueError('自定义波表须为 2–16384 点的 JSON 数组')
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or abs(v) > 1 for v in samples):
            raise ValueError('波表每个值必须是 [-1, 1] 内的有限数值')
    else:
        result.pop('samples', None)
    return result


class Excitation:
    def __init__(self, rp):
        self.rp = rp

    def run(self, settings, *, run_id=None):
        settings = validate(settings)
        required = 3 if settings['mode'] == 'periodic_burst' else 2
        if settings['auto_duration']:
            required = 4
        if (self.rp.bridge_status or {}).get('excitation_protocol', 0) < required:
            raise RuntimeError('当前 RP 后台不支持激励；请停止采集及守护后，在仪器连接中重启 RP 后台')
        if not self.rp.connected:
            raise RuntimeError('请先连接 RP')
        request = self.rp.request if settings['observe'] else self.rp.client.request
        if not settings['auto_duration']:
            settings.pop('auto_duration')  # Omit the optional new field when unused.
        result = request('/excitation/run', json_body={
            'run_id': run_id or uuid.uuid4().hex, 'settings': settings}, timeout_s=15)
        if not result.get('ok'):
            raise RuntimeError(str(result.get('error', result)))
        if 'scope' in result:
            result['capture'] = Capture('scope', result.pop('scope'), self.rp.host).as_dict()
        return result

    def control(self, action, run_id):
        if action not in ('stop', 'keepalive'):
            raise ValueError('Unknown excitation action')
        # Stop must remain available while a capture holds the RP operation lock.
        result = self.rp.client.request('/excitation/' + action,
                                        json_body={'run_id': run_id}, timeout_s=5)
        if not result.get('ok'):
            raise RuntimeError(str(result.get('error', result)))
        return result


class ExcitationHardware:
    def __init__(self, rp):
        self.rp = rp
        self._lock = threading.RLock()
        self.token = None
        self.cancelled = threading.Event()
        self.deadline = 0.
        self.active = False
        self.owned = False
        self.error = None
        self.burst_until = None
        self._stopped = {}  # short tombstones also cover stop arriving before run

    def reserve(self, token):
        if not isinstance(token, str) or not 16 <= len(token) <= 64 or not token.isalnum():
            raise ValueError('Invalid excitation run ID')
        with self._lock:
            now = time.monotonic()
            self._stopped = {k: v for k, v in self._stopped.items() if v > now}
            if token in self._stopped:
                raise RuntimeError('本次激励已取消，未发送')
            if self.token is not None:
                raise RuntimeError('已有激励正在运行，请先停止')
            self.token = token
            self.cancelled = threading.Event()
            self.deadline = now + 10
            self.error = None
            self.burst_until = None
            self.owned = False

    def cancel(self, token):
        with self._lock:
            self._stopped[token] = time.monotonic() + 60
            if token == self.token:
                self.cancelled.set()

    def keepalive(self, token):
        with self._lock:
            if token != self.token and token in self._stopped:
                return dict(ok=True, run_id=token, active=False)
            if token != self.token or self.cancelled.is_set() or time.monotonic() >= self.deadline:
                raise RuntimeError(self.error or '激励已结束或连接租约已过期')
            self.deadline = time.monotonic() + 10
            return dict(ok=True, run_id=token, active=self.active)

    def check(self, token):
        if token != self.token or self.cancelled.is_set() or time.monotonic() >= self.deadline:
            raise RuntimeError('激励已取消或超时')

    def stop(self, token):
        if token != self.token:
            return dict(ok=True, active=False, ignored=True)
        if not self.owned:
            # A cancelled queued request has not acquired ASG1. In particular,
            # it must not switch off an output configured by another tool.
            with self._lock:
                self._stopped[token] = time.monotonic() + 60
                self.token = None
            return dict(ok=True, active=False, cancelled_before_output=True)
        asg = self.rp.asg1
        errors = []
        # 'on' only mutes DAC data. It does not stop the phase counter or
        # internal scope triggers. Clear the software-trigger selector before
        # other writes to the shared control word (which can pulse it again).
        for key, value in [('output_direct', 'off'), ('trigger_source', 'off'),
                           ('sm_reset', True), ('on', False)]:
            try:
                if key == 'trigger_source':
                    type(asg).trigger_source.set_value(asg, value)
                else:
                    setattr(asg, key, value)
            except Exception as exc:
                errors.append(str(exc))
        for restore in (lambda: self._repeat_gate(False), lambda: setattr(asg, 'bursts', 0)):
            try:
                restore()
            except Exception as exc:
                errors.append(str(exc))
        try:
            if asg.output_direct != 'off':
                errors.append('ASG1 输出关闭读回不一致')
            if not asg.sm_reset:
                errors.append('ASG1 内部发生器停止读回不一致')
        except Exception as exc:
            errors.append(str(exc))
        self.active = False
        if errors:
            self.error = '激励关闭未确认：' + '; '.join(errors)
            self.cancelled.set()
            raise RuntimeError(self.error)
        with self._lock:
            self._stopped[token] = time.monotonic() + 60
            self.token = None
            self.owned = False
        return dict(ok=True, active=False, output_off_confirmed=True)

    def tick(self):
        token = self.token
        if token and (self.cancelled.is_set() or time.monotonic() >= self.deadline
                      or self.burst_until is not None and time.monotonic() >= self.burst_until):
            try:
                self.stop(token)
            except Exception as exc:
                self.error = str(exc)

    def check_outputs(self):
        for name in OUTPUT_MODULES:
            route = str(getattr(self.rp, name).output_direct)
            if name == 'asg1':
                if route != 'off':
                    raise RuntimeError('ASG1 已被其他功能使用，请先关闭其输出')
            elif route in ('out1', 'both'):
                raise RuntimeError(f'{name} 已占用 OUT1，请先解除该路由')

    def _repeat_gate(self, enabled):
        # Pinned PyRPL FPGA, red_pitaya_asg.v set_b_rgate (control bit 24).
        # With software/off trigger sources, this holds the repetition counter
        # instead of decrementing it. No external gate is selected. PyRPL does
        # not expose the bit; preserve every other control bit, read back it.
        asg = self.rp.asg1
        mask = 1 << 24
        word = asg._read(0x0)
        asg._write(0x0, (word | mask) if enabled else (word & ~mask))
        if bool(asg._read(0x0) & mask) != enabled:
            raise RuntimeError('ASG1 周期重复控制读回不一致')

    def prepare(self, config):
        import numpy as np
        asg = self.rp.asg1
        asg.output_direct = 'off'
        type(asg).trigger_source.set_value(asg, 'off')
        asg.sm_reset = True
        asg.on = False
        self._repeat_gate(False)
        asg._counter_wrap = asg._default_counter_wrap
        asg._sm_wrappointer = True
        asg.frequency = config['frequency']
        asg.amplitude = config['amplitude']
        asg.offset = config['offset']
        asg.start_phase = 0
        asg.cycles_per_burst = config['cycles'] if config['mode'] != 'continuous' else 0
        # Pinned FPGA RTL loads this register as *additional* repetitions.
        # 1 with zero delay continuously reloads the cycle counter, so a
        # nominal finite burst never ends. Software fires the first burst;
        # 0 disables automatic repeats while cycles_per_burst limits its length.
        asg.bursts = 0
        asg.delay_between_bursts = 0
        asg.random_phase = False
        n = asg.data_length
        x = np.arange(n, dtype=float) / n
        wave = config['waveform']
        if wave == 'sin':
            values = np.sin(2 * np.pi * x)
        elif wave == 'square':
            values = np.where(x < .5, 1., -1.)
        elif wave == 'triangle':
            values = 1 - 4 * np.abs(x - .5)
        elif wave == 'sawtooth':
            values = 2 * x - 1
        else:
            raw = config['samples']
            values = np.interp(x, np.arange(len(raw) + 1) / len(raw), raw + raw[:1])
        asg.data = values
        actual = {k: getattr(asg, k) for k in ('frequency', 'amplitude', 'offset', 'cycles_per_burst', 'bursts')}
        if config['mode'] == 'periodic_burst':
            burst_duration = config['cycles'] / actual['frequency']
            gap = config['burst_period'] - burst_duration
            if gap < 1e-6:
                raise ValueError('按实际频率量化后，重复周期不足；请增大整包重复周期')
            # Never allow zero delay: it reloads cycles every FPGA clock.
            asg.delay_between_bursts = max(1, round(gap * 1e6))
            asg.bursts = 1
            self._repeat_gate(True)
            actual.update(bursts=1, repeat_until_stopped=True,
                          burst_duration=burst_duration,
                          gap_us=int(asg.delay_between_bursts),
                          nominal_burst_period=burst_duration + asg.delay_between_bursts / 1e6)
        return actual

    def fire(self, token):
        self.check(token)
        asg = self.rp.asg1
        asg.sm_reset = True
        asg.on = True
        asg.sm_reset = False
        asg.output_direct = 'out1'
        # Bypass call_setup only; descriptor still masks bits and tracks value.
        type(asg).trigger_source.set_value(asg, 'immediately')
        # The software trigger is a write strobe, not a level to leave enabled.
        # Removing it does not interrupt the already started finite waveform.
        type(asg).trigger_source.set_value(asg, 'off')
        self.active = True

    def run(self, token, settings):
        import numpy as np
        config = validate(settings)
        self.check(token)
        prepared = False
        try:
            # Ownership checked before any writes; do not stop someone else's ASG.
            self.check_outputs()
            self.owned = True
            prepared = True
            actual = self.prepare(config)
            if config['auto_duration'] and config['mode'] != 'continuous':
                # Quantized hardware frequency can be just below the requested one.
                plan = burst_capture_plan(actual['frequency'], config['cycles'])
                config['duration'] = plan['duration']
                actual['capture_plan'] = plan
            if config['mode'] == 'continuous' or not config['observe']:
                self.fire(token)
                if config['mode'] == 'burst':
                    self.burst_until = time.monotonic() + config['cycles'] / actual['frequency'] + .01
                return dict(ok=True, active=True, run_id=token, settings=config, actual=actual)
            from pyrpl.async_utils import ensure_future, wait, sleep_async
            scope = self.rp.scope
            scope.stop()
            scope.input1, scope.input2 = 'asg1', 'in2'
            scope.duration = config['duration']
            scope.trigger_source = 'asg1'
            scope.trigger_delay = 0
            scope.rolling_mode = False
            scope.trace_average = 1

            async def acquire():
                future = scope.single_async()
                try:
                    await sleep_async(.001)
                    while not (scope._trigger_armed and scope.pretrig_ok):
                        self.check(token)
                        await sleep_async(.001)
                    # Same pretrigger settling margin used by PyRPL's helper.
                    await sleep_async(.1)
                    self.fire(token)
                    fired = time.monotonic()
                    while not future.done():
                        self.check(token)
                        await sleep_async(.005)
                    curve = future.result()
                    while time.monotonic() - fired < config['cycles'] / actual['frequency']:
                        self.check(token)
                        await sleep_async(.005)
                    return curve
                finally:
                    if not future.done():
                        future.cancel()
                    scope.stop()
            task = ensure_future(acquire())
            try:
                curve = wait(task, timeout=max(8, float(scope.duration) + 3))
            finally:
                if not task.done():
                    task.cancel()
                    # Settle cancellation on the owner loop before another run
                    # can re-use scope; PyRPL.wait alone does not cancel it.
                    try:
                        wait(task, timeout=1)
                    except BaseException:
                        pass
                scope.stop()
            times = np.asarray(scope.times, dtype=float)
            payload = dict(ok=True, n=len(times), input1='asg1', input2='in2',
                           duration=float(scope.duration), trigger_source='asg1',
                           trigger_reference='internal_asg1_event_not_calibrated_out1_start',
                           excitation=dict(settings=config, actual=actual),
                           trace=dict(t=times.tolist(), ch1=np.asarray(curve[0]).tolist(),
                                      ch2=np.asarray(curve[1]).tolist(), decimation=1))
            self.stop(token)
            return dict(ok=True, active=False, run_id=token, scope=payload, actual=actual,
                        output_off_confirmed=True)
        except BaseException:
            if prepared or self.active:
                self.stop(token)
            else:
                with self._lock:
                    self.token = None
            raise
