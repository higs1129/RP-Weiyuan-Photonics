"""RP-side raw UART stream over SSH stdin/stdout; no protocol interpretation."""

import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.redpitaya'


import argparse
import fcntl
import os
import select
import signal
import subprocess
import sys
import termios


def write_all(fd, data):
    view = memoryview(data)
    while view:
        select.select([], [fd], [])
        count = os.write(fd, view)
        if count <= 0:
            raise IOError('Stream closed during write')
        view = view[count:]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', required=True)
    parser.add_argument('--baudrate', type=int, default=9600)
    parser.add_argument('--service', default='weiyuan-uart.service')
    args = parser.parse_args()
    if 'console=' + os.path.basename(args.device) in open('/proc/cmdline').read():
        raise RuntimeError('Refusing to bridge a system console')
    def interrupted(*_):
        raise SystemExit('SSH UART stream interrupted')
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, interrupted)
    was_active = subprocess.call(['systemctl', 'is-active', '--quiet', args.service]) == 0
    fd = None
    try:
        if was_active:
            subprocess.check_call(['systemctl', 'stop', args.service])
        fd = os.open(args.device, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.ioctl(fd, termios.TIOCEXCL)
        attrs = termios.tcgetattr(fd)
        attrs[0] = attrs[1] = attrs[3] = 0
        attrs[2] = termios.CS8 | termios.CREAD | termios.CLOCAL
        attrs[4] = attrs[5] = getattr(termios, 'B' + str(args.baudrate))
        attrs[6][termios.VMIN] = attrs[6][termios.VTIME] = 0
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
        termios.tcflush(fd, termios.TCIFLUSH)
        print('UART_STREAM_READY', file=sys.stderr, flush=True)
        while True:
            ready, _, _ = select.select([fd, 0], [], [])
            if 0 in ready:
                data = os.read(0, 4096)
                if not data:
                    break
                write_all(fd, data)
            if fd in ready:
                data = os.read(fd, 4096)
                if data:
                    write_all(1, data)
    finally:
        if fd is not None:
            try:
                fcntl.ioctl(fd, termios.TIOCNXCL)
            finally:
                os.close(fd)
        if was_active:
            subprocess.call(['systemctl', 'start', args.service])


if __name__ == '__main__':
    main()
