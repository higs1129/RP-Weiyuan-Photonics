"""Bounded, read-only evidence collected after a failed explicit connection."""
import ipaddress
import socket
from .network import _powershell_json, _active_mac, identity_matches


def local_interfaces():
    return _powershell_json('''Get-NetIPInterface -AddressFamily IPv4 | ForEach-Object {
 $iface=$_; $nic=Get-NetAdapter -InterfaceIndex $iface.InterfaceIndex -ErrorAction SilentlyContinue
 Get-NetIPAddress -InterfaceIndex $iface.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object {
 [PSCustomObject]@{name=$iface.InterfaceAlias; index=$iface.InterfaceIndex; address=$_.IPAddress;
 prefix=$_.PrefixLength; dhcp=($iface.Dhcp -eq 'Enabled'); metric=$iface.InterfaceMetric;
 state=[string]$iface.ConnectionState; description=$nic.InterfaceDescription}
 }
} | ConvertTo-Json -Compress''')


def collect(host, board=None, error=''):
    report = {'host': host, 'board': board, 'summary': str(error), 'detail': str(error), 'interfaces': [], 'checks': [],
              'advice': [], 'read_only': True}
    try:
        report['interfaces'] = [row for row in local_interfaces()
                                if not ipaddress.ip_address(row['address']).is_loopback]
    except Exception as exc:
        report['local_error'] = str(exc)
    if not board:
        report['advice'] = ['连接 CON 数据线后重新检查，可读取 RP 的实际 IP 和网口速率。']
        return report
    addresses = board.get('addresses', [])
    if board.get('carrier') != '1':
        report['summary'] = 'RP 网口未建立物理链路'
        report['advice'] = ['检查 RP 网线、交换机端口和供电。']
        return report
    if not addresses:
        report['summary'] = 'RP 物理链路正常，但尚未取得 IPv4 地址'
        report['advice'] = ['检查交换机上联网络是否提供 DHCP；普通交换机本身通常不分配 IP。']
        return report
    report['summary'] = 'RP 已有 IP，但本机尚未通过板卡身份与通信验证'
    for row in report['interfaces']:
        row['rp_same_subnet'] = False
        try:
            network = ipaddress.ip_network(f"{row['address']}/{row['prefix']}", strict=False)
            row['rp_same_subnet'] = any(ipaddress.ip_address(ip) in network for ip in addresses)
        except ValueError:
            continue
        if row.get('state') != 'Connected' or not row['rp_same_subnet']:
            continue
        for address in addresses:
            if ipaddress.ip_address(address) not in network or len(report['checks']) >= 8:
                continue
            check = {'interface': row['name'], 'source': row['address'], 'target': address}
            try:
                check['mac_matches'] = identity_matches(host, _active_mac(address, source=row['address']))
                with socket.socket() as channel:
                    channel.settimeout(.6)
                    channel.bind((row['address'], 0))
                    channel.connect((address, 22))
                    check['ssh_reachable'] = True
            except OSError:
                check['ssh_reachable'] = False
            report['checks'].append(check)
    connected = [row for row in report['interfaces'] if row.get('state') == 'Connected']
    if not any(row['rp_same_subnet'] for row in connected):
        report['summary'] = 'RP 已有 IP，但电脑已连接的网卡与其网段不匹配'
    if any(not row['rp_same_subnet'] and not row.get('dhcp') for row in connected):
        report['advice'].append('存在不匹配的固定 IP 网卡。确认哪块网卡接了 RP，先保存原配置；有 DHCP 时可改为自动获取，专用网卡可配置匹配地址。')
    if len(connected) > 1:
        report['advice'].append('同时存在多个网络连接；核对有线、Wi-Fi 或 VPN 是否连接同一局域网，以及交换机隔离、路由优先级。')
    report['advice'].append('软件不会自动修改电脑的 IP、网关或 DNS。若 MAC 已匹配但 SSH 不通，再检查 RP 启动状态及网络访问限制。')
    return report
