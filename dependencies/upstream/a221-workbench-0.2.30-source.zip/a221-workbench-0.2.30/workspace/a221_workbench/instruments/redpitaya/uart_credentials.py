"""Read and verify a managed UART credential through an authenticated board session."""
import re

REMOTE = r'''
import json,shlex,subprocess,urllib.request
from pathlib import Path
unit=Path('/etc/systemd/system/a221-weiyuan-uart.service').read_text()
if not unit.startswith('# Managed by a221-workbench: Weiyuan UART'):
    raise RuntimeError('Not an A221 managed UART service')
starts=[shlex.split(line.split('=',1)[1]) for line in unit.splitlines() if line.startswith('ExecStart=')]
if len(starts)!=1 or '--token-file' not in starts[0]:
    raise RuntimeError('Unknown UART service configuration')
args=starts[0]
path=Path(args[args.index('--token-file')+1]).resolve()
if not str(path).startswith('/root/weiyuan-uart/') or path.name!='token':
    raise RuntimeError('Unexpected UART credential location')
pid=int(subprocess.check_output(['systemctl','show','-p','MainPID','--value','a221-weiyuan-uart.service']))
if pid<=0: raise RuntimeError('UART service is not running')
running=Path('/proc/'+str(pid)+'/cmdline').read_bytes().decode().split(chr(0))
if '--token-file' not in running or Path(running[running.index('--token-file')+1]).resolve()!=path:
    raise RuntimeError('Running service configuration does not match')
token=path.read_text().strip()
if not token or len(token)>512: raise RuntimeError('Invalid credential file')
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
health=json.load(opener.open('http://127.0.0.1:8092/health',timeout=3))
if health.get('service')!='weiyuan-uart' or int(health.get('pid',0))!=pid or health.get('mac','').lower()!=Path('/sys/class/net/eth0/address').read_text().strip().lower():
    raise RuntimeError('UART endpoint identity does not match')
request=urllib.request.Request('http://127.0.0.1:8092/verify',headers={'Authorization':'Bearer '+token})
verified=json.load(opener.open(request,timeout=3))
if not verified.get('ok') or verified.get('service')!='weiyuan-uart':
    raise RuntimeError('UART credential verification failed')
result={'token':token}
'''

def validate_token(token):
    if not isinstance(token, str) or not re.fullmatch(r"[A-Za-z0-9_\-]{16,512}", token):
        raise RuntimeError("Unexpected UART credential format")
    return token
