"""Disable and read back RP output registers on the PyRPL owner thread."""
import math
import time

OUTPUT_MODULES = ('asg0', 'asg1', 'pid0', 'pid1', 'pid2', 'iq0', 'iq1', 'iq2', 'trig', 'iir')
OFF_VALUES = (
    [(name, 'output_direct', 'off') for name in OUTPUT_MODULES]
    + [(name, attr, 0.0) for name in ('asg0', 'asg1') for attr in ('amplitude', 'offset')]
    + [(name, attr, 0.0) for name in ('pid0', 'pid1', 'pid2') for attr in ('p', 'i', 'ival')]
    + [(name, 'amplitude', 0.0) for name in ('iq0', 'iq1', 'iq2')]
    + [('pwm0', 'input', 'off'), ('pwm1', 'input', 'off')]
)


def outputs_state(rp):
    values, errors = {}, []
    for name, attr, expected in OFF_VALUES:
        key = name + '.' + attr
        try:
            value = getattr(getattr(rp, name), attr)
            value = str(value) if isinstance(expected, str) else float(value)
            values[key] = value
            if value != expected:
                errors.append(f'{key} is {value!r}, expected {expected!r}')
        except Exception as exc:
            errors.append(f'{key}: {exc}')
    sample = {}
    for name in ('out1', 'out2'):
        try:
            sample[name + '_v'] = float(getattr(rp.sampler, name))
            if not math.isfinite(sample[name + '_v']):
                raise ValueError('Non-finite sampler readback')
        except Exception as exc:
            errors.append(f'sampler.{name}: {exc}')
    return dict(ok=not errors, outputs_off_confirmed=not errors,
                registers=values, sampler=sample, errors=errors, sampled_at=time.time())


def disable_outputs(p):
    errors = []
    # Stop software tasks that could enable an IQ or ASG again after register writes.
    for name in ('networkanalyzer', 'spectrumanalyzer', 'scope'):
        try:
            getattr(p.rp if name == 'scope' else p, name).stop()
        except Exception as exc:
            errors.append(f'{name}.stop: {exc}')
    for name, attr, value in OFF_VALUES:
        try:
            setattr(getattr(p.rp, name), attr, value)
        except Exception as exc:
            errors.append(f'{name}.{attr}: {exc}')
    result = outputs_state(p.rp)
    result['write_errors'] = errors
    result['ok'] = result['outputs_off_confirmed'] = result['ok'] and not errors
    return result
