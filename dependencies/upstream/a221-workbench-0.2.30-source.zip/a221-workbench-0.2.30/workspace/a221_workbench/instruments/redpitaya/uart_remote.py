"""Inspect/deploy the UART service over SSH using the existing PyRPL Python.

Only the selected tty is used; console services and pinmux are never changed.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.redpitaya'

from a221_workbench._shared.paths import module_file, project_root
from a221_workbench.instruments.redpitaya.network import rp_identity, identity_matches


import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import sys
import time
import os
import tempfile
from .uart_credentials import REMOTE as CREDENTIAL_PROBE, validate_token


INSPECT = r'''
import glob,json,os,sys
def read(path):
    try:
        with open(path) as f:return f.read().strip().replace(chr(0),'')
    except IOError:return ''
cmdline=read('/proc/cmdline')
devices=[]
for path in sorted(set(glob.glob('/dev/ttyPS*')+glob.glob('/dev/ttyAMA*')+glob.glob('/dev/ttyS*')+glob.glob('/dev/ttyUSB*')+glob.glob('/dev/ttyACM*'))):
    owners=[]
    for fd in glob.glob('/proc/[0-9]*/fd/*'):
        try:
            if os.path.realpath(fd)==path:
                pid=fd.split('/')[2]
                if pid not in owners:owners.append(pid)
        except OSError:pass
    devices.append(dict(device=path,console=('console='+os.path.basename(path)) in cmdline,owner_pids=owners))
print(json.dumps(dict(ok=True,hostname=read('/etc/hostname'),mac=read('/sys/class/net/eth0/address'),
    model=read('/proc/device-tree/model'),os_release=read('/etc/os-release'),python=list(sys.version_info[:3]),devices=devices)))
'''


SERVICE = 'a221-weiyuan-uart.service'
MARKER = '# Managed by a221-workbench: Weiyuan UART'


def service_health(client, port=8092):
    """Only a refused TCP connection means absent; other failures stay explicit."""
    probe = '''
import errno,json,urllib.request,urllib.error
try:
    response=urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:%d/health',timeout=2)
    print(json.dumps({'present':True,'health':json.load(response)}))
except urllib.error.URLError as e:
    if getattr(e.reason,'errno',None)!=errno.ECONNREFUSED: raise
    print(json.dumps({'present':False}))
''' % int(port)
    return json.loads(command(client, 'python3 -c ' + shlex.quote(probe)))


def choose_device(board, device=None):
    if device:
        rows = [row for row in board['devices'] if row['device'] == device]
    else:
        # External USB serial devices may belong to unrelated instruments.
        rows = [row for row in board['devices'] if re.fullmatch(r'/dev/tty(?:PS|AMA)\d+', row['device'])
                and not row['console'] and not row['owner_pids']]
    if len(rows) != 1 or rows[0]['console'] or rows[0]['owner_pids']:
        raise RuntimeError('未找到唯一空闲的板载激光器 UART；请在高级连接检查中选择实际接线端口，不会改动系统控制台或抢占串口')
    return rows[0]['device']


def ensure_service(client, board, *, device, token, port=8092, adopt_token=None):
    status = service_health(client, port)
    if status['present']:
        health = status['health']
        if (health.get('service') != 'weiyuan-uart' or
                health.get('hostname', '').lower() != board['hostname'].lower() or
                (health.get('mac') and health['mac'].lower() != board['mac'].lower())):
            raise RuntimeError('8092 端口的服务身份与当前 RP 不符，未接管或重启')
        actual = health.get('device')
        row = next((r for r in board['devices'] if r['device'] == actual), None)
        if row is None or row['console'] or (device and device != actual):
            raise RuntimeError('现有服务串口与所选端口不一致，未切换正在使用的服务')
        # Verify auth without sending serial bytes. Legacy service auth is checked
        # by the subsequent read-only laser status request; never replace its token.
        verify = '''
import json,urllib.request,urllib.error
request=urllib.request.Request('http://127.0.0.1:%d/verify',headers={'Authorization':'Bearer '+%s})
try:
    response=urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=2)
    data=json.load(response)
    if data.get('service')!='weiyuan-uart' or not data.get('ok'): raise RuntimeError('Invalid UART verifier')
except urllib.error.HTTPError as e:
    if e.code in (401,403):
        print(json.dumps({'authorized':False}))
        raise SystemExit(0)
    if e.code!=404: raise
print(json.dumps({'authorized':True}))
''' % (int(port), repr(token))
        authenticated = json.loads(command(client, 'python3 -c ' + shlex.quote(verify)))
        synced = False
        if not authenticated['authorized']:
            if adopt_token is None:
                raise RuntimeError('串口访问凭据与 RP 不一致；已明确指定的凭据不会被自动覆盖，请检查 uart_token 或 WEIYUAN_UART_TOKEN')
            # The board has already passed SSH/MAC and endpoint/device checks.
            # This read also verifies managed unit, live PID and /verify; it never
            # changes the RP token, restarts the service or sends UART bytes.
            probe = CREDENTIAL_PROBE + '\nprint(json.dumps(result))\n'
            existing = validate_token(json.loads(command(client, 'python3 -c ' + shlex.quote(probe), timeout=15))['token'])
            adopt_token(existing)
            synced = True
        enabled = command(client, 'systemctl is-enabled ' + SERVICE + ' 2>/dev/null || true').strip() == 'enabled'
        pid = command(client, 'systemctl show -p MainPID --value ' + SERVICE).strip()
        enabled = enabled and str(health.get('pid')) == pid and pid != '0'
        result = {'ok': True, 'service': health, 'reused': True, 'persistent': enabled, 'laser_verified': False, 'credential_synced': synced}
        if not enabled:
            result['warning'] = '复用现有临时串口服务；下次板卡重启后连接时会自动安装开机服务'
        return result
    return deploy(client, board, device=choose_device(board, device), token=token, port=port)


def command(client, text, timeout=10):
    _, stdout, stderr = client.exec_command(text, timeout=timeout)
    output, error = stdout.read().decode(), stderr.read().decode()
    if stdout.channel.recv_exit_status():
        raise RuntimeError(error.strip() or output.strip() or 'RP command failed')
    return output


def inspect_board(client):
    return json.loads(command(client, 'python3 -c ' + shlex.quote(INSPECT)))


def save_local_token(directory, token):
    token = validate_token(token)
    target = Path(directory) / 'uart-token'
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=directory,
                                     prefix='uart-token-', delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(token)
    try:
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)


def deploy(client, board, *, device, token, port=8092):
    if not re.fullmatch(r'/dev/tty(?:PS|AMA|S|USB|ACM)\d+', device or ''):
        raise ValueError('先检查 RP，并选择实际连接激光器的 UART 设备节点')
    if tuple(board['python']) < (3, 5):
        raise RuntimeError('RP 的 python3 版本需要至少 3.5')
    selected = next((row for row in board['devices'] if row['device'] == device), None)
    if selected is None or selected['console'] or selected['owner_pids']:
        raise RuntimeError('UART 不存在、用作系统控制台或正被其他进程使用；没有修改占用服务')
    if not token:
        raise ValueError('UART authentication token is missing')
    sources = [module_file('a221_workbench.instruments.redpitaya.uart_service'), Path(__file__).parents[1] / 'transports/posix_serial.py']
    version = hashlib.sha256(b''.join(path.read_bytes() for path in sources)).hexdigest()[:12]
    base = '/root/weiyuan-uart/' + version
    preflight = '''
from pathlib import Path
import shlex,socket,subprocess
unit=Path('/etc/systemd/system/%s')
if unit.exists():
    text=unit.read_text()
    if not text.startswith(%r): raise RuntimeError('UART unit belongs to another configuration')
    for line in text.splitlines():
        if line.startswith('ExecStart='):
            args=shlex.split(line.split('=',1)[1])
            if '--token-file' not in args: raise RuntimeError('Unknown UART service configuration')
            old=Path(args[args.index('--token-file')+1])
            if old.exists() and old.read_text().strip()!=%r: raise RuntimeError('UART token mismatch; existing configuration was not changed')
    state=subprocess.check_output(['systemctl','show','-p','ActiveState','--value',%r]).decode().strip()
    if state in ('active','activating','reloading'): raise RuntimeError('UART unit is running but unhealthy; not restarted automatically')
probe=socket.socket();probe.bind(('0.0.0.0',%d));probe.close()
''' % (SERVICE, MARKER, token, SERVICE, int(port))
    command(client, 'python3 -c ' + shlex.quote(preflight))
    command(client, 'mkdir -p ' + shlex.quote(base) + ' && chmod 700 ' + shlex.quote(base))
    with client.open_sftp() as sftp:
        for path in sources:
            sftp.put(str(path), base + '/' + path.name)
        with sftp.open(base + '/token', 'w') as stream:
            stream.write(token)
        sftp.chmod(base + '/token', 0o600)
    # Check bind availability before launching; never kill another service.
    probe = 'import socket;s=socket.socket();s.bind(("0.0.0.0",{}));s.close()'.format(int(port))
    command(client, 'python3 -c ' + shlex.quote(probe))
    start = ['/usr/bin/python3', '-u', base + '/uart_service.py', '--device', device,
             '--listen', '0.0.0.0', '--port', str(port), '--token-file', base + '/token']
    unit = (MARKER + '\n[Unit]\nDescription=Weiyuan UART forwarding\nAfter=network.target\n'
            '\n[Service]\nType=simple\nExecStart=' + ' '.join(start) + '\nRestart=on-failure\n'
            'RestartSec=2\nUMask=0077\n\n[Install]\nWantedBy=multi-user.target\n')
    install = '''
from pathlib import Path
path=Path('/etc/systemd/system/%s')
if path.exists() and not path.read_text().startswith(%r):
    raise RuntimeError('UART unit belongs to another configuration')
temp=path.with_suffix('.tmp')
temp.write_text(%r)
temp.replace(path)
''' % (SERVICE, MARKER, unit)
    command(client, 'python3 -c ' + shlex.quote(install))
    command(client, 'systemctl daemon-reload && systemctl enable --now ' + SERVICE)
    for _ in range(20):
        try:
            probe = 'import urllib.request;print(urllib.request.urlopen("http://127.0.0.1:{}/health",timeout=1).read().decode())'.format(port)
            health = json.loads(command(client, 'python3 -c ' + shlex.quote(probe), timeout=3))
            if (health.get('service') == 'weiyuan-uart' and health.get('device') == device
                    and health.get('mac') == board['mac']
                    and health.get('hostname') == board['hostname']):
                return {'ok': True, 'service': health, 'installed_path': base, 'persistent': True, 'reused': False,
                        'laser_verified': False, 'note': '服务已启动；激光器应答需单独读回验证'}
        except Exception:
            time.sleep(0.25)
    raise RuntimeError('UART 服务未就绪；请查看 journalctl -u ' + SERVICE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['inspect', 'deploy', 'ensure'])
    parser.add_argument('--host', required=True)
    parser.add_argument('--settings', type=Path, required=True)
    args = parser.parse_args()
    try:
        import paramiko
        settings = json.loads(args.settings.read_text(encoding='utf-8'))
        client = paramiko.SSHClient()
        identity = rp_identity(settings.get('expected_host', args.host))
        keys = args.settings.parent / ('known_hosts-' + identity if identity else 'known_hosts')
        if keys.exists():
            client.load_host_keys(str(keys))
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh = settings.get('ssh', {})
        client.connect(args.host, port=ssh.get('port', 22), username=ssh.get('user', 'root'),
                       password=ssh.get('password', 'root'), timeout=5, auth_timeout=5,
                       banner_timeout=5, look_for_keys=False, allow_agent=False)
        try:
            client.save_host_keys(str(keys))
            board = inspect_board(client)
            if identity and not identity_matches(settings.get('expected_host', args.host), board['mac']):
                raise RuntimeError('RP 主机名与板端网卡地址不匹配')
            if not board['hostname'].lower().startswith('rp-') and 'red pitaya' not in board['model'].lower():
                raise RuntimeError('目标未识别为 Red Pitaya，未部署服务')
            adopt = (lambda token: save_local_token(args.settings.parent, token)) if settings.get('sync_existing_token') else None
            result = board if args.action == 'inspect' else ensure_service(client, board, device=settings.get('uart_device'), token=settings.get('uart_token', ''), adopt_token=adopt)
        finally:
            client.close()
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except Exception as exc:
        print(json.dumps({'ok': False, 'error': str(exc)}, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    sys.exit(main())
