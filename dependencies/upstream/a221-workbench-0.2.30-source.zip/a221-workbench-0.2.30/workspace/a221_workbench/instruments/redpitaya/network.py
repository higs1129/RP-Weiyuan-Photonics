"""Find an RP's current DHCP address by name and verified LAN MAC identity."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.redpitaya'


import ctypes
import ipaddress
import json
import os
import re
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor


class HostNotFound(RuntimeError):
    """Discovery found no matching board; distinct from ambiguous identity."""


def rp_identity(host):
    match = re.fullmatch(r'rp-([0-9a-f]{6}|[0-9a-f]{12})(?:\.local)?\.?', str(host).strip(), re.I)
    return match.group(1).lower() if match else None


def identity_matches(expected, mac):
    identity = rp_identity(expected)
    actual = re.sub(r'[:-]', '', str(mac)).lower()
    return bool(identity and re.fullmatch(r'[0-9a-f]{12}', actual) and actual.endswith(identity))


def _powershell_json(script):
    script = '$env:PSModulePath="$PSHOME\\Modules;"+$env:PSModulePath; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); ' + script
    result = subprocess.run(['powershell.exe', '-NoProfile', '-Command', script],
                            capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=10,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise RuntimeError('Windows network discovery failed: ' + result.stderr.strip())
    value = json.loads(result.stdout.lstrip('\ufeff') or '[]')
    return [value] if isinstance(value, dict) else (value or [])


def _neighbors():
    return _powershell_json('Get-NetNeighbor -AddressFamily IPv4 | '
                            'Select-Object IPAddress,LinkLayerAddress | ConvertTo-Json -Compress')


def _active_mac(address, source=None):
    """Verify local LAN identity with SendARP instead of trusting a stale row."""
    destination = int.from_bytes(socket.inet_aton(address), 'little')
    buffer = (ctypes.c_ubyte * 8)()
    size = ctypes.c_ulong(6)
    origin = int.from_bytes(socket.inet_aton(source), 'little') if source else 0
    result = ctypes.windll.iphlpapi.SendARP(ctypes.c_ulong(destination), ctypes.c_ulong(origin),
                                         ctypes.byref(buffer), ctypes.byref(size))
    if result != 0 or size.value != 6:
        return ''
    return ':'.join(f'{value:02x}' for value in buffer[:6])


def _local_scan_addresses():
    # Only up physical adapters; exclude VPNs and cap each LAN scan to /24.
    rows = _powershell_json('Get-NetAdapter -Physical | Where-Object Status -eq Up | '
        'Get-NetIPAddress -AddressFamily IPv4 | Select-Object IPAddress,PrefixLength | ConvertTo-Json -Compress')
    addresses = set()
    ranges = [ipaddress.ip_network(value) for value in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')]
    for row in rows:
        address = ipaddress.ip_address(row['IPAddress'])
        if not any(address in network for network in ranges):
            continue
        network = ipaddress.ip_network(f"{address}/{max(24, int(row['PrefixLength']))}", strict=False)
        addresses.update(str(item) for item in network.hosts() if item != address)
    return sorted(addresses)


def _probe(address):
    # Populate the neighbor table without sending application commands.
    try:
        with socket.create_connection((address, 22), timeout=0.2):
            pass
    except OSError:
        pass


def resolve_host(host, *, discover=True):
    host = str(host).strip()
    if not host or any(c in host for c in '/\\?#@ \r\n'):
        raise ValueError('请填写 RP 名称或 IP')
    identity = rp_identity(host)
    canonical = 'RP-' + identity[-6:] if identity else host
    # RP advertises its factory name through mDNS. Try that before a bare
    # Windows/DNS lookup, which may time out on every status read.
    candidates = [canonical + '.local', canonical] if identity else ([host] if '.' in host or ':' in host else [host, host + '.local'])
    addresses = set()
    for candidate in candidates:
        try:
            addresses.update(item[4][0] for item in socket.getaddrinfo(candidate, None, socket.AF_INET, socket.SOCK_STREAM))
        except OSError:
            pass
        if addresses and not identity:
            if len(addresses) == 1:
                return candidate, addresses.pop()
            raise RuntimeError('地址无法唯一解析：' + host)
        if identity and os.name == 'nt':
            verified = [address for address in addresses if identity_matches(host, _active_mac(address))]
            if len(verified) == 1:
                return canonical, verified[0]
            if len(verified) > 1:
                raise RuntimeError(f'{canonical} 对应多个活动地址：{verified}；拒绝猜测设备')
    if not identity or os.name != 'nt':
        # Other platforms use DNS; SGM still checks service identity before POST.
        if len(addresses) == 1:
            return canonical, addresses.pop()
        raise RuntimeError('地址无法唯一解析：' + host)

    def matched_neighbors():
        for row in _neighbors():
            if identity_matches(host, row.get('LinkLayerAddress', '')):
                addresses.add(row['IPAddress'])
        return [address for address in sorted(addresses) if identity_matches(host, _active_mac(address))]

    matches = matched_neighbors()
    if not matches and discover:
        with ThreadPoolExecutor(max_workers=32) as pool:
            list(pool.map(_probe, _local_scan_addresses()))
        matches = matched_neighbors()
    if len(matches) == 1:
        return canonical, matches[0]
    if len(matches) > 1:
        raise RuntimeError(f'{canonical} 对应多个活动地址：{matches}；拒绝猜测设备')
    raise HostNotFound(f'找不到 {canonical}：名称解析及本机局域网 MAC 查找均未找到匹配设备；未使用旧 IP。请检查供电、网线及是否在同一局域网。')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('host')
    args = parser.parse_args()
    try:
        name, address = resolve_host(args.host)
        print(json.dumps(dict(ok=True, host=name, address=address), ensure_ascii=False))
    except Exception as exc:
        print(json.dumps(dict(ok=False, error=str(exc)), ensure_ascii=False))
        raise SystemExit(1)
