"""Loaded backend identity and conservative, read-only replacement preflight."""
from pathlib import Path
import hashlib
from importlib.metadata import version, PackageNotFoundError
from .output_safety import OUTPUT_MODULES


def backend_identity():
    # Snapshot once at startup: replacing files must not relabel a live process.
    digest = hashlib.sha256()
    for path in sorted(Path(__file__).parent.glob('*.py')):
        digest.update(path.name.encode())
        digest.update(path.read_bytes().replace(b'\r\n', b'\n'))
    try:
        pyrpl = version('pyrpl')
    except PackageNotFoundError:
        pyrpl = 'unavailable'
    from a221_workbench import __version__
    return dict(core_version=__version__, driver_sha256=digest.hexdigest(), pyrpl_version=pyrpl)


def assert_idle(client):
    """Unknown/unreadable state is never permission to replace a backend."""
    prefix = '后台版本需要更新；当前正在使用设备或无法确认空闲，已保留现场。请停止采集、激励和守护后重新连接。'
    health = client.health(timeout_s=2)
    if not health.get('ok'):
        raise RuntimeError(prefix)
    activity = health.get('activity', {})
    if activity.get('excitation_owned') or activity.get('queued_commands'):
        raise RuntimeError(prefix)
    state = client.request('/outputs/state', timeout_s=3, return_errors=True)
    registers = state.get('registers', {})
    routes = [name + '.output_direct' for name in OUTPUT_MODULES] + ['pwm0.input', 'pwm1.input']
    if any(registers.get(key) != 'off' for key in routes):
        raise RuntimeError(prefix)
    for module in ('scope', 'spectrumanalyzer', 'networkanalyzer'):
        reply = client.get(module + '.running_state', timeout_s=2, return_errors=True)
        if not reply.get('ok') or reply.get('value') != 'stopped':
            raise RuntimeError(prefix)
