"""Start or reuse a local PyRPL bridge for the requested RP."""

from __future__ import annotations
from a221_workbench._shared.paths import module_file, project_root

import json
import hashlib
from pathlib import Path
import socket
import subprocess
import threading
import time
import os
from urllib.parse import urlparse

from .bridge_client import BridgeClient
from .device import RedPitaya, BridgeIdentityMismatch
from .network import resolve_host, rp_identity
from a221_workbench._shared.paths import configuration_dir


def runtime_python(configured=None):
    configured = configured or os.environ.get('A221_RUNTIME_PYTHON')
    if configured:
        path = Path(configured).expanduser()
    else:
        config = configuration_dir('redpitaya_microcavity_lock') / 'runtime.local.json'
        if not config.is_file():
            raise RuntimeError('尚未配置 PyRPL Python；请在 config.local.json 填写 pyrpl_python')
        path = Path(json.loads(config.read_text(encoding='utf-8-sig'))['runtime_python'])
    if not path.is_file():
        raise RuntimeError('PyRPL Python 不存在：' + str(path))
    return path


class BridgeRuntime:
    def __init__(self, base_url, *, state_dir, python=None, timeout_s=60, auto_select=False, upgrade_idle=False):
        self.client = BridgeClient(base_url)
        self.state_dir = Path(state_dir)
        self.python = python
        self.timeout_s = timeout_s
        self.process = None
        self.auto_select = auto_select
        self.upgrade_idle = upgrade_idle
        self._lock = threading.Lock()

    def _client_for_host(self, host):
        address = resolve_host(host)[1]
        port = 18000 + int(hashlib.sha256(address.encode('ascii')).hexdigest()[:8], 16) % 20000
        return BridgeClient(f'http://127.0.0.1:{port}', timeout_s=30)

    def client_for_restart(self, host):
        """Select an endpoint without touching a broken hardware connection.

        This is only a selection hint; restart_bridge validates the OS process,
        board identity and port ownership before stopping anything.
        """
        if not self.auto_select:
            return self.client
        health = self.client.health(timeout_s=1)
        meta = health.get('bridge', {})
        requested = rp_identity(host)
        reported = rp_identity(meta.get('rp_identity')) or rp_identity(meta.get('hostname'))
        if requested and reported:
            if requested == reported:
                return self.client
        elif meta.get('hostname'):
            try:
                if resolve_host(host)[1] == resolve_host(meta['hostname'])[1]:
                    return self.client
            except (OSError, ValueError, RuntimeError):
                pass
        return self._client_for_host(host)

    def _select_client(self, host):
        """Reuse a matching bridge, otherwise use a stable port for this IP.

        Selection is opt-in: explicitly configured bridge URLs stay strict.
        An existing bridge for another board is never stopped or repointed.
        Name and IP aliases resolve to the same candidate port; an occupied
        candidate is rejected rather than searching arbitrary ports.
        """
        parsed = urlparse(self.client.base)
        if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost'):
            raise ValueError('自动分配只支持本机 HTTP bridge')
        health = self.client.health(timeout_s=1)
        if health.get('ok'):
            try:
                RedPitaya(host, client=self.client).connect()
                return
            except BridgeIdentityMismatch:
                pass
        if self.process and self.process.poll() is None:
            raise RuntimeError('本会话的 PyRPL 仍在运行或启动；请稍后重试')
        self.client = self._client_for_host(host)

    def ensure(self, host):
        with self._lock:
            if self.auto_select:
                self._select_client(host)
            health = self.client.health(timeout_s=1)
            if health.get('ok'):
                # Identity check also rejects an existing bridge for another RP.
                connected = RedPitaya(host, client=self.client).connect()
                if self.upgrade_idle:
                    from .bridge_version import backend_identity, assert_idle
                    expected = backend_identity()
                    if health.get('backend_identity') != expected:
                        assert_idle(self.client)
                        from a221_workbench.tasks.redpitaya.restart_bridge import restart_bridge
                        def started(proc, result):
                            self.process = proc
                        def preflight():
                            RedPitaya(host, client=self.client).connect()
                            assert_idle(self.client)
                        result = restart_bridge(host, bridge_url=self.client.base,
                            state_dir=self.state_dir / 'upgrades', python=self.python,
                            timeout_s=self.timeout_s, _on_started=started, _before_stop=preflight)
                        if not result.get('ok'):
                            raise RuntimeError('后台自动更新未完成：' + result.get('error', str(result)))
                        if self.client.health().get('backend_identity') != expected:
                            raise RuntimeError('新后台版本与当前应用依赖不一致，请检查所选 PyRPL Python 环境')
                        connected = RedPitaya(host, client=self.client).connect()
                return connected
            if self.process and self.process.poll() is None:
                raise RuntimeError('PyRPL 已在启动或暂时没有响应；请稍后重新检查，不会重复启动。')
            parsed = urlparse(self.client.base)
            if parsed.hostname not in ('127.0.0.1', 'localhost') or parsed.scheme != 'http':
                raise RuntimeError('远程 bridge 未响应；自动启动仅支持本机 bridge')
            port = parsed.port or 80
            with socket.socket() as probe:
                if probe.connect_ex((parsed.hostname, port)) == 0:
                    raise RuntimeError('Bridge 端口被其他服务占用，或服务未就绪')
            _, address = resolve_host(host)
            try:
                with socket.create_connection((address, 22), timeout=3):
                    pass
            except OSError as exc:
                raise RuntimeError('RP 的 SSH 端口不可达：' + address) from exc
            python = runtime_python(self.python)
            self.state_dir.mkdir(parents=True, exist_ok=True)
            # Every new session starts from the shipped output-off configuration.
            # PyRPL can modify its own runtime copy; never overwrite the template.
            config = self.state_dir / ('session-' + str(time.time_ns()) + '.yml')
            config.write_text(Path(__file__).with_name('console_startup.yml').read_text(encoding='utf-8'), encoding='utf-8')
            command = [str(python), '-X', 'utf8', str(module_file('a221_workbench.instruments.redpitaya.pyrpl_backend')),
                       '--hostname', address, '--rp-identity', host, '--config', str(config), '--headless', '--allow-risky',
                       '--listen-port', str(port)]
            with (self.state_dir / 'bridge.log').open('ab') as log:
                self.process = subprocess.Popen(command, cwd=project_root(), stdout=log, stderr=log,
                                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            deadline = time.monotonic() + self.timeout_s
            while time.monotonic() < deadline:
                health = self.client.health(timeout_s=1)
                if health.get('ok'):
                    return RedPitaya(host, client=self.client).connect()
                if self.process.poll() is not None:
                    raise RuntimeError('PyRPL 启动失败，查看日志：' + str(self.state_dir / 'bridge.log'))
                time.sleep(0.25)
            raise TimeoutError('PyRPL 尚未就绪；可稍后重试连接，日志：' + str(self.state_dir / 'bridge.log'))
