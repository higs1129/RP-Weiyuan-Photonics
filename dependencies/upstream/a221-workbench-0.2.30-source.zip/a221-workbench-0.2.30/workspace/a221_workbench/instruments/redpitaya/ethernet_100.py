# Managed by a221-workbench: RP Ethernet recovery
"""Apply an explicitly selected RP's 100 Mbps policy after PHY attachment.

Deployed verbatim on the board. Uses only the Python standard library.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import time

LINK = Path('/sys/class/net/eth0')


def advertised_modes(text):
    block = text.split('Advertised link modes:', 1)[1].split('Advertised pause frame use:', 1)[0]
    return re.findall(r'\d+base\S+/(?:Half|Full)', block)


def configure(expected_mac, wait_s=25):
    deadline = time.monotonic() + wait_s
    while True:
        if (LINK / 'address').read_text().strip().lower() != expected_mac.lower():
            raise RuntimeError('RP MAC mismatch; Ethernet settings were not changed')
        # macb attaches/initializes its PHY when the interface first goes UP.
        # An earlier ethtool success can be overwritten by that initialization.
        if int((LINK / 'flags').read_text().strip(), 16) & 1 and (LINK / 'phydev').exists():
            break
        if time.monotonic() >= deadline:
            raise TimeoutError('eth0/PHY did not become ready; no speed change attempted')
        time.sleep(.25)
    env = dict(os.environ, LC_ALL='C')
    subprocess.run(['ethtool', '-s', 'eth0', 'advertise', '0x008', 'autoneg', 'on'],
                   check=True, timeout=5, env=env)
    # Confirm both configuration and the negotiated speed when a cable is up.
    # A disconnected cable is allowed: the advertisement remains for reconnection.
    deadline = time.monotonic() + 10
    while True:
        text = subprocess.check_output(['ethtool', 'eth0'], text=True, timeout=3, env=env)
        if advertised_modes(text) != ['100baseT/Full']:
            raise RuntimeError('100 Mbps advertisement readback failed')
        carrier = (LINK / 'carrier').read_text().strip() == '1'
        try:
            speed = int((LINK / 'speed').read_text().strip())
        except (OSError, ValueError):
            speed = 0
        if not carrier or speed == 100:
            return {'advertisement_verified': True, 'carrier': carrier,
                    'speed_mbps': speed if carrier else None, 'mac': expected_mac}
        if time.monotonic() >= deadline:
            raise RuntimeError('Advertisement is 100 Mbps but negotiated speed is not 100 Mbps')
        time.sleep(.25)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-mac', required=True)
    args = parser.parse_args()
    try:
        print(json.dumps({'ok': True, **configure(args.expected_mac)}), flush=True)
    except Exception as exc:
        print(json.dumps({'ok': False, 'error': str(exc)}), flush=True)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
