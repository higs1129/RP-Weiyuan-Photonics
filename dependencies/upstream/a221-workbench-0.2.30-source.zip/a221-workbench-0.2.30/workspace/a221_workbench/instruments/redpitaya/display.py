"""PyRPL display units and GUI patches; called explicitly by the bridge."""
from __future__ import annotations
from typing import Any
import math

import time

import numpy as np


def patch_spectrum_power_units(
    load_ohm: float,
    correction_enabled: bool = True,
    highz_correction_db: float = 20.0 * math.log10(2.0),
    external_gain_db: float = 0.0,
) -> dict[str, Any]:
    """Add 50-ohm-equivalent dBm display units to PyRPL's spectrum GUI."""
    from pyrpl.attributes import FloatProperty
    from pyrpl.software_modules.spectrum_analyzer import SpectrumAnalyzer

    if load_ohm <= 0:
        raise ValueError("--spectrum-load-ohm must be positive")
    if not all(
        np.isfinite(value)
        for value in (highz_correction_db, external_gain_db)
    ):
        raise ValueError("Spectrum display correction values must be finite")

    unit_property = SpectrumAnalyzer.display_unit
    options = list(unit_property.options(None).keys())
    for unit in ("dBm", "dBm/Hz"):
        if unit not in options:
            options.append(unit)
    unit_property.default_options = options

    if not hasattr(SpectrumAnalyzer, "external_gain_db"):

        class SpectrumExternalGainProperty(FloatProperty):
            def set_value(self, obj, value):
                super(SpectrumExternalGainProperty, self).set_value(obj, value)
                try:
                    obj._emit_signal_by_name("unit_changed")
                except Exception:
                    pass

        external_gain_property = SpectrumExternalGainProperty(
            default=external_gain_db,
            min=-200.0,
            max=200.0,
            increment=1.0,
            doc=(
                "External RF chain gain in dB. For dBm/dBm/Hz display, "
                "this value is subtracted after the fixed RP high-Z correction."
            ),
        )
        external_gain_property.name = "external_gain_db"
        SpectrumAnalyzer.external_gain_db = external_gain_property

    if "external_gain_db" not in SpectrumAnalyzer._gui_attributes:
        gui_attrs = list(SpectrumAnalyzer._gui_attributes)
        insert_after = "display_unit"
        try:
            index = gui_attrs.index(insert_after) + 1
        except ValueError:
            index = len(gui_attrs)
        gui_attrs.insert(index, "external_gain_db")
        SpectrumAnalyzer._gui_attributes = gui_attrs

    if getattr(SpectrumAnalyzer, "_daily_note_dbm_units_patched", False):
        SpectrumAnalyzer._daily_note_spectrum_load_ohm = load_ohm
        SpectrumAnalyzer._daily_note_power_correction_enabled = correction_enabled
        SpectrumAnalyzer._daily_note_highz_correction_db = highz_correction_db
        SpectrumAnalyzer._daily_note_external_gain_default_db = external_gain_db
        return spectrum_power_correction_state()

    original_data_to_unit = SpectrumAnalyzer.data_to_unit

    def data_to_unit_with_dbm(self, data, unit, rbw):
        if unit in {"dBm", "dBm/Hz"}:
            data = np.abs(data)
            divisor = 2.0 * self._daily_note_spectrum_load_ohm * 1e-3
            if unit == "dBm/Hz":
                divisor *= rbw
            values = 10.0 * np.log10(data / divisor + np.finfo(float).tiny)
            if self._daily_note_power_correction_enabled:
                values -= (
                    self._daily_note_highz_correction_db
                    + float(self.external_gain_db)
                )
            return values
        return original_data_to_unit(self, data, unit, rbw)

    SpectrumAnalyzer._daily_note_spectrum_load_ohm = load_ohm
    SpectrumAnalyzer._daily_note_power_correction_enabled = correction_enabled
    SpectrumAnalyzer._daily_note_highz_correction_db = highz_correction_db
    SpectrumAnalyzer._daily_note_external_gain_default_db = external_gain_db
    SpectrumAnalyzer.data_to_unit = data_to_unit_with_dbm
    SpectrumAnalyzer._daily_note_dbm_units_patched = True
    return spectrum_power_correction_state()


def patch_scope_mean_display() -> None:
    """Add a live active-channel mean readout to PyRPL's scope GUI."""
    from pyrpl.attributes import BoolProperty, FloatProperty, IntProperty, StringProperty
    from pyrpl.hardware_modules.scope import Scope
    from pyrpl.widgets.module_widgets.scope_widget import ScopeWidget
    from qtpy import QtWidgets
    import pyqtgraph as pg

    if not hasattr(Scope, "active_means_v"):
        active_means_property = StringProperty(
            default="mean: n/a",
            doc="Mean value of active scope traces currently displayed, in volts.",
        )
        active_means_property.name = "active_means_v"
        Scope.active_means_v = active_means_property

    if not hasattr(Scope, "scope_zero_enabled"):
        zero_enabled_property = BoolProperty(
            default=False,
            doc="Apply stored CH1/CH2 voltage offsets to the displayed scope traces.",
        )
        zero_enabled_property.name = "scope_zero_enabled"
        Scope.scope_zero_enabled = zero_enabled_property

    if not hasattr(Scope, "ch1_zero_offset_v"):
        ch1_zero_property = FloatProperty(
            default=0.0,
            min=-100.0,
            max=100.0,
            increment=1e-3,
            doc="CH1 voltage offset subtracted from displayed scope traces.",
        )
        ch1_zero_property.name = "ch1_zero_offset_v"
        Scope.ch1_zero_offset_v = ch1_zero_property

    if not hasattr(Scope, "ch2_zero_offset_v"):
        ch2_zero_property = FloatProperty(
            default=0.0,
            min=-100.0,
            max=100.0,
            increment=1e-3,
            doc="CH2 voltage offset subtracted from displayed scope traces.",
        )
        ch2_zero_property.name = "ch2_zero_offset_v"
        Scope.ch2_zero_offset_v = ch2_zero_property

    if not hasattr(Scope, "ch1_power_response_v_per_w"):
        ch1_response_property = FloatProperty(
            default=3.22013e3,
            min=1e-12,
            max=1e12,
            increment=100.0,
            doc="CH1 optical-power calibration, voltage response in V/W.",
        )
        ch1_response_property.name = "ch1_power_response_v_per_w"
        Scope.ch1_power_response_v_per_w = ch1_response_property

    if not hasattr(Scope, "ch2_power_response_v_per_w"):
        ch2_response_property = FloatProperty(
            default=3.22013e3,
            min=1e-12,
            max=1e12,
            increment=100.0,
            doc="CH2 optical-power calibration, voltage response in V/W.",
        )
        ch2_response_property.name = "ch2_power_response_v_per_w"
        Scope.ch2_power_response_v_per_w = ch2_response_property

    if not hasattr(Scope, "scope_power_avg_frames"):
        power_avg_property = IntProperty(
            default=30,
            min=1,
            max=10000,
            increment=1,
            doc="Number of displayed scope frames used for slow optical-power averaging.",
        )
        power_avg_property.name = "scope_power_avg_frames"
        Scope.scope_power_avg_frames = power_avg_property

    if "active_means_v" in Scope._gui_attributes:
        gui_attrs = list(Scope._gui_attributes)
        gui_attrs = [attr for attr in gui_attrs if attr != "active_means_v"]
        Scope._gui_attributes = gui_attrs

    if getattr(ScopeWidget, "_daily_note_scope_mean_display_patched", False):
        return

    original_init_gui = ScopeWidget.init_gui
    original_display_curve = ScopeWidget.display_curve

    def format_mean(value: float) -> str:
        if not np.isfinite(value):
            return "nan"
        abs_value = abs(value)
        if abs_value < 1e-3:
            return f"{value * 1e6:.2f} uV"
        if abs_value < 1.0:
            return f"{value * 1e3:.3f} mV"
        return f"{value:.5g} V"

    def format_response(value: float) -> str:
        if not np.isfinite(value) or value <= 0:
            return "n/a"
        if value >= 1e6:
            return f"{value / 1e6:.3g} MV/W"
        if value >= 1e3:
            return f"{value / 1e3:.3g} kV/W"
        return f"{value:.3g} V/W"

    def format_power_w(value: float) -> str:
        if not np.isfinite(value):
            return "nan"
        abs_value = abs(value)
        if abs_value < 1e-9:
            return f"{value * 1e12:.2f} pW"
        if abs_value < 1e-6:
            return f"{value * 1e9:.2f} nW"
        if abs_value < 1e-3:
            return f"{value * 1e6:.3f} uW"
        return f"{value * 1e3:.3f} mW"

    def set_active_means(widget: Any, text: str) -> None:
        try:
            widget.module.active_means_v = text
        except Exception:
            pass
        try:
            aw = widget.attribute_widgets.get("active_means_v")
            if aw is not None:
                aw.widget_value = text
        except Exception:
            pass

    def raw_scope_arrays(widget: Any) -> tuple[np.ndarray, np.ndarray] | None:
        cached = getattr(widget, "_daily_note_last_raw_scope_curves", None)
        if cached is not None:
            return cached
        data_avg = getattr(widget.module, "data_avg", None)
        if data_avg is None:
            return None
        try:
            data_avg = np.asarray(data_avg, dtype=float)
            return np.asarray(data_avg[0], dtype=float), np.asarray(data_avg[1], dtype=float)
        except Exception:
            return None

    def clear_power_history(widget: Any) -> None:
        widget._daily_note_power_history = [[], []]

    def update_power_history(
        widget: Any, powers: tuple[float, float], update_history: bool
    ) -> tuple[float, float]:
        history = getattr(widget, "_daily_note_power_history", None)
        if history is None:
            history = [[], []]
            widget._daily_note_power_history = history
        try:
            avg_frames = max(1, int(getattr(widget.module, "scope_power_avg_frames", 30)))
        except Exception:
            avg_frames = 30
        if update_history:
            for idx, power in enumerate(powers):
                if np.isfinite(power):
                    history[idx].append(float(power))
                if len(history[idx]) > avg_frames:
                    del history[idx][:-avg_frames]
        averages = []
        for idx, power in enumerate(powers):
            values = history[idx][-avg_frames:]
            if values:
                averages.append(float(np.nanmean(values)))
            else:
                averages.append(float(power))
        return averages[0], averages[1]

    def set_zero_from_current(widget: Any, mode: str) -> None:
        arrays = raw_scope_arrays(widget)
        if arrays is None:
            return
        ch1, ch2 = arrays
        if mode in {"active", "both"} and (mode == "both" or widget.module.ch1_active):
            widget.module.ch1_zero_offset_v = float(np.nanmean(ch1))
        if mode in {"active", "both"} and (mode == "both" or widget.module.ch2_active):
            widget.module.ch2_zero_offset_v = float(np.nanmean(ch2))
        widget.module.scope_zero_enabled = True
        clear_power_history(widget)
        refresh_zero_overlay(widget)

    def clear_zero(widget: Any) -> None:
        widget.module.ch1_zero_offset_v = 0.0
        widget.module.ch2_zero_offset_v = 0.0
        widget.module.scope_zero_enabled = False
        clear_power_history(widget)
        refresh_zero_overlay(widget)

    def make_response_spinbox(widget: Any, attr: str) -> Any:
        spin = QtWidgets.QDoubleSpinBox()
        spin.setDecimals(2)
        spin.setRange(1e-12, 1e12)
        spin.setSingleStep(100.0)
        spin.setValue(float(getattr(widget.module, attr)))
        spin.setSuffix(" V/W")
        spin.setMaximumWidth(150)

        def update_response(value: float) -> None:
            setattr(widget.module, attr, float(value))
            clear_power_history(widget)
            refresh_zero_overlay(widget)

        spin.valueChanged.connect(update_response)
        return spin

    def make_avg_frames_spinbox(widget: Any) -> Any:
        spin = QtWidgets.QSpinBox()
        spin.setRange(1, 10000)
        spin.setSingleStep(1)
        spin.setValue(int(getattr(widget.module, "scope_power_avg_frames", 30)))
        spin.setSuffix(" frames")
        spin.setMaximumWidth(130)

        def update_avg_frames(value: int) -> None:
            widget.module.scope_power_avg_frames = int(value)
            clear_power_history(widget)
            refresh_zero_overlay(widget)

        spin.valueChanged.connect(update_avg_frames)
        return spin

    def init_gui_with_active_means(self):
        original_init_gui(self)
        try:
            self.mean_text_item = pg.TextItem(
                text="mean: n/a",
                color=(255, 255, 255),
                anchor=(1, 0),
                fill=(0, 0, 0, 170),
                border=(255, 255, 255, 120),
            )
            self.plot_item.addItem(self.mean_text_item, ignoreBounds=True)
        except Exception:
            self.mean_text_item = None
        update_mean_text_position(self)

        try:
            self.zero_group = QtWidgets.QGroupBox("Display zero")
            zero_layout = QtWidgets.QHBoxLayout()
            zero_layout.setContentsMargins(4, 4, 4, 4)
            self.zero_group.setLayout(zero_layout)

            self.zero_active_button = QtWidgets.QPushButton("Set active")
            self.zero_both_button = QtWidgets.QPushButton("Set both")
            self.zero_clear_button = QtWidgets.QPushButton("Clear")
            for button in (
                self.zero_active_button,
                self.zero_both_button,
                self.zero_clear_button,
            ):
                button.setMaximumWidth(85)
                zero_layout.addWidget(button)
            self.zero_active_button.clicked.connect(
                lambda: set_zero_from_current(self, "active")
            )
            self.zero_both_button.clicked.connect(
                lambda: set_zero_from_current(self, "both")
            )
            self.zero_clear_button.clicked.connect(lambda: clear_zero(self))
            self.layout_misc.addWidget(self.zero_group)
        except Exception:
            pass

        try:
            self.power_group = QtWidgets.QGroupBox("Power cal")
            power_layout = QtWidgets.QGridLayout()
            power_layout.setContentsMargins(4, 4, 4, 4)
            self.power_group.setLayout(power_layout)

            power_layout.addWidget(QtWidgets.QLabel("CH1"), 0, 0)
            self.ch1_response_spin = make_response_spinbox(
                self, "ch1_power_response_v_per_w"
            )
            power_layout.addWidget(self.ch1_response_spin, 0, 1)

            power_layout.addWidget(QtWidgets.QLabel("CH2"), 1, 0)
            self.ch2_response_spin = make_response_spinbox(
                self, "ch2_power_response_v_per_w"
            )
            power_layout.addWidget(self.ch2_response_spin, 1, 1)

            power_layout.addWidget(QtWidgets.QLabel("avg"), 2, 0)
            self.power_avg_frames_spin = make_avg_frames_spinbox(self)
            power_layout.addWidget(self.power_avg_frames_spin, 2, 1)

            self.power_avg_clear_button = QtWidgets.QPushButton("Clear avg")
            self.power_avg_clear_button.setMaximumWidth(100)
            self.power_avg_clear_button.clicked.connect(
                lambda: (clear_power_history(self), refresh_zero_overlay(self))
            )
            power_layout.addWidget(self.power_avg_clear_button, 3, 1)

            self.layout_misc.addWidget(self.power_group)
        except Exception:
            pass

        try:
            self.plot_item.vb.sigRangeChanged.connect(
                lambda *args: update_mean_text_position(self)
            )
        except Exception:
            pass

    def update_mean_text_position(widget: Any) -> None:
        item = getattr(widget, "mean_text_item", None)
        if item is None:
            return
        try:
            (x_min, x_max), (y_min, y_max) = widget.plot_item.viewRange()
            x = x_min + 0.985 * (x_max - x_min)
            y = y_max - 0.055 * (y_max - y_min)
            item.setPos(x, y)
        except Exception:
            pass

    def refresh_zero_overlay(widget: Any, update_history: bool = False) -> None:
        arrays = raw_scope_arrays(widget)
        if arrays is None:
            text = "mean: waiting for scope data"
            set_active_means(widget, text)
            try:
                if getattr(widget, "mean_text_item", None) is not None:
                    widget.mean_text_item.setText(text)
            except Exception:
                pass
            return

        ch1, ch2 = arrays
        zero_enabled = bool(getattr(widget.module, "scope_zero_enabled", False))
        offsets = (
            float(getattr(widget.module, "ch1_zero_offset_v", 0.0)),
            float(getattr(widget.module, "ch2_zero_offset_v", 0.0)),
        )
        raw_means = (float(np.nanmean(ch1)), float(np.nanmean(ch2)))
        shown_means = (
            raw_means[0] - offsets[0] if zero_enabled else raw_means[0],
            raw_means[1] - offsets[1] if zero_enabled else raw_means[1],
        )
        responses = (
            float(getattr(widget.module, "ch1_power_response_v_per_w", np.nan)),
            float(getattr(widget.module, "ch2_power_response_v_per_w", np.nan)),
        )
        powers = (
            shown_means[0] / responses[0]
            if np.isfinite(responses[0]) and responses[0] > 0
            else np.nan,
            shown_means[1] / responses[1]
            if np.isfinite(responses[1]) and responses[1] > 0
            else np.nan,
        )
        avg_powers = update_power_history(widget, powers, update_history)
        try:
            avg_frames = max(1, int(getattr(widget.module, "scope_power_avg_frames", 30)))
        except Exception:
            avg_frames = 30

        raw_entries: list[str] = []
        offset_entries: list[str] = []
        shown_entries: list[str] = []
        response_entries: list[str] = []
        power_entries: list[str] = []
        avg_power_entries: list[str] = []
        active = (bool(widget.module.ch1_active), bool(widget.module.ch2_active))
        for idx, is_active in enumerate(active):
            if not is_active:
                continue
            label = f"CH{idx + 1}"
            raw_entries.append(f"{label} {format_mean(raw_means[idx])}")
            offset_entries.append(f"{label} {format_mean(offsets[idx])}")
            shown_entries.append(f"{label} {format_mean(shown_means[idx])}")
            response_entries.append(f"{label} {format_response(responses[idx])}")
            power_entries.append(f"{label} {format_power_w(powers[idx])}")
            avg_power_entries.append(f"{label} {format_power_w(avg_powers[idx])}")
        if widget.module.ch_math_active:
            shown_entries.append("MATH shown")

        if raw_entries:
            lines = [f"raw mean: {' | '.join(raw_entries)}"]
            if zero_enabled:
                lines.append(f"offset: {' | '.join(offset_entries)}")
                lines.append(f"shown mean: {' | '.join(shown_entries)}")
            else:
                lines.append("zero: off")
            lines.append(f"response: {' | '.join(response_entries)}")
            lines.append(f"P inst: {' | '.join(power_entries)}")
            lines.append(f"P avg({avg_frames}f): {' | '.join(avg_power_entries)}")
        else:
            lines = ["mean: no active channel"]
        text = "\n".join(lines)
        set_active_means(widget, text)
        try:
            if getattr(widget, "mean_text_item", None) is not None:
                widget.mean_text_item.setText(text)
                update_mean_text_position(widget)
        except Exception:
            pass

    def display_curve_with_active_means(self, list_of_arrays):
        times, curves = list_of_arrays
        ch1 = np.asarray(curves[0], dtype=float)
        ch2 = np.asarray(curves[1], dtype=float)
        self._daily_note_last_raw_scope_curves = (ch1, ch2)
        frame_id = int(getattr(self.module, "_daily_note_scope_cache_frame_id", 0)) + 1
        self.module._daily_note_last_raw_scope_curves = (ch1, ch2)
        self.module._daily_note_scope_cache_frame_id = frame_id
        self.module._daily_note_scope_cache_updated_at = time.time()
        if bool(getattr(self.module, "scope_zero_enabled", False)):
            ch1_display = ch1 - float(getattr(self.module, "ch1_zero_offset_v", 0.0))
            ch2_display = ch2 - float(getattr(self.module, "ch2_zero_offset_v", 0.0))
            result = original_display_curve(
                self,
                [times, np.asarray((ch1_display, ch2_display), dtype=float)],
            )
        else:
            result = original_display_curve(self, list_of_arrays)
        refresh_zero_overlay(self, update_history=True)
        return result

    ScopeWidget.init_gui = init_gui_with_active_means
    ScopeWidget.display_curve = display_curve_with_active_means
    ScopeWidget._daily_note_scope_mean_display_patched = True


def sync_scope_display_controls(scope: Any) -> None:
    """Refresh patched scope GUI spin boxes after startup args are applied."""
    try:
        from qtpy import QtWidgets
    except Exception:
        return
    app = QtWidgets.QApplication.instance()
    if app is None:
        return
    controls = {
        "ch1_response_spin": "ch1_power_response_v_per_w",
        "ch2_response_spin": "ch2_power_response_v_per_w",
        "power_avg_frames_spin": "scope_power_avg_frames",
    }
    for widget in app.allWidgets():
        if getattr(widget, "module", None) is not scope:
            continue
        for control_name, attr in controls.items():
            control = getattr(widget, control_name, None)
            if control is None:
                continue
            try:
                value = getattr(scope, attr)
                previous = control.blockSignals(True)
                control.setValue(value)
                control.blockSignals(previous)
            except Exception:
                continue


def spectrum_power_correction_state(spectrum: Any | None = None) -> dict[str, Any]:
    from pyrpl.software_modules.spectrum_analyzer import SpectrumAnalyzer

    enabled = bool(
        getattr(SpectrumAnalyzer, "_daily_note_power_correction_enabled", True)
    )
    highz = float(getattr(SpectrumAnalyzer, "_daily_note_highz_correction_db", 0.0))
    if spectrum is not None:
        gain = float(getattr(spectrum, "external_gain_db", 0.0))
    else:
        gain = float(
            getattr(SpectrumAnalyzer, "_daily_note_external_gain_default_db", 0.0)
        )
    load = float(getattr(SpectrumAnalyzer, "_daily_note_spectrum_load_ohm", 50.0))
    total = highz + gain if enabled else 0.0
    return {
        "ok": True,
        "load_ohm": load,
        "enabled": enabled,
        "highz_correction_db": highz,
        "external_gain_db": gain,
        "total_subtracted_db": total,
        "applies_to_units": ["dBm", "dBm/Hz"],
    }


def spectrum_vpk2_to_display_dbm_per_hz(
    vpk2: np.ndarray,
    rbw_hz: float,
    correction_state: dict[str, Any],
) -> np.ndarray:
    """Convert PyRPL Vpk^2 spectrum data to corrected display dBm/Hz."""
    if rbw_hz <= 0:
        raise ValueError("rbw_hz must be positive")
    load_ohm = float(correction_state["load_ohm"])
    if load_ohm <= 0:
        raise ValueError("load_ohm must be positive")
    values = 10.0 * np.log10(
        np.abs(vpk2) / (2.0 * load_ohm * 1e-3 * rbw_hz) + np.finfo(float).tiny
    )
    values -= float(correction_state.get("total_subtracted_db", 0.0))
    return values


def networkanalyzer_response_to_dbm(
    response: np.ndarray | complex | float,
    *,
    drive_vpk: float,
    load_ohm: float,
    correction_enabled: bool,
    highz_correction_db: float,
    external_gain_db: float,
) -> np.ndarray:
    """Convert NA coherent voltage transfer response to corrected dBm.

    PyRPL's network analyzer stores a complex voltage ratio:
    V_read / V_drive. Its GUI normally plots 20log10(abs(response)).
    This helper multiplies by the configured drive Vpk, converts to Vrms,
    then reports coherent power in dBm for the chosen equivalent load.
    """
    if load_ohm <= 0:
        raise ValueError("load_ohm must be positive")
    drive_vpk = max(float(abs(drive_vpk)), np.finfo(float).tiny)
    values = (
        20.0 * np.log10(np.abs(response) + np.finfo(float).tiny)
        + 20.0 * np.log10(drive_vpk / math.sqrt(2.0))
        - 10.0 * math.log10(load_ohm)
        + 30.0
    )
    if correction_enabled:
        values -= highz_correction_db + external_gain_db
    return values


def patch_networkanalyzer_dbm_display(
    *,
    enabled: bool = True,
    load_ohm: float = 50.0,
    highz_correction_db: float = 20.0 * math.log10(2.0),
    external_gain_db: float = 0.0,
) -> dict[str, Any]:
    """Display PyRPL network-analyzer magnitude as coherent dBm."""
    from pyrpl.attributes import BoolProperty, FloatProperty
    from pyrpl.software_modules.network_analyzer import NetworkAnalyzer

    if load_ohm <= 0:
        raise ValueError("--networkanalyzer-load-ohm must be positive")
    if not all(np.isfinite(value) for value in (highz_correction_db, external_gain_db)):
        raise ValueError("Network-analyzer display correction values must be finite")

    if not hasattr(NetworkAnalyzer, "dbm_display_enabled"):
        enabled_property = BoolProperty(
            default=enabled,
            doc="Display network-analyzer magnitude as coherent dBm instead of transfer dB.",
        )
        enabled_property.name = "dbm_display_enabled"
        NetworkAnalyzer.dbm_display_enabled = enabled_property

    if not hasattr(NetworkAnalyzer, "dbm_load_ohm"):
        load_property = FloatProperty(
            default=load_ohm,
            min=1e-9,
            max=1e12,
            increment=1.0,
            doc="Equivalent load resistance for coherent network-analyzer dBm display.",
        )
        load_property.name = "dbm_load_ohm"
        NetworkAnalyzer.dbm_load_ohm = load_property

    if not hasattr(NetworkAnalyzer, "dbm_highz_correction_db"):
        highz_property = FloatProperty(
            default=highz_correction_db,
            min=-200.0,
            max=200.0,
            increment=1.0,
            doc="RP high-impedance input correction subtracted in network-analyzer dBm mode.",
        )
        highz_property.name = "dbm_highz_correction_db"
        NetworkAnalyzer.dbm_highz_correction_db = highz_property

    if not hasattr(NetworkAnalyzer, "external_gain_db"):
        gain_property = FloatProperty(
            default=external_gain_db,
            min=-200.0,
            max=200.0,
            increment=1.0,
            doc="External RF-chain gain subtracted in network-analyzer dBm mode.",
        )
        gain_property.name = "external_gain_db"
        NetworkAnalyzer.external_gain_db = gain_property

    desired_attrs = [
        "dbm_display_enabled",
        "dbm_load_ohm",
        "dbm_highz_correction_db",
        "external_gain_db",
    ]
    gui_attrs = list(NetworkAnalyzer._gui_attributes)
    try:
        index = gui_attrs.index("amplitude") + 1
    except ValueError:
        index = len(gui_attrs)
    for attr in desired_attrs:
        if attr not in gui_attrs:
            gui_attrs.insert(index, attr)
            index += 1
    NetworkAnalyzer._gui_attributes = gui_attrs

    if not getattr(NetworkAnalyzer, "_daily_note_dbm_display_patched", False):
        from pyrpl.widgets.module_widgets.na_widget import NaWidget

        original_init_gui = NaWidget.init_gui
        original_update_attribute_by_name = NaWidget.update_attribute_by_name

        def update_na_magnitude_title(widget):
            if bool(getattr(widget.module, "dbm_display_enabled", False)):
                widget.plot_item.setTitle("Magnitude (dBm)")
            else:
                widget.plot_item.setTitle("Magnitude (dB)")

        def init_gui_with_dbm_display(self):
            original_init_gui(self)
            update_na_magnitude_title(self)

        def magnitude_with_dbm_display(self, data):
            if bool(getattr(self.module, "dbm_display_enabled", False)):
                return networkanalyzer_response_to_dbm(
                    data,
                    drive_vpk=float(getattr(self.module, "amplitude", 0.0)),
                    load_ohm=float(getattr(self.module, "dbm_load_ohm", 50.0)),
                    correction_enabled=True,
                    highz_correction_db=float(
                        getattr(self.module, "dbm_highz_correction_db", 0.0)
                    ),
                    external_gain_db=float(getattr(self.module, "external_gain_db", 0.0)),
                )
            return 20.0 * np.log10(np.abs(data) + np.finfo(float).tiny)

        def update_attribute_by_name_with_dbm(self, name, new_value_list):
            original_update_attribute_by_name(self, name, new_value_list)
            if name in {
                "dbm_display_enabled",
                "dbm_load_ohm",
                "dbm_highz_correction_db",
                "external_gain_db",
                "amplitude",
            }:
                update_na_magnitude_title(self)
                try:
                    for chunk_index in range(len(self.chunks)):
                        self.update_chunk(chunk_index)
                except Exception:
                    pass

        NaWidget.init_gui = init_gui_with_dbm_display
        NaWidget._magnitude = magnitude_with_dbm_display
        NaWidget.update_attribute_by_name = update_attribute_by_name_with_dbm
        NetworkAnalyzer._daily_note_dbm_display_patched = True

    NetworkAnalyzer._daily_note_dbm_display_default_enabled = enabled
    NetworkAnalyzer._daily_note_dbm_load_ohm = load_ohm
    NetworkAnalyzer._daily_note_dbm_highz_correction_db = highz_correction_db
    NetworkAnalyzer._daily_note_external_gain_default_db = external_gain_db
    return networkanalyzer_power_state()


def networkanalyzer_power_state(networkanalyzer: Any | None = None) -> dict[str, Any]:
    from pyrpl.software_modules.network_analyzer import NetworkAnalyzer

    if networkanalyzer is not None:
        enabled = bool(getattr(networkanalyzer, "dbm_display_enabled", True))
        load = float(getattr(networkanalyzer, "dbm_load_ohm", 50.0))
        highz = float(getattr(networkanalyzer, "dbm_highz_correction_db", 0.0))
        gain = float(getattr(networkanalyzer, "external_gain_db", 0.0))
    else:
        enabled = bool(
            getattr(NetworkAnalyzer, "_daily_note_dbm_display_default_enabled", True)
        )
        load = float(getattr(NetworkAnalyzer, "_daily_note_dbm_load_ohm", 50.0))
        highz = float(
            getattr(NetworkAnalyzer, "_daily_note_dbm_highz_correction_db", 0.0)
        )
        gain = float(
            getattr(NetworkAnalyzer, "_daily_note_external_gain_default_db", 0.0)
        )
    return {
        "ok": True,
        "display_unit": "dBm" if enabled else "dB",
        "enabled": enabled,
        "load_ohm": load,
        "highz_correction_db": highz,
        "external_gain_db": gain,
        "total_subtracted_db": highz + gain if enabled else 0.0,
        "drive_amplitude": "networkanalyzer.amplitude, interpreted as Vpk",
    }
