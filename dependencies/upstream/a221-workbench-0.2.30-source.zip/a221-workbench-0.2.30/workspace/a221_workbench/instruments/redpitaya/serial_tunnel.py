"""Expose an RP UART at a local TCP socket for a Windows virtual COM driver.

Raw 9600/8N1 bytes travel over authenticated SSH. No commands are generated,
parsed or retried; only one TCP client is serviced at a time.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.redpitaya'

from a221_workbench._shared.paths import module_file, project_root

import argparse
import json
import os
from pathlib import Path
import shlex
import select
import socket
import sys
import threading
import time

from a221_workbench.instruments.redpitaya.network import resolve_host
from a221_workbench.instruments.redpitaya.uart_remote import command, inspect_board


def forward(sock, channel, stop_requested=lambda: False):
    counts = {'to_uart': 0, 'from_uart': 0}
    stopped = threading.Event()
    def upload():
        try:
            while not stopped.is_set():
                if not select.select([sock], [], [], .2)[0]:
                    continue
                data = sock.recv(4096)
                if not data:
                    break
                channel.sendall(data)
                counts['to_uart'] += len(data)
        except (OSError, EOFError):
            pass
        finally:
            channel.shutdown_write()
    worker = threading.Thread(target=upload, daemon=True)
    worker.start()
    def watch_stop():
        while not stopped.wait(.2):
            if stop_requested():
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                channel.shutdown_write()
                return
    watcher = threading.Thread(target=watch_stop, daemon=True)
    watcher.start()
    try:
        while True:
            data = channel.recv(4096)
            if not data:
                break
            sock.sendall(data)
            counts['from_uart'] += len(data)
    finally:
        stopped.set()
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        channel.shutdown_write()
        worker.join(timeout=3)
        watcher.join(timeout=1)
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True)
    parser.add_argument('--address', help='Explicit current IP; host MAC identity is still checked')
    parser.add_argument('--state-dir', type=Path, required=True)
    parser.add_argument('--device', default='/dev/ttyPS1')
    parser.add_argument('--port', type=int, default=4001)
    args = parser.parse_args()
    import paramiko
    address = args.address or resolve_host(args.host)[1]
    client = paramiko.SSHClient()
    client.load_host_keys(str(args.state_dir / 'known_hosts'))
    client.connect(address, username='root', password=os.environ.get('RP_SSH_PASSWORD', 'root'),
                   timeout=8, look_for_keys=False, allow_agent=False)
    client.get_transport().set_keepalive(10)
    board = inspect_board(client)
    expected = args.host.upper().removeprefix('RP-').removesuffix('.LOCAL')
    if len(expected) == 6 and board['mac'].replace(':', '').upper()[-6:] != expected:
        raise RuntimeError('RP MAC does not match requested board')
    selected = next((row for row in board['devices'] if row['device'] == args.device), None)
    if not selected or selected['console']:
        raise RuntimeError('Requested UART missing or used as console')
    remote = '/tmp/measurement-uart-stream.py'
    with client.open_sftp() as sftp:
        sftp.put(str(module_file('a221_workbench.instruments.redpitaya.uart_stream')), remote)
    pause_file = args.state_dir / 'vendor-serial-active.json'
    listener = socket.socket()
    listener.bind(('127.0.0.1', args.port))
    listener.listen(1)
    listener.settimeout(1)
    args.state_dir.mkdir(parents=True, exist_ok=True)
    pause_file.write_text(json.dumps({'pid': os.getpid(), 'host': args.host, 'port': args.port, 'device': args.device}), encoding='utf-8')
    print(json.dumps({'ready': True, 'listen': '127.0.0.1', 'port': args.port, 'host': address, 'device': args.device}), flush=True)
    try:
        while not (args.state_dir / 'vendor-serial-stop').exists():
            try:
                sock, peer = listener.accept()
            except socket.timeout:
                continue
            channel = client.get_transport().open_session()
            channel.exec_command('python3 -u ' + shlex.quote(remote) + ' --device ' + shlex.quote(args.device))
            try:
                channel.settimeout(10)
                readiness = b''
                while b'UART_STREAM_READY' not in readiness:
                    chunk = channel.recv_stderr(4096)
                    readiness += chunk
                    if not chunk or len(readiness) > 16384:
                        raise RuntimeError('RP UART startup failed: ' + readiness.decode(errors='replace'))
                channel.settimeout(None)
                print('Client attached; UART HTTP service paused', flush=True)
                print(json.dumps(forward(sock, channel,
                      lambda: (args.state_dir / 'vendor-serial-stop').exists())), flush=True)
            except Exception as exc:
                print('Client error: ' + str(exc), flush=True)
            finally:
                channel.shutdown_write()
                # EOF lets the RP process release UART and restore its prior service.
                deadline = time.monotonic() + 5
                while not channel.exit_status_ready() and time.monotonic() < deadline:
                    time.sleep(.05)
                channel.close()
                sock.close()
    finally:
        listener.close()
        client.close()
        pause_file.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
