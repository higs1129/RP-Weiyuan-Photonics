from __future__ import annotations
from datetime import datetime, timezone
import json
import math
from pathlib import Path

class Capture:
    def __init__(self, kind, payload, host):
        trace = payload.get('trace', {})
        if trace.get('decimation') != 1:
            raise RuntimeError('Bridge returned a preview, not the full capture')
        names = ('t', 'ch1', 'ch2') if kind == 'scope' else ('frequency_hz', 'input1_dbm_per_hz')
        arrays = [trace.get(name, []) for name in names]
        if not arrays[0] or any(len(a) != payload.get('n') for a in arrays):
            raise RuntimeError('Capture arrays are empty or incomplete')
        if any(not isinstance(v, (int, float)) or not math.isfinite(v) for a in arrays for v in a):
            raise RuntimeError('Capture contains non-finite values')
        self.kind, self.payload, self.host = kind, payload, host
        self.captured_at = datetime.now(timezone.utc).isoformat()

    def as_dict(self):
        return {'kind': self.kind, 'host': self.host, 'captured_at': self.captured_at,
                'units': {'t': 's', 'ch1': 'V', 'ch2': 'V'} if self.kind == 'scope'
                else {'frequency_hz': 'Hz', 'input1_dbm_per_hz': 'dBm/Hz'},
                'bridge_result': self.payload}

    def save(self, path, *, provenance):
        """Save complete returned arrays, metadata and caller-supplied source provenance."""
        if not provenance:
            raise ValueError('Record actual source version/snapshot in provenance')
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x', encoding='utf-8') as stream:
            json.dump({**self.as_dict(), 'provenance': provenance}, stream, ensure_ascii=False, indent=2, allow_nan=False)
        return path
