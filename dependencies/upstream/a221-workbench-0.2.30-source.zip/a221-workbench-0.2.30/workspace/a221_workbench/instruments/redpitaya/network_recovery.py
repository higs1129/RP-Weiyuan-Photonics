"""Explicit connection preparation; passive address resolution never changes a board."""
from __future__ import annotations

import argparse
import base64
import ipaddress
import json
from pathlib import Path
import re
import socket
import time

from .network import HostNotFound, identity_matches, resolve_host, rp_identity, _active_mac


SNAPSHOT = '''
import json,subprocess
from pathlib import Path
links=json.loads(subprocess.check_output(['ip','-j','address','show','dev','eth0']))
result={'hostname':Path('/etc/hostname').read_text().strip(),
        'mac':Path('/sys/class/net/eth0/address').read_text().strip(),
        'carrier':Path('/sys/class/net/eth0/carrier').read_text().strip(),
        'addresses':[a['local'] for link in links for a in link['addr_info'] if a['family']=='inet']}
try: result['speed']=int(Path('/sys/class/net/eth0/speed').read_text())
except (OSError,ValueError): result['speed']=0
'''

PERSIST_100 = r'''
import os,shutil,subprocess
from pathlib import Path
marker='# Managed by a221-workbench: RP Ethernet recovery'
path=Path('/etc/systemd/system/a221-rp-ethernet.service')
if path.exists() and not path.read_text().startswith(marker):
    raise RuntimeError('Ethernet service path belongs to another configuration')
helper=Path('/usr/local/lib/a221-rp/ethernet_100.py')
if helper.exists() and not helper.read_text().startswith(marker):
    raise RuntimeError('Ethernet helper path belongs to another configuration')
python=shutil.which('python3')
if not python or not shutil.which('ethtool'): raise RuntimeError('python3/ethtool unavailable')
mac=Path('/sys/class/net/eth0/address').read_text().strip()
source=__A221_HELPER_SOURCE__
unit=marker+'\n[Unit]\nDescription=RP 100 Mbps after PHY initialization\nAfter=systemd-networkd.service sys-subsystem-net-devices-eth0.device\nWants=systemd-networkd.service\nRequires=sys-subsystem-net-devices-eth0.device\nPartOf=systemd-networkd.service\nBefore=network-online.target\n\n[Service]\nType=oneshot\nExecStart='+python+' '+str(helper)+' --expected-mac '+mac+'\nTimeoutStartSec=45\nRemainAfterExit=yes\n\n[Install]\nWantedBy=multi-user.target\n'
previous={p:p.read_bytes() if p.exists() else None for p in (path,helper)}
backup=path.with_suffix('.service.before-phy-fix')
if previous[path] is not None and not backup.exists(): backup.write_bytes(previous[path])
def save(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix('.tmp')
    temp.write_bytes(data)
    temp.replace(p)
try:
    save(helper,source.encode())
    save(path,unit.encode())
    subprocess.check_call(['systemd-analyze','verify',str(path)])
    subprocess.check_call(['systemctl','daemon-reload'])
    subprocess.check_call(['systemctl','enable',path.name])
    os.sync()
except Exception:
    for p,data in previous.items():
        if data is None:
            if p.exists(): p.unlink()
        else: save(p,data)
    subprocess.run(['systemctl','daemon-reload'])
    os.sync()
    raise
result={'persistent':True,'unit':path.name,'policy':'after-phy-ready-v2'}
'''.replace('__A221_HELPER_SOURCE__', repr(Path(__file__).with_name('ethernet_100.py').read_text(encoding='utf-8')))


class Console:
    """Use one selected FT231X console; verify shell and MAC before any recovery."""
    def __init__(self, host, port=None):
        self.host, self.port, self.serial = host, port, None

    def __enter__(self):
        import serial
        from serial.tools import list_ports
        candidates = [p.device for p in list_ports.comports()
                      if p.vid == 0x0403 and p.pid == 0x6015]
        if self.port:
            selected = next((p for p in candidates if p.lower() == self.port.lower()), None)
            if selected is None:
                raise RuntimeError('指定 CON 串口不是已就绪的 FT231X 设备：' + self.port)
            self.port = selected
        elif len(candidates) == 1:
            self.port = candidates[0]
        else:
            raise RuntimeError('网络不可达；请用 USB 数据线连接 RP 的 CON 口。'
                               '无可用串口时检查驱动；存在多个时设置 rp_console_port。')
        self.serial = serial.Serial(port=None, baudrate=115200, timeout=.2, write_timeout=3)
        self.serial.port = self.port
        self.serial.dtr = self.serial.rts = False
        try:
            self.serial.open()
            initial = self.serial.read(8192).decode(errors='replace')
            if 'U-Boot' in initial or 'autoboot' in initial.lower():
                raise RuntimeError('RP 正在启动，请等启动完成后重试')
            # Only a newline is sent before the expected Linux prompt is identified.
            self.serial.write(b'\r')
            deadline = time.monotonic() + 3
            text = initial
            expected = 'rp-' + rp_identity(self.host)[-6:]
            while time.monotonic() < deadline:
                text += self.serial.read(8192).decode(errors='replace')
                if re.search(r'root@' + re.escape(expected) + r':[^\r\n]*#', text, re.I):
                    board = self.run(SNAPSHOT)
                    if not identity_matches(self.host, board['mac']):
                        raise RuntimeError('CON 控制台的板端 MAC 与目标 RP 不一致')
                    return self
            raise RuntimeError('CON 未返回目标 RP 的 root shell；未执行网络修改。请检查所选串口和板卡启动。')
        except Exception:
            self.serial.close()
            raise

    def __exit__(self, *args):
        self.serial.close()

    def run(self, code, timeout=12):
        import secrets
        marker = 'A221_' + secrets.token_hex(8)
        encoded = base64.b64encode(code.encode()).decode()
        # Heredoc avoids terminal canonical-line length limits for larger scripts.
        lines = ['import base64,json', 'try:', ' exec(base64.b64decode(']
        lines += ['  ' + repr(encoded[i:i + 240]) for i in range(0, len(encoded), 240)]
        lines += [' ))',
                 ' print(' + repr(marker) + '+json.dumps({"ok":True,"result":result}))',
                 'except Exception as e:',
                 ' print(' + repr(marker) + '+json.dumps({"ok":False,"error":str(e)}))']
        command = "python3 - <<'" + marker + "'\n" + '\n'.join(lines) + '\n' + marker + '\n'
        self.serial.write(command.encode())
        self.serial.flush()
        deadline, data = time.monotonic() + timeout, ''
        while time.monotonic() < deadline:
            data += self.serial.read(16384).decode(errors='replace')
            if len(data) > 262144:
                raise RuntimeError('CON 返回数据过多，停止自动操作')
            for line in data.splitlines(keepends=True):
                if line.startswith(marker + '{') and line.endswith(('\r', '\n')):
                    payload = json.loads(line[len(marker):])
                    if not payload['ok']:
                        raise RuntimeError('RP 控制台：' + payload['error'])
                    return payload['result']
        raise TimeoutError('RP 控制台操作未确认；未自动重发命令，请检查板卡状态')


def _reachable_address(host, board):
    if not identity_matches(host, board['mac']):
        raise RuntimeError('恢复过程中 RP 身份发生变化')
    for address in board['addresses']:
        ip = ipaddress.ip_address(address)
        if ip.is_loopback or ip.is_link_local or not ip.is_private:
            continue
        if not identity_matches(host, _active_mac(address)):
            continue
        try:
            with socket.create_connection((address, 22), timeout=1):
                return address
        except OSError:
            pass
    return None


def _prepare_network(host, *, console_port=None, evidence):
    try:
        name, address = resolve_host(host)
        return {'ok': True, 'host': name, 'address': address, 'recovered': False}
    except HostNotFound:
        if not rp_identity(host):
            raise
    with Console(host, console_port) as console:
        board = console.run(SNAPSHOT)
        evidence['board'] = board
        address = _reachable_address(host, board)
        if address:
            return {'ok': True, 'host': host, 'address': address, 'recovered': False}
        if board['carrier'] != '1':
            raise RuntimeError('RP 网口没有物理链路，请检查网线和交换机端口')
        # Allow a normal DHCP renewal first; never assign an arbitrary static IP.
        console.run("import subprocess\nsubprocess.check_call(['networkctl','renew','eth0'])\nresult={}")
        for _ in range(5):
            time.sleep(1)
            board = console.run(SNAPSHOT)
            evidence['board'] = board
            address = _reachable_address(host, board)
            if address:
                return {'ok': True, 'host': host, 'address': address, 'recovered': False}
        if board['speed'] != 1000:
            raise RuntimeError(f"RP 链路速率 {board['speed']} Mbps；" +
                               ('已有 IP：' + ', '.join(board['addresses']) + '，但本机尚无法验证通信' if board['addresses'] else '尚未取得 IPv4 地址'))
        # Save the actual advertisement (including pause modes) for failed recovery.
        saved = console.run("import subprocess\nresult={'text':subprocess.check_output(['ethtool','eth0']).decode()}")['text']
        advertised = saved.split('Advertised link modes:', 1)[1].split('Advertised pause frame use:', 1)
        mask = sum(bit for mode, bit in [('10baseT/Half', 1), ('10baseT/Full', 2),
                   ('100baseT/Half', 4), ('100baseT/Full', 8), ('1000baseT/Half', 16),
                   ('1000baseT/Full', 32)] if mode in advertised[0])
        pause = advertised[1].splitlines()[0].strip()
        if not mask & 32 or pause not in {'No', 'Symmetric', 'Transmit-only', 'Symmetric Receive-only'}:
            raise RuntimeError('无法完整确认原网口协商能力，未修改速率')
        mask |= {'No': 0, 'Symmetric': 0x2000, 'Transmit-only': 0x4000,
                 'Symmetric Receive-only': 0x6000}[pause]
        console.run("import subprocess\nsubprocess.check_call(['ethtool','-s','eth0','advertise','0x008','autoneg','on'])\nresult={}")
        address = None
        try:
            for _ in range(20):
                time.sleep(1)
                board = console.run(SNAPSHOT)
                evidence['board'] = board
                address = _reachable_address(host, board)
                if address:
                    break
        finally:
            if not address:
                console.run("import subprocess\nsubprocess.check_call(['ethtool','-s','eth0','advertise',"
                            + repr(hex(mask)) + ",'autoneg','on'])\nresult={}")
        if not address:
            raise RuntimeError('百兆尝试未恢复通信，已恢复原协商能力；请检查网线、DHCP 或交换机端口')
        result = {'ok': True, 'host': host, 'address': address, 'recovered': True,
                  'speed_mbps': 100, 'console_port': console.port}
        try:
            result.update(console.run(PERSIST_100))
        except Exception as exc:
            result.update(persistent=False, warning='百兆通信已恢复，但开机配置未保存：' + str(exc))
        return result


class NetworkPreparationError(RuntimeError):
    def __init__(self, message, diagnostics):
        super().__init__(message)
        self.diagnostics = diagnostics


def prepare_network(host, *, console_port=None):
    evidence = {}
    try:
        return _prepare_network(host, console_port=console_port, evidence=evidence)
    except Exception as exc:
        from .network_diagnostics import collect
        try:
            report = collect(host, evidence.get('board'), str(exc))
        except Exception:
            report = {'host': host, 'board': evidence.get('board'), 'summary': str(exc),
                      'advice': ['请核对接线及电脑网络配置，诊断详情读取未完成。']}
        raise NetworkPreparationError(str(exc), report) from exc


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True)
    parser.add_argument('--console-port')
    args = parser.parse_args()
    try:
        result = prepare_network(args.host, console_port=args.console_port)
    except Exception as exc:
        print(json.dumps({'ok': False, 'error': str(exc), 'diagnostics': getattr(exc, 'diagnostics', None)}, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
