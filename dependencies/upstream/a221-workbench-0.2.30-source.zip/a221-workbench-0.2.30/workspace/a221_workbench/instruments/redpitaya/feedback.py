"""PID0 feedback operations independent of the shared waveform acquisition engine.

FeedbackHardware runs only on the PyRPL owner/Qt thread. Feedback is its client.
The sampler reads physical IN1/OUT2, irrespective of scope/spectrum routing.
"""

from __future__ import annotations
import math
import time


def validate_handoff(values):
    limits = {'setpoint': (-1, 1), 'p': (-100, 100), 'i': (-1e6, 1e6),
              'ival': (-1, 1), 'min_voltage': (-1, 0), 'max_voltage': (0, 1)}
    if set(values) != set(limits):
        raise ValueError('Feedback requires setpoint, p, i, ival, min_voltage, max_voltage')
    result = {}
    for key, (lo, hi) in limits.items():
        value = float(values[key])
        if not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError(f'Invalid feedback {key}: allowed {lo}..{hi}')
        result[key] = value
    if not result['min_voltage'] < result['max_voltage'] or not result['i']:
        raise ValueError('Feedback needs nonzero integral gain and valid output limits')
    if not result['min_voltage'] <= result['ival'] <= result['max_voltage']:
        raise ValueError('Initial ival must be within the output limits')
    return result


class FeedbackHardware:
    def __init__(self, rp):
        self.rp = rp

    def state(self):
        pid, asg = self.rp.pid0, self.rp.asg0
        sample = {'in1_v': float(self.rp.sampler.in1), 'out2_v': float(self.rp.sampler.out2),
                  'ival_v': float(pid.ival), 'setpoint_v': float(pid.setpoint),
                  'p': float(pid.p), 'i': float(pid.i), 'min_voltage': float(pid.min_voltage),
                  'max_voltage': float(pid.max_voltage)}
        if not all(math.isfinite(v) for v in sample.values()):
            raise RuntimeError('Non-finite feedback telemetry')
        return {'ok': True, **sample, 'input': str(pid.input), 'output': str(pid.output_direct),
                'sweep_output': str(asg.output_direct), 'sampled_at': time.time(),
                'source': 'rp.sampler.in1 / rp.sampler.out2'}

    def off(self):
        # Try every operation even if one register write fails.
        errors = []
        for module, key, value in ((self.rp.pid0, 'output_direct', 'off'),
                                   (self.rp.pid0, 'i', 0), (self.rp.pid0, 'p', 0),
                                   (self.rp.asg0, 'output_direct', 'off')):
            try:
                setattr(module, key, value)
            except Exception as exc:
                errors.append(str(exc))
        if errors:
            raise RuntimeError('Feedback off not fully confirmed: ' + '; '.join(errors))
        return {'ok': True}

    def handoff(self, values):
        values = validate_handoff(values)  # Validate before changing an output.
        try:
            self.off()
            pid = self.rp.pid0
            pid.input = 'in1'
            pid.inputfilter = 0
            for key in ('min_voltage', 'max_voltage', 'setpoint', 'ival', 'p'):
                setattr(pid, key, values[key])
            pid.output_direct = 'out2'
            pid.i = values['i']
            return self.state()
        except Exception:
            self.off()
            raise


class Feedback:
    def __init__(self, rp):
        self.rp = rp

    def _request(self, action, values=None):
        if not self.rp.connected:
            raise RuntimeError('Connect and verify the RP identity first')
        # Intentionally bypass rp.operation(): sampler/PID do not use scope RAM.
        result = self.rp.client.request('/feedback/' + action, values, timeout_s=5)
        if not result.get('ok'):
            raise RuntimeError(result.get('error', str(result)))
        return result

    def state(self):
        return self._request('state')

    def handoff(self, **values):
        return self._request('handoff', validate_handoff(values))

    def off(self):
        return self._request('off')
