from __future__ import annotations
import math

class Parameters:
    def __init__(self, rp, prefix, allowed):
        self.rp, self.prefix, self.allowed = rp, prefix, allowed

    def configure(self, **settings):
        if set(settings) - self.allowed:
            raise ValueError(f'Unknown {self.prefix} settings: {set(settings) - self.allowed}')
        for value in settings.values():
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError('Settings must be finite')
        health = self.rp.bridge_status or {}
        if 'safe_params' in health and not health.get('bridge', {}).get('allow_risky'):
            blocked = [f'{self.prefix}.{name}' for name in settings if f'{self.prefix}.{name}' not in health['safe_params']]
            if blocked:
                raise RuntimeError(f'Bridge does not permit these settings: {blocked}; see bridge startup instructions')
        results = {}
        with self.rp.operation():
            for name, value in settings.items():
                result = self.rp.request('/set', {'param': f'{self.prefix}.{name}',
                                                'value': str(value).lower() if isinstance(value, bool) else str(value)})
                results[name] = result.get('after')
        return results

    def read(self, name):
        if name not in self.allowed:
            raise ValueError(f'Unknown {self.prefix} parameter {name}')
        return self.rp.request('/get', {'param': f'{self.prefix}.{name}'})['value']
