"""Run PyRPL GUI with a tiny local control bridge.

This process owns exactly one PyRPL instance. The GUI and HTTP commands operate
on that same instance, so parameter changes can be observed in the GUI without
editing YAML files behind PyRPL's back.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.redpitaya'

from a221_workbench.instruments.redpitaya.output_safety import disable_outputs, outputs_state
from a221_workbench.tasks.analysis.rp_trace import (
    analyze_scope_trace,
    channel_stats,
    dip_position_features,
    extrema_features,
    make_lockpoint_plot,
    quarter_lockpoint_features,
    smoothed_trace,
    threshold_crossing_features,
    triangle_similarity
)
from a221_workbench.instruments.redpitaya.display import (
    networkanalyzer_power_state,
    networkanalyzer_response_to_dbm,
    patch_networkanalyzer_dbm_display,
    patch_scope_mean_display,
    patch_spectrum_power_units,
    spectrum_power_correction_state,
    spectrum_vpk2_to_display_dbm_per_hz,
    sync_scope_display_controls
)


import argparse
from asyncio import TimeoutError as AsyncTimeoutError
import json
import math
import os
from pathlib import Path
import queue
import sys
import threading
import traceback
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse

import numpy as np

BRIDGE_DIR = Path(__file__).resolve().parent
# The hardware service imports pure analysis and shared output-path policy only.
from a221_workbench.tasks.analysis.lock_trace import analyze_apparent_width, assess_raw_lock_presence
from a221_workbench._shared.lock_paths import RESULTS_DIR


SAFE_PARAMS = {
    "scope.input1",
    "scope.input2",
    "scope.duration",
    "scope.trigger_delay",
    "scope.trigger_source",
    "scope.threshold",
    "scope.hysteresis",
    "scope.rolling_mode",
    "scope.run_continuous",
    "scope.average",
    "scope.scope_zero_enabled",
    "scope.ch1_zero_offset_v",
    "scope.ch2_zero_offset_v",
    "scope.ch1_power_response_v_per_w",
    "scope.ch2_power_response_v_per_w",
    "scope.scope_power_avg_frames",
    "pid0.p",
    "pid0.i",
    "pid0.ival",
    "pid0.output_direct",
    "pid0.inputfilter",
    "asg0.waveform",
    "asg0.frequency",
    "asg0.amplitude",
    "asg0.offset",
    "asg0.output_direct",
    "asg1.waveform",
    "asg1.frequency",
    "asg1.amplitude",
    "asg1.offset",
    "asg1.output_direct",
    "networkanalyzer.dbm_display_enabled",
    "networkanalyzer.dbm_load_ohm",
    "networkanalyzer.dbm_highz_correction_db",
    "networkanalyzer.external_gain_db",
    "networkanalyzer.amplitude",
    "networkanalyzer.start_freq",
    "networkanalyzer.stop_freq",
    "networkanalyzer.points",
    "networkanalyzer.rbw",
    "spectrumanalyzer.span",
    "spectrumanalyzer.trace_average",
}


READABLE_PREFIXES = (
    "scope.",
    "pid0.",
    "pid1.",
    "pid2.",
    "asg0.",
    "asg1.",
    "spectrumanalyzer.",
    "networkanalyzer.",
)


def parse_bool(text: str) -> bool:
    lowered = text.strip().lower()
    if lowered in {"1", "true", "yes", "on"}:
        return True
    if lowered in {"0", "false", "no", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"Cannot parse boolean value: {text!r}")


def json_ready(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer, np.bool_)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_ready(v) for v in value]
    if hasattr(value, "__iter__") and not isinstance(value, (str, bytes)):
        try:
            return [json_ready(v) for v in value]
        except TypeError:
            pass
    try:
        json.dumps(value)
        return value
    except TypeError:
        return repr(value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Start PyRPL and expose a localhost parameter bridge."
    )
    parser.add_argument("--config", default="try", help="PyRPL config name without .yml")
    parser.add_argument("--hostname", default="192.168.1.34", help="Red Pitaya IP")
    parser.add_argument("--listen-host", default="127.0.0.1")
    parser.add_argument("--listen-port", type=int, default=7870)
    parser.add_argument("--loglevel", default="info")
    parser.add_argument("--rp-identity", help="Requested RP name retained for local process identification")
    parser.add_argument("--instance-token", help="Unique token for an explicit restart")
    parser.add_argument("--startup-output-off", action="store_true",
                        help="Disable and verify output registers before accepting HTTP requests")
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Do not open the PyRPL Qt GUI; keep only the localhost bridge running.",
    )
    parser.add_argument(
        "--allow-risky",
        action="store_true",
        help="Allow writes outside the initial safe parameter whitelist.",
    )
    parser.add_argument(
        "--spectrum-load-ohm",
        type=float,
        default=50.0,
        help="Equivalent load resistance for spectrum dBm/dBm/Hz display units.",
    )
    parser.add_argument(
        "--spectrum-power-correction-enabled",
        type=parse_bool,
        default=True,
        help=(
            "Apply display-only dB correction to spectrum dBm/dBm/Hz units. "
            "Use false to show raw RP 50-ohm-equivalent values."
        ),
    )
    parser.add_argument(
        "--spectrum-highz-correction-db",
        type=float,
        default=20.0 * math.log10(2.0),
        help=(
            "Display correction for RP 1 Mohm input reading a 50-ohm source. "
            "Default is 20log10(2)=6.0206 dB."
        ),
    )
    parser.add_argument(
        "--spectrum-external-gain-db",
        type=float,
        default=0.0,
        help="Display correction for external RF gain before the RP input.",
    )
    parser.add_argument(
        "--scope-ch1-response-v-per-w",
        type=float,
        default=3.22013e3,
        help="Initial CH1 optical-power response used by the patched scope GUI.",
    )
    parser.add_argument(
        "--scope-ch2-response-v-per-w",
        type=float,
        default=3.22013e3,
        help="Initial CH2 optical-power response used by the patched scope GUI.",
    )
    parser.add_argument(
        "--scope-zero-enabled",
        type=parse_bool,
        default=False,
        help="Apply configured CH1/CH2 display-zero offsets when opening the patched scope GUI.",
    )
    parser.add_argument(
        "--scope-ch1-zero-offset-v",
        type=float,
        default=0.0,
        help="Initial CH1 display-zero offset in volts, subtracted from the scope GUI trace.",
    )
    parser.add_argument(
        "--scope-ch2-zero-offset-v",
        type=float,
        default=0.0,
        help="Initial CH2 display-zero offset in volts, subtracted from the scope GUI trace.",
    )
    parser.add_argument(
        "--networkanalyzer-dbm-display-enabled",
        type=parse_bool,
        default=True,
        help="Display network-analyzer magnitude as coherent 50-ohm-equivalent dBm.",
    )
    parser.add_argument(
        "--networkanalyzer-load-ohm",
        type=float,
        default=50.0,
        help="Equivalent load resistance for network-analyzer dBm display.",
    )
    parser.add_argument(
        "--networkanalyzer-highz-correction-db",
        type=float,
        default=20.0 * math.log10(2.0),
        help="Display correction for RP 1 Mohm input in network-analyzer dBm mode.",
    )
    parser.add_argument(
        "--networkanalyzer-external-gain-db",
        type=float,
        default=None,
        help=(
            "External RF gain subtracted from network-analyzer dBm display. "
            "Defaults to --spectrum-external-gain-db."
        ),
    )
    return parser.parse_args()


def coerce_value(text: str, current: Any | None) -> Any:
    lowered = text.strip().lower()
    if isinstance(current, bool) or lowered in {"true", "false"}:
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        raise ValueError(f"Cannot parse boolean value: {text!r}")
    if isinstance(current, int) and not isinstance(current, bool):
        return int(text)
    if isinstance(current, float):
        return float(text)
    try:
        return int(text)
    except ValueError:
        pass
    try:
        return float(text)
    except ValueError:
        return text


def format_voltage(value: float) -> str:
    if not np.isfinite(value):
        return "nan"
    abs_value = abs(value)
    if abs_value < 1e-6:
        return f"{value * 1e9:.3f} nV"
    if abs_value < 1e-3:
        return f"{value * 1e6:.3f} uV"
    if abs_value < 1.0:
        return f"{value * 1e3:.3f} mV"
    return f"{value:.5g} V"


def format_response_v_per_w(value: float) -> str:
    if not np.isfinite(value) or value <= 0:
        return "n/a"
    if value >= 1e6:
        return f"{value / 1e6:.3g} MV/W"
    if value >= 1e3:
        return f"{value / 1e3:.3g} kV/W"
    return f"{value:.3g} V/W"


def format_power_w(value: float) -> str:
    if not np.isfinite(value):
        return "nan"
    abs_value = abs(value)
    if abs_value < 1e-9:
        return f"{value * 1e12:.2f} pW"
    if abs_value < 1e-6:
        return f"{value * 1e9:.2f} nW"
    if abs_value < 1e-3:
        return f"{value * 1e6:.3f} uW"
    return f"{value * 1e3:.3f} mW"


class Bridge:
    def __init__(
        self,
        pyrpl_instance: Any,
        allow_risky: bool = False,
        metadata: dict[str, Any] | None = None,
    ):
        self.p = pyrpl_instance
        self.allow_risky = allow_risky
        self.metadata = metadata or {}
        self.started_at = time.time()
        from .bridge_version import backend_identity
        self.backend_identity = backend_identity()
        from a221_workbench.instruments.redpitaya.feedback import FeedbackHardware
        self.feedback = FeedbackHardware(self.p.rp)
        from .excitation import ExcitationHardware
        self.excitation = ExcitationHardware(self.p.rp)
        self.feedback_tasks = queue.Queue()
        self.tasks: "queue.Queue[tuple[callable, threading.Event, dict[str, Any]]]" = (
            queue.Queue()
        )

    def submit(self, fn: callable, wait_timeout: float = 5.0) -> dict[str, Any]:
        done = threading.Event()
        box: dict[str, Any] = {}
        self.tasks.put((fn, done, box))
        if not done.wait(timeout=wait_timeout):
            return {"ok": False, "error": "Timed out waiting for PyRPL GUI thread"}
        return box

    def submit_feedback(self, fn, wait_timeout=4.0):
        done, box = threading.Event(), {}
        cancelled = threading.Event()
        self.feedback_tasks.put((fn, done, box, time.perf_counter() + wait_timeout, cancelled))
        if not done.wait(wait_timeout):
            cancelled.set()
            return {'ok': False, 'error': 'Feedback command timed out; state is unconfirmed'}
        return box

    def drain_feedback(self):
        self.excitation.tick()
        # A separate Qt timer remains serviceable inside scope.single()'s nested
        # event loop. Never access PyRPL registers from an HTTP/worker thread.
        while True:
            try:
                fn, done, box, deadline, cancelled = self.feedback_tasks.get_nowait()
            except queue.Empty:
                return
            try:
                if cancelled.is_set() or time.perf_counter() >= deadline:
                    raise TimeoutError('Expired feedback command was not executed')
                box.update(fn())
            except Exception as exc:
                box.update(ok=False, error=str(exc))
            finally:
                done.set()

    def drain_once(self) -> None:
        while True:
            try:
                fn, done, box = self.tasks.get_nowait()
            except queue.Empty:
                break
            try:
                box.update(fn())
            except BaseException as exc:  # pragma: no cover - interactive diagnostics
                if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                    raise
                box.update(
                    {
                        "ok": False,
                        "error": repr(exc),
                        "traceback": traceback.format_exc(limit=4),
                    }
                )
            finally:
                done.set()

    def resolve(self, dotted: str) -> tuple[Any, str]:
        if "." not in dotted:
            raise ValueError("Parameter must look like module.attribute")
        module_name, attr = dotted.split(".", 1)
        if hasattr(self.p.rp, module_name):
            module = getattr(self.p.rp, module_name)
        else:
            module = getattr(self.p, module_name)
        return module, attr

    def get_param(self, dotted: str) -> dict[str, Any]:
        if not dotted.startswith(READABLE_PREFIXES):
            raise ValueError(f"Reading {dotted!r} is not in the bridge allowlist")
        module, attr = self.resolve(dotted)
        value = json_ready(getattr(module, attr))
        return {"ok": True, "param": dotted, "value": value, "type": type(value).__name__}

    def set_param(self, dotted: str, raw_value: str) -> dict[str, Any]:
        if dotted not in SAFE_PARAMS and not self.allow_risky:
            raise ValueError(
                f"Refusing to write {dotted!r}. Start with --allow-risky only after "
                "the safe scope-parameter test is working."
            )
        module, attr = self.resolve(dotted)
        before = getattr(module, attr)
        value = coerce_value(raw_value, before)
        setattr(module, attr, value)
        after = getattr(module, attr)
        return {
            "ok": True,
            "param": dotted,
            "before": before,
            "written": value,
            "after": after,
            "type": type(after).__name__,
        }

    def prepare_lock_sweep(
        self,
        duration: float,
        frequency: float,
        amplitude: float,
    ) -> dict[str, Any]:
        """Configure the RP fine sweep in one bridge-thread transaction."""
        updates = (
            ("pid0.p", 0),
            ("pid0.i", 0),
            ("pid0.output_direct", "off"),
            ("asg0.waveform", "ramp"),
            ("asg0.frequency", frequency),
            ("asg0.amplitude", amplitude),
            ("asg0.offset", 0),
            ("asg0.output_direct", "out2"),
            ("scope.input1", "in1"),
            ("scope.input2", "out2"),
            ("scope.trigger_source", "asg0"),
            ("scope.trigger_delay", 0),
            ("scope.duration", duration),
            ("scope.rolling_mode", "false"),
            ("scope.run_continuous", "true"),
        )
        started = time.perf_counter()
        steps = [self.set_param(param, str(value)) for param, value in updates]
        return {
            "ok": True,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "steps": steps,
        }

    def get_spectrum_power_correction(self) -> dict[str, Any]:
        return spectrum_power_correction_state(self.p.spectrumanalyzer)

    def get_networkanalyzer_power_display(self) -> dict[str, Any]:
        return networkanalyzer_power_state(self.p.networkanalyzer)

    def acquisition_settings(self) -> dict[str, Any]:
        spectrum = self.p.spectrumanalyzer
        network = self.p.networkanalyzer
        span_options = [float(v) for v in spectrum.spans]
        spectrum_rbw_options = [
            float(v) for v in spectrum.__class__.rbw.valid_frequencies(spectrum)
        ]
        network_rbw_options = [
            float(v) for v in network.__class__.rbw.valid_frequencies(network)
        ]
        spectrum_pairs = [
            {"span_hz": span, "rbw_hz": spectrum_rbw_options[idx]}
            for idx, span in enumerate(span_options)
            if idx < len(spectrum_rbw_options)
        ]
        return {
            "ok": True,
            "spectrum": {
                "span_hz": float(spectrum.span),
                "rbw_hz": float(spectrum.rbw),
                "trace_average": int(spectrum.trace_average),
                "window": str(spectrum.window),
                "baseband": bool(spectrum.baseband),
                "data_length": int(spectrum.data_length),
                "display_points": int(spectrum._real_points),
                "span_rbw_options": spectrum_pairs,
            },
            "network": {
                "amplitude_vpk": float(network.amplitude),
                "start_freq_hz": float(network.start_freq),
                "stop_freq_hz": float(network.stop_freq),
                "points": int(network.points),
                "rbw_hz": float(network.rbw),
                "average_per_point": int(network.average_per_point),
                "trace_average": int(network.trace_average),
                "rbw_options": network_rbw_options,
            },
        }

    def stop_acquisitions(self) -> dict[str, Any]:
        steps: list[dict[str, Any]] = []
        for name in ("spectrumanalyzer", "networkanalyzer", "scope"):
            module = getattr(self.p, name, None)
            if module is None:
                continue
            module_steps: list[dict[str, Any]] = []
            for method_name in ("stop", "pause"):
                method = getattr(module, method_name, None)
                if callable(method):
                    try:
                        method()
                        module_steps.append({"action": method_name, "ok": True})
                        break
                    except Exception as exc:
                        module_steps.append({"action": method_name, "ok": False, "error": repr(exc)})
            for attr_name, value in (
                ("running", False),
                ("run_continuous", False),
            ):
                if hasattr(module, attr_name):
                    try:
                        setattr(module, attr_name, value)
                        module_steps.append({"action": f"set {attr_name}", "ok": True, "value": value})
                    except Exception as exc:
                        module_steps.append({"action": f"set {attr_name}", "ok": False, "error": repr(exc)})
            steps.append({"module": name, "steps": module_steps})
        return {"ok": True, "message": "best-effort acquisition stop requested", "steps": steps}

    def configure_scope_inputs(
        self, input1: str = "in1", input2: str = "out2"
    ) -> dict[str, Any]:
        scope = self.p.rp.scope
        steps: list[dict[str, Any]] = []
        for method_name in ("stop", "pause"):
            method = getattr(scope, method_name, None)
            if callable(method):
                try:
                    method()
                    steps.append({"action": method_name, "ok": True})
                    break
                except Exception as exc:
                    steps.append({"action": method_name, "ok": False, "error": repr(exc)})
        for attr_name, value in (
            ("running", False),
            ("run_continuous", False),
            ("input1", input1),
            ("input2", input2),
        ):
            if not hasattr(scope, attr_name):
                continue
            try:
                before = getattr(scope, attr_name)
                setattr(scope, attr_name, value)
                after = getattr(scope, attr_name)
                steps.append(
                    {
                        "param": f"scope.{attr_name}",
                        "before": json_ready(before),
                        "written": json_ready(value),
                        "after": json_ready(after),
                        "ok": True,
                    }
                )
            except Exception as exc:
                steps.append({"param": f"scope.{attr_name}", "value": value, "ok": False, "error": repr(exc)})
        return {
            "ok": str(scope.input1) == input1 and str(scope.input2) == input2,
            "input1": str(scope.input1),
            "input2": str(scope.input2),
            "expected_input1": input1,
            "expected_input2": input2,
            "steps": steps,
        }

    def scope_power(self, timeout: float = 3.0, retries: int = 8) -> dict[str, Any]:
        scope = self.p.rp.scope
        attempts: list[dict[str, Any]] = []
        input_setup = self.configure_scope_inputs("in1", "out2")
        if not input_setup.get("ok"):
            return {
                "ok": False,
                "error": "failed to configure scope inputs for power readout",
                "input_setup": input_setup,
            }
        try:
            capture = self.capture_scope(
                tag="scope_power",
                timeout=timeout,
                make_plot=False,
                save=False,
                inline=False,
            )
            attempts.append({"attempt": 1, "ok": True})
        except BaseException as exc:
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            attempts.append({"attempt": 1, "ok": False, "error": repr(exc)})
            return {
                "ok": False,
                "error": "scope capture failed",
                "input_setup": input_setup,
                "attempts": attempts,
            }
        stats = ((capture.get("analysis") or {}).get("stats") or {})
        raw_means = (
            float((stats.get("ch1") or {}).get("mean", np.nan)),
            float((stats.get("ch2") or {}).get("mean", np.nan)),
        )
        zero_enabled = bool(
            getattr(scope, "scope_zero_enabled", self.metadata.get("scope_zero_enabled", False))
        )
        offsets = (
            float(getattr(scope, "ch1_zero_offset_v", self.metadata.get("scope_ch1_zero_offset_v", 0.0))),
            float(getattr(scope, "ch2_zero_offset_v", self.metadata.get("scope_ch2_zero_offset_v", 0.0))),
        )
        shown_means = (
            raw_means[0] - offsets[0] if zero_enabled else raw_means[0],
            raw_means[1] - offsets[1] if zero_enabled else raw_means[1],
        )
        responses = (
            float(
                getattr(
                    scope,
                    "ch1_power_response_v_per_w",
                    self.metadata.get("scope_ch1_response_v_per_w", np.nan),
                )
            ),
            float(
                getattr(
                    scope,
                    "ch2_power_response_v_per_w",
                    self.metadata.get("scope_ch2_response_v_per_w", np.nan),
                )
            ),
        )
        powers = (
            shown_means[0] / responses[0]
            if np.isfinite(responses[0]) and responses[0] > 0
            else np.nan,
            shown_means[1] / responses[1]
            if np.isfinite(responses[1]) and responses[1] > 0
            else np.nan,
        )
        lines = [f"raw mean: CH1 {format_voltage(raw_means[0])} | CH2 {format_voltage(raw_means[1])}"]
        if zero_enabled:
            lines.append(f"offset: CH1 {format_voltage(offsets[0])} | CH2 {format_voltage(offsets[1])}")
        lines.extend(
            [
                f"shown mean: CH1 {format_voltage(shown_means[0])} | CH2 {format_voltage(shown_means[1])}",
                f"response: CH1 {format_response_v_per_w(responses[0])} | CH2 {format_response_v_per_w(responses[1])}",
                f"P inst: CH1 {format_power_w(powers[0])} | CH2 {format_power_w(powers[1])}",
            ]
        )
        overlay = "\n".join(lines)
        try:
            scope.active_means_v = overlay
        except Exception:
            pass
        post_input_setup = self.configure_scope_inputs("in1", "out2")
        return {
            "ok": True,
            "overlay": overlay,
            "power_w": {"CH1": powers[0], "CH2": powers[1]},
            "raw_mean_v": {"CH1": raw_means[0], "CH2": raw_means[1]},
            "shown_mean_v": {"CH1": shown_means[0], "CH2": shown_means[1]},
            "offset_v": {"CH1": offsets[0], "CH2": offsets[1]},
            "response_v_per_w": {"CH1": responses[0], "CH2": responses[1]},
            "zero_enabled": zero_enabled,
            "input_setup": input_setup,
            "post_input_setup": post_input_setup,
            "attempts": attempts,
            "input1": str(scope.input1),
            "input2": str(scope.input2),
            "duration": float(scope.duration),
            "n": int(capture.get("n") or 0),
            "capture": capture,
        }

    def health(self) -> dict[str, Any]:
        pyrpl_module = sys.modules.get("pyrpl")
        return {
            "ok": True,
            "message": "pyrpl_live_bridge is running",
            "bridge": {
                "pid": os.getpid(),
                "python_executable": sys.executable,
                "pyrpl_version": getattr(pyrpl_module, "__version__", None),
                "pyrpl_file": getattr(pyrpl_module, "__file__", None),
                "started_at": self.started_at,
                "uptime_s": time.time() - self.started_at,
                "allow_risky": self.allow_risky,
                **self.metadata,
            },
            "spectrum_power_correction": self.get_spectrum_power_correction(),
            "networkanalyzer_power_display": self.get_networkanalyzer_power_display(),
            "safe_params": sorted(SAFE_PARAMS),
            "supports_shutdown": True,
            "backend_identity": self.backend_identity,
            "activity": {"excitation_owned": self.excitation.token is not None,
                         "queued_commands": self.tasks.qsize() + self.feedback_tasks.qsize()},
            "supports_gui": True,
            "supports_feedback": True,
            "supports_excitation": True,
            "excitation_protocol": 4,
            "scope_trigger_wait_revision": 1,
            "supports_output_safety": True,
        }

    def show_gui(self) -> dict[str, Any]:
        """Called via submit on the Qt thread, using the existing PyRPL instance."""
        self.p.show_gui()
        for widget in self.p.widgets:
            widget.showNormal()
            widget.raise_()
            widget.activateWindow()
        return {"ok": True, "visible": True, "same_session": True}

    def request_shutdown(self) -> None:
        # Leave time to deliver the HTTP response, then close the whole owner.
        import pyrpl
        from qtpy import QtCore
        QtCore.QTimer.singleShot(250, pyrpl.APP.quit)

    def hide_gui(self) -> dict[str, Any]:
        self.p.hide_gui()
        return {"ok": True, "visible": False, "same_session": True}

    def set_spectrum_power_correction(
        self,
        enabled: bool | None = None,
        highz_correction_db: float | None = None,
        external_gain_db: float | None = None,
        load_ohm: float | None = None,
    ) -> dict[str, Any]:
        spectrum = self.p.spectrumanalyzer
        state = spectrum_power_correction_state(spectrum)
        patch_spectrum_power_units(
            load_ohm=state["load_ohm"] if load_ohm is None else load_ohm,
            correction_enabled=state["enabled"] if enabled is None else enabled,
            highz_correction_db=(
                state["highz_correction_db"]
                if highz_correction_db is None
                else highz_correction_db
            ),
            external_gain_db=(
                state["external_gain_db"]
                if external_gain_db is None
                else external_gain_db
            ),
        )
        if external_gain_db is not None:
            spectrum.external_gain_db = external_gain_db
        return spectrum_power_correction_state(spectrum)

    def capture_scope(
        self,
        tag: str = "scope_capture",
        timeout: float = 5.0,
        make_plot: bool = True,
        save: bool = True,
        inline: bool = False,
        max_points: int = 1500,
    ) -> dict[str, Any]:
        scope = self.p.rp.scope
        try:
            curve = scope.single(timeout=timeout)
        except AsyncTimeoutError:
            # Python 3.10 asyncio.TimeoutError is NOT builtins.TimeoutError.
            # Only a pending, armed ASG1 acquisition with no trigger received
            # is a normal wait. Do not hide transport timeouts or a stalled
            # post-trigger acquisition under the same UI status.
            try:
                pending = scope._last_run
                waiting = (str(scope.trigger_source) == 'asg1'
                           and pending is not None and not pending.done()
                           and bool(scope._trigger_armed)
                           and not bool(scope._trigger_delay_running))
            finally:
                scope.stop()
            if waiting:
                return dict(ok=False, code='TRIGGER_TIMEOUT', error='Waiting for ASG1 trigger')
            raise
        ch1 = np.asarray(curve[0], dtype=float)
        ch2 = np.asarray(curve[1], dtype=float)
        times = np.asarray(scope.times, dtype=float)
        safe_tag = "".join(c if c.isalnum() or c in "-_" else "_" for c in tag)
        path = None
        if save:
            path = RESULTS_DIR / f"{safe_tag}.npz"
            RESULTS_DIR.mkdir(parents=True, exist_ok=True)
            np.savez(
                path,
                t=times,
                ch1=ch1,
                ch2=ch2,
                input1=str(scope.input1),
                input2=str(scope.input2),
                duration=float(scope.duration),
                trigger_source=str(scope.trigger_source),
            )
        analysis = analyze_scope_trace(times, ch1, ch2, str(scope.input1), str(scope.input2))
        plot_path = None
        if make_plot and save:
            plot_path = RESULTS_DIR / f"{safe_tag}_lockpoint.png"
            plot_result = make_lockpoint_plot(
                times=times,
                ch1=ch1,
                ch2=ch2,
                input1=str(scope.input1),
                input2=str(scope.input2),
                analysis=analysis,
                path=plot_path,
                title=safe_tag,
            )
        else:
            reason = "plot=false" if not make_plot else "save=false"
            plot_result = {"ok": False, "skipped": True, "reason": reason}
        payload = {
            "ok": True,
            "path": str(path) if save else None,
            "plot_path": str(plot_path) if plot_result.get("ok") else None,
            "plot": plot_result,
            "n": int(len(times)),
            "input1": str(scope.input1),
            "input2": str(scope.input2),
            "duration": float(scope.duration),
            "trigger_source": str(scope.trigger_source),
            "analysis": analysis,
        }
        if inline:
            limit = max(100, int(max_points))
            step = max(1, int(math.ceil(len(times) / limit)))
            payload["trace"] = {
                "t": times[::step].astype(float).tolist(),
                "ch1": ch1[::step].astype(float).tolist(),
                "ch2": ch2[::step].astype(float).tolist(),
                "decimation": step,
            }
        return payload

    def scope_dip_position(
        self,
        timeout: float = 2.5,
        branch: str = "auto",
        smooth_points: int = 7,
        source: str = "cache",
        center_time_s: float | None = None,
        window_s: float | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        scope = self.p.rp.scope
        source_used = "single"
        curve = None
        cache_frame_id = None
        cache_updated_at = None
        requested_source = str(source or "cache").strip().lower()
        if requested_source in {"cache", "cached", "auto"}:
            cached = getattr(scope, "_daily_note_last_raw_scope_curves", None)
            if cached is not None:
                try:
                    cached_arr = np.asarray(cached, dtype=float)
                    if cached_arr.ndim >= 2 and cached_arr.shape[0] >= 2 and cached_arr.shape[1] >= 8:
                        curve = cached_arr[:2]
                        source_used = "scope.display_cache"
                        cache_frame_id = int(getattr(scope, "_daily_note_scope_cache_frame_id", 0))
                        cache_updated_at = float(getattr(scope, "_daily_note_scope_cache_updated_at", math.nan))
                except Exception:
                    curve = None
            cached = getattr(scope, "data_avg", None) if curve is None else None
            if cached is not None:
                try:
                    cached_arr = np.asarray(cached, dtype=float)
                    if cached_arr.ndim >= 2 and cached_arr.shape[0] >= 2 and cached_arr.shape[1] >= 8:
                        curve = cached_arr[:2]
                        source_used = "scope.data_avg"
                        cache_frame_id = None
                        cache_updated_at = None
                except Exception:
                    curve = None
        if curve is None:
            if requested_source in {"cache", "cached"}:
                return {
                    "ok": False,
                    "error": "scope cached data is unavailable; open/refresh PyRPL scope GUI or request source=single",
                    "source_requested": source,
                }
            curve = scope.single(timeout=timeout)
            source_used = "scope.single"
            try:
                cached_arr = np.asarray(curve[:2], dtype=float)
                frame_id = int(getattr(scope, "_daily_note_scope_cache_frame_id", 0)) + 1
                scope._daily_note_last_raw_scope_curves = cached_arr
                scope._daily_note_scope_cache_frame_id = frame_id
                scope._daily_note_scope_cache_updated_at = time.time()
                cache_frame_id = frame_id
                cache_updated_at = float(scope._daily_note_scope_cache_updated_at)
            except Exception:
                cache_frame_id = None
                cache_updated_at = None
        ch1 = np.asarray(curve[0], dtype=float)
        ch2 = np.asarray(curve[1], dtype=float)
        times = np.asarray(scope.times, dtype=float)
        if times.size != ch1.size:
            times = np.arange(ch1.size, dtype=float)
        input1 = str(scope.input1)
        input2 = str(scope.input2)
        analysis = analyze_scope_trace(times, ch1, ch2, input1, input2)
        sweep_ch = str(analysis.get("likely_sweep_channel") or "ch2")
        trans_ch = str(analysis.get("likely_transmission_channel") or "ch1")
        sweep = ch1 if sweep_ch == "ch1" else ch2
        transmission = ch1 if trans_ch == "ch1" else ch2
        position = dip_position_features(
            times,
            transmission,
            sweep,
            branch=branch,
            smooth_points=smooth_points,
            center_time_s=center_time_s,
            window_s=window_s,
        )
        return {
            "ok": bool(position.get("ok")),
            "source_requested": source,
            "source_used": source_used,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "cache_frame_id": cache_frame_id,
            "cache_updated_at": cache_updated_at,
            "cache_age_ms": (
                round((time.time() - cache_updated_at) * 1000.0, 3)
                if cache_updated_at is not None and math.isfinite(cache_updated_at)
                else None
            ),
            "n": int(len(times)),
            "input1": input1,
            "input2": input2,
            "duration": float(scope.duration),
            "trigger_source": str(scope.trigger_source),
            "likely_sweep_channel": sweep_ch,
            "likely_sweep_input": input1 if sweep_ch == "ch1" else input2,
            "likely_transmission_channel": trans_ch,
            "likely_transmission_input": input1 if trans_ch == "ch1" else input2,
            "position": position,
        }

    def scope_lock_analysis(
        self,
        timeout: float = 8.0,
        width_depth_fraction: float = 0.75,
        lock_depth_fraction: float = 0.25,
        presence_min_snr: float = 6.0,
        presence_min_samples: int = 3,
    ) -> dict[str, Any]:
        """Acquire one pre-lock frame and return only lock-analysis scalars."""
        started = time.perf_counter()
        scope = self.p.rp.scope
        curve = scope.single(timeout=timeout)
        ch1 = np.asarray(curve[0], dtype=float)
        ch2 = np.asarray(curve[1], dtype=float)
        times = np.asarray(scope.times, dtype=float)
        if times.size != ch1.size:
            times = np.arange(ch1.size, dtype=float)

        width = analyze_apparent_width(
            times,
            ch1,
            ch2,
            float(width_depth_fraction),
        )
        lock = analyze_apparent_width(
            times,
            ch1,
            ch2,
            float(lock_depth_fraction),
        )
        segment = lock.get("downsweep_segment") if isinstance(lock.get("downsweep_segment"), dict) else {}
        segment_start = max(0, int(segment.get("start_index") or 0))
        segment_end = min(ch1.size - 1, int(segment.get("end_index") or (ch1.size - 1)))
        segment_ch1 = ch1[segment_start : segment_end + 1]
        finite_segment = segment_ch1[np.isfinite(segment_ch1)]
        if finite_segment.size >= 4:
            differences = np.diff(finite_segment)
            diff_median = float(np.median(differences))
            noise_sigma_v = float(
                1.4826 * np.median(np.abs(differences - diff_median)) / math.sqrt(2.0)
            )
        else:
            noise_sigma_v = float("nan")
        presence = assess_raw_lock_presence(
            lock,
            noise_sigma_v=noise_sigma_v,
            min_snr=float(presence_min_snr),
            min_samples=int(presence_min_samples),
        )
        return {
            "ok": bool(width.get("ok") and lock.get("ok")),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "n": int(ch1.size),
            "input1": str(scope.input1),
            "input2": str(scope.input2),
            "duration": float(scope.duration),
            "trigger_source": str(scope.trigger_source),
            "width_depth_fraction": float(width_depth_fraction),
            "lock_depth_fraction": float(lock_depth_fraction),
            "width_analysis": width,
            "lockpoint_analysis": lock,
            "presence_analysis": presence,
        }

    def scope_threshold_crossing(
        self,
        timeout: float = 2.5,
        smooth_points: int = 5,
        source: str = "cache",
        center_time_s: float | None = None,
        window_s: float | None = None,
        reference_time_s: float | None = None,
        threshold_v: float | None = None,
        edge: str = "nearest",
    ) -> dict[str, Any]:
        started = time.perf_counter()
        scope = self.p.rp.scope
        source_used = "single"
        curve = None
        cache_frame_id = None
        cache_updated_at = None
        requested_source = str(source or "cache").strip().lower()
        if requested_source in {"cache", "cached", "auto"}:
            cached = getattr(scope, "_daily_note_last_raw_scope_curves", None)
            if cached is not None:
                try:
                    cached_arr = np.asarray(cached, dtype=float)
                    if cached_arr.ndim >= 2 and cached_arr.shape[0] >= 2 and cached_arr.shape[1] >= 8:
                        curve = cached_arr[:2]
                        source_used = "scope.display_cache"
                        cache_frame_id = int(getattr(scope, "_daily_note_scope_cache_frame_id", 0))
                        cache_updated_at = float(getattr(scope, "_daily_note_scope_cache_updated_at", math.nan))
                except Exception:
                    curve = None
            cached = getattr(scope, "data_avg", None) if curve is None else None
            if cached is not None:
                try:
                    cached_arr = np.asarray(cached, dtype=float)
                    if cached_arr.ndim >= 2 and cached_arr.shape[0] >= 2 and cached_arr.shape[1] >= 8:
                        curve = cached_arr[:2]
                        source_used = "scope.data_avg"
                        cache_frame_id = None
                        cache_updated_at = None
                except Exception:
                    curve = None
        if curve is None:
            if requested_source in {"cache", "cached"}:
                return {
                    "ok": False,
                    "error": "scope cached data is unavailable; open/refresh PyRPL scope GUI or request source=single",
                    "source_requested": source,
                }
            curve = scope.single(timeout=timeout)
            source_used = "scope.single"
            try:
                cached_arr = np.asarray(curve[:2], dtype=float)
                frame_id = int(getattr(scope, "_daily_note_scope_cache_frame_id", 0)) + 1
                scope._daily_note_last_raw_scope_curves = cached_arr
                scope._daily_note_scope_cache_frame_id = frame_id
                scope._daily_note_scope_cache_updated_at = time.time()
                cache_frame_id = frame_id
                cache_updated_at = float(scope._daily_note_scope_cache_updated_at)
            except Exception:
                cache_frame_id = None
                cache_updated_at = None
        ch1 = np.asarray(curve[0], dtype=float)
        ch2 = np.asarray(curve[1], dtype=float)
        times = np.asarray(scope.times, dtype=float)
        if times.size != ch1.size:
            times = np.arange(ch1.size, dtype=float)
        input1 = str(scope.input1)
        input2 = str(scope.input2)
        analysis = analyze_scope_trace(times, ch1, ch2, input1, input2)
        sweep_ch = str(analysis.get("likely_sweep_channel") or "ch2")
        trans_ch = str(analysis.get("likely_transmission_channel") or "ch1")
        sweep = ch1 if sweep_ch == "ch1" else ch2
        transmission = ch1 if trans_ch == "ch1" else ch2
        crossing = threshold_crossing_features(
            times,
            transmission,
            sweep,
            center_time_s=center_time_s,
            window_s=window_s,
            reference_time_s=reference_time_s,
            threshold_v=threshold_v,
            edge=edge,
            smooth_points=smooth_points,
        )
        return {
            "ok": bool(crossing.get("ok")),
            "source_requested": source,
            "source_used": source_used,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "cache_frame_id": cache_frame_id,
            "cache_updated_at": cache_updated_at,
            "cache_age_ms": (
                round((time.time() - cache_updated_at) * 1000.0, 3)
                if cache_updated_at is not None and math.isfinite(cache_updated_at)
                else None
            ),
            "n": int(len(times)),
            "input1": input1,
            "input2": input2,
            "duration": float(scope.duration),
            "trigger_source": str(scope.trigger_source),
            "likely_sweep_channel": sweep_ch,
            "likely_sweep_input": input1 if sweep_ch == "ch1" else input2,
            "likely_transmission_channel": trans_ch,
            "likely_transmission_input": input1 if trans_ch == "ch1" else input2,
            "crossing": crossing,
        }

    def capture_spectrum(
        self,
        tag: str = "spectrum_capture",
        timeout: float = 15.0,
        load_ohm: float = 50.0,
        save_csv: bool = False,
        save_npz: bool = True,
        inline: bool = False,
        max_points: int = 1500,
        acquire: bool = True,
        output_dir: str | None = None,
    ) -> dict[str, Any]:
        if load_ohm <= 0:
            raise ValueError("load_ohm must be positive")
        spectrum = self.p.spectrumanalyzer
        data = None
        freqs = None
        source = "single"
        if not acquire:
            cached = getattr(spectrum, "data_avg", None)
            cached_x = getattr(spectrum, "data_x", None)
            if cached is not None and cached_x is not None:
                try:
                    cached_arr = np.asarray(cached, dtype=float)
                    cached_freqs = np.asarray(cached_x, dtype=float)
                    if cached_arr.size and cached_freqs.size:
                        data = cached_arr
                        freqs = cached_freqs
                        source = "cache"
                except Exception:
                    data = None
                    freqs = None
        if data is None or freqs is None:
            data = np.asarray(spectrum.single(timeout=timeout), dtype=float)
            freqs = np.asarray(spectrum.data_x, dtype=float)
        rbw = float(spectrum.rbw)
        if data.ndim == 1:
            input1_vpk2 = data
        else:
            input1_vpk2 = np.asarray(data[0], dtype=float)
        display_power_correction = spectrum_power_correction_state(spectrum)
        input1_dbm_per_hz = spectrum_vpk2_to_display_dbm_per_hz(
            input1_vpk2,
            rbw,
            display_power_correction,
        )

        output_root = (Path(output_dir).expanduser() if output_dir else RESULTS_DIR.resolve()) if (save_npz or save_csv) else None
        if output_root is not None:
            output_root.mkdir(parents=True, exist_ok=True)
        safe_tag = "".join(c if c.isalnum() or c in "-_" else "_" for c in tag)
        npz_path = output_root / f"{safe_tag}.npz" if save_npz else None
        csv_path = output_root / f"{safe_tag}.csv" if save_csv else None
        meta_path = output_root / f"{safe_tag}.json" if save_npz else None

        arrays = {
            "frequency_hz": freqs,
            "input1_dbm_per_hz": input1_dbm_per_hz,
        }
        if save_npz:
            np.savez(npz_path, **arrays)

        if csv_path is not None:
            with csv_path.open("w", encoding="utf-8", newline="") as fh:
                fh.write("frequency_hz,input1_dbm_per_hz\n")
                for idx, freq in enumerate(freqs):
                    fh.write(
                        f"{float(freq):.12g},"
                        f"{float(input1_dbm_per_hz[idx]):.12g}\n"
                    )

        finite = (
            np.isfinite(input1_vpk2)
            & np.isfinite(input1_dbm_per_hz)
            & np.isfinite(freqs)
        )
        band = finite & (freqs > 0)
        summary = {}
        if np.any(band):
            summary["input1_dbm_per_hz"] = {
                "median": float(np.nanmedian(input1_dbm_per_hz[band])),
                "min": float(np.nanmin(input1_dbm_per_hz[band])),
                "max": float(np.nanmax(input1_dbm_per_hz[band])),
            }

        meta = {
            "ok": True,
            "tag": safe_tag,
            "path": str(npz_path) if save_npz else None,
            "output_dir": str(output_root) if output_root is not None else None,
            "csv_path": str(csv_path) if csv_path is not None else None,
            "save_csv": save_csv,
            "save_npz": save_npz,
            "metadata_path": str(meta_path) if save_npz else None,
            "saved_arrays": ["frequency_hz", "input1_dbm_per_hz"],
            "raw_channel": "input1",
            "raw_unit_not_saved": "Vpk^2, from PyRPL spectrumanalyzer.single() before display-unit conversion",
            "display_unit_saved": "dBm/Hz",
            "conversion_note": {
                "vpk_to_vrms": "Vrms = Vpk / sqrt(2)",
                "spectrum_vpk2_to_dbm_per_hz": (
                    "uncorrected_dbm_per_hz = 10*log10((Vpk^2 / (2*R_ohm)) / RBW_Hz / 1e-3); "
                    "saved input1_dbm_per_hz = uncorrected_dbm_per_hz - total_subtracted_db when correction is enabled"
                ),
                "inverse_dbm_per_hz_to_vpk2": (
                    "Vpk^2 = 2*R_ohm*RBW_Hz*1e-3*10^((saved_dbm_per_hz + total_subtracted_db)/10) "
                    "when correction is enabled"
                ),
            },
            "display_power_correction": display_power_correction,
            "display_load_ohm": display_power_correction["load_ohm"],
            "source": source,
            "rbw_hz": rbw,
            "baseband": bool(spectrum.baseband),
            "span_hz": float(spectrum.span),
            "center_hz": float(spectrum.center),
            "window": str(spectrum.window),
            "trace_average": int(spectrum.trace_average),
            "current_avg": int(spectrum.current_avg),
            "input": str(spectrum.input),
            "input1_baseband": str(spectrum.input1_baseband),
            "input2_baseband": str(spectrum.input2_baseband),
            "display_input1_baseband": bool(spectrum.display_input1_baseband),
            "display_input2_baseband": bool(spectrum.display_input2_baseband),
            "n": int(len(freqs)),
            "labels": ["frequency_hz", "input1_dbm_per_hz"],
            "summary": summary,
        }
        if inline:
            limit = max(100, int(max_points))
            step = max(1, int(math.ceil(len(freqs) / limit)))
            meta["trace"] = {
                "frequency_hz": freqs[::step].astype(float).tolist(),
                "input1_dbm_per_hz": input1_dbm_per_hz[::step].astype(float).tolist(),
                "decimation": step,
            }
        if save_npz:
            meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return meta

    def capture_network_analyzer(
        self,
        tag: str = "network_analyzer_preview",
        timeout: float = 20.0,
        save_npz: bool = True,
        inline: bool = True,
        max_points: int = 1200,
        acquire: bool = True,
        output_dir: str | None = None,
    ) -> dict[str, Any]:
        na = self.p.networkanalyzer
        data = None
        freqs = None
        source = "single"
        if not acquire:
            cached = getattr(na, "data_avg", None)
            cached_x = getattr(na, "data_x", None)
            if cached is not None and cached_x is not None:
                try:
                    cached_arr = np.asarray(cached)
                    cached_freqs = np.asarray(cached_x, dtype=float)
                    if cached_arr.size and cached_freqs.size:
                        data = cached_arr
                        freqs = cached_freqs
                        source = "cache"
                except Exception:
                    data = None
                    freqs = None
        if data is None or freqs is None:
            data = np.asarray(na.single(timeout=timeout))
            freqs = np.asarray(na.frequencies, dtype=float)
        if data.ndim > 1:
            response = np.asarray(data[0], dtype=complex)
        else:
            response = np.asarray(data, dtype=complex)
        n = min(len(freqs), len(response))
        freqs = freqs[:n]
        response = response[:n]
        magnitude = np.abs(response)
        magnitude_db = 20.0 * np.log10(np.maximum(magnitude, 1e-300))
        na_power = networkanalyzer_power_state(na)
        magnitude_dbm = networkanalyzer_response_to_dbm(
            response,
            drive_vpk=float(na.amplitude),
            load_ohm=float(na_power["load_ohm"]),
            correction_enabled=bool(na_power["enabled"]),
            highz_correction_db=float(na_power["highz_correction_db"]),
            external_gain_db=float(na_power["external_gain_db"]),
        )
        phase_deg = np.angle(response) * 180.0 / np.pi
        finite = (
            np.isfinite(freqs)
            & np.isfinite(magnitude_db)
            & np.isfinite(magnitude_dbm)
            & np.isfinite(phase_deg)
        )
        summary = {}
        if np.any(finite):
            summary = {
                "magnitude_dbm": {
                    "median": float(np.nanmedian(magnitude_dbm[finite])),
                    "min": float(np.nanmin(magnitude_dbm[finite])),
                    "max": float(np.nanmax(magnitude_dbm[finite])),
                },
                "phase_deg": {
                    "median": float(np.nanmedian(phase_deg[finite])),
                    "min": float(np.nanmin(phase_deg[finite])),
                    "max": float(np.nanmax(phase_deg[finite])),
                },
            }
        safe_tag = "".join(c if c.isalnum() or c in "-_" else "_" for c in tag)
        output_root = Path(output_dir).expanduser() if output_dir else RESULTS_DIR.resolve()
        npz_path = output_root / f"{safe_tag}.npz"
        meta_path = output_root / f"{safe_tag}.json"
        if save_npz:
            output_root.mkdir(parents=True, exist_ok=True)
            np.savez(
                npz_path,
                frequency_hz=freqs,
                magnitude_dbm=magnitude_dbm,
                phase_deg=phase_deg,
            )
        payload = {
            "ok": True,
            "tag": safe_tag,
            "path": str(npz_path) if save_npz else None,
            "output_dir": str(output_root),
            "metadata_path": str(meta_path) if save_npz else None,
            "save_npz": save_npz,
            "saved_arrays": [
                "frequency_hz",
                "magnitude_dbm",
                "phase_deg",
            ],
            "raw_unit_not_saved": "complex voltage response ratio from PyRPL networkanalyzer.single()",
            "display_unit_saved": "dBm when networkanalyzer dBm display is enabled, otherwise computed alongside dB",
            "conversion_note": {
                "response_to_magnitude_db": "magnitude_db = 20*log10(abs(response_complex))",
                "response_to_received_vpk": "received_Vpk = abs(response_complex) * networkanalyzer.amplitude_Vpk",
                "vpk_to_vrms": "Vrms = Vpk / sqrt(2)",
                "received_vpk_to_dbm": (
                    "uncorrected_dBm = 10*log10((received_Vpk^2 / (2*R_ohm)) / 1e-3); "
                    "saved magnitude_dbm = uncorrected_dBm - total_subtracted_db when correction is enabled"
                ),
                "phase_deg": "phase_deg = angle(response_complex)*180/pi, wrapped to -180..+180 deg",
            },
            "n": int(n),
            "input": str(na.input),
            "output_direct": str(na.output_direct),
            "source": source,
            "start_freq_hz": float(na.start_freq),
            "stop_freq_hz": float(na.stop_freq),
            "rbw_hz": float(na.rbw),
            "points": int(na.points),
            "trace_average": int(na.trace_average),
            "average_per_point": int(na.average_per_point),
            "amplitude_v": float(na.amplitude),
            "amplitude_unit": "Vpk",
            "logscale": bool(na.logscale),
            "power_display": na_power,
            "summary": summary,
        }
        if inline:
            limit = max(100, int(max_points))
            step = max(1, int(math.ceil(n / limit)))
            payload["trace"] = {
                "frequency_hz": freqs[::step].astype(float).tolist(),
                "magnitude_dbm": magnitude_dbm[::step].astype(float).tolist(),
                "phase_deg": phase_deg[::step].astype(float).tolist(),
                "decimation": step,
            }
        if save_npz:
            meta_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return payload


def make_handler(bridge: Bridge) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def send_json(self, status: int, payload: dict[str, Any]) -> None:
            body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self) -> None:
            from .excitation import validate
            token = None
            reserved = False
            try:
                if self.headers.get('Origin') not in (None, 'http://' + self.headers.get('Host', '')):
                    raise ValueError('Cross-origin request rejected')
                path = urlparse(self.path).path
                if path not in ('/excitation/run', '/excitation/stop', '/excitation/keepalive'):
                    raise ValueError('Unknown endpoint')
                size = int(self.headers.get('Content-Length', 0))
                if not 0 < size <= 524288:
                    raise ValueError('Invalid request size')
                body = json.loads(self.rfile.read(size))
                token = body['run_id']
                if not isinstance(token, str) or not 16 <= len(token) <= 64 or not token.isalnum():
                    raise ValueError('Invalid excitation run ID')
                if path == '/excitation/run':
                    if not bridge.allow_risky:
                        raise ValueError('Bridge output writes are disabled')
                    settings = validate(body['settings'])
                    bridge.excitation.reserve(token)
                    reserved = True
                    if settings['observe'] and settings['mode'] == 'burst':
                        payload = bridge.submit(lambda: bridge.excitation.run(token, settings), wait_timeout=12)
                    else:
                        # Output control does not take over scope. The feedback
                        # queue remains serviceable while scope awaits a trigger.
                        payload = bridge.submit_feedback(lambda: bridge.excitation.run(token, settings))
                    if not payload.get('ok'):
                        bridge.excitation.cancel(token)
                elif path == '/excitation/stop':
                    bridge.excitation.cancel(token)
                    payload = bridge.submit_feedback(lambda: bridge.excitation.stop(token))
                else:
                    payload = bridge.excitation.keepalive(token)
                self.send_json(200 if payload.get('ok') else 400, payload)
            except Exception as exc:
                if reserved:
                    bridge.excitation.cancel(token)
                self.send_json(400, dict(ok=False, error=str(exc)))

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            try:
                if parsed.path == "/health":
                    payload = bridge.health()
                elif parsed.path == "/gui/show":
                    payload = bridge.submit(bridge.show_gui)
                elif parsed.path == '/feedback/state':
                    payload = bridge.submit_feedback(bridge.feedback.state)
                elif parsed.path == '/scope/armed':
                    def armed():
                        scope = bridge.p.rp.scope
                        return dict(ok=True, armed=bool(scope._trigger_armed and scope.pretrig_ok),
                                    trigger_source=str(scope.trigger_source), duration=float(scope.duration))
                    payload = bridge.submit_feedback(armed)
                elif parsed.path == '/feedback/off':
                    payload = bridge.submit_feedback(bridge.feedback.off)
                elif parsed.path == '/feedback/handoff':
                    if not bridge.allow_risky:
                        raise ValueError('Feedback output requires the bridge --allow-risky option')
                    values = {key: items[0] for key, items in qs.items()}
                    payload = bridge.submit_feedback(lambda: bridge.feedback.handoff(values))
                elif parsed.path == "/gui/hide":
                    payload = bridge.submit(bridge.hide_gui)
                elif parsed.path == "/outputs/state":
                    payload = bridge.submit_feedback(lambda: outputs_state(bridge.p.rp))
                elif parsed.path == "/outputs/off":
                    payload = bridge.submit_feedback(lambda: disable_outputs(bridge.p))
                elif parsed.path == "/shutdown":
                    payload = {
                        "ok": True,
                        "message": "bridge shutdown requested",
                        "bridge": bridge.health().get("bridge"),
                    }
                    bridge.submit(bridge.request_shutdown)
                elif parsed.path == "/get":
                    param = qs.get("param", [""])[0]
                    payload = bridge.submit(lambda: bridge.get_param(param))
                elif parsed.path == "/set":
                    param = qs.get("param", [""])[0]
                    value = qs.get("value", [""])[0]
                    payload = bridge.submit(lambda: bridge.set_param(param, value))
                elif parsed.path == "/lock/prepare-sweep":
                    duration = float(qs.get("duration", ["0.067108864"])[0])
                    frequency = float(qs.get("frequency", ["50"])[0])
                    amplitude = float(qs.get("amplitude", ["1"])[0])
                    payload = bridge.submit(
                        lambda: bridge.prepare_lock_sweep(
                            duration=duration,
                            frequency=frequency,
                            amplitude=amplitude,
                        )
                    )
                elif parsed.path == "/scope/single":
                    tag = qs.get("tag", ["scope_capture"])[0]
                    timeout = float(qs.get("timeout", ["5"])[0])
                    make_plot = qs.get("plot", ["true"])[0].strip().lower() not in {
                        "0",
                        "false",
                        "no",
                        "off",
                    }
                    save = qs.get("save", ["true"])[0].strip().lower() not in {
                        "0",
                        "false",
                        "no",
                        "off",
                    }
                    inline = qs.get("inline", ["false"])[0].strip().lower() in {
                        "1",
                        "true",
                        "yes",
                        "on",
                    }
                    max_points = int(qs.get("max_points", ["1500"])[0])
                    payload = bridge.submit(
                        lambda: bridge.capture_scope(
                            tag,
                            timeout,
                            make_plot,
                            save=save,
                            inline=inline,
                            max_points=max_points,
                        ),
                        wait_timeout=max(10.0, timeout + 5.0),
                    )
                elif parsed.path == "/scope/power":
                    timeout = float(qs.get("timeout", ["3"])[0])
                    retries = int(qs.get("retries", ["8"])[0])
                    payload = bridge.submit(
                        lambda: bridge.scope_power(timeout, retries=retries),
                        wait_timeout=max(20.0, retries * (timeout + 5.0)),
                    )
                elif parsed.path == "/scope/dip-position":
                    timeout = float(qs.get("timeout", ["2.5"])[0])
                    branch = qs.get("branch", ["auto"])[0]
                    smooth_points = int(qs.get("smooth_points", ["7"])[0])
                    source = qs.get("source", ["cache"])[0]
                    center_time_s = (
                        float(qs["center_time_s"][0])
                        if qs.get("center_time_s", [""])[0].strip()
                        else None
                    )
                    window_s = (
                        float(qs["window_s"][0])
                        if qs.get("window_s", [""])[0].strip()
                        else None
                    )
                    payload = bridge.submit(
                        lambda: bridge.scope_dip_position(
                            timeout=timeout,
                            branch=branch,
                            smooth_points=smooth_points,
                            source=source,
                            center_time_s=center_time_s,
                            window_s=window_s,
                        ),
                        wait_timeout=1.0 if source.strip().lower() in {"cache", "cached"} else max(10.0, timeout + 5.0),
                    )
                elif parsed.path == "/scope/lock-analysis":
                    timeout = float(qs.get("timeout", ["8"])[0])
                    width_depth_fraction = float(qs.get("width_depth_fraction", ["0.75"])[0])
                    lock_depth_fraction = float(qs.get("lock_depth_fraction", ["0.25"])[0])
                    presence_min_snr = float(qs.get("presence_min_snr", ["6"])[0])
                    presence_min_samples = int(qs.get("presence_min_samples", ["3"])[0])
                    payload = bridge.submit(
                        lambda: bridge.scope_lock_analysis(
                            timeout=timeout,
                            width_depth_fraction=width_depth_fraction,
                            lock_depth_fraction=lock_depth_fraction,
                            presence_min_snr=presence_min_snr,
                            presence_min_samples=presence_min_samples,
                        ),
                        wait_timeout=max(10.0, timeout + 5.0),
                    )
                elif parsed.path == "/scope/threshold-crossing":
                    timeout = float(qs.get("timeout", ["2.5"])[0])
                    smooth_points = int(qs.get("smooth_points", ["5"])[0])
                    source = qs.get("source", ["cache"])[0]
                    edge = qs.get("edge", ["nearest"])[0]
                    center_time_s = (
                        float(qs["center_time_s"][0])
                        if qs.get("center_time_s", [""])[0].strip()
                        else None
                    )
                    window_s = (
                        float(qs["window_s"][0])
                        if qs.get("window_s", [""])[0].strip()
                        else None
                    )
                    reference_time_s = (
                        float(qs["reference_time_s"][0])
                        if qs.get("reference_time_s", [""])[0].strip()
                        else None
                    )
                    threshold_v = (
                        float(qs["threshold_v"][0])
                        if qs.get("threshold_v", [""])[0].strip()
                        else None
                    )
                    payload = bridge.submit(
                        lambda: bridge.scope_threshold_crossing(
                            timeout=timeout,
                            smooth_points=smooth_points,
                            source=source,
                            center_time_s=center_time_s,
                            window_s=window_s,
                            reference_time_s=reference_time_s,
                            threshold_v=threshold_v,
                            edge=edge,
                        ),
                        wait_timeout=1.0 if source.strip().lower() in {"cache", "cached"} else max(10.0, timeout + 5.0),
                    )
                elif parsed.path == "/acquisition/settings":
                    payload = bridge.submit(lambda: bridge.acquisition_settings())
                elif parsed.path == "/acquisition/stop":
                    payload = bridge.submit_feedback(bridge.stop_acquisitions)
                elif parsed.path == "/spectrum/single":
                    tag = qs.get("tag", ["spectrum_capture"])[0]
                    timeout = float(qs.get("timeout", ["15"])[0])
                    load_ohm = float(qs.get("load_ohm", ["50"])[0])
                    save_csv = qs.get("save_csv", ["false"])[0].strip().lower() in {
                        "1",
                        "true",
                        "yes",
                        "on",
                    }
                    save_npz = qs.get("save", ["true"])[0].strip().lower() not in {
                        "0",
                        "false",
                        "no",
                        "off",
                    }
                    inline = qs.get("inline", ["false"])[0].strip().lower() in {
                        "1",
                        "true",
                        "yes",
                        "on",
                    }
                    acquire = qs.get("acquire", ["true"])[0].strip().lower() not in {
                        "0",
                        "false",
                        "no",
                        "off",
                    }
                    max_points = int(qs.get("max_points", ["1500"])[0])
                    output_dir = qs.get("output_dir", [None])[0]
                    payload = bridge.submit(
                        lambda: bridge.capture_spectrum(
                            tag,
                            timeout,
                            load_ohm,
                            save_csv,
                            save_npz=save_npz,
                            inline=inline,
                            max_points=max_points,
                            acquire=acquire,
                            output_dir=output_dir,
                        ),
                        wait_timeout=max(20.0, timeout + 10.0),
                    )
                elif parsed.path == "/networkanalyzer/single":
                    tag = qs.get("tag", ["network_analyzer_preview"])[0]
                    timeout = float(qs.get("timeout", ["20"])[0])
                    save_npz = qs.get("save", ["true"])[0].strip().lower() not in {
                        "0",
                        "false",
                        "no",
                        "off",
                    }
                    inline = qs.get("inline", ["true"])[0].strip().lower() in {
                        "1",
                        "true",
                        "yes",
                        "on",
                    }
                    acquire = qs.get("acquire", ["true"])[0].strip().lower() not in {
                        "0",
                        "false",
                        "no",
                        "off",
                    }
                    max_points = int(qs.get("max_points", ["1200"])[0])
                    output_dir = qs.get("output_dir", [None])[0]
                    payload = bridge.submit(
                        lambda: bridge.capture_network_analyzer(
                            tag,
                            timeout,
                            save_npz=save_npz,
                            inline=inline,
                            max_points=max_points,
                            acquire=acquire,
                            output_dir=output_dir,
                        ),
                        wait_timeout=max(30.0, timeout + 10.0),
                    )
                elif parsed.path == "/spectrum/power_correction":
                    enabled = (
                        parse_bool(qs["enabled"][0])
                        if "enabled" in qs
                        else None
                    )
                    highz_correction_db = (
                        float(qs["highz_correction_db"][0])
                        if "highz_correction_db" in qs
                        else None
                    )
                    external_gain_db = (
                        float(qs["external_gain_db"][0])
                        if "external_gain_db" in qs
                        else None
                    )
                    load_ohm = (
                        float(qs["load_ohm"][0])
                        if "load_ohm" in qs
                        else None
                    )
                    if any(
                        value is not None
                        for value in (
                            enabled,
                            highz_correction_db,
                            external_gain_db,
                            load_ohm,
                        )
                    ):
                        payload = bridge.submit(
                            lambda: bridge.set_spectrum_power_correction(
                                enabled=enabled,
                                highz_correction_db=highz_correction_db,
                                external_gain_db=external_gain_db,
                                load_ohm=load_ohm,
                            )
                        )
                    else:
                        payload = bridge.submit(bridge.get_spectrum_power_correction)
                elif parsed.path == "/networkanalyzer/power_display":
                    if "enabled" in qs:
                        payload = bridge.submit(
                            lambda: bridge.set_param(
                                "networkanalyzer.dbm_display_enabled", qs["enabled"][0]
                            )
                        )
                    elif "external_gain_db" in qs:
                        payload = bridge.submit(
                            lambda: bridge.set_param(
                                "networkanalyzer.external_gain_db",
                                qs["external_gain_db"][0],
                            )
                        )
                    elif "highz_correction_db" in qs:
                        payload = bridge.submit(
                            lambda: bridge.set_param(
                                "networkanalyzer.dbm_highz_correction_db",
                                qs["highz_correction_db"][0],
                            )
                        )
                    elif "load_ohm" in qs:
                        payload = bridge.submit(
                            lambda: bridge.set_param(
                                "networkanalyzer.dbm_load_ohm", qs["load_ohm"][0]
                            )
                        )
                    else:
                        payload = bridge.submit(bridge.get_networkanalyzer_power_display)
                else:
                    payload = {
                        "ok": True,
                        "usage": {
                            "health": "/health",
                            "shutdown": "/shutdown",
                            "get": "/get?param=scope.duration",
                            "set": "/set?param=scope.duration&value=0.1",
                            "scope_single": "/scope/single?tag=test",
                            "spectrum_single": "/spectrum/single?tag=test",
                            "networkanalyzer_single": "/networkanalyzer/single?tag=test",
                            "spectrum_power_correction": "/spectrum/power_correction?external_gain_db=23",
                            "networkanalyzer_power_display": "/networkanalyzer/power_display",
                        },
                    }
                status = 200 if payload.get("ok") else 400
                self.send_json(status, payload)
            except Exception as exc:
                self.send_json(400, {"ok": False, "error": repr(exc)})

    return Handler


def main() -> int:
    args = parse_args()

    # Import PyRPL only after argument parsing so --help never creates PyRPL
    # user config files or touches the Red Pitaya.
    from .qt_runtime import prepare_qt_plugins
    prepare_qt_plugins()
    import pyrpl
    from qtpy import QtCore
    # Hiding/closing the optional window must not disconnect the shared device.
    pyrpl.APP.setQuitOnLastWindowClosed(False)

    networkanalyzer_external_gain_db = (
        args.spectrum_external_gain_db
        if args.networkanalyzer_external_gain_db is None
        else args.networkanalyzer_external_gain_db
    )
    patch_spectrum_power_units(
        load_ohm=args.spectrum_load_ohm,
        correction_enabled=args.spectrum_power_correction_enabled,
        highz_correction_db=args.spectrum_highz_correction_db,
        external_gain_db=args.spectrum_external_gain_db,
    )
    patch_networkanalyzer_dbm_display(
        enabled=args.networkanalyzer_dbm_display_enabled,
        load_ohm=args.networkanalyzer_load_ohm,
        highz_correction_db=args.networkanalyzer_highz_correction_db,
        external_gain_db=networkanalyzer_external_gain_db,
    )
    if not args.headless:
        patch_scope_mean_display()
    print(
        f"Starting PyRPL {pyrpl.__version__} config={args.config!r} "
        f"headless={args.headless} loglevel={args.loglevel}",
        flush=True,
    )
    print(f"Connecting to Red Pitaya at {args.hostname}", flush=True)
    p = pyrpl.Pyrpl(
        config=args.config,
        hostname=args.hostname,
        gui=not args.headless,
        loglevel=args.loglevel,
    )
    if args.startup_output_off:
        startup_state = disable_outputs(p)
        print("Output-off startup readback: " + json.dumps(startup_state), flush=True)
        if not startup_state['ok']:
            raise RuntimeError('Output-off startup verification failed; HTTP bridge was not started')
    print("PyRPL connection returned; applying bridge display settings", flush=True)
    p.spectrumanalyzer.external_gain_db = args.spectrum_external_gain_db
    p.networkanalyzer.dbm_display_enabled = args.networkanalyzer_dbm_display_enabled
    p.networkanalyzer.dbm_load_ohm = args.networkanalyzer_load_ohm
    p.networkanalyzer.dbm_highz_correction_db = args.networkanalyzer_highz_correction_db
    p.networkanalyzer.external_gain_db = networkanalyzer_external_gain_db
    if not args.headless:
        try:
            p.rp.scope.ch1_power_response_v_per_w = args.scope_ch1_response_v_per_w
            p.rp.scope.ch2_power_response_v_per_w = args.scope_ch2_response_v_per_w
            p.rp.scope.ch1_zero_offset_v = args.scope_ch1_zero_offset_v
            p.rp.scope.ch2_zero_offset_v = args.scope_ch2_zero_offset_v
            p.rp.scope.scope_zero_enabled = args.scope_zero_enabled
            sync_scope_display_controls(p.rp.scope)
        except Exception as exc:
            print(f"WARN could not apply scope display settings: {exc}", flush=True)
    power_correction = spectrum_power_correction_state(p.spectrumanalyzer)
    print(f"Spectrum dBm units use {args.spectrum_load_ohm:g} ohm equivalent load", flush=True)
    print(
        "Spectrum dBm correction: "
        f"enabled={power_correction['enabled']} "
        f"high-Z={power_correction['highz_correction_db']:.3f} dB "
        f"external_gain={power_correction['external_gain_db']:.3f} dB "
        f"total_subtracted={power_correction['total_subtracted_db']:.3f} dB",
        flush=True,
    )
    networkanalyzer_display = networkanalyzer_power_state(p.networkanalyzer)
    print(
        "Network analyzer magnitude display: "
        f"unit={networkanalyzer_display['display_unit']} "
        f"load={networkanalyzer_display['load_ohm']:.3g} ohm "
        f"high-Z={networkanalyzer_display['highz_correction_db']:.3f} dB "
        f"external_gain={networkanalyzer_display['external_gain_db']:.3f} dB "
        f"total_subtracted={networkanalyzer_display['total_subtracted_db']:.3f} dB",
        flush=True,
    )

    bridge = Bridge(
        p,
        allow_risky=args.allow_risky,
        metadata={
            "config": args.config,
            "hostname": args.hostname,
            "rp_identity": args.rp_identity,
            "instance_token": args.instance_token,
            "startup_output_off": args.startup_output_off,
            "headless": args.headless,
            "listen_host": args.listen_host,
            "listen_port": args.listen_port,
            "loglevel": args.loglevel,
            "scope_ch1_response_v_per_w": args.scope_ch1_response_v_per_w,
            "scope_ch2_response_v_per_w": args.scope_ch2_response_v_per_w,
            "scope_zero_enabled": args.scope_zero_enabled,
            "scope_ch1_zero_offset_v": args.scope_ch1_zero_offset_v,
            "scope_ch2_zero_offset_v": args.scope_ch2_zero_offset_v,
            "networkanalyzer_dbm_display": networkanalyzer_display,
        },
    )
    server = ThreadingHTTPServer(
        (args.listen_host, args.listen_port), make_handler(bridge)
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"Bridge listening on http://{args.listen_host}:{args.listen_port}", flush=True)
    print("Initial safe write example: /set?param=scope.duration&value=0.1", flush=True)

    timer = QtCore.QTimer()
    timer.timeout.connect(bridge.drain_once)
    timer.start(50)
    feedback_timer = QtCore.QTimer()
    feedback_timer.timeout.connect(bridge.drain_feedback)
    feedback_timer.start(25)
    if not args.headless:
        for delay_ms in (0, 250, 1000):
            QtCore.QTimer.singleShot(
                delay_ms, lambda scope=p.rp.scope: sync_scope_display_controls(scope)
            )

    def shutdown() -> None:
        server.shutdown()
        server.server_close()
        try:
            p._clear()
        except Exception:
            pass

    pyrpl.APP.aboutToQuit.connect(shutdown)
    return pyrpl.APP.exec_()


if __name__ == "__main__":
    raise SystemExit(main())
