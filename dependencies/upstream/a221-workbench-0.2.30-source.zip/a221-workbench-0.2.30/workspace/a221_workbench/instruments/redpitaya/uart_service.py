"""Run on the RP: serialized byte exchange over one explicitly selected UART.

No FPGA loading, output settings or automatic laser commands.
"""

import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.instruments.redpitaya'


import argparse
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import json
import os
from pathlib import Path
import sys

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def make_server(address, transport, *, token=''):
    if address[0] not in {'127.0.0.1', 'localhost', '::1'} and not token:
        raise ValueError('Set WEIYUAN_UART_TOKEN before listening on the network')

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, status, body):
            raw = json.dumps(body).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            if self.path == '/verify':
                if not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
                    return self.reply(401, {'ok': False, 'error': 'Unauthorized'})
                return self.reply(200, {'ok': True, 'service': 'weiyuan-uart'})
            self.reply(200 if self.path == '/health' else 404,
                       {'ok': self.path == '/health', 'service': 'weiyuan-uart',
                        'serial_opened_by_health': False,
                        'device': getattr(transport, 'port', None),
                        'baudrate': getattr(transport, 'baudrate', 9600),
                        'hostname': __import__('socket').gethostname(),
                        'pid': os.getpid(),
                        'mac': Path('/sys/class/net/eth0/address').read_text().strip() if os.name == 'posix' and Path('/sys/class/net/eth0/address').exists() else None})

        def do_POST(self):
            if self.path != '/exchange':
                return self.reply(404, {'ok': False})
            if token and not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
                return self.reply(401, {'ok': False, 'error': 'Unauthorized'})
            try:
                size = int(self.headers.get('Content-Length', 0))
                if not 0 < size <= 4096:
                    raise ValueError('Invalid body size')
                body = json.loads(self.rfile.read(size))
                frame = bytes.fromhex(body['frame_hex'])
                expected = body['expected_length']
                if not 4 <= len(frame) <= 256 or type(expected) is not int or not 4 <= expected <= 256:
                    raise ValueError('Invalid frame/reply size')
            except (ValueError, KeyError, TypeError) as exc:
                return self.reply(400, {'ok': False, 'error': str(exc)})
            try:
                result = transport.exchange(frame, expected)
                self.reply(200, {'ok': True, 'frame_hex': result.hex()})
            except Exception as exc:
                self.reply(502, {'ok': False, 'error': str(exc), 'retried': False})

    return ThreadingHTTPServer(address, Handler)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', required=True, help='Actual free Linux UART device, verified on this RP')
    parser.add_argument('--listen', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8092)
    parser.add_argument('--token-file', type=Path)
    args = parser.parse_args()
    # Deploy just this file and posix_serial.py beside it on older RP systems.
    if os.name == 'posix':
        try:
            from a221_workbench.instruments.transports.posix_serial import PosixSerialTransport
        except ImportError:
            from posix_serial import PosixSerialTransport
        transport = PosixSerialTransport(args.device)
    else:
        from a221_workbench.instruments.transports import SerialTransport
        transport = SerialTransport(args.device)
    token = args.token_file.read_text().strip() if args.token_file else os.environ.get('WEIYUAN_UART_TOKEN', '')
    server = make_server((args.listen, args.port), transport, token=token)
    try:
        print('UART service on {}; physical port opens on first exchange'.format(server.server_address), flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        transport.close()


if __name__ == '__main__':
    main()
