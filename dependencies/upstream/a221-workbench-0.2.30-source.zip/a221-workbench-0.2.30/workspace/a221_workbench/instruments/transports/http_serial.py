from __future__ import annotations
import json
from urllib.error import HTTPError
from urllib.request import Request, build_opener, ProxyHandler

urlopen = build_opener(ProxyHandler({})).open

class HttpSerialTransport:
    def __init__(self, base_url: str, *, token: str = '', timeout_s: float = 5):
        self.base_url, self.token, self.timeout_s = base_url.rstrip('/'), token, timeout_s

    def open(self):
        """No remote ownership or output changes on construction/open."""

    def exchange(self, frame: bytes, expected_length: int) -> bytes:
        request = Request(self.base_url + '/exchange',
                          data=json.dumps({'frame_hex': frame.hex(), 'expected_length': expected_length}).encode(),
                          headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + self.token},
                          method='POST')
        try:
            with urlopen(request, timeout=self.timeout_s) as response:
                result = json.load(response)
        except HTTPError as exc:
            if exc.code != 502:
                raise
            try:
                detail = json.loads(exc.read(4096)).get('error', '')
            except (ValueError, AttributeError):
                raise exc
            if not isinstance(detail, str) or not detail:
                raise exc
            if detail.startswith('Incomplete UART reply:'):
                raise TimeoutError('RP 串口服务已响应，但激光器应答超时：' + detail) from exc
            raise IOError('RP 串口服务通信失败：' + detail) from exc
        if not result.get('ok'):
            raise IOError(result.get('error', 'UART service failed'))
        data = bytes.fromhex(result['frame_hex'])
        if len(data) != expected_length:
            raise IOError('UART service returned an incomplete reply')
        return data

    def close(self):
        """The service owns the physical UART; no remote shutdown here."""
