from __future__ import annotations
import threading

class SerialTransport:
    def __init__(self, port: str, *, baudrate: int = 9600, timeout_s: float = 0.8):
        self.port, self.baudrate, self.timeout_s = port, baudrate, timeout_s
        self._serial = None
        self._lock = threading.RLock()

    def open(self):
        with self._lock:
            if self._serial is None:
                import serial
                self._serial = serial.Serial(self.port, self.baudrate, bytesize=8,
                                             parity='N', stopbits=1,
                                             timeout=self.timeout_s, write_timeout=self.timeout_s)

    def exchange(self, frame: bytes, expected_length: int) -> bytes:
        with self._lock:
            self.open()
            self._serial.reset_input_buffer()
            written = self._serial.write(frame)
            if written != len(frame):
                raise IOError('Partial serial write; command outcome unknown; not retried')
            self._serial.flush()
            # pyserial.read waits for the requested size or its configured timeout.
            result = self._serial.read(expected_length)
            if len(result) != expected_length:
                raise TimeoutError(f'Incomplete reply: expected {expected_length}, got {len(result)}; not retried')
            return result

    def close(self):
        with self._lock:
            if self._serial is not None:
                self._serial.close()
                self._serial = None
