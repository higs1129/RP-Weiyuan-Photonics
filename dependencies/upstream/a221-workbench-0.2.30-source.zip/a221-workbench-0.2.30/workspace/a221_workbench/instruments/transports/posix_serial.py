"""Linux UART transport using the standard library (Python 3.5+).

An exclusive tty is opened lazily. Timeout/partial writes are never retried.
"""
import os
import select
import threading
import time


class PosixSerialTransport:
    def __init__(self, port, baudrate=9600, timeout_s=0.8):
        self.port = port
        self.baudrate = baudrate
        self.timeout_s = timeout_s
        self._fd = None
        self._lock = threading.RLock()

    def open(self):
        import fcntl
        import termios
        with self._lock:
            if self._fd is not None:
                return
            speed = getattr(termios, 'B' + str(self.baudrate))
            fd = os.open(self.port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.ioctl(fd, termios.TIOCEXCL)
                attrs = termios.tcgetattr(fd)
                attrs[0] = 0
                attrs[1] = 0
                attrs[2] = termios.CS8 | termios.CREAD | termios.CLOCAL
                attrs[3] = 0
                attrs[4] = attrs[5] = speed
                attrs[6][termios.VMIN] = 0
                attrs[6][termios.VTIME] = 0
                termios.tcsetattr(fd, termios.TCSANOW, attrs)
            except Exception:
                os.close(fd)
                raise
            self._fd = fd

    def exchange(self, frame, expected_length):
        import termios
        with self._lock:
            self.open()
            termios.tcflush(self._fd, termios.TCIFLUSH)
            deadline = time.monotonic() + self.timeout_s
            if not select.select([], [self._fd], [], self.timeout_s)[1]:
                raise TimeoutError('UART not writable; command was not sent')
            if os.write(self._fd, frame) != len(frame):
                raise IOError('Partial UART write; command outcome unknown; not retried')
            result = bytearray()
            while len(result) < expected_length:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not select.select([self._fd], [], [], remaining)[0]:
                    raise TimeoutError('Incomplete UART reply: expected {}, got {}; not retried'.format(expected_length, len(result)))
                result.extend(os.read(self._fd, expected_length - len(result)))
            return bytes(result)

    def close(self):
        with self._lock:
            if self._fd is not None:
                import fcntl
                import termios
                try:
                    fcntl.ioctl(self._fd, termios.TIOCNXCL)
                finally:
                    os.close(self._fd)
                    self._fd = None
