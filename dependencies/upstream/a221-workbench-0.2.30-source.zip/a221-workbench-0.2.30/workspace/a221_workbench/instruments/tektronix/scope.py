from __future__ import annotations
import math
import time
from typing import Any

import re
from .connection import TekVisaSession

class TektronixMso6(TekVisaSession):
    def __init__(self, resource: str, visa_backend: str = "@py", timeout_ms: int = 120000) -> None:
        super().__init__(resource, timeout_ms=timeout_ms, visa_backend=visa_backend)
        self._idn = self.query("*IDN?")
        self._channel_count = self._infer_channel_count(self._idn)

    @staticmethod
    def _infer_channel_count(idn: str) -> int:
        match = re.search(r"\bMSO\d(\d)", idn.upper())
        if match:
            return int(match.group(1))
        return 6

    def close(self) -> None:
        try:
            self._inst.close()
        finally:
            self._rm.close()

    def write(self, command: str) -> None:
        self._inst.write(command)

    def query(self, command: str) -> str:
        return str(self._inst.query(command)).strip()

    def idn(self) -> str:
        return self._idn

    def opc(self) -> None:
        self.query("*OPC?")

    def stop(self) -> None:
        self.write("ACQuire:STATE STOP")

    def run(self) -> None:
        self.write("ACQuire:STOPAfter RUNSTop")
        self.write("ACQuire:STATE RUN")

    def single(self) -> None:
        self.write("ACQuire:STOPAfter SEQuence")
        self.write("ACQuire:SEQuence:NUMSEQuence 1")
        self.write("ACQuire:STATE RUN")

    def wait_for_single_complete(self, timeout_s: float) -> dict[str, str | float]:
        deadline = time.monotonic() + float(timeout_s)
        last_acquire_state = ""
        last_trigger_state = ""
        while time.monotonic() < deadline:
            try:
                last_acquire_state = self.query("ACQuire:STATE?")
            except Exception as exc:
                last_acquire_state = f"error:{exc!r}"
            try:
                last_trigger_state = self.query("TRIGger:STATE?")
            except Exception as exc:
                last_trigger_state = f"error:{exc!r}"
            if str(last_acquire_state).strip() in {"0", "OFF", "STOP"}:
                return {
                    "ok": True,
                    "acquire_state": last_acquire_state,
                    "trigger_state": last_trigger_state,
                    "elapsed_s": timeout_s - max(0.0, deadline - time.monotonic()),
                }
            time.sleep(0.03)
        raise TimeoutError(
            "Tektronix single acquisition did not complete before waveform readout; "
            f"ACQuire:STATE?={last_acquire_state!r}, TRIGger:STATE?={last_trigger_state!r}. "
            "Check that the selected trigger channel crosses the trigger level."
        )

    @staticmethod
    def _tek_slope(slope: str) -> str:
        return "FALL" if slope.lower().startswith("neg") else "RISE"

    @staticmethod
    def _tek_trigger_mode(mode: str) -> str:
        return "AUTO" if mode.lower().startswith("auto") else "NORMal"

    def _set_channel_display(self, channel: int, enabled: bool) -> None:
        state = "ON" if enabled else "OFF"
        self.write(f"SELect:CH{channel} {state}")
        self.write(f"DISplay:WAVEView1:CH{channel}:STATE {state}")

    def _require_channel(self, channel: int) -> None:
        if channel < 1 or channel > self._channel_count:
            raise ValueError(f"Tektronix scope {self._idn!r} does not have CH{channel}")

    def configure_large_scan(
        self,
        *,
        record_seconds: float,
        sample_rate_hz: float,
        trigger_channel: int,
        trigger_level_v: float,
        trigger_slope: str,
        trans_channel: int,
        mzi_channel: int,
        aux_mzi_channel: int | None = None,
        save_transmission: bool = True,
        save_trigger: bool,
    ) -> None:
        channels_to_enable = {trigger_channel, mzi_channel}
        if save_transmission:
            channels_to_enable.add(trans_channel)
        if aux_mzi_channel is not None:
            channels_to_enable.add(aux_mzi_channel)
        for channel in channels_to_enable:
            self._require_channel(channel)
        for channel in range(1, self._channel_count + 1):
            self._set_channel_display(channel, channel in channels_to_enable)

        self.write("HORizontal:MODe MANual")
        self.write(f"HORizontal:MODe:SAMPLERate {sample_rate_hz:.9g}")
        self.write(f"HORizontal:MODe:RECOrdlength {int(round(record_seconds * sample_rate_hz))}")
        self.write(f"HORizontal:MODe:SCAle {record_seconds / 10.0:.9g}")
        self.write("HORizontal:DELay:MODe OFF")
        self.write("HORizontal:POSition 50")
        self.write("TRIGger:A:TYPe EDGE")
        self.write(f"TRIGger:A:EDGE:SOUrce CH{trigger_channel}")
        self.write(f"TRIGger:A:LEVel:CH{trigger_channel} {trigger_level_v:.9g}")
        self.write(f"TRIGger:A:EDGE:SLOpe {self._tek_slope(trigger_slope)}")
        self.write("TRIGger:A:MODe NORMal")
        self.opc()

    def configure_fine_scan_idle(
        self,
        *,
        trigger_channel: int = 4,
        trigger_level_v: float = 0.0,
        trigger_slope: str = "negative",
        trigger_mode: str = "auto",
        time_scale_s_per_div: float = 1e-3,
        horizontal_delay_s: float | None = None,
    ) -> None:
        self._require_channel(trigger_channel)
        self.stop()
        self._set_channel_display(1, False)
        self._set_channel_display(trigger_channel, True)
        self.write(f"TRIGger:A:EDGE:SOUrce CH{trigger_channel}")
        self.write(f"TRIGger:A:LEVel:CH{trigger_channel} {trigger_level_v:.9g}")
        self.write(f"TRIGger:A:EDGE:SLOpe {self._tek_slope(trigger_slope)}")
        self.write(f"TRIGger:A:MODe {self._tek_trigger_mode(trigger_mode)}")
        self.write("HORizontal:POSition 50")
        self.write(f"HORizontal:MODe:SCAle {time_scale_s_per_div:.9g}")
        if horizontal_delay_s is not None:
            self.write("HORizontal:DELay:MODe ON")
            self.write(f"HORizontal:DELay:TIMe {float(horizontal_delay_s):.9g}")
        else:
            self.write("HORizontal:DELay:MODe OFF")
        self.run()
        self.opc()

    def read_channel(self, channel: int) -> tuple[list[float], list[float], dict[str, float]]:
        self._require_channel(channel)
        self.write(f"DATa:SOUrce CH{channel}")
        available = self.query("DATa:SOUrce:AVAILable?")
        available_sources = {item.strip().upper() for item in re.split(r"[,;]", available) if item.strip()}
        if f"CH{channel}" not in available_sources:
            raise RuntimeError(
                f"Tektronix source CH{channel} is not available for waveform transfer "
                f"(DATa:SOUrce:AVAILable? -> {available!r}). "
                "The single acquisition probably did not trigger or the channel is inactive."
            )
        self.write("DATa:STARt 1")
        self.write("DATa:STOP 1000000000")
        self.write("DATa:ENCdg SRIbinary")
        self.write("WFMOutpre:BYT_Nr 2")
        self.write("WFMOutpre:BYT_Or LSB")
        x_incr = float(self.query("WFMOutpre:XINcr?").split()[-1])
        x_zero = float(self.query("WFMOutpre:XZEro?").split()[-1])
        point_offset = float(self.query("WFMOutpre:PT_Off?").split()[-1])
        y_mult = float(self.query("WFMOutpre:YMUlt?").split()[-1])
        y_off = float(self.query("WFMOutpre:YOFf?").split()[-1])
        y_zero = float(self.query("WFMOutpre:YZEro?").split()[-1])
        points = int(float(self.query("WFMOutpre:NR_Pt?").split()[-1]))
        values_raw = self._inst.query_binary_values(
            "CURVe?",
            datatype="h",
            is_big_endian=False,
            expect_termination=False,
            container=list,
        )
        values = [(float(v) - y_off) * y_mult + y_zero for v in values_raw]
        time_axis = [x_zero + (idx - point_offset) * x_incr for idx in range(len(values))]
        header = {
            "x_start_s": time_axis[0] if time_axis else x_zero,
            "x_stop_s": time_axis[-1] if time_axis else x_zero,
            "header_points": float(points),
            "sample_rate_hz": 1.0 / x_incr if x_incr else math.nan,
            "x_incr_s": x_incr,
            "x_zero_s": x_zero,
            "point_offset": point_offset,
            "y_mult_v": y_mult,
            "y_off": y_off,
            "y_zero_v": y_zero,
            "raw": (
                f"WFMOutpre NR_Pt={points}, XINcr={x_incr}, XZEro={x_zero}, "
                f"PT_Off={point_offset}, YMUlt={y_mult}, YOFf={y_off}, YZEro={y_zero}"
            ),
        }
        return time_axis, values, header
