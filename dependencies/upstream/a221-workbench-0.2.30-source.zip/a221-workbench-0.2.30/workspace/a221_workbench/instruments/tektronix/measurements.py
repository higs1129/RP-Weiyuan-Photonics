from __future__ import annotations
import math
import time
from typing import Any, Callable

from .connection import TekVisaSession

class TekTimeToMinReader(TekVisaSession):
    def __init__(self, resource: str, *, source_channel: int, timeout_ms: int = 2500, visa_backend: str = "@py") -> None:
        super().__init__(resource, timeout_ms=timeout_ms, visa_backend=visa_backend)
        self._source_channel = int(source_channel)

    def write(self, command: str) -> float:
        return self.write_command(command)

    def query(self, command: str) -> tuple[str, float]:
        return self.query_timed(command)

    def setup(self, *, check_cancel: Callable[[], None] | None = None) -> dict[str, Any]:
        steps: list[dict[str, Any]] = []
        for command in (
            f"MEASUrement:IMMed:SOUrce1 CH{self._source_channel}",
            "MEASUrement:IMMed:TYPe TIMETOMIN",
        ):
            if check_cancel is not None:
                check_cancel()
            try:
                elapsed_ms = self.write(command)
                steps.append({"cmd": command, "ok": True, "elapsed_ms": round(elapsed_ms, 3)})
            except Exception as exc:
                steps.append({"cmd": command, "ok": False, "error": repr(exc)})
                return {"ok": False, "source_channel": self._source_channel, "steps": steps}
        checks: list[dict[str, Any]] = []
        for command in ("*IDN?", "MEASUrement:IMMed:TYPe?", "MEASUrement:IMMed:SOUrce1?"):
            if check_cancel is not None:
                check_cancel()
            try:
                answer, elapsed_ms = self.query(command)
                checks.append({"cmd": command, "ok": True, "answer": answer, "elapsed_ms": round(elapsed_ms, 3)})
            except Exception as exc:
                checks.append({"cmd": command, "ok": False, "error": repr(exc)})
        type_answer = next((item.get("answer") for item in checks if item.get("cmd") == "MEASUrement:IMMed:TYPe?"), "")
        ok = str(type_answer).strip().upper() == "TIMETOMIN"
        return {
            "ok": ok,
            "source_channel": self._source_channel,
            "steps": steps,
            "checks": checks,
            "error": None if ok else f"Tek measurement type is {type_answer!r}, expected TIMETOMIN",
        }

    def set_measurement_range(
        self, center_s: float, half_width_s: float, *, check_cancel: Callable[[], None] | None = None,
    ) -> dict[str, Any]:
        half = abs(float(half_width_s))
        return self.set_measurement_range_bounds(
            float(center_s) - half,
            float(center_s) + half,
            center_s=float(center_s),
            half_width_s=half,
            check_cancel=check_cancel,
        )

    def set_measurement_range_bounds(
        self,
        min_s: float,
        max_s: float,
        *,
        center_s: float | None = None,
        half_width_s: float | None = None,
        check_cancel: Callable[[], None] | None = None,
    ) -> dict[str, Any]:
        lo = float(min_s)
        hi = float(max_s)
        if hi <= lo:
            return {"ok": False, "min_s": lo, "max_s": hi, "error": "measurement range max must be greater than min"}
        steps: list[dict[str, Any]] = []
        for command in (
            "MEASUrement:IMMed:MEASRange:STATE ON",
            f"MEASUrement:IMMed:MEASRange:MIN {lo:.12g}",
            f"MEASUrement:IMMed:MEASRange:MAX {hi:.12g}",
        ):
            if check_cancel is not None:
                check_cancel()
            try:
                elapsed_ms = self.write(command)
                steps.append({"cmd": command, "ok": True, "elapsed_ms": round(elapsed_ms, 3)})
            except Exception as exc:
                steps.append({"cmd": command, "ok": False, "error": repr(exc)})
                return {
                    "ok": False,
                    "center_s": center_s,
                    "half_width_s": half_width_s,
                    "min_s": lo,
                    "max_s": hi,
                    "steps": steps,
                }
        result: dict[str, Any] = {"ok": True, "min_s": lo, "max_s": hi, "steps": steps}
        if center_s is not None:
            result["center_s"] = center_s
        if half_width_s is not None:
            result["half_width_s"] = half_width_s
        return result

    def disable_measurement_range(self) -> dict[str, Any]:
        try:
            elapsed_ms = self.write("MEASUrement:IMMed:MEASRange:STATE OFF")
        except Exception as exc:
            return {"ok": False, "error": repr(exc)}
        return {"ok": True, "elapsed_ms": round(elapsed_ms, 3)}

    def read_once(self) -> dict[str, Any]:
        try:
            answer, elapsed_ms = self.query("MEASUrement:IMMed:VALue?")
            value = float(answer)
        except Exception as exc:
            return {"ok": False, "error": repr(exc)}
        ok = math.isfinite(value) and abs(value) < 1e6
        return {
            "ok": ok,
            "time_to_min_s": value if ok else None,
            "raw_value": answer,
            "elapsed_ms": round(elapsed_ms, 3),
            "source": f"TEK CH{self._source_channel} TIMETOMIN",
            "error": None if ok else f"invalid TIMETOMIN value {answer!r}",
        }
