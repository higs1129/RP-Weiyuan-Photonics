from __future__ import annotations
import math
import time
from typing import Any

class TekVisaSession:
    def __init__(self, resource: str, *, timeout_ms: int = 2500, visa_backend: str = "@py") -> None:
        try:
            import pyvisa  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Missing dependency pyvisa for Tektronix control; start the workflow with the managed PyRPL environment."
            ) from exc
        self._rm = pyvisa.ResourceManager(visa_backend)
        self._inst = self._rm.open_resource(resource)
        self._inst.timeout = int(timeout_ms)
        self._inst.chunk_size = 1024 * 1024
        if "SOCKET" in resource.upper():
            self._inst.read_termination = "\n"
            self._inst.write_termination = "\n"

    @property
    def instrument(self) -> Any:
        return self._inst

    def close(self) -> None:
        try:
            self._inst.close()
        finally:
            self._rm.close()

    def __enter__(self) -> "TekVisaSession":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def write_command(self, command: str) -> float:
        started = time.perf_counter()
        self._inst.write(command)
        return (time.perf_counter() - started) * 1000.0

    def query_text(self, command: str) -> str:
        return str(self._inst.query(command)).strip()

    def query_timed(self, command: str) -> tuple[str, float]:
        started = time.perf_counter()
        value = self.query_text(command)
        return value, (time.perf_counter() - started) * 1000.0
