from __future__ import annotations
from typing import Iterable
from .controller import MDT693B

def discover_ports(ports: Iterable[str]) -> list[dict[str, object]]:
    """Read identity and voltage state from MDT693B ports."""
    rows: list[dict[str, object]] = []
    for port in ports:
        row: dict[str, object] = {"port": port, "ok": False}
        try:
            with MDT693B(port) as dev:
                row.update(dev.identify())
                row["vlimit"] = dev.cleaned_query("vlimit?", allow_empty=True)
                row["msenable"] = dev.cleaned_query("msenable?", allow_empty=True)
                row["msvoltage_v"] = dev._read_optional_float("msvoltage?")
                for axis in ("x", "y", "z"):
                    row[f"{axis}_voltage_v"] = dev.read_axis_voltage(axis)
                    limits = dev.read_axis_limits(axis)
                    row[f"{axis}_min_v"] = limits.minimum_v
                    row[f"{axis}_max_v"] = limits.maximum_v
                row["ok"] = True
        except Exception as exc:
            row["error"] = repr(exc)
        rows.append(row)
    return rows
