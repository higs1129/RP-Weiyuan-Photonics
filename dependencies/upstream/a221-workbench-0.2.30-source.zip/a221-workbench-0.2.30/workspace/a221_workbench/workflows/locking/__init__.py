"""Reusable lock supervision and scan restoration."""
