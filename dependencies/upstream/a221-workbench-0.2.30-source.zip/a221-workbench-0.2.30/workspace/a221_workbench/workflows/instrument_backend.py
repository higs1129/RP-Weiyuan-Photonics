"""Reusable instrument and workflow backend for microcavity dashboards.

This module contains no dashboard page or HTTP server. Both the single-cavity
and array-cavity interfaces call it directly so bridge, laser, scan, locking,
and instrument-health behavior stays in one place.
"""

from __future__ import annotations
from a221_workbench.instruments.toptica import control as toptica_control
from a221_workbench.instruments.weiyuan import cli as weiyuan_control
from a221_workbench._shared import lock_paths
from a221_workbench._shared.paths import module_file, project_root


from a221_workbench._shared.paths import package_dir, configuration_dir

import argparse
import csv
import html
import importlib.util
import json
import math
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlencode, urlparse
from urllib.request import urlopen

import numpy as np


SCRIPT_PATH = Path(__file__).resolve()
DASHBOARD_DIR = SCRIPT_PATH.parent
SRC_DIR = DASHBOARD_DIR.parent
PACKAGE_DIR = SRC_DIR.parent
REPO_ROOT = project_root()

from a221_workbench.tasks.analysis.mechanical_q import mechanical_fit_javascript
from a221_workbench.tasks.analysis.power import calculate_optical_power
from a221_workbench.tasks.analysis.large_scan import validate_array_min_depth
from a221_workbench.instruments.redpitaya.bridge_client import BridgeClient
from a221_workbench._shared.runtime import (
    expand_optional_path as core_expand_optional_path,
    python_has_module as core_python_has_module,
)

LOCK_DIR = SRC_DIR / "lock"
BRIDGE_DIR = SRC_DIR / "bridge"
DRIVERS_DIR = SRC_DIR / "drivers"
COMMON_DIR = SRC_DIR / "common"
CONFIG_DIR = configuration_dir('redpitaya_microcavity_lock') / 'config'
DEFAULT_LOCK_SCRIPT = module_file('a221_workbench.workflows.locking.current_mode_fast_lock')
DEFAULT_WEIYUAN_LOCK_SCRIPT = module_file('a221_workbench.workflows.locking.weiyuan_current_mode_lock')
DEFAULT_BEST_Q_SCRIPT = module_file('a221_workbench.workflows.locking.lock_best_q_mode')
LARGE_SCAN_DIR = package_dir('a221_workbench.workflows.large_scan')
AUTO_COUPLING_DIR = package_dir('a221_workbench.workflows.auto_coupling')
DEFAULT_AUTO_COUPLING_SCRIPT = module_file('a221_workbench.workflows.auto_coupling.monotonic_step_optimize_coupling')
DEFAULT_MDT693B_MIDPOINT_SCRIPT = module_file('a221_workbench.tasks.coupling.initialize_mdt693b_midpoint')
DEFAULT_LARGE_SCAN_SCRIPT = module_file('a221_workbench.workflows.large_scan.large_scan_flow')
DEFAULT_CARD_SCRIPT = module_file('a221_workbench.tasks.large_scan.write_cavity_card')
DEFAULT_TOPTICA_PYTHON = Path(r"C:\Users\win10\toptica_lasersdk_venv\Scripts\python.exe")
DEFAULT_RP_HOST = "RP-f0cb0d"
DEFAULT_LASER_TYPE = "toptica_serial"
DEFAULT_LARGE_SCAN_LASER_PORT = "COM3"
DEFAULT_SCOPE_RESOURCE = "TCPIP::192.168.1.8::INSTR"
SCOPE_TYPE_CHOICES = ("none", "rs_rte", "tektronix_mso66b")
SCOPE_TYPE_LABELS = {
    "none": "none",
    "rs_rte": "R&S RTE",
    "tektronix_mso66b": "Tektronix MSO66B",
}
DEFAULT_LOCK_SWEEP_FREQUENCY_HZ = 50.0
DEFAULT_LOCK_SWEEP_AMPLITUDE_V = 1.0
DEFAULT_LOCK_SCOPE_DURATION_S = 0.067108864
DEFAULT_FINE_TRIGGER_CHANNEL = 4
DEFAULT_FINE_TRIGGER_LEVEL_V = 0.0
DEFAULT_FINE_TRIGGER_SLOPE = "negative"
DEFAULT_FINE_TRIGGER_MODE = "auto"
DEFAULT_FINE_HORIZONTAL_DELAY_S: float | None = None
DEFAULT_CAVITY: Path | None = None
ACTIVE_LARGE_SCAN: dict[str, Any] = {"proc": None}
ACTIVE_LARGE_SCAN_LOCK = threading.Lock()
ACTIVE_AUTO_COUPLING: dict[str, Any] = {"proc": None}
ACTIVE_AUTO_COUPLING_LOCK = threading.Lock()
ACTIVE_BRIDGE: dict[str, Any] = {"proc": None}
ACTIVE_BRIDGE_LOCK = threading.Lock()
ACTIVE_SENSITIVITY: dict[str, Any] = {"running": False, "cancel_requested": False}
ACTIVE_SENSITIVITY_LOCK = threading.Lock()

DEFAULT_RP_F0CB0D_EXTERNAL_GAIN_DB = 23.0
DEFAULT_CONFIG_FILE = configuration_dir('redpitaya_microcavity_lock') / 'config.local.json'
RUNTIME_CONFIG_FILE = configuration_dir('redpitaya_microcavity_lock') / 'runtime.local.json'
DEFAULT_PRESSURE_CALIBRATION_ROOT = (
    REPO_ROOT
    / "workspace"
    / "experiments"
    / "calibrations"
    / "ultrasound_sources"
)
DEFAULT_PRESSURE_SOURCE = "OLYMPUS_V103_RB"
DEFAULT_PRESSURE_CALIBRATION_FILE = "1MHz_pressure_10Vpp_10k-1M_100Hzbest.npz"
DEFAULT_PRESSURE_CALIBRATION = (
    DEFAULT_PRESSURE_CALIBRATION_ROOT
    / DEFAULT_PRESSURE_SOURCE
    / "processed"
    / DEFAULT_PRESSURE_CALIBRATION_FILE
)


def configured_runtime_python() -> str | None:
    env_python = os.environ.get("MICROCAVITY_RUNTIME_PYTHON")
    if env_python:
        return env_python
    if not RUNTIME_CONFIG_FILE.exists():
        return None
    try:
        config = json.loads(RUNTIME_CONFIG_FILE.read_text(encoding="utf-8-sig"))
        value = config.get("runtime_python")
        return str(value) if value else None
    except Exception:
        return None


def package_python_executable() -> str:
    """Use the installed runtime for child scripts unless explicitly overridden."""
    if os.environ.get("MICROCAVITY_USE_EXTERNAL_PYTHON") == "1":
        external = os.environ.get("PYTHON_EXE")
        if external:
            return external
    configured = configured_runtime_python()
    if configured and Path(configured).exists():
        return configured
    return sys.executable


def expand_optional_path(value: Any) -> Path | None:
    return core_expand_optional_path(value)


def python_has_module(python_exe: Path, module_name: str) -> bool:
    return core_python_has_module(python_exe, module_name)


def toptica_child_python(args: argparse.Namespace, laser_type: str) -> str:
    """Pick the Python used by TOPTICA helper scripts."""
    if laser_type == "toptica_serial":
        return package_python_executable()
    candidates: list[Path] = []
    for raw in (
        getattr(args, "toptica_python", None),
        os.environ.get("TOPTICA_PYTHON_EXE"),
        Path.home() / "python311_embed" / "python.exe",
        Path.home() / "toptica_lasersdk_venv" / "Scripts" / "python.exe",
        package_python_executable(),
    ):
        path = expand_optional_path(raw)
        if path is not None and path.exists() and path not in candidates:
            candidates.append(path)
    for path in candidates:
        if python_has_module(path, "toptica"):
            return str(path)
    tried = ", ".join(str(path) for path in candidates) or "<none>"
    raise RuntimeError(f"No Python with TOPTICA SDK found for TCP laser control. Tried: {tried}")


def bridge_log_dir() -> Path:
    return Path(os.environ.get("MICROCAVITY_BRIDGE_LOG_DIR") or Path(tempfile.gettempdir()) / "redpitaya_microcavity_lock")


def bridge_ready_timeout_s() -> float:
    raw = os.environ.get("MICROCAVITY_BRIDGE_READY_TIMEOUT_S")
    try:
        timeout = float(raw) if raw else 60.0
    except ValueError:
        timeout = 60.0
    return max(10.0, timeout)


def read_text_tail(path: str | Path | None, limit_bytes: int = 4000) -> str | None:
    if not path:
        return None
    p = Path(path)
    if not p.exists():
        return None
    try:
        with p.open("rb") as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - limit_bytes), os.SEEK_SET)
            return handle.read().decode("utf-8", errors="replace")
    except Exception as exc:
        return f"<failed to read log tail: {exc!r}>"


PD_MODELS: dict[str, dict[str, float]] = {
    "KY-PRM-10M-I-FA": {
        "dc_response_v_per_w_1mohm": 2.0e5,
        "rf_response_v_per_w_50ohm": 1.0e5,
        "saturation_power_uw": 25.0,
    },
    "KY-PRM-10M-I-FC": {
        "dc_response_v_per_w_1mohm": 4.0e4,
        "rf_response_v_per_w_50ohm": 2.0e4,
        "saturation_power_uw": 125.0,
    },
}

BIAS_TEE_MODELS: dict[str, dict[str, float]] = {
    "ZFBT-4R2GW+": {"rf_loss_db": 0.6},
}

AMPLIFIER_MODELS: dict[str, dict[str, float]] = {
    # Use the measured in-chain value as the default gain for this lab setup.
    "ZX60-43-S+": {"gain_db": 23.0, "noise_figure_db": 5.8},
}

LOCAL_MODULE_DIRS = (DASHBOARD_DIR, LOCK_DIR, DRIVERS_DIR, COMMON_DIR, BRIDGE_DIR)


def load_config_file(path: Path | None) -> dict[str, Any]:
    if path is None or not path.exists():
        return {}
    with path.open("r", encoding="utf-8-sig") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"Dashboard config must be a JSON object: {path}")
    return data


def bool_from_config(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return default


def config_path(value: Any) -> Path:
    return Path(os.path.expanduser(os.path.expandvars(str(value))))


def finite_config_float(value: Any, default: float | None = None) -> float | None:
    if value is None or value == "":
        return default
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    return parsed if math.isfinite(parsed) else default


def read_pressure_source_meta(source_dir: Path) -> dict[str, Any] | None:
    meta_path = source_dir / "calibration.meta.json"
    if not meta_path.exists():
        return None
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8-sig"))
    except Exception:
        return None
    if not isinstance(meta, dict):
        return None
    default_file = str(meta.get("default_processed_file") or "").strip()
    pressure_path = (source_dir / default_file).resolve() if default_file else None
    return {
        "id": str(meta.get("id") or source_dir.name),
        "label": str(meta.get("label") or meta.get("model") or source_dir.name),
        "model": str(meta.get("model") or meta.get("label") or source_dir.name),
        "path": str(pressure_path) if pressure_path else "",
        "exists": bool(pressure_path and pressure_path.exists()),
        "center_frequency_hz": finite_config_float(meta.get("center_frequency_hz"), None),
        "frequency_min_hz": finite_config_float(meta.get("frequency_min_hz"), None),
        "frequency_max_hz": finite_config_float(meta.get("frequency_max_hz"), None),
        "calibration_drive_vpp": finite_config_float(meta.get("calibration_drive_vpp"), None),
        "pressure_quantity": str(meta.get("pressure_quantity") or "pk"),
        "meta_path": str(meta_path),
        "note": str(meta.get("note") or ""),
    }


def list_pressure_sources(root: Path) -> list[dict[str, Any]]:
    if not root.exists():
        return []
    sources: list[dict[str, Any]] = []
    for source_dir in sorted([p for p in root.iterdir() if p.is_dir()], key=lambda p: p.name.lower()):
        meta = read_pressure_source_meta(source_dir)
        if meta:
            sources.append(meta)
    return sources


def default_pressure_calibration_from_source(root: Path, source_model: str | None) -> Path:
    source_id = str(source_model or DEFAULT_PRESSURE_SOURCE).strip() or DEFAULT_PRESSURE_SOURCE
    meta = read_pressure_source_meta(root / source_id)
    if meta and meta.get("path"):
        return Path(str(meta["path"]))
    return root / source_id / "processed" / DEFAULT_PRESSURE_CALIBRATION_FILE


def voltage_ratio_from_db(db_value: float | None) -> float:
    if db_value is None:
        return 1.0
    return 10.0 ** (float(db_value) / 20.0)


def model_record(table: dict[str, dict[str, float]], model: str | None) -> dict[str, float]:
    if not model:
        return {}
    return table.get(str(model).strip(), {})


def resolve_device_profile(config: dict[str, Any]) -> dict[str, Any]:
    pd_cfg = config.get("photodetector") or config.get("pd") or {}
    if not isinstance(pd_cfg, dict):
        pd_cfg = {}
    rp_frontend = config.get("rp_frontend") or {}
    if not isinstance(rp_frontend, dict):
        rp_frontend = {}
    dc_path = rp_frontend.get("dc_path") or {}
    if not isinstance(dc_path, dict):
        dc_path = {}
    rf_path = rp_frontend.get("rf_path") or {}
    if not isinstance(rf_path, dict):
        rf_path = {}

    pd_model = str(pd_cfg.get("model") or "").strip()
    pd_model_info = model_record(PD_MODELS, pd_model)
    dc_response = finite_config_float(
        pd_cfg.get("scope_response_v_per_w")
        or pd_cfg.get("rp_scope_response_v_per_w")
        or config.get("scope_response_v_per_w")
    )
    if dc_response is None:
        base_response = finite_config_float(
            pd_cfg.get("dc_response_v_per_w_1mohm"),
            pd_model_info.get("dc_response_v_per_w_1mohm"),
        )
        dc_attenuator_db = finite_config_float(dc_path.get("attenuator_db"), 0.0)
        dc_gain_db = finite_config_float(dc_path.get("gain_db"), 0.0)
        dc_response = (
            base_response
            * voltage_ratio_from_db(-(dc_attenuator_db or 0.0))
            * voltage_ratio_from_db(dc_gain_db or 0.0)
            if base_response is not None
            else 3.22013e3
        )

    ch1_response = finite_config_float(
        config.get("scope_ch1_response_v_per_w")
        or pd_cfg.get("scope_ch1_response_v_per_w"),
        dc_response,
    )
    ch2_response = finite_config_float(
        config.get("scope_ch2_response_v_per_w")
        or pd_cfg.get("scope_ch2_response_v_per_w"),
        dc_response,
    )
    scope_zero_cfg = (
        config.get("scope_zero")
        or dc_path.get("scope_zero")
        or rp_frontend.get("scope_zero")
        or {}
    )
    if not isinstance(scope_zero_cfg, dict):
        scope_zero_cfg = {}
    scope_zero_enabled = bool_from_config(scope_zero_cfg.get("enabled"), False)
    ch1_zero_offset = finite_config_float(
        scope_zero_cfg.get("ch1_offset_v")
        or scope_zero_cfg.get("input1_offset_v"),
        0.0,
    )
    ch2_zero_offset = finite_config_float(
        scope_zero_cfg.get("ch2_offset_v")
        or scope_zero_cfg.get("input2_offset_v"),
        0.0,
    )

    bias_enabled = bool_from_config(rf_path.get("bias_tee_enabled"), False)
    amp_enabled = bool_from_config(rf_path.get("amplifier_enabled"), False)
    bias_model = str(rf_path.get("bias_tee_model") or "").strip()
    amp_model = str(rf_path.get("amplifier_model") or "").strip()
    bias_info = model_record(BIAS_TEE_MODELS, bias_model)
    amp_info = model_record(AMPLIFIER_MODELS, amp_model)

    explicit_external_gain = finite_config_float(
        rf_path.get("external_gain_db")
        or rf_path.get("rf_external_gain_db")
        or config.get("spectrum_external_gain_db")
    )
    if explicit_external_gain is not None:
        external_gain_db = explicit_external_gain
        external_gain_source = "config rf_path.external_gain_db"
    elif "rp_frontend" in config:
        external_gain_db = finite_config_float(rf_path.get("extra_gain_db"), 0.0) or 0.0
        if bias_enabled:
            external_gain_db -= finite_config_float(
                rf_path.get("bias_tee_loss_db"),
                bias_info.get("rf_loss_db", 0.0),
            ) or 0.0
        if amp_enabled:
            external_gain_db += finite_config_float(
                rf_path.get("amplifier_gain_db"),
                amp_info.get("gain_db", 0.0),
            ) or 0.0
        external_gain_source = "computed from rp_frontend.rf_path"
    else:
        external_gain_db = None
        external_gain_source = "legacy RP-host fallback"

    return {
        "photodetector_model": pd_model or None,
        "pd_model_known": bool(pd_model_info),
        "scope_ch1_response_v_per_w": ch1_response,
        "scope_ch2_response_v_per_w": ch2_response,
        "scope_zero_enabled": scope_zero_enabled,
        "scope_ch1_zero_offset_v": ch1_zero_offset,
        "scope_ch2_zero_offset_v": ch2_zero_offset,
        "saturation_power_uw": finite_config_float(
            pd_cfg.get("saturation_power_uw"),
            pd_model_info.get("saturation_power_uw"),
        ),
        "rf_response_v_per_w_50ohm": finite_config_float(
            pd_cfg.get("rf_response_v_per_w_50ohm"),
            pd_model_info.get("rf_response_v_per_w_50ohm"),
        ),
        "bias_tee_enabled": bias_enabled,
        "bias_tee_model": bias_model or None,
        "amplifier_enabled": amp_enabled,
        "amplifier_model": amp_model or None,
        "spectrum_external_gain_db": external_gain_db,
        "spectrum_external_gain_source": external_gain_source,
    }


def dashboard_defaults_from_config(config: dict[str, Any]) -> dict[str, Any]:
    laser_type = str(
        config.get("laser_type")
        or config.get("default_laser_type")
        or DEFAULT_LASER_TYPE
    )
    laser_port = config.get("laser_port")
    toptica_port = str(config.get("toptica_port", DEFAULT_LARGE_SCAN_LASER_PORT))
    weiyuan_port = str(config.get("weiyuan_port", "COM5"))
    if laser_port is None:
        if laser_type == "weiyuan":
            laser_port = weiyuan_port
        else:
            laser_port = toptica_port
    return {
        "listen_host": str(config.get("listen_host", "127.0.0.1")),
        "listen_port": int(config.get("listen_port", 7880)),
        "bridge_base": str(config.get("bridge_base", "http://127.0.0.1:7870")),
        "rp_host": str(config.get("rp_host") or config.get("rp_hostname") or DEFAULT_RP_HOST),
        "laser_type": laser_type,
        "toptica_host": str(config.get("toptica_host", "192.168.1.104")),
        "toptica_python": config_path(config.get("toptica_python") or DEFAULT_TOPTICA_PYTHON),
        "large_scan_laser_port": str(laser_port),
        "toptica_port": toptica_port,
        "weiyuan_port": weiyuan_port,
        "scope_type": str(config.get("scope_type", "rs_rte")),
        "scope_resource": str(config.get("scope_resource", DEFAULT_SCOPE_RESOURCE)),
        "default_cavity": (
            config_path(config["default_cavity"])
            if config.get("default_cavity")
            else DEFAULT_CAVITY
        ),
        "auto_start_bridge": bool_from_config(config.get("auto_start_bridge"), True),
        "auto_start_bridge_gui": bool_from_config(
            config.get("open_pyrpl_gui", config.get("auto_start_bridge_gui")),
            False,
        ),
        "device_profile": resolve_device_profile(config),
        "sensitivity_defaults": resolve_sensitivity_defaults(config),
    }


def resolve_sensitivity_defaults(config: dict[str, Any]) -> dict[str, Any]:
    sensitivity = config.get("sensitivity") if isinstance(config.get("sensitivity"), dict) else {}
    root_value = sensitivity.get("pressure_calibration_root") if sensitivity else None
    calibration_root = config_path(root_value) if root_value else DEFAULT_PRESSURE_CALIBRATION_ROOT
    source_model = str(sensitivity.get("pressure_source_model") or DEFAULT_PRESSURE_SOURCE)
    path_value = sensitivity.get("pressure_calibration_path") if sensitivity else None
    calibration_path = (
        config_path(path_value)
        if path_value
        else default_pressure_calibration_from_source(calibration_root, source_model)
    )
    return {
        "pressure_calibration_root": str(calibration_root),
        "pressure_source_model": source_model,
        "pressure_calibration_path": str(calibration_path),
        "pressure_quantity": str(sensitivity.get("pressure_quantity") or "pk"),
        "pressure_calibration_drive_vpp": finite_config_float(
            sensitivity.get("pressure_calibration_drive_vpp"),
            None,
        ),
    }


def parse_args() -> argparse.Namespace:
    pre_parser = argparse.ArgumentParser(add_help=False)
    pre_parser.add_argument("--config-file", type=Path, default=DEFAULT_CONFIG_FILE)
    pre_args, _ = pre_parser.parse_known_args()
    config = load_config_file(pre_args.config_file)
    defaults = dashboard_defaults_from_config(config)

    parser = argparse.ArgumentParser(description=__doc__, parents=[pre_parser])
    parser.add_argument("--listen-host", default=defaults["listen_host"])
    parser.add_argument("--listen-port", type=int, default=defaults["listen_port"])
    parser.add_argument("--bridge-base", default=defaults["bridge_base"])
    parser.add_argument("--rp-host", default=defaults["rp_host"])
    parser.add_argument("--laser-type", choices=["none", "toptica_tcp", "toptica_serial", "weiyuan"], default=defaults["laser_type"])
    parser.add_argument("--toptica-host", default=defaults["toptica_host"])
    parser.add_argument("--toptica-python", type=Path, default=defaults["toptica_python"])
    parser.add_argument("--large-scan-laser-port", default=defaults["large_scan_laser_port"])
    parser.add_argument("--scope-type", choices=SCOPE_TYPE_CHOICES, default=defaults["scope_type"])
    parser.add_argument("--scope-resource", default=defaults["scope_resource"])
    parser.add_argument("--default-cavity", type=Path, default=defaults["default_cavity"])
    parser.add_argument(
        "--auto-start-bridge",
        action=argparse.BooleanOptionalAction,
        default=defaults["auto_start_bridge"],
        help="Start a dashboard-managed PyRPL bridge when the dashboard starts.",
    )
    parser.add_argument(
        "--auto-start-bridge-gui",
        action=argparse.BooleanOptionalAction,
        default=defaults["auto_start_bridge_gui"],
        help="With --auto-start-bridge, open the PyRPL Qt GUI instead of using headless bridge mode.",
    )
    parser.set_defaults(
        array_min_depth=config.get("array_min_depth"),
        device_profile=defaults["device_profile"],
        sensitivity_defaults=defaults["sensitivity_defaults"],
        toptica_port=defaults["toptica_port"],
        weiyuan_port=defaults["weiyuan_port"],
    )
    return parser.parse_args()


def finite_float(value: object) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed


def json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict[str, Any]) -> None:
    body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def html_response(handler: BaseHTTPRequestHandler, body: str) -> None:
    data = body.encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


def read_json_body(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length", "0") or "0")
    if length <= 0:
        return {}
    body = handler.rfile.read(length).decode("utf-8")
    return json.loads(body) if body.strip() else {}


def request_json(url: str, timeout: float = 3.0) -> dict[str, Any]:
    try:
        with urlopen(url, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = {"raw_body": raw}
        if not isinstance(payload, dict):
            payload = {"raw_body": raw}
        payload.setdefault("ok", False)
        payload.setdefault("error", f"HTTP {exc.code}: {exc.reason}")
        payload["http_status"] = exc.code
        payload["url"] = url
        raise RuntimeError(json.dumps(payload, ensure_ascii=False)) from exc


def bridge_query(base: str, path: str, params: dict[str, Any], timeout: float = 30.0) -> dict[str, Any]:
    clean_params = {key: value for key, value in params.items() if value is not None}
    return request_json(f"{base}{path}?{urlencode(clean_params)}", timeout=timeout)


class SensitivityCancelled(RuntimeError):
    pass


def bridge_get(base: str, param: str) -> dict[str, Any]:
    return BridgeClient(base).get(param)


def bridge_set(base: str, param: str, value: str | int | float) -> dict[str, Any]:
    return BridgeClient(base).set(param, value)


def configure_coupling_scope_inputs(base: str) -> dict[str, Any]:
    return BridgeClient(base).configure_coupling_scope_inputs()


def bridge_stop_acquisitions(base: str) -> dict[str, Any]:
    return BridgeClient(base).stop_acquisitions()


def safe_off(base: str) -> dict[str, Any]:
    return BridgeClient(base).safe_off()


def payload_text(value: Any) -> str:
    if isinstance(value, dict):
        return " ".join(f"{key} {payload_text(item)}" for key, item in value.items())
    if isinstance(value, list):
        return " ".join(payload_text(item) for item in value)
    return str(value)


def bridge_socket_closed(payload: dict[str, Any]) -> bool:
    text = payload_text(payload).lower()
    return "socket is closed" in text or "winerror 10057" in text


def compact_safe_off_errors(payload: dict[str, Any]) -> list[dict[str, Any]]:
    compact = []
    for step in payload.get("steps") or []:
        if not isinstance(step, dict):
            continue
        error = str(step.get("error") or step.get("result", {}).get("error") or "")
        compact.append(
            {
                "param": step.get("param"),
                "value": step.get("value"),
                "error": error[:500] + ("..." if len(error) > 500 else ""),
            }
        )
    return compact


def compact_bridge_action(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if payload is None:
        return None
    status = payload.get("status") if isinstance(payload.get("status"), dict) else {}
    health = status.get("health") if isinstance(status.get("health"), dict) else {}
    bridge = health.get("bridge") if isinstance(health.get("bridge"), dict) else {}
    return {
        "ok": payload.get("ok"),
        "action": payload.get("action"),
        "message": payload.get("message"),
        "error": payload.get("error"),
        "bridge_pid": bridge.get("pid"),
        "headless": bridge.get("headless"),
    }


def safe_off_with_bridge_recovery(config: dict[str, str], args: argparse.Namespace) -> dict[str, Any]:
    first = safe_off(config["bridge_base"])
    if first.get("ok") or not bridge_socket_closed(first):
        return first

    start = start_or_restart_bridge(config, args, headless=True)
    retry = safe_off(config["bridge_base"]) if start.get("ok") else None
    return {
        "ok": bool(retry and retry.get("ok")),
        "steps": retry.get("steps") if isinstance(retry, dict) else first.get("steps"),
        "recovery": {
            "attempted": True,
            "reason": "bridge socket is closed",
            "first_errors": compact_safe_off_errors(first),
            "stop": start.get("old"),
            "start": compact_bridge_action(start),
            "retry_ok": bool(retry and retry.get("ok")),
        },
    }


def restore_lock_sweep(base: str) -> dict[str, Any]:
    results = []
    ok = True
    try:
        result = bridge_stop_acquisitions(base)
        results.append({"action": "stop_acquisitions", "result": result})
    except Exception as exc:
        results.append({"action": "stop_acquisitions", "warning": repr(exc)})
    for param, value in (
        ("pid0.p", 0),
        ("pid0.i", 0),
        ("pid0.output_direct", "off"),
        ("asg0.waveform", "ramp"),
        ("asg0.frequency", DEFAULT_LOCK_SWEEP_FREQUENCY_HZ),
        ("asg0.amplitude", DEFAULT_LOCK_SWEEP_AMPLITUDE_V),
        ("asg0.offset", 0),
        ("asg0.output_direct", "out2"),
        ("asg1.waveform", "square"),
        ("asg1.frequency", DEFAULT_LOCK_SWEEP_FREQUENCY_HZ),
        ("asg1.amplitude", 0.5),
        ("asg1.offset", 0),
        ("scope.input1", "in1"),
        ("scope.input2", "out2"),
        ("scope.trigger_source", "asg0"),
        ("scope.trigger_delay", 0),
        ("scope.duration", DEFAULT_LOCK_SCOPE_DURATION_S),
        ("scope.rolling_mode", "false"),
    ):
        try:
            result = bridge_set(base, param, value)
            results.append({"param": param, "value": value, "result": result})
            ok = ok and bool(result.get("ok"))
        except Exception as exc:
            ok = False
            results.append({"param": param, "value": value, "error": repr(exc)})
    try:
        result = bridge_set(base, "scope.run_continuous", "true")
        results.append({"param": "scope.run_continuous", "value": "true", "result": result})
    except Exception as exc:
        results.append({"param": "scope.run_continuous", "value": "true", "warning": repr(exc)})
    return {
        "ok": ok,
        "message": "lock sweep restored; spectrum/network acquisitions stopped, PID disabled, ASG ramp sent to out2, and scope continuous run requested",
        "sweep_frequency_hz": DEFAULT_LOCK_SWEEP_FREQUENCY_HZ,
        "sweep_amplitude_v": DEFAULT_LOCK_SWEEP_AMPLITUDE_V,
        "fine_trigger_helper": "loaded from try_bridge_safe.yml at bridge startup: pid1(input=asg0, p=2000, output_direct=out1)",
        "scope_duration_s": DEFAULT_LOCK_SCOPE_DURATION_S,
        "steps": results,
    }


def restore_lock_sweep_with_laser(config: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    rp_restore = restore_lock_sweep(config["bridge_base"])
    laser_type = str(config.get("laser_type") or "none")
    pc_voltage: dict[str, Any]
    if laser_type not in {"toptica_tcp", "toptica_serial"}:
        pc_voltage = {
            "ok": True,
            "skipped": True,
            "reason": "当前激光器不是 TOPTICA，无 PC Piezo Set Voltage 可恢复。",
        }
    else:
        target_v = 75.0
        laser_connection = "tcp" if laser_type == "toptica_tcp" else "serial"
        try:
            acquire_module = load_acquire_module()
            laser = acquire_module.create_laser(
                laser_connection,
                config["laser_port"],
                laser_host=config["toptica_host"],
                toptica_python=(
                    toptica_child_python(args, laser_type)
                    if laser_connection == "tcp"
                    else ""
                ),
            )
            try:
                laser.set_pc_voltage_v(target_v)
                pc_voltage = {
                    "ok": True,
                    "target_v": target_v,
                    "readback_v": laser.pc_voltage_act_v(),
                    "connection": laser_connection,
                }
            finally:
                laser.close()
        except Exception as exc:
            pc_voltage = {
                "ok": False,
                "target_v": target_v,
                "connection": laser_connection,
                "error": repr(exc),
            }
    ok = bool(rp_restore.get("ok")) and bool(pc_voltage.get("ok"))
    return {
        "ok": ok,
        "message": (
            "lock sweep restored and TOPTICA PC Piezo Set Voltage restored to 75 V"
            if not pc_voltage.get("skipped")
            else "lock sweep restored; PC Piezo voltage restore skipped for the selected laser"
        ),
        "rp_restore": rp_restore,
        "pc_voltage": pc_voltage,
    }


def instrument_config_from_mapping(source: dict[str, Any], args: argparse.Namespace) -> dict[str, str]:
    return {
        "rp_type": str(source.get("rp_type") or "pyrpl_bridge"),
        "bridge_base": str(source.get("bridge_base") or args.bridge_base),
        "rp_host": str(source.get("rp_host") or args.rp_host),
        "laser_type": str(source.get("laser_type") or args.laser_type),
        "toptica_host": str(source.get("toptica_host") or args.toptica_host),
        "toptica_python": str(source.get("toptica_python") or args.toptica_python),
        "laser_port": str(source.get("laser_port") or args.large_scan_laser_port),
        "weiyuan_slave": str(source.get("weiyuan_slave") or "255"),
        "scope_type": str(source.get("scope_type") or args.scope_type),
        "scope_resource": str(source.get("scope_resource") or args.scope_resource),
    }


def scope_type_label(scope_type: str) -> str:
    return SCOPE_TYPE_LABELS.get(scope_type, scope_type)


def query_visa_idn(resource: str, *, visa_backend: str = "@py", timeout_ms: int = 2500) -> str:
    try:
        import pyvisa  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Missing dependency pyvisa. Install with: python -m pip install pyvisa") from exc

    rm = pyvisa.ResourceManager(visa_backend)
    inst = None
    try:
        inst = rm.open_resource(resource)
        inst.timeout = timeout_ms
        if "SOCKET" in resource.upper():
            inst.read_termination = "\n"
            inst.write_termination = "\n"
        return str(inst.query("*IDN?")).strip()
    finally:
        if inst is not None:
            inst.close()
        rm.close()


def check_instruments(
    config: dict[str, str],
    toptica_python: Path,
    device_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    instruments: dict[str, Any] = {}

    if config["rp_type"] == "none":
        instruments["red_pitaya"] = {"type": "none", "ok": None, "message": "not selected"}
    else:
        try:
            bridge = request_json(f"{config['bridge_base']}/health", timeout=2.0)
        except Exception as exc:
            bridge = {"ok": False, "error": repr(exc)}
        instruments["red_pitaya"] = {
            "type": "PyRPL bridge",
            "bridge_base": config["bridge_base"],
            "rp_host": config["rp_host"] or None,
            "ok": bool(bridge.get("ok")),
            "bridge": bridge,
        }

    laser_type = config["laser_type"]
    if laser_type == "none":
        instruments["laser"] = {"type": "none", "ok": None, "message": "not selected"}
    elif laser_type == "toptica_tcp":
        try:
            acquire_module = load_acquire_module()
            laser = acquire_module.create_laser(
                "tcp",
                config["laser_port"],
                laser_host=config["toptica_host"],
                toptica_python=str(toptica_python),
            )
            try:
                info = laser._read_pc()
            finally:
                laser.close()
            instruments["laser"] = {
                "type": "TOPTICA DLC PRO TCP/IP",
                "ok": True,
                "host": config["toptica_host"],
                "pc": info,
                "python": str(info.get("worker_python") or toptica_python),
            }
        except Exception as exc:
            instruments["laser"] = {
                "type": "TOPTICA DLC PRO TCP/IP",
                "ok": False,
                "host": config["toptica_host"],
                "error": repr(exc),
                "python": str(toptica_python),
            }
    elif laser_type == "toptica_serial":
        try:
            adapter_read_pc = toptica_control.read_pc

            info = adapter_read_pc(connection="serial", host=config["toptica_host"], port=config["laser_port"])
            instruments["laser"] = {
                "type": "TOPTICA DLC PRO serial",
                "ok": True,
                "port": config["laser_port"],
                "pc": info,
            }
        except Exception as exc:
            instruments["laser"] = {
                "type": "TOPTICA DLC PRO serial",
                "ok": False,
                "port": config["laser_port"],
                "error": repr(exc),
            }
    elif laser_type == "weiyuan":
        try:
            read_status = weiyuan_control.read_status

            info = read_status(config["laser_port"], slave=int(config["weiyuan_slave"]))
            instruments["laser"] = {
                "type": "微源光子",
                "ok": True,
                "port": config["laser_port"],
                "weiyuan": info,
            }
        except Exception as exc:
            instruments["laser"] = {
                "type": "微源光子",
                "ok": False,
                "port": config["laser_port"],
                "error": repr(exc),
            }
    else:
        instruments["laser"] = {"type": laser_type, "ok": False, "error": f"unknown laser type: {laser_type}"}

    scope_type = config["scope_type"]
    if scope_type == "none":
        instruments["oscilloscope"] = {"type": "none", "ok": None, "message": "not selected"}
    elif scope_type == "rs_rte":
        try:
            _TopticaDlcPro, RohdeSchwarzRte = load_acquire_helpers()
            scope = RohdeSchwarzRte(config["scope_resource"], timeout_ms=2500)
            close_warning = None
            try:
                idn = scope.idn()
            finally:
                try:
                    scope.close()
                except Exception as exc:
                    close_warning = repr(exc)
            instruments["oscilloscope"] = {
                "type": "R&S RTE",
                "ok": True,
                "scope_resource": config["scope_resource"],
                "idn": idn,
                "close_warning": close_warning,
            }
        except Exception as exc:
            instruments["oscilloscope"] = {
                "type": "R&S RTE",
                "ok": False,
                "scope_resource": config["scope_resource"],
                "error": repr(exc),
            }
    else:
        label = scope_type_label(scope_type)
        try:
            idn = query_visa_idn(config["scope_resource"], timeout_ms=2500)
            instruments["oscilloscope"] = {
                "type": label,
                "ok": True,
                "scope_resource": config["scope_resource"],
                "idn": idn,
            }
        except Exception as exc:
            instruments["oscilloscope"] = {
                "type": label,
                "ok": False,
                "scope_resource": config["scope_resource"],
                "error": repr(exc),
            }

    selected = [item for item in instruments.values() if item.get("ok") is not None]
    return {
        "ok": all(bool(item.get("ok")) for item in selected) if selected else True,
        "config": config,
        "device_profile": device_profile or {},
        "instruments": instruments,
    }


def parse_script_json(stdout: str) -> dict[str, Any] | None:
    for start in (idx for idx, char in reversed(list(enumerate(stdout))) if char == "{"):
        try:
            payload = json.loads(stdout[start:].strip())
        except json.JSONDecodeError:
            continue
        return payload if isinstance(payload, dict) else None
    return None


def script_environment() -> dict[str, str]:
    env = os.environ.copy()
    local_paths = [str(path) for path in (DASHBOARD_DIR, LOCK_DIR, DRIVERS_DIR, COMMON_DIR, BRIDGE_DIR, SRC_DIR)]
    existing_pythonpath = env.get("PYTHONPATH")
    if existing_pythonpath:
        local_paths.append(existing_pythonpath)
    env["PYTHONPATH"] = os.pathsep.join(local_paths)
    return env


def run_script(command: list[str], timeout_s: float) -> dict[str, Any]:
    started = time.time()
    proc = subprocess.run(
        command,
        cwd=REPO_ROOT,
        env=script_environment(),
        text=True,
        capture_output=True,
        timeout=timeout_s,
        check=False,
    )
    parsed = parse_script_json(proc.stdout)
    return {
        "ok": proc.returncode == 0 and bool(parsed is None or parsed.get("ok", True)),
        "returncode": proc.returncode,
        "elapsed_s": time.time() - started,
        "command": command,
        "json": parsed,
        "stdout_tail": proc.stdout[-4000:],
        "stderr_tail": proc.stderr[-4000:],
    }


def run_auto_coupling_script(command: list[str], timeout_s: float, *, stage: str) -> dict[str, Any]:
    started = time.time()
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform.startswith("win") else 0
    with ACTIVE_AUTO_COUPLING_LOCK:
        old_proc = ACTIVE_AUTO_COUPLING.get("proc")
        if old_proc is not None and old_proc.poll() is None:
            return {
                "ok": False,
                "error": "auto coupling is already running",
                "pid": old_proc.pid,
                "stage": ACTIVE_AUTO_COUPLING.get("stage"),
                "elapsed_s": time.time() - float(ACTIVE_AUTO_COUPLING.get("started_at") or time.time()),
            }
    proc = subprocess.Popen(
        command,
        cwd=REPO_ROOT,
        env=script_environment(),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=creationflags,
    )
    with ACTIVE_AUTO_COUPLING_LOCK:
        ACTIVE_AUTO_COUPLING.update(
            {
                "proc": proc,
                "command": command,
                "stage": stage,
                "started_at": started,
                "cancel_requested": False,
            }
        )
    stop: dict[str, Any] | None = None
    try:
        try:
            stdout, stderr = proc.communicate(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            stop = terminate_process_tree(proc)
            try:
                stdout, stderr = proc.communicate(timeout=5.0)
            except Exception:
                stdout, stderr = "", ""
            parsed = parse_script_json(stdout)
            return {
                "ok": False,
                "returncode": proc.poll(),
                "elapsed_s": time.time() - started,
                "command": command,
                "json": parsed,
                "stdout_tail": stdout[-4000:],
                "stderr_tail": stderr[-4000:],
                "error": "auto coupling timed out",
                "stop": stop,
            }
        parsed = parse_script_json(stdout)
        with ACTIVE_AUTO_COUPLING_LOCK:
            stopped_by_user = (
                ACTIVE_AUTO_COUPLING.get("proc") is proc
                and bool(ACTIVE_AUTO_COUPLING.get("cancel_requested"))
            )
        return {
            "ok": (
                proc.returncode == 0
                and not stopped_by_user
                and bool(parsed is None or parsed.get("ok", True))
            ),
            "returncode": proc.returncode,
            "elapsed_s": time.time() - started,
            "command": command,
            "json": parsed,
            "stdout_tail": stdout[-4000:],
            "stderr_tail": stderr[-4000:],
            **({"stopped": True, "error": "auto coupling stopped by user"} if stopped_by_user else {}),
        }
    finally:
        with ACTIVE_AUTO_COUPLING_LOCK:
            if ACTIVE_AUTO_COUPLING.get("proc") is proc:
                ACTIVE_AUTO_COUPLING.update({"proc": None, "cancel_requested": False})


def stop_auto_coupling() -> dict[str, Any]:
    with ACTIVE_AUTO_COUPLING_LOCK:
        proc = ACTIVE_AUTO_COUPLING.get("proc")
        command = ACTIVE_AUTO_COUPLING.get("command")
        stage = ACTIVE_AUTO_COUPLING.get("stage")
        started_at = ACTIVE_AUTO_COUPLING.get("started_at")
        if proc is None or proc.poll() is not None:
            ACTIVE_AUTO_COUPLING.update({"proc": None, "cancel_requested": False})
            return {"ok": True, "message": "no auto coupling process is running"}
        ACTIVE_AUTO_COUPLING["cancel_requested"] = True
    stop = terminate_process_tree(proc)
    return {
        "ok": bool(stop.get("ok")),
        "message": "auto coupling stop requested",
        "pid": proc.pid,
        "stage": stage,
        "elapsed_s": time.time() - float(started_at or time.time()),
        "command": command,
        "stop": stop,
    }


def run_mdt693b_midpoint_initialization(body: dict[str, Any]) -> dict[str, Any]:
    if not bool(body.get("safety_confirmed")):
        raise ValueError("MDT693B midpoint initialization requires confirmation that both fiber probes are clear of the chip")
    if not DEFAULT_MDT693B_MIDPOINT_SCRIPT.exists():
        raise FileNotFoundError(f"missing MDT693B midpoint script: {DEFAULT_MDT693B_MIDPOINT_SCRIPT}")
    cavity_dir_text = str(body.get("cavity_dir") or "").strip()
    if not cavity_dir_text:
        raise ValueError("Select a chip / die before initializing MDT693B axes")
    target_v = finite_float(body.get("target_v"))
    target_v = 37.5 if target_v is None else float(target_v)
    if target_v < 0.0 or target_v > 75.0:
        raise ValueError(f"MDT693B midpoint target must be within 0..75 V, got {target_v:g} V")

    output_dir = Path(cavity_dir_text).expanduser().resolve() / "coupling" / "mdt693b_initialization"
    command = [
        package_python_executable(),
        str(DEFAULT_MDT693B_MIDPOINT_SCRIPT),
        "--execute",
        "--ports",
        "COM13",
        "COM14",
        "--axes",
        "x",
        "y",
        "z",
        "--target-v",
        f"{target_v:.6g}",
        "--min-v",
        "0",
        "--max-v",
        "75",
        "--step-v",
        "3",
        "--settle-s",
        "0.05",
        "--out-dir",
        str(output_dir),
    ]
    result = run_auto_coupling_script(
        command,
        timeout_s=180.0,
        stage="MDT693B midpoint initialization",
    )
    payload = result.get("json") if isinstance(result.get("json"), dict) else {}
    controller_summaries = []
    for controller in payload.get("controllers", []) if isinstance(payload.get("controllers"), list) else []:
        if not isinstance(controller, dict):
            continue
        controller_summaries.append(
            {
                "port": controller.get("port"),
                "status": controller.get("status"),
                "before_v": controller.get("before_v"),
                "readback_after_v": controller.get("readback_after_v"),
                "commanded_after_v": controller.get("commanded_after_v"),
                "axis_results": [
                    {
                        "axis": axis_result.get("axis"),
                        "ok": axis_result.get("ok"),
                        "before_v": axis_result.get("before_v"),
                        "target_v": axis_result.get("target_v"),
                        "commanded_after_v": axis_result.get("commanded_after_v"),
                        "readback_after_v": axis_result.get("readback_after_v"),
                        "n_steps": axis_result.get("n_steps"),
                        "error": axis_result.get("error"),
                    }
                    for axis_result in controller.get("axis_results", [])
                    if isinstance(axis_result, dict)
                ],
            }
        )
    return {
        "ok": bool(result.get("ok")),
        "message": (
            f"MDT693B six-axis initialization finished at approximately {target_v:g} V"
            if result.get("ok")
            else "MDT693B six-axis initialization failed or was stopped"
        ),
        "target_v": target_v,
        "ports": ["COM13", "COM14"],
        "axes": ["x", "y", "z"],
        "output_dir": str(output_dir),
        "record_path": payload.get("record_path"),
        "status": payload.get("status"),
        "failed_port": payload.get("failed_port"),
        "failed_axis": payload.get("failed_axis"),
        "controllers": controller_summaries,
        "elapsed_s": result.get("elapsed_s"),
        "returncode": result.get("returncode"),
        "error": payload.get("error") or result.get("error"),
        "stderr_tail": result.get("stderr_tail"),
    }


def run_standard_auto_coupling(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    config = instrument_config_from_mapping(body, args)
    if config["laser_type"] not in {"toptica_tcp", "toptica_serial"}:
        raise ValueError("Auto coupling is only enabled in TOPTICA Q / Lock mode")
    if config["rp_type"] == "none":
        raise ValueError("Auto coupling requires RP / PyRPL bridge power readout")
    if not DEFAULT_AUTO_COUPLING_SCRIPT.exists():
        raise FileNotFoundError(f"missing auto-coupling script: {DEFAULT_AUTO_COUPLING_SCRIPT}")

    scope_inputs = configure_coupling_scope_inputs(config["bridge_base"])
    if not scope_inputs.get("ok"):
        return {
            "ok": False,
            "message": "failed to configure coupling scope inputs; expected CH1=in1 for photodetector and CH2=out2",
            "scope_inputs": scope_inputs,
        }

    common = [
        package_python_executable(),
        str(DEFAULT_AUTO_COUPLING_SCRIPT),
        "--execute",
        "--power-kind",
        "inst",
        "--channel",
        "CH1",
        "--bridge",
        config["bridge_base"],
        "--min-v",
        "0",
        "--max-v",
        "75",
        "--settle-s",
        "0.08",
        "--stop-below-start-count",
        "3",
    ]
    first_pass = common + [
        "--axis-order",
        "COM13:z",
        "COM13:y",
        "COM14:z",
        "COM14:x",
        "--round-steps-v",
        "1,0.3,0.1",
        "--round-max-travel-v",
        "20,20,20",
        "--distance-axis-order",
        "COM13:x",
        "COM14:y",
        "--distance-round-steps-v",
        "2,0.6,0.2",
        "--distance-round-max-travel-v",
        "20,20,20",
    ]
    second_pass = common + [
        "--axis-order",
        "COM13:z",
        "COM13:y",
        "COM14:z",
        "COM14:x",
        "COM13:x",
        "COM14:y",
        "--round-steps-v",
        "0.5,0.3,0.1",
        "--round-max-travel-v",
        "10,10,10",
    ]
    steps = [
        {
            "name": "configure scope inputs",
            "parameters": {"scope_ch1_input": "in1", "scope_ch2_input": "out2"},
            "result": scope_inputs,
        },
        {
            "name": "coarse alignment + distance",
            "parameters": {
                "primary_axes": "COM13:z COM13:y COM14:z COM14:x",
                "primary_steps_v": "1,0.3,0.1",
                "primary_max_travel_v": "20,20,20",
                "distance_axes": "COM13:x COM14:y",
                "distance_steps_v": "2,0.6,0.2",
                "distance_max_travel_v": "20,20,20",
            },
            "result": run_auto_coupling_script(first_pass, timeout_s=900.0, stage="coarse alignment + distance"),
        }
    ]
    if not steps[-1]["result"].get("ok"):
        return {
            "ok": False,
            "message": "auto coupling stopped during first pass",
            "steps": steps,
        }
    steps.append(
        {
            "name": "fine confirmation",
            "parameters": {
                "axes": "COM13:z COM13:y COM14:z COM14:x COM13:x COM14:y",
                "steps_v": "0.5,0.3,0.1",
                "max_travel_v": "10,10,10",
            },
            "result": run_auto_coupling_script(second_pass, timeout_s=900.0, stage="fine confirmation"),
        }
    )
    return {
        "ok": all(bool(step["result"].get("ok")) for step in steps),
        "message": "standard auto coupling finished",
        "workflow": "coarse monotonic alignment, distance tuning, then fine confirmation; instantaneous RP power is used",
        "steps": steps,
    }


def run_weiyuan_action(body: dict[str, Any]) -> dict[str, Any]:
    port = str(body.get("laser_port") or DEFAULT_LARGE_SCAN_LASER_PORT)
    slave = int(body.get("weiyuan_slave") or 255)
    action = str(body.get("weiyuan_action") or "status")
    try:
        WeiyuanLaser = weiyuan_control.WeiyuanLaser

        with WeiyuanLaser(port=port, slave=slave) as laser:
            if action == "status":
                pass
            elif action == "set_temperature":
                value = finite_float(body.get("temperature_c"))
                if value is None:
                    raise ValueError("temperature_c is required")
                laser.set_temperature_c(value)
            elif action == "set_current":
                value = finite_float(body.get("current_ma"))
                if value is None:
                    raise ValueError("current_ma is required")
                laser.set_current_ma(value)
            elif action == "set_initial_current":
                laser.set_current_ma(260.0)
            elif action == "tec_on":
                laser.set_tec_enabled(True)
            elif action == "tec_off":
                laser.set_tec_enabled(False)
            elif action == "ld_on":
                laser.set_ld_enabled(True)
            elif action == "ld_off":
                laser.set_ld_enabled(False)
            else:
                raise ValueError(f"Unknown Weiyuan action: {action}")
            status = laser.read_status()
        return {"ok": True, "json": {"message": "微源光子通信成功", "weiyuan": status, "action": action}}
    except Exception as exc:
        return {"ok": False, "json": {"message": "微源光子通信失败", "port": port, "action": action, "error": repr(exc)}}


def capture_scope_preview(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    config = instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("Bridge scope preview requires RP / PyRPL bridge")
    timeout = finite_float(body.get("timeout_s")) or 5.0
    max_points = int(finite_float(body.get("max_points")) or 1500)
    query = urlencode(
        {
            "tag": "dashboard_scope_preview",
            "timeout": timeout,
            "plot": "false",
            "save": "false",
            "inline": "true",
            "max_points": max_points,
        }
    )
    return request_json(f"{config['bridge_base']}/scope/single?{query}", timeout=max(10.0, timeout + 5.0))


def safe_tag_text(value: object, default: str = "sensitivity") -> str:
    text = str(value or default).strip() or default
    return re.sub(r"[^A-Za-z0-9_-]+", "_", text)


def unique_run_dir(base_dir: Path) -> Path:
    if not base_dir.exists():
        return base_dir
    for idx in range(2, 1000):
        candidate = base_dir.with_name(f"{base_dir.name}_{idx:02d}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not find an unused run directory near {base_dir}")


def default_sensitivity_root() -> Path:
    data_paths = lock_paths
    return data_paths.default_results_dir() / "sensitivity"


def resolve_sensitivity_run_dir(body: dict[str, Any], tag_prefix: str, timestamp: str) -> tuple[Path, bool, str | None]:
    cavity_text = str(body.get("cavity_dir") or "").strip()
    run_name = f"{timestamp}_{tag_prefix}"
    if cavity_text:
        cavity_dir = Path(cavity_text).expanduser()
        return unique_run_dir(cavity_dir / "sensitivity" / run_name), False, str(cavity_dir)
    return unique_run_dir(default_sensitivity_root() / run_name), True, None


def latest_sensitivity_run_dir(cavity_dir: Path) -> Path | None:
    latest_path = cavity_dir / "sensitivity" / "latest.json"
    if latest_path.exists():
        try:
            latest = json.loads(latest_path.read_text(encoding="utf-8-sig"))
            run_dir = latest.get("run_dir")
            if run_dir:
                path = Path(run_dir)
                if not path.is_absolute():
                    path = cavity_dir / "sensitivity" / str(run_dir)
                if path.exists():
                    return path
        except Exception:
            pass
    sensitivity_dir = cavity_dir / "sensitivity"
    if not sensitivity_dir.exists():
        return None
    candidates = sorted(
        [path for path in sensitivity_dir.iterdir() if path.is_dir() and (path / "raw").exists()],
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def pressure_npz_value(data: np.lib.npyio.NpzFile, key: str, default: Any = None) -> Any:
    if key not in data.files:
        return default
    value = data[key]
    if getattr(value, "shape", ()) == ():
        item = value.item()
        if isinstance(item, bytes):
            return item.decode("utf-8", errors="replace")
        return item
    return value


def load_pressure_calibration(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Pressure calibration file not found: {path}")
    data = np.load(str(path), allow_pickle=False)
    if "frequency_hz" not in data.files:
        raise ValueError(f"Pressure calibration lacks frequency_hz: {path}")
    pressure_key = None
    for candidate in ("pressure_pa_at_10vpp", "pressure_pk_pa_at_10vpp", "pressure_pa"):
        if candidate in data.files:
            pressure_key = candidate
            break
    if pressure_key is None:
        raise ValueError(f"Pressure calibration lacks pressure array: {path}")
    freq = np.asarray(data["frequency_hz"], dtype=float)
    pressure = np.asarray(data[pressure_key], dtype=float)
    n = min(len(freq), len(pressure))
    if n < 2:
        raise ValueError(f"Pressure calibration needs at least two points: {path}")
    freq = freq[:n]
    pressure = pressure[:n]
    order = np.argsort(freq)
    freq = freq[order]
    pressure = pressure[order]
    calibration_vpp = finite_config_float(pressure_npz_value(data, "calibration_drive_vpp"), None)
    if calibration_vpp is None:
        text = path.name.lower()
        match = re.search(r"(\d+(?:\.\d+)?)\s*vpp", text)
        calibration_vpp = float(match.group(1)) if match else 10.0
    quantity = str(pressure_npz_value(data, "pressure_quantity", "pk") or "pk")
    if quantity == "unknown_confirm_rms_or_peak":
        quantity = "pk"
    return {
        "path": str(path),
        "frequency_hz": freq,
        "pressure_pa": pressure,
        "pressure_array_key": pressure_key,
        "pressure_quantity": quantity,
        "calibration_drive_vpp": float(calibration_vpp),
        "start_hz": float(np.nanmin(freq)),
        "stop_hz": float(np.nanmax(freq)),
        "points": int(n),
    }


def pressure_calibration_from_body(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    defaults = getattr(args, "sensitivity_defaults", {}) or {}
    path_text = str(body.get("pressure_calibration_path") or "").strip()
    source_model = str(
        body.get("pressure_source_model")
        or defaults.get("pressure_source_model")
        or DEFAULT_PRESSURE_SOURCE
    ).strip()
    if not path_text:
        root = Path(str(defaults.get("pressure_calibration_root") or DEFAULT_PRESSURE_CALIBRATION_ROOT))
        path_text = str(default_pressure_calibration_from_source(root, source_model))
    if not path_text:
        path_text = str(defaults.get("pressure_calibration_path") or DEFAULT_PRESSURE_CALIBRATION)
    calibration = load_pressure_calibration(Path(path_text).expanduser())
    quantity = str(body.get("pressure_quantity") or defaults.get("pressure_quantity") or calibration["pressure_quantity"] or "pk")
    calibration_drive_vpp = finite_config_float(
        body.get("pressure_calibration_drive_vpp"),
        finite_config_float(defaults.get("pressure_calibration_drive_vpp"), calibration["calibration_drive_vpp"]),
    )
    use_start_hz = finite_config_float(body.get("pressure_use_start_hz"), calibration["start_hz"])
    use_stop_hz = finite_config_float(body.get("pressure_use_stop_hz"), calibration["stop_hz"])
    if use_start_hz is not None and use_stop_hz is not None and use_start_hz > use_stop_hz:
        use_start_hz, use_stop_hz = use_stop_hz, use_start_hz
    calibration.update(
        {
            "pressure_quantity": quantity,
            "calibration_drive_vpp": float(calibration_drive_vpp or calibration["calibration_drive_vpp"]),
            "use_start_hz": float(use_start_hz or calibration["start_hz"]),
            "use_stop_hz": float(use_stop_hz or calibration["stop_hz"]),
        }
    )
    return calibration


def read_bridge_params(base: str, params: list[str]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    values: dict[str, Any] = {}
    steps: list[dict[str, Any]] = []
    for param in params:
        try:
            result = bridge_get(base, param)
            values[param] = result.get("value")
            steps.append({"param": param, "ok": bool(result.get("ok")), "result": result})
        except Exception as exc:
            steps.append({"param": param, "ok": False, "error": repr(exc)})
    return values, steps


def sensitivity_settings(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    config = instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("Sensitivity settings require RP / PyRPL bridge")
    base = config["bridge_base"].rstrip("/")
    mode = str(body.get("acquisition_mode") or "both").strip().lower()
    settings = {} if mode == "compute" else bridge_query(base, "/acquisition/settings", {}, timeout=8.0)
    settings["bridge_base"] = base
    sensitivity_defaults = getattr(args, "sensitivity_defaults", {}) or {}
    pressure_root = Path(str(sensitivity_defaults.get("pressure_calibration_root") or DEFAULT_PRESSURE_CALIBRATION_ROOT))
    settings["pressure_sources"] = list_pressure_sources(pressure_root)
    try:
        pressure = pressure_calibration_from_body(body, args)
        settings["pressure_calibration"] = {
            "path": pressure["path"],
            "start_hz": pressure["start_hz"],
            "stop_hz": pressure["stop_hz"],
            "points": pressure["points"],
            "pressure_quantity": pressure["pressure_quantity"],
            "calibration_drive_vpp": pressure["calibration_drive_vpp"],
            "use_start_hz": pressure["use_start_hz"],
            "use_stop_hz": pressure["use_stop_hz"],
            "pressure_array_key": pressure["pressure_array_key"],
            "source_model": str(sensitivity_defaults.get("pressure_source_model") or DEFAULT_PRESSURE_SOURCE),
        }
    except Exception as exc:
        fallback_pressure_path = default_pressure_calibration_from_source(
            pressure_root,
            str(sensitivity_defaults.get("pressure_source_model") or DEFAULT_PRESSURE_SOURCE),
        )
        settings["pressure_calibration"] = {
            "ok": False,
            "error": repr(exc),
            "path": str(sensitivity_defaults.get("pressure_calibration_path") or fallback_pressure_path),
            "source_model": str(sensitivity_defaults.get("pressure_source_model") or DEFAULT_PRESSURE_SOURCE),
        }
    return settings


def sensitivity_requested_settings(body: dict[str, Any]) -> dict[str, Any]:
    optical_mode = body.get("optical_mode")
    if isinstance(optical_mode, dict):
        optical_mode = {str(k): json_ready(v) for k, v in optical_mode.items()}
    else:
        optical_mode = None
    return {
        "spectrum": {
            "span_hz": finite_config_float(body.get("spectrum_span_hz"), None),
            "rbw_hz": finite_config_float(body.get("spectrum_rbw_hz"), None),
            "trace_average": int(finite_config_float(body.get("spectrum_trace_average"), 0.0) or 0) or None,
        },
        "network": {
            "amplitude_vpk": finite_config_float(body.get("network_amplitude_vpk"), None),
            "start_freq_hz": finite_config_float(body.get("network_start_freq_hz"), None),
            "stop_freq_hz": finite_config_float(body.get("network_stop_freq_hz"), None),
            "points": int(finite_config_float(body.get("network_points"), 0.0) or 0) or None,
            "rbw_hz": finite_config_float(body.get("network_rbw_hz"), None),
        },
        "pressure": {
            "source_model": str(body.get("pressure_source_model") or "").strip() or None,
            "calibration_path": str(body.get("pressure_calibration_path") or "").strip() or None,
            "calibration_drive_vpp": finite_config_float(body.get("pressure_calibration_drive_vpp"), None),
            "quantity": str(body.get("pressure_quantity") or "").strip() or None,
            "use_start_hz": finite_config_float(body.get("pressure_use_start_hz"), None),
            "use_stop_hz": finite_config_float(body.get("pressure_use_stop_hz"), None),
        },
        "optical_mode": optical_mode,
    }


def apply_sensitivity_settings(base: str, mode: str, settings: dict[str, Any]) -> dict[str, Any]:
    requested: list[tuple[str, str | int | float | None]] = []
    if mode in {"psd", "both"}:
        spectrum = settings.get("spectrum") or {}
        requested.extend(
            [
                ("spectrumanalyzer.span", spectrum.get("span_hz")),
                ("spectrumanalyzer.trace_average", spectrum.get("trace_average")),
            ]
        )
    if mode in {"network", "both"}:
        network = settings.get("network") or {}
        requested.extend(
            [
                ("networkanalyzer.amplitude", network.get("amplitude_vpk")),
                ("networkanalyzer.start_freq", network.get("start_freq_hz")),
                ("networkanalyzer.stop_freq", network.get("stop_freq_hz")),
                ("networkanalyzer.points", network.get("points")),
                ("networkanalyzer.rbw", network.get("rbw_hz")),
            ]
        )

    steps: list[dict[str, Any]] = []
    ok = True
    for param, value in requested:
        if value is None:
            steps.append({"param": param, "ok": True, "skipped": True, "reason": "empty value"})
            continue
        try:
            result = bridge_set(base, param, value)
            steps.append({"param": param, "value": value, "ok": bool(result.get("ok")), "result": result})
            ok = ok and bool(result.get("ok"))
        except Exception as exc:
            ok = False
            steps.append({"param": param, "value": value, "ok": False, "error": repr(exc)})
    return {"ok": ok, "steps": steps}


def downsample_points(x: np.ndarray, y: np.ndarray, max_points: int) -> list[list[float]]:
    n = min(len(x), len(y))
    if n <= 0:
        return []
    step = max(1, int(math.ceil(n / max(100, int(max_points)))))
    points: list[list[float]] = []
    for xi, yi in zip(np.asarray(x[:n])[::step], np.asarray(y[:n])[::step]):
        if np.isfinite(xi) and np.isfinite(yi):
            points.append([float(xi), float(yi)])
    return points


def json_ready(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    return value


def write_interactive_series_html(
    output: Path,
    *,
    title: str,
    subtitle: str,
    panels: list[dict[str, Any]],
) -> None:
    payload = json_ready({"title": title, "subtitle": subtitle, "panels": panels})
    payload_js = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    content = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
body{{margin:0;background:#fff;color:#000;font-family:Arial,sans-serif}}
#wrap{{padding:16px 20px 28px;max-width:1500px;margin:auto}}
h1{{font-size:26px;margin:0 0 4px;color:#000}}
#sub{{font-size:15px;margin:0 0 14px;color:#000}}
.panel{{border:1px solid #000;border-radius:6px;padding:10px;margin-bottom:14px;background:#fff}}
.panel h2{{font-size:19px;margin:0 0 8px;color:#000}}
.fitbar{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 8px;font-size:14px;color:#000}}
.fitbar button{{border:1px solid #000;border-radius:4px;background:#fff;color:#000;padding:5px 10px;font:14px Arial,sans-serif;cursor:pointer}}
.fitbar button:hover{{background:#f2f2f2}}
.fitResult{{font-weight:700}}
.fitLegend{{display:inline-flex;gap:10px;align-items:center;flex-wrap:wrap}}
.swatch{{display:inline-block;width:22px;height:0;border-top:3px solid #000;vertical-align:middle;margin-right:4px}}
.box{{position:relative;height:420px}}
canvas{{display:block;width:100%;height:100%;background:#fff}}
.selectBox{{position:absolute;display:none;border:1.5px dashed #000;background:rgba(0,0,0,.08);pointer-events:none}}
#tooltip{{position:fixed;display:none;pointer-events:none;background:#fff;border:1px solid #000;border-radius:4px;padding:7px 9px;font-size:14px;box-shadow:0 2px 7px rgba(0,0,0,.25);z-index:10;white-space:nowrap;color:#000}}
.hint{{font-size:13px;margin-top:8px;color:#000}}
</style>
</head>
<body>
<div id="wrap">
  <h1 id="title"></h1>
  <div id="sub"></div>
  <div id="panels"></div>
  <div class="hint">Left-drag box zooms, Shift+drag pans, wheel zooms, double click resets. Hover reads data values.</div>
</div>
<div id="tooltip"></div>
<script>
const payload={payload_js};
const tooltip=document.getElementById('tooltip');
document.getElementById('title').textContent=payload.title;
document.getElementById('sub').textContent=payload.subtitle;
function range(vals,p=.05){{let fs=vals.filter(Number.isFinite);if(!fs.length)return[0,1];let mn=Math.min(...fs),mx=Math.max(...fs);if(mn===mx){{mn-=1;mx+=1}}let q=(mx-mn)*p;return[mn-q,mx+q]}}
function niceTicks(a,b,n=6){{const span=Math.abs(b-a)||1,raw=span/n,pow=Math.pow(10,Math.floor(Math.log10(raw))),m=raw/pow,step=(m<1.5?1:m<3?2:m<7?5:10)*pow,start=Math.ceil(a/step)*step,out=[];for(let v=start;v<=b+step*.3;v+=step)out.push(v);return out}}
function tickText(v,span){{const a=Math.abs(span);const d=a<.01?5:a<.1?4:a<1?3:a<10?2:1;return v.toFixed(d)}}
function finite(v){{return Number.isFinite(v)}}
{mechanical_fit_javascript()}
class Chart{{
  constructor(canvas,opt){{this.canvas=canvas;this.box=canvas.parentElement;this.sel=this.box.querySelector('.selectBox');this.ctx=canvas.getContext('2d');this.opt=opt;this.pad={{l:92,r:28,t:18,b:62}};const xs=opt.series.flatMap(s=>s.data.map(p=>p[0])),ys=opt.series.flatMap(s=>s.data.map(p=>p[1]));const xr=range(xs,.02),yr=range(ys,.06);this.init={{x0:xr[0],x1:xr[1],y0:yr[0],y1:yr[1]}};this.view={{...this.init}};this.drag=false;this.pan=false;this.start=null;this.last=null;this.hoverState=null;this.fit=null;this.bind();this.resize()}}
  W(){{return this.box.clientWidth}} H(){{return this.box.clientHeight}}
  sx(x){{return this.pad.l+(x-this.view.x0)/(this.view.x1-this.view.x0)*(this.W()-this.pad.l-this.pad.r)}} sy(y){{return this.H()-this.pad.b-(y-this.view.y0)/(this.view.y1-this.view.y0)*(this.H()-this.pad.t-this.pad.b)}}
  ix(px){{return this.view.x0+(px-this.pad.l)/(this.W()-this.pad.l-this.pad.r)*(this.view.x1-this.view.x0)}} iy(py){{return this.view.y0+(this.H()-this.pad.b-py)/(this.H()-this.pad.t-this.pad.b)*(this.view.y1-this.view.y0)}}
  inPlot(x,y){{return x>=this.pad.l&&x<=this.W()-this.pad.r&&y>=this.pad.t&&y<=this.H()-this.pad.b}}
  resize(){{const dpr=window.devicePixelRatio||1;this.canvas.width=Math.round(this.W()*dpr);this.canvas.height=Math.round(this.H()*dpr);this.ctx.setTransform(dpr,0,0,dpr,0,0);this.draw()}}
  bind(){{window.addEventListener('resize',()=>this.resize());this.canvas.addEventListener('dblclick',()=>{{this.view={{...this.init}};this.draw()}});this.canvas.addEventListener('wheel',e=>{{e.preventDefault();const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,cx=this.ix(mx),cy=this.iy(my),f=e.deltaY<0?.82:1.22;this.view.x0=cx-(cx-this.view.x0)*f;this.view.x1=cx+(this.view.x1-cx)*f;this.view.y0=cy-(cy-this.view.y0)*f;this.view.y1=cy+(this.view.y1-cy)*f;this.draw()}});this.canvas.addEventListener('mousedown',e=>{{const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;if(!this.inPlot(mx,my))return;this.drag=true;this.pan=!!e.shiftKey;this.start={{x:mx,y:my}};this.last={{x:e.clientX,y:e.clientY}};if(!this.pan)this.updateSel(mx,my)}});window.addEventListener('mouseup',e=>{{if(!this.drag)return;if(!this.pan&&this.start){{const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,xA=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,this.start.x)),xB=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,mx)),yA=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,this.start.y)),yB=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,my));if(Math.abs(xB-xA)>8&&Math.abs(yB-yA)>8){{this.view={{x0:Math.min(this.ix(xA),this.ix(xB)),x1:Math.max(this.ix(xA),this.ix(xB)),y0:Math.min(this.iy(yA),this.iy(yB)),y1:Math.max(this.iy(yA),this.iy(yB))}};this.draw()}}}}this.drag=false;this.pan=false;this.start=null;this.sel.style.display='none'}});this.canvas.addEventListener('mouseleave',()=>{{if(!this.drag){{tooltip.style.display='none';if(this.hoverState){{this.hoverState=null;this.draw()}}}}}});this.canvas.addEventListener('mousemove',e=>{{const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;if(this.drag&&this.pan){{const dx=e.clientX-this.last.x,dy=e.clientY-this.last.y;this.last={{x:e.clientX,y:e.clientY}};const xs=this.view.x1-this.view.x0,ys=this.view.y1-this.view.y0;this.view.x0-=dx/(this.W()-this.pad.l-this.pad.r)*xs;this.view.x1-=dx/(this.W()-this.pad.l-this.pad.r)*xs;this.view.y0+=dy/(this.H()-this.pad.t-this.pad.b)*ys;this.view.y1+=dy/(this.H()-this.pad.t-this.pad.b)*ys;this.draw();return}}if(this.drag&&!this.pan){{this.updateSel(mx,my);return}}this.hover(e,mx,my)}})}}
  updateSel(mx,my){{const x1=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,this.start.x)),y1=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,this.start.y)),x2=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,mx)),y2=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,my));this.sel.style.left=Math.min(x1,x2)+'px';this.sel.style.top=Math.min(y1,y2)+'px';this.sel.style.width=Math.abs(x2-x1)+'px';this.sel.style.height=Math.abs(y2-y1)+'px';this.sel.style.display='block'}}
  interp(s,xq){{const d=s.data;if(!d||!d.length)return null;let prev=d[0];if(xq<=prev[0])return {{x:prev[0],y:prev[1]}};for(let i=1;i<d.length;i++){{const p=d[i];if(xq<=p[0]){{const x0=prev[0],y0=prev[1],x1=p[0],y1=p[1],t=(xq-x0)/((x1-x0)||1);return {{x:xq,y:y0+(y1-y0)*t}}}}prev=p}}const last=d[d.length-1];return {{x:last[0],y:last[1]}}}}
  hover(e,mx,my){{if(!this.inPlot(mx,my)){{tooltip.style.display='none';if(this.hoverState){{this.hoverState=null;this.draw()}}return}}const xq=this.ix(mx),rows=[];for(const s of this.opt.series){{const p=this.interp(s,xq);if(!p||!Number.isFinite(p.y))continue;if(p.y<this.view.y0||p.y>this.view.y1)continue;rows.push({{s,x:p.x,y:p.y}})}}if(!rows.length){{tooltip.style.display='none';if(this.hoverState){{this.hoverState=null;this.draw()}}return}}this.hoverState={{x:xq,rows}};this.draw();tooltip.style.display='block';tooltip.style.left=e.clientX+14+'px';tooltip.style.top=e.clientY+12+'px';const body=rows.map(r=>`<div><b style="color:${{r.s.color||'#000'}}">${{r.s.name}}</b>: ${{r.y.toFixed(3)}}</div>`).join('');tooltip.innerHTML=`<b>${{this.opt.xLabel}}: ${{xq.toFixed(4)}}</b><br>${{body}}`}}
  drawHover(){{const h=this.hoverState;if(!h)return;const c=this.ctx,x=this.sx(h.x);c.save();c.strokeStyle='#000';c.lineWidth=1;c.setLineDash([4,4]);c.beginPath();c.moveTo(x,this.pad.t);c.lineTo(x,this.H()-this.pad.b);c.stroke();c.setLineDash([]);for(const r of h.rows){{const y=this.sy(r.y);if(!this.inPlot(x,y))continue;c.beginPath();c.arc(x,y,4.5,0,Math.PI*2);c.fillStyle=r.s.color||'#000';c.fill();c.strokeStyle='#000';c.lineWidth=1;c.stroke()}}c.restore()}}
  setFit(fit){{this.fit=fit;this.draw()}}
  clearFit(){{this.fit=null;this.draw()}}
  drawFit(){{const f=this.fit;if(!f||!f.data||!f.data.length)return;const c=this.ctx;c.save();c.beginPath();let started=false;for(const p of f.data){{const x=p[0],y=p[1];if(!finite(x)||!finite(y)||x<this.view.x0||x>this.view.x1)continue;const px=this.sx(x),py=this.sy(y);if(!started){{c.moveTo(px,this.sy(f.bgDb));c.lineTo(px,py);started=true}}else c.lineTo(px,py)}}if(started){{for(let i=f.data.length-1;i>=0;i--){{const p=f.data[i],x=p[0];if(!finite(x)||x<this.view.x0||x>this.view.x1)continue;c.lineTo(this.sx(x),this.sy(f.bgDb))}}c.closePath();c.fillStyle='rgba(214,39,40,.12)';c.fill()}}const drawLine=(data,color,width,dash=[])=>{{c.save();c.strokeStyle=color;c.lineWidth=width;c.setLineDash(dash);c.beginPath();let st=false;for(const p of data){{const x=p[0],y=p[1];if(!finite(x)||!finite(y)||x<this.view.x0||x>this.view.x1)continue;const px=this.sx(x),py=this.sy(y);if(!st){{c.moveTo(px,py);st=true}}else c.lineTo(px,py)}}if(st)c.stroke();c.restore()}};drawLine(f.data.map(p=>[p[0],f.bgDb]),'#2ca02c',1.8,[7,5]);drawLine(f.mechData||[],'#1f77b4',1.9,[3,3]);drawLine(f.data,'#d62728',2.5,[]);const x0=this.sx(f.f0);if(finite(x0)){{c.setLineDash([5,4]);c.strokeStyle='#d62728';c.lineWidth=1;c.beginPath();c.moveTo(x0,this.pad.t);c.lineTo(x0,this.H()-this.pad.b);c.stroke()}}c.restore()}}
  draw(){{const c=this.ctx;c.clearRect(0,0,this.W(),this.H());c.fillStyle='#fff';c.fillRect(0,0,this.W(),this.H());c.strokeStyle='#000';c.lineWidth=1.2;c.strokeRect(this.pad.l,this.pad.t,this.W()-this.pad.l-this.pad.r,this.H()-this.pad.t-this.pad.b);const xt=niceTicks(this.view.x0,this.view.x1,6),yt=niceTicks(this.view.y0,this.view.y1,6);c.strokeStyle='#000';c.lineWidth=.45;c.font='14px Arial';c.textAlign='center';c.textBaseline='top';for(const v of xt){{const x=this.sx(v);c.beginPath();c.moveTo(x,this.pad.t);c.lineTo(x,this.H()-this.pad.b);c.stroke();c.fillStyle='#000';c.fillText(tickText(v,this.view.x1-this.view.x0),x,this.H()-this.pad.b+9)}}c.textAlign='right';c.textBaseline='middle';for(const v of yt){{const y=this.sy(v);c.beginPath();c.moveTo(this.pad.l,y);c.lineTo(this.W()-this.pad.r,y);c.stroke();c.fillStyle='#000';c.fillText(tickText(v,this.view.y1-this.view.y0),this.pad.l-9,y)}}c.font='18px Arial';c.textAlign='center';c.textBaseline='bottom';c.fillText(this.opt.xLabel,(this.pad.l+this.W()-this.pad.r)/2,this.H()-10);c.save();c.translate(24,(this.pad.t+this.H()-this.pad.b)/2);c.rotate(-Math.PI/2);c.fillText(this.opt.yLabel,0,0);c.restore();for(const s of this.opt.series){{c.strokeStyle=s.color||'#000';c.lineWidth=s.width||2;c.beginPath();let st=false;for(const p of s.data){{const x=p[0],y=p[1];if(x<this.view.x0||x>this.view.x1||y<this.view.y0-10||y>this.view.y1+10)continue;if(!st){{c.moveTo(this.sx(x),this.sy(y));st=true}}else c.lineTo(this.sx(x),this.sy(y))}}c.stroke()}}this.drawFit();this.drawHover()}}
}}
const root=document.getElementById('panels');
function installMechanicalFit(panel,chart){{
  const bar=document.createElement('div');bar.className='fitbar';
  const btn=document.createElement('button');btn.textContent='Fit visible mechanical peak';
  const res=document.createElement('span');res.className='fitResult';res.textContent='zoom to one peak, then fit';
  btn.onclick=()=>{{if(chart.fit){{chart.clearFit();btn.textContent='Fit visible mechanical peak';res.textContent='fit cleared';return}}try{{const fit=fitMechanicalSusceptibilityVisible(chart);chart.setFit(fit);btn.textContent='Clear fit';res.textContent=`f0=${{fit.f0.toFixed(6)}} MHz, Gamma/FWHM~${{(fit.fwhm*1e3).toFixed(2)}} kHz, Q~${{fit.qm.toFixed(0)}}, rms=${{fit.rmseDb.toFixed(2)}} dB`}}catch(err){{res.textContent='fit failed: '+err.message}}}};
  const legend=document.createElement('span');legend.className='fitLegend';legend.innerHTML='<span><i class="swatch" style="border-color:#d62728"></i>total</span><span><i class="swatch" style="border-color:#1f77b4;border-top-style:dashed"></i>mechanical</span><span><i class="swatch" style="border-color:#2ca02c;border-top-style:dashed"></i>background</span>';
  bar.appendChild(btn);bar.appendChild(res);bar.appendChild(legend);panel.insertBefore(bar,panel.querySelector('.box'));
}}
payload.panels.forEach((p,i)=>{{const panel=document.createElement('div');panel.className='panel';panel.innerHTML=`<h2>${{p.title}}</h2><div class="box"><canvas></canvas><div class="selectBox"></div></div>`;root.appendChild(panel);const chart=new Chart(panel.querySelector('canvas'),p);if(p.fitMechanical)installMechanicalFit(panel,chart)}});
</script>
</body>
</html>
"""
    output.write_text(content, encoding="utf-8")


def write_sensitivity_preview_plots(
    *,
    run_dir: Path,
    tag_prefix: str,
    timestamp: str,
    spectrum: dict[str, Any] | None,
    network: dict[str, Any] | None,
    max_points: int,
) -> dict[str, str]:
    plots: dict[str, str] = {}
    if spectrum and spectrum.get("ok") and spectrum.get("path"):
        data = np.load(str(spectrum["path"]))
        freq_mhz = np.asarray(data["frequency_hz"], dtype=float) / 1e6
        psd = np.asarray(data["input1_dbm_per_hz"], dtype=float)
        output = run_dir / "noise_psd.html"
        write_interactive_series_html(
            output,
            title=f"{tag_prefix} noise PSD",
            subtitle=f"{timestamp}; saved data: {spectrum.get('path')}",
            panels=[
                {
                    "title": "Spectrum analyzer PSD",
                    "xLabel": "Frequency (MHz)",
                    "yLabel": "PSD (dBm/Hz)",
                    "fitMechanical": True,
                    "series": [{"name": "PSD", "color": "#000", "width": 1.8, "data": downsample_points(freq_mhz, psd, max_points)}],
                }
            ],
        )
        plots["noise_psd_html"] = str(output)
    if network and network.get("ok") and network.get("path"):
        data = np.load(str(network["path"]))
        freq_mhz = np.asarray(data["frequency_hz"], dtype=float) / 1e6
        mag = np.asarray(data["magnitude_dbm"], dtype=float)
        phase = np.asarray(data["phase_deg"], dtype=float)
        output = run_dir / "network_response.html"
        write_interactive_series_html(
            output,
            title=f"{tag_prefix} network response",
            subtitle=f"{timestamp}; saved data: {network.get('path')}",
            panels=[
                {
                    "title": "Network analyzer coherent response",
                    "xLabel": "Frequency (MHz)",
                    "yLabel": "Magnitude (dBm)",
                    "series": [{"name": "Magnitude", "color": "#000", "width": 1.8, "data": downsample_points(freq_mhz, mag, max_points)}],
                },
                {
                    "title": "Network analyzer phase",
                    "xLabel": "Frequency (MHz)",
                    "yLabel": "Phase (deg)",
                    "series": [{"name": "Phase", "color": "#000", "width": 1.8, "data": downsample_points(freq_mhz, phase, max_points)}],
                },
            ],
        )
        plots["network_response_html"] = str(output)
    return plots


def copy_to_subdir_if_needed(path_text: str | None, target_dir: Path, target_name: str | None = None) -> str | None:
    if not path_text:
        return None
    source = Path(path_text)
    if not source.exists():
        return path_text
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / (target_name or source.name)
    if source.resolve() != target.resolve() and source.parent.resolve() == target_dir.resolve():
        source.replace(target)
    elif source.resolve() != target.resolve():
        target.write_bytes(source.read_bytes())
    return str(target)


def finite_interp(x_new: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 2:
        raise ValueError("Interpolation source has fewer than two finite points")
    x_src = np.asarray(x[mask], dtype=float)
    y_src = np.asarray(y[mask], dtype=float)
    order = np.argsort(x_src)
    return np.interp(x_new, x_src[order], y_src[order])


def previous_network_amplitude_vpk(run_dir: Path, raw_dir: Path) -> float | None:
    candidates = [run_dir / "run.json", raw_dir / "network_response.json", run_dir / "network_response.json"]
    for path in candidates:
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        values = [
            payload.get("network", {}).get("amplitude_v") if isinstance(payload.get("network"), dict) else None,
            payload.get("amplitude_v"),
            payload.get("amplitude_vpk"),
        ]
        for value in values:
            parsed = finite_config_float(value, None)
            if parsed is not None:
                return parsed
    return None


def compact_optical_mode_text(mode: dict[str, Any] | None) -> str:
    if not mode:
        return "mode not recorded"
    family = mode.get("family_label") or mode.get("family") or "mode"
    mu = mode.get("mode_number", mode.get("mu", "-"))
    wavelength = finite_config_float(mode.get("wavelength_nm"), None)
    q0 = finite_config_float(mode.get("Q0"), None)
    parts = [str(family), f"mu={mu}"]
    if wavelength is not None:
        parts.append(f"{wavelength:.6f} nm")
    if q0 is not None:
        parts.append(f"Q0={q0/1e6:.3f} M")
    return ", ".join(parts)


def write_sensitivity_result_html(output: Path, result: dict[str, np.ndarray], meta: dict[str, Any]) -> None:
    freq_mhz = result["frequency_hz"] / 1e6
    sens = result["sensitivity_pa_per_sqrt_hz"]
    panels = [
        {
            "title": "Noise PSD",
            "xLabel": "Frequency (MHz)",
            "yLabel": "PSD (dBm/Hz)",
            "fitMechanical": True,
            "series": [{"name": "noise PSD", "color": "#000", "width": 1.7, "data": np.column_stack([freq_mhz, result["noise_dbm_per_hz"]]).tolist()}],
        },
        {
            "title": "Acoustic response",
            "xLabel": "Frequency (MHz)",
            "yLabel": "Response (dBm/Pa²)",
            "series": [{"name": "response", "color": "#000", "width": 1.7, "data": np.column_stack([freq_mhz, result["response_dbm_per_pa2"]]).tolist()}],
        },
        {
            "title": "Sensitivity",
            "xLabel": "Frequency (MHz)",
            "yLabel": "NEP (Pa/√Hz)",
            "yScale": "log",
            "series": [{"name": "sensitivity", "color": "#000", "width": 1.7, "data": np.column_stack([freq_mhz, sens]).tolist()}],
        },
    ]
    payload = json.dumps(json_ready({"title": "Ultrasound sensitivity", "subtitle": meta, "panels": panels}), ensure_ascii=False, separators=(",", ":"))
    content = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>Ultrasound sensitivity</title>
<style>
body{{margin:0;background:#fff;color:#000;font-family:Arial,sans-serif}}
#wrap{{padding:16px 20px 28px;max-width:1500px;margin:auto}}
h1{{font-size:26px;margin:0 0 4px;color:#000}}
#sub{{font-size:15px;margin:0 0 14px;color:#000}}
.panel{{border:1px solid #000;border-radius:6px;padding:10px;margin-bottom:14px;background:#fff}}
.panel h2{{font-size:19px;margin:0 0 8px;color:#000}}
.fitbar{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 8px;font-size:14px;color:#000}}
.fitbar button{{border:1px solid #000;border-radius:4px;background:#fff;color:#000;padding:5px 10px;font:14px Arial,sans-serif;cursor:pointer}}
.fitbar button:hover{{background:#f2f2f2}}
.fitResult{{font-weight:700}}
.fitLegend{{display:inline-flex;gap:10px;align-items:center;flex-wrap:wrap}}
.swatch{{display:inline-block;width:22px;height:0;border-top:3px solid #000;vertical-align:middle;margin-right:4px}}
.box{{position:relative;height:360px}}
canvas{{display:block;width:100%;height:100%;background:#fff}}
.selectBox{{position:absolute;display:none;border:1.5px dashed #000;background:rgba(0,0,0,.08);pointer-events:none}}
#tooltip{{position:fixed;display:none;pointer-events:none;background:#fff;border:1px solid #000;border-radius:4px;padding:7px 9px;font-size:14px;box-shadow:0 2px 7px rgba(0,0,0,.25);z-index:10;white-space:nowrap;color:#000}}
.hint{{font-size:13px;margin-top:8px;color:#000}}
</style>
</head>
<body>
<div id="wrap"><h1>Ultrasound sensitivity</h1><div id="sub"></div><div id="panels"></div><div class="hint">Left-drag box zooms, Shift+drag pans, wheel zooms, double click resets. Hover reads data values.</div></div>
<div id="tooltip"></div>
<script>
const payload={payload};
const tooltip=document.getElementById('tooltip');
document.getElementById('sub').textContent = `mode: ${{payload.subtitle.optical_mode_text || 'not recorded'}}; pressure: ${{payload.subtitle.pressure_file || '-'}}; drive: ${{payload.subtitle.actual_drive_vpp || '-'}} Vpp`;
function finite(v){{return Number.isFinite(v)}}
function log10(v){{return Math.log(v)/Math.LN10}}
function formatLog(v){{if(!finite(v)||v<=0)return ''; const e=Math.round(log10(v)); return `10^${{e}}`}}
function range(vals,p=.05,log=false){{let fs=vals.filter(v=>finite(v)&&(!log||v>0));if(!fs.length)return log?[1e-9,1e-3]:[0,1];let arr=log?fs.map(log10):fs;let mn=Math.min(...arr),mx=Math.max(...arr);if(mn===mx){{mn-=1;mx+=1}}let q=(mx-mn)*p;return log?[Math.pow(10,mn-q),Math.pow(10,mx+q)]:[mn-q,mx+q]}}
function niceTicks(a,b,n=6){{const span=Math.abs(b-a)||1,raw=span/n,pow=Math.pow(10,Math.floor(Math.log10(raw))),m=raw/pow,step=(m<1.5?1:m<3?2:m<7?5:10)*pow,start=Math.ceil(a/step)*step,out=[];for(let v=start;v<=b+step*.3;v+=step)out.push(v);return out}}
function logMajorTicks(a,b){{const ea=Math.ceil(log10(a)), eb=Math.floor(log10(b)), out=[];for(let e=ea;e<=eb;e++){{const v=Math.pow(10,e); if(v>=a&&v<=b)out.push(v)}}return out}}
function logMinorTicks(a,b){{const ea=Math.floor(log10(a)), eb=Math.ceil(log10(b)), out=[];for(let e=ea;e<=eb;e++){{for(const m of [2,3,4,5,6,7,8,9]){{const v=m*Math.pow(10,e); if(v>=a&&v<=b)out.push(v)}}}}return out}}
function tickText(v,span){{const a=Math.abs(span);const d=a<.01?5:a<.1?4:a<1?3:a<10?2:1;return v.toFixed(d)}}
{mechanical_fit_javascript()}
class Chart{{
  constructor(canvas,opt){{this.canvas=canvas;this.box=canvas.parentElement;this.sel=this.box.querySelector('.selectBox');this.ctx=canvas.getContext('2d');this.opt=opt;this.logY=opt.yScale==='log';this.pad={{l:92,r:28,t:18,b:62}};const xs=opt.series.flatMap(s=>s.data.map(p=>p[0])),ys=opt.series.flatMap(s=>s.data.map(p=>p[1]));const xr=range(xs,.02,false),yr=range(ys,.08,this.logY);this.init={{x0:xr[0],x1:xr[1],y0:yr[0],y1:yr[1]}};this.view={{...this.init}};this.drag=false;this.pan=false;this.start=null;this.last=null;this.hoverState=null;this.fit=null;this.bind();this.resize()}}
  W(){{return this.box.clientWidth}} H(){{return this.box.clientHeight}}
  yv(y){{return this.logY?log10(Math.max(y,1e-300)):y}} iyv(v){{return this.logY?Math.pow(10,v):v}}
  sx(x){{return this.pad.l+(x-this.view.x0)/(this.view.x1-this.view.x0)*(this.W()-this.pad.l-this.pad.r)}} sy(y){{const y0=this.yv(this.view.y0),y1=this.yv(this.view.y1);return this.H()-this.pad.b-(this.yv(y)-y0)/(y1-y0)*(this.H()-this.pad.t-this.pad.b)}}
  ix(px){{return this.view.x0+(px-this.pad.l)/(this.W()-this.pad.l-this.pad.r)*(this.view.x1-this.view.x0)}} iy(py){{const y0=this.yv(this.view.y0),y1=this.yv(this.view.y1);return this.iyv(y0+(this.H()-this.pad.b-py)/(this.H()-this.pad.t-this.pad.b)*(y1-y0))}}
  inPlot(x,y){{return x>=this.pad.l&&x<=this.W()-this.pad.r&&y>=this.pad.t&&y<=this.H()-this.pad.b}}
  resize(){{const dpr=window.devicePixelRatio||1;this.canvas.width=Math.round(this.W()*dpr);this.canvas.height=Math.round(this.H()*dpr);this.ctx.setTransform(dpr,0,0,dpr,0,0);this.draw()}}
  bind(){{window.addEventListener('resize',()=>this.resize());this.canvas.addEventListener('dblclick',()=>{{this.view={{...this.init}};this.draw()}});this.canvas.addEventListener('wheel',e=>{{e.preventDefault();const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,cx=this.ix(mx),cy=this.iy(my),f=e.deltaY<0?.82:1.22;this.view.x0=cx-(cx-this.view.x0)*f;this.view.x1=cx+(this.view.x1-cx)*f;const y0=this.yv(this.view.y0),y1=this.yv(this.view.y1),yc=this.yv(cy);this.view.y0=this.iyv(yc-(yc-y0)*f);this.view.y1=this.iyv(yc+(y1-yc)*f);this.draw()}});this.canvas.addEventListener('mousedown',e=>{{const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;if(!this.inPlot(mx,my))return;this.drag=true;this.pan=!!e.shiftKey;this.start={{x:mx,y:my}};this.last={{x:e.clientX,y:e.clientY}};if(!this.pan)this.updateSel(mx,my)}});window.addEventListener('mouseup',e=>{{if(!this.drag)return;if(!this.pan&&this.start){{const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,xA=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,this.start.x)),xB=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,mx)),yA=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,this.start.y)),yB=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,my));if(Math.abs(xB-xA)>8&&Math.abs(yB-yA)>8){{this.view={{x0:Math.min(this.ix(xA),this.ix(xB)),x1:Math.max(this.ix(xA),this.ix(xB)),y0:Math.min(this.iy(yA),this.iy(yB)),y1:Math.max(this.iy(yA),this.iy(yB))}};this.draw()}}}}this.drag=false;this.pan=false;this.start=null;this.sel.style.display='none'}});this.canvas.addEventListener('mouseleave',()=>{{tooltip.style.display='none';if(this.hoverState){{this.hoverState=null;this.draw()}}}});this.canvas.addEventListener('mousemove',e=>{{const r=this.canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;if(this.drag&&this.pan){{const dx=e.clientX-this.last.x,dy=e.clientY-this.last.y;this.last={{x:e.clientX,y:e.clientY}};const xs=this.view.x1-this.view.x0,ys=this.yv(this.view.y1)-this.yv(this.view.y0);this.view.x0-=dx/(this.W()-this.pad.l-this.pad.r)*xs;this.view.x1-=dx/(this.W()-this.pad.l-this.pad.r)*xs;const y0=this.yv(this.view.y0)+dy/(this.H()-this.pad.t-this.pad.b)*ys,y1=this.yv(this.view.y1)+dy/(this.H()-this.pad.t-this.pad.b)*ys;this.view.y0=this.iyv(y0);this.view.y1=this.iyv(y1);this.draw();return}}if(this.drag&&!this.pan){{this.updateSel(mx,my);return}}this.hover(e,mx,my)}})}}
  updateSel(mx,my){{const x1=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,this.start.x)),y1=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,this.start.y)),x2=Math.max(this.pad.l,Math.min(this.W()-this.pad.r,mx)),y2=Math.max(this.pad.t,Math.min(this.H()-this.pad.b,my));this.sel.style.left=Math.min(x1,x2)+'px';this.sel.style.top=Math.min(y1,y2)+'px';this.sel.style.width=Math.abs(x2-x1)+'px';this.sel.style.height=Math.abs(y2-y1)+'px';this.sel.style.display='block'}}
  interp(s,xq){{const d=s.data;if(!d||!d.length)return null;let prev=d[0];if(xq<=prev[0])return {{x:prev[0],y:prev[1]}};for(let i=1;i<d.length;i++){{const p=d[i];if(xq<=p[0]){{const t=(xq-prev[0])/((p[0]-prev[0])||1);return {{x:xq,y:prev[1]+(p[1]-prev[1])*t}}}}prev=p}}const last=d[d.length-1];return {{x:last[0],y:last[1]}}}}
  hover(e,mx,my){{if(!this.inPlot(mx,my)){{tooltip.style.display='none';if(this.hoverState){{this.hoverState=null;this.draw()}}return}}const xq=this.ix(mx),rows=[];for(const s of this.opt.series){{const p=this.interp(s,xq);if(!p||!finite(p.y))continue;if(p.y<this.view.y0||p.y>this.view.y1)continue;rows.push({{s,x:p.x,y:p.y}})}}if(!rows.length){{tooltip.style.display='none';if(this.hoverState){{this.hoverState=null;this.draw()}}return}}this.hoverState={{x:xq,rows}};this.draw();tooltip.style.display='block';tooltip.style.left=e.clientX+14+'px';tooltip.style.top=e.clientY+12+'px';const body=rows.map(r=>`<div><b>${{r.s.name}}</b>: ${{this.logY?r.y.toExponential(3):r.y.toFixed(3)}}</div>`).join('');tooltip.innerHTML=`<b>${{this.opt.xLabel}}: ${{xq.toFixed(4)}}</b><br>${{body}}`}}
  drawHover(){{const h=this.hoverState;if(!h)return;const c=this.ctx,x=this.sx(h.x);c.save();c.strokeStyle='#000';c.lineWidth=1;c.setLineDash([4,4]);c.beginPath();c.moveTo(x,this.pad.t);c.lineTo(x,this.H()-this.pad.b);c.stroke();c.setLineDash([]);for(const r of h.rows){{const y=this.sy(r.y);if(!this.inPlot(x,y))continue;c.beginPath();c.arc(x,y,4.5,0,Math.PI*2);c.fillStyle=r.s.color||'#000';c.fill();c.strokeStyle='#000';c.stroke()}}c.restore()}}
  setFit(fit){{this.fit=fit;this.draw()}}
  clearFit(){{this.fit=null;this.draw()}}
  drawFit(){{const f=this.fit;if(!f||!f.data||!f.data.length)return;const c=this.ctx;c.save();c.beginPath();let started=false;for(const p of f.data){{const x=p[0],y=p[1];if(!finite(x)||!finite(y)||x<this.view.x0||x>this.view.x1)continue;const px=this.sx(x),py=this.sy(y);if(!started){{c.moveTo(px,this.sy(f.bgDb));c.lineTo(px,py);started=true}}else c.lineTo(px,py)}}if(started){{for(let i=f.data.length-1;i>=0;i--){{const p=f.data[i],x=p[0];if(!finite(x)||x<this.view.x0||x>this.view.x1)continue;c.lineTo(this.sx(x),this.sy(f.bgDb))}}c.closePath();c.fillStyle='rgba(214,39,40,.12)';c.fill()}}const drawLine=(data,color,width,dash=[])=>{{c.save();c.strokeStyle=color;c.lineWidth=width;c.setLineDash(dash);c.beginPath();let st=false;for(const p of data){{const x=p[0],y=p[1];if(!finite(x)||!finite(y)||x<this.view.x0||x>this.view.x1)continue;const px=this.sx(x),py=this.sy(y);if(!st){{c.moveTo(px,py);st=true}}else c.lineTo(px,py)}}if(st)c.stroke();c.restore()}};drawLine(f.data.map(p=>[p[0],f.bgDb]),'#2ca02c',1.8,[7,5]);drawLine(f.mechData||[],'#1f77b4',1.9,[3,3]);drawLine(f.data,'#d62728',2.5,[]);const x0=this.sx(f.f0);if(finite(x0)){{c.setLineDash([5,4]);c.strokeStyle='#d62728';c.lineWidth=1;c.beginPath();c.moveTo(x0,this.pad.t);c.lineTo(x0,this.H()-this.pad.b);c.stroke()}}c.restore()}}
  draw(){{const c=this.ctx;c.clearRect(0,0,this.W(),this.H());c.fillStyle='#fff';c.fillRect(0,0,this.W(),this.H());c.strokeStyle='#000';c.lineWidth=1.2;c.strokeRect(this.pad.l,this.pad.t,this.W()-this.pad.l-this.pad.r,this.H()-this.pad.t-this.pad.b);const xt=niceTicks(this.view.x0,this.view.x1,6),yt=this.logY?logMajorTicks(this.view.y0,this.view.y1):niceTicks(this.view.y0,this.view.y1,6),ym=this.logY?logMinorTicks(this.view.y0,this.view.y1):[];c.font='14px Arial';if(this.logY){{c.strokeStyle='rgba(0,0,0,.22)';c.lineWidth=.35;for(const v of ym){{const y=this.sy(v);c.beginPath();c.moveTo(this.pad.l,y);c.lineTo(this.W()-this.pad.r,y);c.stroke()}}}}c.strokeStyle='#000';c.lineWidth=.45;c.textAlign='center';c.textBaseline='top';for(const v of xt){{const x=this.sx(v);c.beginPath();c.moveTo(x,this.pad.t);c.lineTo(x,this.H()-this.pad.b);c.stroke();c.fillStyle='#000';c.fillText(tickText(v,this.view.x1-this.view.x0),x,this.H()-this.pad.b+9)}}c.textAlign='right';c.textBaseline='middle';for(const v of yt){{const y=this.sy(v);c.beginPath();c.moveTo(this.pad.l,y);c.lineTo(this.W()-this.pad.r,y);c.stroke();c.fillStyle='#000';c.fillText(this.logY?formatLog(v):tickText(v,this.view.y1-this.view.y0),this.pad.l-9,y)}}c.font='18px Arial';c.textAlign='center';c.textBaseline='bottom';c.fillText(this.opt.xLabel,(this.pad.l+this.W()-this.pad.r)/2,this.H()-10);c.save();c.translate(24,(this.pad.t+this.H()-this.pad.b)/2);c.rotate(-Math.PI/2);c.fillText(this.opt.yLabel,0,0);c.restore();for(const s of this.opt.series){{c.strokeStyle=s.color||'#000';c.lineWidth=s.width||2;c.beginPath();let st=false;for(const p of s.data){{const x=p[0],y=p[1];if(!finite(x)||!finite(y)||(this.logY&&y<=0)||x<this.view.x0||x>this.view.x1)continue;const py=this.sy(y);if(!st){{c.moveTo(this.sx(x),py);st=true}}else c.lineTo(this.sx(x),py)}}c.stroke()}}this.drawFit();this.drawHover()}}
}}
const root=document.getElementById('panels');
function installMechanicalFit(panel,chart){{
  const bar=document.createElement('div');bar.className='fitbar';
  const btn=document.createElement('button');btn.textContent='Fit visible mechanical peak';
  const res=document.createElement('span');res.className='fitResult';res.textContent='zoom to one peak, then fit';
  btn.onclick=()=>{{if(chart.fit){{chart.clearFit();btn.textContent='Fit visible mechanical peak';res.textContent='fit cleared';return}}try{{const fit=fitMechanicalSusceptibilityVisible(chart);chart.setFit(fit);btn.textContent='Clear fit';res.textContent=`f0=${{fit.f0.toFixed(6)}} MHz, Gamma/FWHM~${{(fit.fwhm*1e3).toFixed(2)}} kHz, Q~${{fit.qm.toFixed(0)}}, rms=${{fit.rmseDb.toFixed(2)}} dB`}}catch(err){{res.textContent='fit failed: '+err.message}}}};
  const legend=document.createElement('span');legend.className='fitLegend';legend.innerHTML='<span><i class="swatch" style="border-color:#d62728"></i>total</span><span><i class="swatch" style="border-color:#1f77b4;border-top-style:dashed"></i>mechanical</span><span><i class="swatch" style="border-color:#2ca02c;border-top-style:dashed"></i>background</span>';
  bar.appendChild(btn);bar.appendChild(res);bar.appendChild(legend);panel.insertBefore(bar,panel.querySelector('.box'));
}}
payload.panels.forEach(p=>{{const panel=document.createElement('div');panel.className='panel';panel.innerHTML=`<h2>${{p.title}}</h2><div class="box"><canvas></canvas><div class="selectBox"></div></div>`;root.appendChild(panel);const chart=new Chart(panel.querySelector('canvas'),p);if(p.fitMechanical)installMechanicalFit(panel,chart)}});
</script>
</body>
</html>
"""
    output.write_text(content, encoding="utf-8")


def write_sensitivity_png(output: Path, result: dict[str, np.ndarray], summary: dict[str, Any]) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    freq_mhz = result["frequency_hz"] / 1e6
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 12,
            "axes.labelsize": 13,
            "axes.titlesize": 14,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
        }
    )
    fig, axes = plt.subplots(3, 1, figsize=(8.0, 8.5), sharex=True, constrained_layout=True)
    mode_text = summary.get("optical_mode_text") or "mode not recorded"
    fig.suptitle(f"Optical mode: {mode_text}", fontsize=15)
    axes[0].plot(freq_mhz, result["noise_dbm_per_hz"], color="black", lw=0.9)
    axes[0].set_ylabel("PSD (dBm/Hz)")
    axes[0].set_title("Noise PSD")
    axes[1].plot(freq_mhz, result["response_dbm_per_pa2"], color="black", lw=0.9)
    axes[1].set_ylabel("Response (dBm/Pa$^2$)")
    axes[1].set_title("Acoustic response")
    axes[2].semilogy(freq_mhz, result["sensitivity_pa_per_sqrt_hz"], color="black", lw=0.9)
    axes[2].set_ylabel("NEP (Pa/$\\sqrt{Hz}$)")
    axes[2].set_xlabel("Frequency (MHz)")
    axes[2].set_title(
        f"Sensitivity: median {summary['median_pa_per_sqrt_hz']:.2e}, best {summary['best_pa_per_sqrt_hz']:.2e} Pa/√Hz"
    )
    for ax in axes:
        ax.grid(True, which="both", alpha=0.35)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180)
    plt.close(fig)


def compute_sensitivity_result(
    *,
    run_dir: Path,
    raw_dir: Path,
    processed_dir: Path,
    figures_dir: Path,
    pressure: dict[str, Any],
    requested_settings: dict[str, Any],
    spectrum: dict[str, Any] | None,
    network: dict[str, Any] | None,
) -> dict[str, Any]:
    noise_path = raw_dir / "noise.npz"
    network_path = raw_dir / "network_response.npz"
    if not noise_path.exists():
        spectrum_path = (spectrum or {}).get("path")
        noise_path = Path(str(spectrum_path)) if spectrum_path else run_dir / "noise.npz"
    if not network_path.exists():
        network_path_text = (network or {}).get("path")
        network_path = Path(str(network_path_text)) if network_path_text else run_dir / "network_response.npz"
    if not noise_path.exists() or not network_path.exists():
        raise FileNotFoundError("Sensitivity calculation requires both raw/noise.npz and raw/network_response.npz")

    noise_data = np.load(str(noise_path), allow_pickle=False)
    network_data = np.load(str(network_path), allow_pickle=False)
    noise_freq = np.asarray(noise_data["frequency_hz"], dtype=float)
    noise_psd = np.asarray(noise_data["input1_dbm_per_hz"], dtype=float)
    net_freq = np.asarray(network_data["frequency_hz"], dtype=float)
    net_mag = np.asarray(network_data["magnitude_dbm"], dtype=float)
    net_phase = np.asarray(network_data["phase_deg"], dtype=float)

    requested_pressure = requested_settings.get("pressure") or {}
    use_start = finite_config_float(requested_pressure.get("use_start_hz"), pressure["use_start_hz"]) or pressure["use_start_hz"]
    use_stop = finite_config_float(requested_pressure.get("use_stop_hz"), pressure["use_stop_hz"]) or pressure["use_stop_hz"]
    lo = max(float(use_start), float(np.nanmin(noise_freq)), float(np.nanmin(net_freq)), pressure["start_hz"])
    hi = min(float(use_stop), float(np.nanmax(noise_freq)), float(np.nanmax(net_freq)), pressure["stop_hz"])
    if not hi > lo:
        raise ValueError(f"No overlapping frequency range for sensitivity calculation: {lo:g}..{hi:g} Hz")
    mask = np.isfinite(net_freq) & (net_freq >= lo) & (net_freq <= hi)
    freq = net_freq[mask]
    if len(freq) < 2:
        raise ValueError("Network response has fewer than two points inside pressure calibration range")
    mag = net_mag[mask]
    phase = net_phase[mask]
    noise_interp = finite_interp(freq, noise_freq, noise_psd)
    pressure_interp = finite_interp(freq, pressure["frequency_hz"], pressure["pressure_pa"])
    network_settings = requested_settings.get("network") or {}
    actual_drive_vpk = finite_config_float(network_settings.get("amplitude_vpk"), None)
    if actual_drive_vpk is None:
        actual_drive_vpk = (
            finite_config_float((network or {}).get("amplitude_v"), None)
            or previous_network_amplitude_vpk(run_dir, raw_dir)
            or 1.0
        )
    actual_drive_vpp = actual_drive_vpk * 2.0
    calibration_drive_vpp = float(pressure["calibration_drive_vpp"])
    pressure_scaled = pressure_interp * (actual_drive_vpp / calibration_drive_vpp)
    pressure_quantity = str(pressure["pressure_quantity"]).lower()
    pressure_rms = pressure_scaled if "rms" in pressure_quantity else pressure_scaled / math.sqrt(2.0)
    response_dbm_per_pa2 = mag - 20.0 * np.log10(np.maximum(pressure_rms, 1e-300))
    sensitivity_db = noise_interp - response_dbm_per_pa2
    sensitivity = 10.0 ** (sensitivity_db / 20.0)
    optical_mode = requested_settings.get("optical_mode") if isinstance(requested_settings.get("optical_mode"), dict) else None
    optical_mode_text = compact_optical_mode_text(optical_mode)
    result = {
        "frequency_hz": freq,
        "noise_dbm_per_hz": noise_interp,
        "network_magnitude_dbm": mag,
        "network_phase_deg": phase,
        "pressure_pa_at_calibration_drive": pressure_interp,
        "pressure_pk_pa": pressure_scaled if "rms" not in pressure_quantity else pressure_scaled * math.sqrt(2.0),
        "pressure_rms_pa": pressure_rms,
        "response_dbm_per_pa2": response_dbm_per_pa2,
        "sensitivity_db_pa_per_sqrt_hz": sensitivity_db,
        "sensitivity_pa_per_sqrt_hz": sensitivity,
    }
    processed_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)
    result_npz = processed_dir / "sensitivity_result.npz"
    np.savez(result_npz, **result)

    best_idx = int(np.nanargmin(sensitivity))
    summary = {
        "frequency_start_hz": float(freq[0]),
        "frequency_stop_hz": float(freq[-1]),
        "points": int(len(freq)),
        "median_pa_per_sqrt_hz": float(np.nanmedian(sensitivity)),
        "best_pa_per_sqrt_hz": float(sensitivity[best_idx]),
        "best_frequency_hz": float(freq[best_idx]),
        "median_db_pa_per_sqrt_hz": float(20.0 * np.log10(np.nanmedian(sensitivity))),
        "best_db_pa_per_sqrt_hz": float(20.0 * np.log10(sensitivity[best_idx])),
        "actual_drive_vpp": float(actual_drive_vpp),
        "pressure_calibration_drive_vpp": float(calibration_drive_vpp),
        "pressure_quantity": pressure_quantity,
        "pressure_file": pressure["path"],
        "optical_mode": optical_mode,
        "optical_mode_text": optical_mode_text,
    }
    meta = {
        "run_dir": str(run_dir),
        "raw_noise_npz": str(noise_path),
        "raw_network_npz": str(network_path),
        "result_npz": str(result_npz),
        "pressure": {
            "path": pressure["path"],
            "array_key": pressure["pressure_array_key"],
            "quantity": pressure_quantity,
            "calibration_drive_vpp": calibration_drive_vpp,
            "requested_start_hz": float(use_start),
            "requested_stop_hz": float(use_stop),
        },
        "optical_mode": optical_mode,
        "optical_mode_text": optical_mode_text,
        "summary": summary,
        "formula": {
            "pressure_rms": "pressure_calibrated * actual_drive_vpp / calibration_drive_vpp / sqrt(2) when pressure calibration is peak",
            "response_dbm_per_pa2": "network_magnitude_dbm - 20*log10(pressure_rms_pa)",
            "sensitivity_pa_per_sqrt_hz": "10**((noise_dbm_per_hz - response_dbm_per_pa2)/20)",
        },
    }
    result_json = processed_dir / "sensitivity_result.json"
    result_json.write_text(json.dumps(json_ready(meta), ensure_ascii=False, indent=2), encoding="utf-8")
    result_html = figures_dir / "sensitivity_result.html"
    write_sensitivity_result_html(result_html, result, {**summary, "pressure_file": Path(pressure["path"]).name, "optical_mode_text": optical_mode_text})
    png_path = figures_dir / "sensitivity_summary.png"
    write_sensitivity_png(png_path, result, summary)
    return {
        "ok": True,
        "result_npz": str(result_npz),
        "result_json": str(result_json),
        "result_html": str(result_html),
        "summary_png": str(png_path),
        "summary": summary,
    }


def rel_to(path: Path, base: Path) -> str:
    try:
        return str(path.resolve().relative_to(base.resolve())).replace("\\", "/")
    except Exception:
        return str(path)


def update_sensitivity_latest(
    cavity_dir: Path,
    run_dir: Path,
    sensitivity: dict[str, Any],
    plots: dict[str, str] | None = None,
) -> Path:
    latest_path = cavity_dir / "sensitivity" / "latest.json"
    latest_path.parent.mkdir(parents=True, exist_ok=True)
    plots = plots or {}
    payload = {
        "run_dir": rel_to(run_dir, latest_path.parent),
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "figure_png": rel_to(Path(sensitivity["summary_png"]), cavity_dir),
        "interactive_html": rel_to(Path(sensitivity["result_html"]), cavity_dir),
        "noise_psd_html": rel_to(Path(plots["noise_psd_html"]), cavity_dir) if plots.get("noise_psd_html") else None,
        "network_response_html": rel_to(Path(plots["network_response_html"]), cavity_dir) if plots.get("network_response_html") else None,
        "result_json": rel_to(Path(sensitivity["result_json"]), cavity_dir),
        "result_npz": rel_to(Path(sensitivity["result_npz"]), cavity_dir),
        "summary": sensitivity.get("summary", {}),
    }
    latest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return latest_path


def sensitivity_summary_text(summary: dict[str, Any]) -> str:
    if not summary:
        return "measured"
    median = summary.get("median_pa_per_sqrt_hz")
    best = summary.get("best_pa_per_sqrt_hz")
    best_freq = summary.get("best_frequency_hz")
    mode_text = summary.get("optical_mode_text")
    if median is None or best is None or best_freq is None:
        return "measured"
    prefix = f"{mode_text}; " if mode_text and mode_text != "mode not recorded" else ""
    return f"{prefix}median {median:.2e} Pa/sqrtHz; best {best:.2e} @ {best_freq/1e3:.1f} kHz"


def refresh_card_for_sensitivity(cavity_dir_text: str | None, summary: dict[str, Any]) -> dict[str, Any] | None:
    if not cavity_dir_text:
        return None
    context = infer_cavity_context(cavity_dir_text)
    command = [
        package_python_executable(),
        str(DEFAULT_CARD_SCRIPT),
        "--chip",
        context["chip"],
        "--die",
        context["die"],
        "--cavity",
        context["cavity"],
        "--results-root",
        str(context["results_root"]),
        "--sensitivity",
        sensitivity_summary_text(summary),
    ]
    return run_script(command, timeout_s=60.0)


def start_sensitivity_job(mode: str, tag_prefix: str, base: str) -> bool:
    with ACTIVE_SENSITIVITY_LOCK:
        if ACTIVE_SENSITIVITY.get("running"):
            return False
        ACTIVE_SENSITIVITY.update(
            {
                "running": True,
                "cancel_requested": False,
                "started_at": time.time(),
                "mode": mode,
                "tag_prefix": tag_prefix,
                "bridge_base": base,
            }
        )
        return True


def finish_sensitivity_job() -> None:
    with ACTIVE_SENSITIVITY_LOCK:
        ACTIVE_SENSITIVITY.update({"running": False})


def sensitivity_cancel_requested() -> bool:
    with ACTIVE_SENSITIVITY_LOCK:
        return bool(ACTIVE_SENSITIVITY.get("cancel_requested"))


def check_sensitivity_cancelled() -> None:
    if sensitivity_cancel_requested():
        raise SensitivityCancelled("sensitivity acquisition cancelled by user")


def sensitivity_status() -> dict[str, Any]:
    with ACTIVE_SENSITIVITY_LOCK:
        status = dict(ACTIVE_SENSITIVITY)
    started = status.get("started_at")
    status["elapsed_s"] = time.time() - started if status.get("running") and started else None
    return {"ok": True, "sensitivity_acquisition": status}


def cancel_sensitivity_acquisition(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    config = instrument_config_from_mapping(body, args)
    with ACTIVE_SENSITIVITY_LOCK:
        was_running = bool(ACTIVE_SENSITIVITY.get("running"))
        ACTIVE_SENSITIVITY["cancel_requested"] = True
        base = str(ACTIVE_SENSITIVITY.get("bridge_base") or config["bridge_base"]).rstrip("/")
    stop_result = None
    if config["rp_type"] != "none":
        try:
            stop_result = bridge_query(base, "/acquisition/stop", {}, timeout=2.0)
        except Exception as exc:
            stop_result = {"ok": False, "error": repr(exc)}
    return {
        "ok": True,
        "message": "cancel requested" if was_running else "no active sensitivity acquisition",
        "was_running": was_running,
        "bridge_stop": stop_result,
        **sensitivity_status(),
    }


def run_sensitivity_acquisition(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    config = instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("Sensitivity acquisition requires RP / PyRPL bridge")
    base = config["bridge_base"].rstrip("/")
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    tag_prefix = safe_tag_text(body.get("tag_prefix"), "sensitivity")
    mode = str(body.get("acquisition_mode") or "both").strip().lower()
    if mode not in {"psd", "network", "both", "compute"}:
        raise ValueError(f"Unknown sensitivity acquisition mode: {mode}")
    spectrum_timeout = finite_config_float(body.get("spectrum_timeout_s"), 30.0) or 30.0
    network_timeout = finite_config_float(body.get("network_timeout_s"), 600.0) or 600.0
    max_points = int(finite_config_float(body.get("max_points"), 1500.0) or 1500)
    acquire = bool_from_config(body.get("acquire"), True)
    requested_settings = sensitivity_requested_settings(body)
    pressure = pressure_calibration_from_body(body, args)
    if not start_sensitivity_job(mode, tag_prefix, base):
        return {
            "ok": False,
            "message": "another sensitivity acquisition is already active",
            **sensitivity_status(),
        }
    try:
        if mode == "compute":
            cavity_text = str(body.get("cavity_dir") or "").strip()
            if not cavity_text:
                raise ValueError("Compute-only sensitivity requires a selected cavity directory with previous raw data")
            cavity_dir = Path(cavity_text).expanduser()
            latest_run = latest_sensitivity_run_dir(cavity_dir)
            if latest_run is None:
                raise FileNotFoundError(f"No previous sensitivity raw data found under {cavity_dir / 'sensitivity'}")
            run_dir, no_cavity_dir, cavity_dir_text = latest_run, False, str(cavity_dir)
        else:
            run_dir, no_cavity_dir, cavity_dir_text = resolve_sensitivity_run_dir(body, tag_prefix, timestamp)
        raw_dir = run_dir / "raw"
        processed_dir = run_dir / "processed"
        figures_dir = run_dir / "figures"
        run_dir.mkdir(parents=True, exist_ok=True)
        raw_dir.mkdir(parents=True, exist_ok=True)
        figures_dir.mkdir(parents=True, exist_ok=True)

        started = time.time()
        steps: list[dict[str, Any]] = []
        spectrum: dict[str, Any] | None = None
        network: dict[str, Any] | None = None
        applied_settings = {"ok": True, "steps": []}
        if mode != "compute":
            check_sensitivity_cancelled()
            applied_settings = apply_sensitivity_settings(base, mode, requested_settings)
            check_sensitivity_cancelled()
            steps.append({"name": "apply_settings", "ok": bool(applied_settings.get("ok")), "result": applied_settings})
            if not applied_settings.get("ok"):
                run_payload = {
                    "ok": False,
                    "message": "instrument parameter update failed; acquisition was not run",
                    "elapsed_s": time.time() - started,
                    "acquisition_mode": mode,
                    "tag_prefix": tag_prefix,
                    "timestamp": timestamp,
                    "output_dir": str(run_dir),
                    "cavity_dir": cavity_dir_text,
                    "no_cavity_dir": no_cavity_dir,
                    "requested_settings": requested_settings,
                    "applied_settings": applied_settings,
                    "pressure_calibration": {k: v for k, v in pressure.items() if k not in {"frequency_hz", "pressure_pa"}},
                    "steps": steps,
                }
                run_json = run_dir / "run.json"
                run_payload["run_json_path"] = str(run_json)
                run_json.write_text(json.dumps(run_payload, ensure_ascii=False, indent=2), encoding="utf-8")
                return run_payload

            if mode in {"psd", "both"}:
                check_sensitivity_cancelled()
                spectrum = bridge_query(
                    base,
                    "/spectrum/single",
                    {
                        "tag": "noise",
                        "timeout": spectrum_timeout,
                        "save": "true",
                        "save_csv": "false",
                        "inline": "false",
                        "acquire": "true" if acquire else "false",
                        "max_points": max_points,
                        "output_dir": str(raw_dir),
                    },
                    timeout=max(20.0, spectrum_timeout + 15.0),
                )
                check_sensitivity_cancelled()
                spectrum["path"] = copy_to_subdir_if_needed(spectrum.get("path"), raw_dir, "noise.npz")
                spectrum["metadata_path"] = copy_to_subdir_if_needed(spectrum.get("metadata_path"), raw_dir, "noise.json")
                steps.append({"name": "spectrum_noise", "ok": bool(spectrum.get("ok")), "result": spectrum})
                if mode == "both" and not spectrum.get("ok"):
                    run_payload = {
                        "ok": False,
                        "message": "spectrum acquisition failed; network analyzer was not run",
                        "elapsed_s": time.time() - started,
                        "acquisition_mode": mode,
                        "tag_prefix": tag_prefix,
                        "timestamp": timestamp,
                        "output_dir": str(run_dir),
                        "raw_dir": str(raw_dir),
                        "cavity_dir": cavity_dir_text,
                        "no_cavity_dir": no_cavity_dir,
                        "requested_settings": requested_settings,
                        "applied_settings": applied_settings,
                        "pressure_calibration": {k: v for k, v in pressure.items() if k not in {"frequency_hz", "pressure_pa"}},
                        "steps": steps,
                    }
                    run_json = run_dir / "run.json"
                    run_json.write_text(json.dumps(run_payload, ensure_ascii=False, indent=2), encoding="utf-8")
                    run_payload["run_json_path"] = str(run_json)
                    return run_payload

            if mode in {"network", "both"}:
                check_sensitivity_cancelled()
                network = bridge_query(
                    base,
                    "/networkanalyzer/single",
                    {
                        "tag": "network_response",
                        "timeout": network_timeout,
                        "save": "true",
                        "inline": "false",
                        "acquire": "true" if acquire else "false",
                        "max_points": max_points,
                        "output_dir": str(raw_dir),
                    },
                    timeout=max(30.0, network_timeout + 15.0),
                )
                check_sensitivity_cancelled()
                network["path"] = copy_to_subdir_if_needed(network.get("path"), raw_dir, "network_response.npz")
                network["metadata_path"] = copy_to_subdir_if_needed(network.get("metadata_path"), raw_dir, "network_response.json")
                steps.append({"name": "network_response", "ok": bool(network.get("ok")), "result": network})

        check_sensitivity_cancelled()
        plots = write_sensitivity_preview_plots(
            run_dir=figures_dir,
            tag_prefix=tag_prefix,
            timestamp=timestamp,
            spectrum=spectrum,
            network=network,
            max_points=max_points,
        )
        sensitivity: dict[str, Any] | None = None
        sensitivity_error: str | None = None
        if mode == "both" or mode == "compute":
            try:
                check_sensitivity_cancelled()
                sensitivity = compute_sensitivity_result(
                    run_dir=run_dir,
                    raw_dir=raw_dir,
                    processed_dir=processed_dir,
                    figures_dir=figures_dir,
                    pressure=pressure,
                    requested_settings=requested_settings,
                    spectrum=spectrum,
                    network=network,
                )
                plots["sensitivity_html"] = sensitivity["result_html"]
                plots["sensitivity_png"] = sensitivity["summary_png"]
                steps.append({"name": "compute_sensitivity", "ok": True, "result": sensitivity})
                if cavity_dir_text:
                    latest_path = update_sensitivity_latest(Path(cavity_dir_text), run_dir, sensitivity, plots)
                    card_result = refresh_card_for_sensitivity(cavity_dir_text, sensitivity.get("summary", {}))
                    steps.append(
                        {
                            "name": "refresh_sensitivity_card",
                            "ok": bool(card_result.get("ok")) if card_result else False,
                            "latest_path": str(latest_path),
                            "result": card_result,
                        }
                    )
            except SensitivityCancelled:
                raise
            except Exception as exc:
                sensitivity_error = repr(exc)
                steps.append({"name": "compute_sensitivity", "ok": False, "error": sensitivity_error})
        ok = all(bool(step.get("ok")) for step in steps)
        message_by_mode = {
            "psd": "sensitivity acquisition finished: noise PSD",
            "network": "sensitivity acquisition finished: network response",
            "both": "sensitivity acquisition finished: noise PSD + network response + sensitivity",
            "compute": "sensitivity recomputed from existing raw data",
        }
        run_payload = {
            "ok": ok,
            "message": message_by_mode[mode],
            "elapsed_s": time.time() - started,
            "acquisition_mode": mode,
            "tag_prefix": tag_prefix,
            "timestamp": timestamp,
            "output_dir": str(run_dir),
            "raw_dir": str(raw_dir),
            "processed_dir": str(processed_dir),
            "figures_dir": str(figures_dir),
            "cavity_dir": cavity_dir_text,
            "no_cavity_dir": no_cavity_dir,
            "requested_settings": requested_settings,
            "applied_settings": applied_settings,
            "pressure_calibration": {k: v for k, v in pressure.items() if k not in {"frequency_hz", "pressure_pa"}},
            "spectrum": {
                "raw_path": spectrum.get("path"),
                "metadata_path": spectrum.get("metadata_path"),
                "rbw_hz": spectrum.get("rbw_hz"),
                "n": spectrum.get("n"),
                "display_power_correction": spectrum.get("display_power_correction"),
                "summary": spectrum.get("summary", {}),
                "plot_html": plots.get("noise_psd_html"),
            } if spectrum else None,
            "network": {
                "raw_path": network.get("path"),
                "metadata_path": network.get("metadata_path"),
                "n": network.get("n"),
                "input": network.get("input"),
                "output_direct": network.get("output_direct"),
                "amplitude_v": network.get("amplitude_v"),
                "amplitude_unit": network.get("amplitude_unit"),
                "power_display": network.get("power_display"),
                "summary": network.get("summary", {}),
                "plot_html": plots.get("network_response_html"),
            } if network else None,
            "sensitivity": {
                "error": sensitivity_error,
                **(sensitivity or {}),
            } if (sensitivity or sensitivity_error) else None,
            "plots": plots,
            "steps": steps,
        }
        run_json = run_dir / ("compute_latest.json" if mode == "compute" else "run.json")
        run_payload["run_json_path"] = str(run_json)
        run_json.write_text(json.dumps(run_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return run_payload
    except SensitivityCancelled as exc:
        return {
            "ok": False,
            "cancelled": True,
            "message": str(exc),
            "acquisition_mode": mode,
            "tag_prefix": tag_prefix,
            "timestamp": timestamp,
        }
    finally:
        finish_sensitivity_job()


def normalize_rp_host(host: str) -> str:
    return host.strip().rstrip(".").lower()


def rp_host_default_external_gain_db(host: str) -> float:
    normalized = normalize_rp_host(host)
    if normalized in {"rp-f0cb0d", "rp-f0cb0d.local", "192.168.1.21"}:
        return DEFAULT_RP_F0CB0D_EXTERNAL_GAIN_DB
    return float(os.environ.get("SPECTRUM_EXTERNAL_GAIN_DB", "0") or 0)


def check_rp_host_resolution(host: str) -> dict[str, Any]:
    if not host.strip():
        return {"ok": False, "error": "RP host is empty"}
    try:
        infos = socket.getaddrinfo(host, None)
    except Exception as exc:
        return {
            "ok": False,
            "host": host,
            "error": repr(exc),
            "hint": "If .local resolves through a virtual adapter, try the bare hostname such as RP-f0cb0d.",
        }

    addresses: list[dict[str, Any]] = []
    seen: set[tuple[int, str]] = set()
    for family, _type, _proto, _canon, sockaddr in infos:
        address = str(sockaddr[0])
        key = (family, address)
        if key in seen:
            continue
        seen.add(key)
        addresses.append(
            {
                "family": "IPv4" if family == socket.AF_INET else "IPv6" if family == socket.AF_INET6 else str(family),
                "address": address,
            }
        )
    warnings = []
    if host.lower().endswith(".local") and any(item["address"].startswith("198.18.") for item in addresses):
        warnings.append("This .local name resolved to a 198.18.x.x virtual-adapter address; use RP-f0cb0d instead.")
    return {
        "ok": bool(addresses),
        "host": host,
        "addresses": addresses,
        "warnings": warnings,
        "external_gain_db_if_started": rp_host_default_external_gain_db(host),
    }


def bridge_runtime_status(bridge_base: str) -> dict[str, Any]:
    with ACTIVE_BRIDGE_LOCK:
        proc = ACTIVE_BRIDGE.get("proc")
        started_at = ACTIVE_BRIDGE.get("started_at")
        command = ACTIVE_BRIDGE.get("command")
        host = ACTIVE_BRIDGE.get("rp_host")
        pyrpl_host = ACTIVE_BRIDGE.get("pyrpl_host")
        external_gain_db = ACTIVE_BRIDGE.get("external_gain_db")
        device_profile = ACTIVE_BRIDGE.get("device_profile")
        headless = ACTIVE_BRIDGE.get("headless")
        log_path = ACTIVE_BRIDGE.get("log_path")
        python_executable = ACTIVE_BRIDGE.get("python_executable")
    process = {
        "managed": proc is not None,
        "running": bool(proc is not None and proc.poll() is None),
        "pid": proc.pid if proc is not None else None,
        "returncode": proc.poll() if proc is not None else None,
        "rp_host": host,
        "pyrpl_host": pyrpl_host,
        "external_gain_db": external_gain_db,
        "device_profile": device_profile,
        "headless": headless,
        "python_executable": python_executable,
        "elapsed_s": time.time() - float(started_at) if started_at else None,
        "command": command,
        "log_path": str(log_path) if log_path else None,
        "log_tail": read_text_tail(log_path),
    }
    try:
        health = request_json(f"{bridge_base.rstrip('/')}/health", timeout=1.5)
        http_ok = bool(health.get("ok"))
    except Exception as exc:
        health = {"ok": False, "error": repr(exc)}
        http_ok = False
    return {"ok": http_ok, "bridge_base": bridge_base, "process": process, "health": health}


def stop_managed_bridge(bridge_base: str) -> dict[str, Any]:
    with ACTIVE_BRIDGE_LOCK:
        proc = ACTIVE_BRIDGE.get("proc")
        host = ACTIVE_BRIDGE.get("rp_host")
    if proc is None or proc.poll() is not None:
        return {"ok": True, "message": "no live dashboard-managed bridge"}
    return stop_target_bridge(bridge_base, host)


def stop_target_bridge(bridge_base: str, rp_host: str) -> dict[str, Any]:
    from a221_workbench.tasks.redpitaya.restart_bridge import stop_bridge
    result = stop_bridge(rp_host, bridge_url=bridge_base)
    if result['ok']:
        with ACTIVE_BRIDGE_LOCK:
            proc = ACTIVE_BRIDGE.get('proc')
            if proc is not None and proc.poll() is not None:
                ACTIVE_BRIDGE['proc'] = None
    return result


def start_or_restart_bridge(config: dict[str, str], args: argparse.Namespace, *,
                            headless: bool = True, _require_idle: bool = False) -> dict[str, Any]:
    """Dashboard parameter adapter for the shared explicit restart task."""
    from a221_workbench.tasks.redpitaya.restart_bridge import restart_bridge
    if config["rp_type"] == "none":
        return {"ok": False, "error": "RP / PyRPL is set to none"}
    profile = getattr(args, 'device_profile', {}) or {}
    gain = profile.get('spectrum_external_gain_db')
    gain = float(gain) if gain is not None else rp_host_default_external_gain_db(config['rp_host'])
    display = {
        'loglevel': os.environ.get('PYRPL_BRIDGE_LOGLEVEL', 'debug'),
        'spectrum-load-ohm': os.environ.get('SPECTRUM_LOAD_OHM', '50'),
        'spectrum-power-correction-enabled': os.environ.get('SPECTRUM_POWER_CORRECTION_ENABLED', 'true'),
        'spectrum-highz-correction-db': os.environ.get('SPECTRUM_HIGHZ_CORRECTION_DB', '6.0206'),
        'spectrum-external-gain-db': f'{gain:g}',
        'scope-ch1-response-v-per-w': f"{float(profile.get('scope_ch1_response_v_per_w', 3.22013e3)):g}",
        'scope-ch2-response-v-per-w': f"{float(profile.get('scope_ch2_response_v_per_w', 3.22013e3)):g}",
        'scope-zero-enabled': 'true' if profile.get('scope_zero_enabled') else 'false',
        'scope-ch1-zero-offset-v': f"{float(profile.get('scope_ch1_zero_offset_v') or 0.):g}",
        'scope-ch2-zero-offset-v': f"{float(profile.get('scope_ch2_zero_offset_v') or 0.):g}",
    }

    def remember(proc, started):
        with ACTIVE_BRIDGE_LOCK:
            ACTIVE_BRIDGE.update(proc=proc, command=started['command'], log_path=started['log_path'],
                                 started_at=time.time(), rp_host=config['rp_host'],
                                 pyrpl_host=started['address'], external_gain_db=gain,
                                 device_profile=profile, headless=headless,
                                 python_executable=started['command'][0])

    result = restart_bridge(config['rp_host'], bridge_url=config['bridge_base'],
                            python=package_python_executable(), state_dir=bridge_log_dir() / 'restarts',
                            timeout_s=min(300., bridge_ready_timeout_s()), headless=headless,
                            display_options=display, _on_started=remember, _require_idle=_require_idle)
    result.update(action='start_restart_bridge', headless=headless, external_gain_db=gain,
                  device_profile=profile, status=bridge_runtime_status(config['bridge_base']),
                  log_tail=read_text_tail(result.get('log_path')))
    return result


def ensure_bridge_for_dashboard(config: dict[str, str], args: argparse.Namespace, *, headless=True):
    """Automatic panel opening reuses a live bridge; only a user restart replaces it."""
    from a221_workbench.instruments.redpitaya.device import RedPitaya
    status = bridge_runtime_status(config['bridge_base'])
    if status['ok']:
        try:
            RedPitaya(config['rp_host'], bridge_url=config['bridge_base']).connect()
            return dict(ok=True, action='use_existing_bridge', message='using the live bridge', status=status)
        except Exception as exc:
            return dict(ok=False, error=str(exc), message='Existing bridge needs explicit restart', status=status)
    return start_or_restart_bridge(config, args, headless=headless, _require_idle=True)


def run_bridge_action(body: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    config = instrument_config_from_mapping(body, args)
    action = str(body.get("bridge_action") or "refresh_bridge_status")
    if action == "check_rp_host":
        host_check = check_rp_host_resolution(config["rp_host"])
        device_profile = getattr(args, "device_profile", {})
        if device_profile.get("spectrum_external_gain_db") is not None:
            host_check["external_gain_db_if_started"] = device_profile["spectrum_external_gain_db"]
            host_check["external_gain_source"] = device_profile.get("spectrum_external_gain_source")
        return {
            "ok": bool(host_check.get("ok")),
            "action": action,
            "host_check": host_check,
            "device_profile": device_profile,
        }
    if action == "start_restart_bridge":
        return start_or_restart_bridge(config, args, headless=True)
    if action == "start_restart_bridge_gui":
        return start_or_restart_bridge(config, args, headless=False)
    if action == "stop_bridge":
        result = stop_managed_bridge(config["bridge_base"])
        return {"ok": bool(result.get("ok")), "action": action, **result}
    if action == "stop_any_bridge":
        result = stop_target_bridge(config["bridge_base"], config["rp_host"])
        return {"ok": bool(result.get("ok")), "action": action, **result}
    if action == "refresh_bridge_status":
        status = bridge_runtime_status(config["bridge_base"])
        return {
            "ok": bool(status.get("ok")),
            "action": action,
            "status": status,
            "device_profile": getattr(args, "device_profile", {}),
        }
    raise ValueError(f"Unknown bridge action: {action}")


def load_acquire_module() -> Any:
    from a221_workbench.tasks.large_scan import acquire_large_scan
    return acquire_large_scan


def load_acquire_helpers() -> tuple[Any, Any]:
    module = load_acquire_module()
    return module.TopticaDlcPro, module.RohdeSchwarzRte


def read_large_scan_initial_wavelength(
    *,
    laser_connection: str,
    laser_port: str,
    laser_host: str,
    toptica_python: str,
) -> dict[str, Any]:
    try:
        acquire_module = load_acquire_module()
        laser = acquire_module.create_laser(
            laser_connection,
            laser_port,
            laser_host=laser_host,
            toptica_python=toptica_python,
        )
        try:
            return {
                "ok": True,
                "connection": laser_connection,
                "host": laser_host if laser_connection == "tcp" else "",
                "port": laser_port if laser_connection == "serial" else "",
                "wavelength_nm": laser.wavelength_nm(),
            }
        finally:
            laser.close()
    except Exception as exc:
        return {"ok": False, "connection": laser_connection, "error": repr(exc), "wavelength_nm": None}


def terminate_process_tree(proc: subprocess.Popen) -> dict[str, Any]:
    if proc.poll() is not None:
        return {"ok": True, "message": "large-scan process already exited", "returncode": proc.returncode}
    try:
        taskkill = subprocess.run(
            ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
            text=True,
            capture_output=True,
            timeout=10.0,
            check=False,
        )
        return {
            "ok": taskkill.returncode == 0 or proc.poll() is not None,
            "pid": proc.pid,
            "taskkill_returncode": taskkill.returncode,
            "stdout_tail": taskkill.stdout[-1200:],
            "stderr_tail": taskkill.stderr[-1200:],
        }
    except Exception as exc:
        try:
            proc.terminate()
        except Exception:
            pass
        return {"ok": False, "pid": proc.pid, "error": repr(exc)}


def restore_large_scan_idle(
    base: str,
    restore_wavelength_nm: float | None,
    *,
    laser_connection: str,
    laser_port: str,
    laser_host: str,
    toptica_python: str,
    scope_type: str,
    scope_resource: str,
) -> dict[str, Any]:
    steps: list[dict[str, Any]] = []

    steps.append({"name": "rp_safe_off", **safe_off(base)})

    try:
        acquire_module = load_acquire_module()
    except Exception as exc:
        steps.append({"name": "load_acquire_helpers", "ok": False, "error": repr(exc)})
        return {"ok": False, "steps": steps}

    try:
        laser = acquire_module.create_laser(
            laser_connection,
            laser_port,
            laser_host=laser_host,
            toptica_python=toptica_python,
        )
        try:
            try:
                laser.stop_wide_scan()
                steps.append({"name": "wide_scan_stop", "ok": True})
            except Exception as exc:
                steps.append({"name": "wide_scan_stop", "ok": False, "error": repr(exc)})

            if restore_wavelength_nm is not None:
                try:
                    laser.move_to_wavelength(float(restore_wavelength_nm), timeout_s=45.0)
                    steps.append(
                        {
                            "name": "restore_wavelength",
                            "ok": True,
                            "target_nm": restore_wavelength_nm,
                            "readback_nm": laser.wavelength_nm(),
                        }
                    )
                except Exception as exc:
                    steps.append(
                        {
                            "name": "restore_wavelength",
                            "ok": False,
                            "target_nm": restore_wavelength_nm,
                            "error": repr(exc),
                        }
                    )
            else:
                steps.append({"name": "restore_wavelength", "ok": False, "error": "initial wavelength unavailable"})

            try:
                laser.set_pc_voltage_v(75.0)
                steps.append({"name": "pc_voltage", "ok": True, "target_v": 75.0, "readback_v": laser.pc_voltage_act_v()})
            except Exception as exc:
                steps.append({"name": "pc_voltage", "ok": False, "target_v": 75.0, "error": repr(exc)})

            try:
                laser.configure_fine_scan_arc_factor(25.0)
                steps.append({"name": "fine_scan_arc", "ok": True, "factor_v_per_v": 25.0})
            except Exception as exc:
                steps.append({"name": "fine_scan_arc", "ok": False, "factor_v_per_v": 25.0, "error": repr(exc)})
        finally:
            laser.close()
    except Exception as exc:
        steps.append({"name": "toptica_restore", "ok": False, "error": repr(exc)})

    try:
        restored = restore_lock_sweep(base)
        steps.append({"name": "rp_restore_lock_sweep", "ok": bool(restored.get("ok")), "result": restored})
    except Exception as exc:
        steps.append({"name": "rp_restore_lock_sweep", "ok": False, "error": repr(exc)})

    try:
        scope = acquire_module.create_scope(scope_type, scope_resource)
        try:
            scope.configure_fine_scan_idle(
                trigger_channel=DEFAULT_FINE_TRIGGER_CHANNEL,
                trigger_level_v=DEFAULT_FINE_TRIGGER_LEVEL_V,
                trigger_slope=DEFAULT_FINE_TRIGGER_SLOPE,
                trigger_mode=DEFAULT_FINE_TRIGGER_MODE,
                horizontal_delay_s=DEFAULT_FINE_HORIZONTAL_DELAY_S,
            )
            steps.append(
                {
                    "name": "scope_fine_scan_idle",
                    "ok": True,
                    "trigger_channel": DEFAULT_FINE_TRIGGER_CHANNEL,
                    "trigger_level_v": DEFAULT_FINE_TRIGGER_LEVEL_V,
                    "trigger_slope": DEFAULT_FINE_TRIGGER_SLOPE,
                    "horizontal_delay_s": DEFAULT_FINE_HORIZONTAL_DELAY_S,
                    "trigger_source": "RP OUT1 via pid1(asg0)",
                }
            )
        finally:
            scope.close()
    except Exception as exc:
        steps.append({"name": "scope_fine_scan_idle", "ok": False, "warning": repr(exc)})

    critical_steps = [step for step in steps if "warning" not in step]
    return {"ok": all(bool(step.get("ok")) for step in critical_steps), "steps": steps}


def run_large_scan_script(
    command: list[str],
    timeout_s: float,
    bridge_base: str,
    *,
    laser_connection: str,
    laser_port: str,
    laser_host: str,
    toptica_python: str,
    scope_type: str,
    scope_resource: str,
) -> dict[str, Any]:
    started = time.time()
    with ACTIVE_LARGE_SCAN_LOCK:
        active = ACTIVE_LARGE_SCAN.get("proc")
        if active is not None and active.poll() is None:
            return {"ok": False, "error": "another large-scan process is already active"}
    initial = read_large_scan_initial_wavelength(
        laser_connection=laser_connection,
        laser_port=laser_port,
        laser_host=laser_host,
        toptica_python=toptica_python,
    )
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform.startswith("win") else 0
    proc = subprocess.Popen(
        command,
        cwd=REPO_ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=creationflags,
    )
    with ACTIVE_LARGE_SCAN_LOCK:
        ACTIVE_LARGE_SCAN.update(
            {
                "proc": proc,
                "command": command,
                "started_at": started,
                "initial_wavelength_nm": initial.get("wavelength_nm"),
                "initial_read": initial,
            }
        )
    try:
        try:
            stdout, stderr = proc.communicate(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            stop = terminate_process_tree(proc)
            stdout, stderr = proc.communicate(timeout=5.0)
            restore = restore_large_scan_idle(
                bridge_base,
                initial.get("wavelength_nm"),
                laser_connection=laser_connection,
                laser_port=laser_port,
                laser_host=laser_host,
                toptica_python=toptica_python,
                scope_type=scope_type,
                scope_resource=scope_resource,
            )
            return {
                "ok": False,
                "error": "large scan timed out; process was terminated and restore was attempted",
                "elapsed_s": time.time() - started,
                "command": command,
                "stop": stop,
                "restore": restore,
                "stdout_tail": stdout[-4000:],
                "stderr_tail": stderr[-4000:],
            }
        parsed = parse_script_json(stdout)
        if proc.returncode == 0 and bool(parsed is None or parsed.get("ok", True)):
            # Acquisition already restored TOPTICA and the VISA scope. The
            # dashboard owns only its additional RP sweep on normal completion.
            try:
                rp_result = restore_lock_sweep(bridge_base)
                restore = {"ok": bool(rp_result.get("ok")), "acquisition_restore": "completed_by_scan",
                           "steps": [{"name": "rp_restore_lock_sweep", "result": rp_result}]}
            except Exception as exc:
                restore = {"ok": False, "error": repr(exc)}
        else:
            restore = restore_large_scan_idle(
                bridge_base,
                initial.get("wavelength_nm"),
                laser_connection=laser_connection,
                laser_port=laser_port,
                laser_host=laser_host,
                toptica_python=toptica_python,
                scope_type=scope_type,
                scope_resource=scope_resource,
            )
        return {
            "ok": proc.returncode == 0 and bool(parsed is None or parsed.get("ok", True)),
            "returncode": proc.returncode,
            "elapsed_s": time.time() - started,
            "command": command,
            "initial_read": initial,
            "restore": restore,
            "json": parsed,
            "stdout_tail": stdout[-4000:],
            "stderr_tail": stderr[-4000:],
        }
    finally:
        with ACTIVE_LARGE_SCAN_LOCK:
            if ACTIVE_LARGE_SCAN.get("proc") is proc:
                ACTIVE_LARGE_SCAN.update({"proc": None})


def stop_large_scan_and_restore(
    base: str,
    *,
    laser_connection: str,
    laser_port: str,
    laser_host: str,
    toptica_python: str,
    scope_type: str,
    scope_resource: str,
) -> dict[str, Any]:
    with ACTIVE_LARGE_SCAN_LOCK:
        proc = ACTIVE_LARGE_SCAN.get("proc")
        restore_wavelength_nm = ACTIVE_LARGE_SCAN.get("initial_wavelength_nm")
        command = ACTIVE_LARGE_SCAN.get("command")
        started_at = ACTIVE_LARGE_SCAN.get("started_at")
    if proc is None or proc.poll() is not None:
        restore = restore_large_scan_idle(
            base,
            restore_wavelength_nm,
            laser_connection=laser_connection,
            laser_port=laser_port,
            laser_host=laser_host,
            toptica_python=toptica_python,
            scope_type=scope_type,
            scope_resource=scope_resource,
        )
        return {
            "ok": bool(restore.get("ok")),
            "json": {
                "message": "no active large-scan process; restore attempted",
                "restore": restore,
                "initial_wavelength_nm": restore_wavelength_nm,
            },
        }

    stop = terminate_process_tree(proc)
    time.sleep(0.5)
    restore = restore_large_scan_idle(
        base,
        restore_wavelength_nm,
        laser_connection=laser_connection,
        laser_port=laser_port,
        laser_host=laser_host,
        toptica_python=toptica_python,
        scope_type=scope_type,
        scope_resource=scope_resource,
    )
    with ACTIVE_LARGE_SCAN_LOCK:
        if ACTIVE_LARGE_SCAN.get("proc") is proc:
            ACTIVE_LARGE_SCAN.update({"proc": None})
    return {
        "ok": bool(stop.get("ok")) and bool(restore.get("ok")),
        "json": {
            "message": "large scan stopped; restore attempted",
            "command": command,
            "elapsed_s": time.time() - float(started_at or time.time()),
            "initial_wavelength_nm": restore_wavelength_nm,
            "stop": stop,
            "restore": restore,
        },
    }


VALID_Q_SUBDIRS = {"Q", "Q'"}


def normalize_q_subdir(value: object) -> str:
    q_subdir = str(value or "Q").strip()
    if q_subdir not in VALID_Q_SUBDIRS:
        raise ValueError(f"q_subdir must be one of {sorted(VALID_Q_SUBDIRS)!r}, got {q_subdir!r}")
    return q_subdir


def resolve_q_dir(cavity_dir: Path, q_subdir: object = "Q") -> Path:
    selected = cavity_dir / normalize_q_subdir(q_subdir)
    if selected.exists() or cavity_dir.name in VALID_Q_SUBDIRS:
        return selected if selected.exists() else cavity_dir
    return cavity_dir


def load_cavity(cavity_dir_text: str, q_subdir: object = "Q") -> dict[str, Any]:
    cavity_dir = Path(cavity_dir_text).expanduser()
    q_dir = resolve_q_dir(cavity_dir, q_subdir)
    manifest_path = q_dir / "best_lock_candidate.json"
    q_table = q_dir / "q_by_mode.csv"
    manifest: dict[str, Any] | None = None
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    rows: list[dict[str, Any]] = []
    if q_table.exists():
        with q_table.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                if row.get("fit_status") != "ok":
                    continue
                wavelength = finite_float(row.get("wavelength_nm"))
                q0 = finite_float(row.get("Q0"))
                if wavelength is None:
                    continue
                rows.append(
                    {
                        "family": row.get("family", ""),
                        "family_label": row.get("family_label", row.get("family", "")),
                        "mode_number": row.get("mode_number", ""),
                        "wavelength_nm": wavelength,
                        "Q0": q0,
                        "Q1": finite_float(row.get("Q1")),
                        "QL": finite_float(row.get("QL")),
                        "depth": finite_float(row.get("depth")),
                        "fit_status": row.get("fit_status", ""),
                        "coupling_note": row.get("coupling_note", ""),
                    }
                )
        rows.sort(key=lambda item: float(item["wavelength_nm"]))

    return {
        "ok": True,
        "cavity_dir": str(cavity_dir),
        "q_dir": str(q_dir),
        "manifest_path": str(manifest_path) if manifest_path.exists() else None,
        "q_table": str(q_table) if q_table.exists() else None,
        "manifest": manifest,
        "q_rows": rows,
    }


def infer_cavity_context(cavity_dir_text: str) -> dict[str, Any]:
    if not str(cavity_dir_text).strip():
        raise ValueError("Select a cavity directory first")
    cavity_dir = Path(cavity_dir_text).expanduser().resolve()
    cavity = cavity_dir.name
    die_dir = cavity_dir.parent
    die = die_dir.name
    results_root = die_dir.parent
    chip = results_root.name

    campaign = "wafer_measuement/Batch_260515"
    parts = list(cavity_dir.parts)
    lowered = [part.lower() for part in parts]
    if "experiments" in lowered and "results" in lowered:
        exp_idx = lowered.index("experiments")
        res_idx = lowered.index("results")
        if exp_idx < res_idx:
            campaign_parts = parts[exp_idx + 1 : res_idx]
            if campaign_parts:
                campaign = "/".join(campaign_parts)
        if res_idx + 1 < len(parts):
            chip = parts[res_idx + 1]
            results_root = Path(*parts[: res_idx + 2])
        remainder = parts[res_idx + 2 :]
        if len(remainder) == 1:
            die = remainder[0]
            cavity = "."
            die_dir = cavity_dir
        elif len(remainder) >= 2:
            die = remainder[0]
            cavity = remainder[1]
            die_dir = results_root / die

    return {
        "cavity_dir": cavity_dir,
        "die_dir": die_dir,
        "results_root": results_root,
        "campaign": campaign,
        "chip": chip,
        "die": die,
        "cavity": cavity,
    }


def compute_power_fields(
    input_monitor_power_uw: float | None,
    output_power_uw: float | None,
    *,
    input_monitor_fraction: float = 0.01,
) -> dict[str, Any]:
    return calculate_optical_power(
        input_monitor_power_uw,
        output_power_uw,
        input_monitor_fraction=input_monitor_fraction,
    ).as_dict()


def finite_from_text(text: str | None) -> float | None:
    if text is None or text == "":
        return None
    try:
        value = float(text)
    except ValueError:
        return None
    return value if math.isfinite(value) else None


def power_from_card(cavity_dir: Path) -> dict[str, Any] | None:
    card_path = cavity_dir / "cavity_card.html"
    if not card_path.exists():
        return None
    text = card_path.read_text(encoding="utf-8")
    pout_match = re.search(r"Pout\s+([0-9.eE+-]+)\s+uW", text)
    input_match = re.search(r"\(([0-9.eE+-]+)\s+uW input\)", text)
    input_monitor_fraction = 0.01
    if pout_match:
        output_power_uw = float(pout_match.group(1))
        input_power_uw = float(input_match.group(1)) if input_match else 100.0
    else:
        legacy_match = re.search(r"<tr><td>throughput</td><td>\s*([0-9.eE+-]+)\s*%\s*/\s*([0-9.eE+-]+)\s*dB", text)
        if not legacy_match:
            return None
        throughput_pct = float(legacy_match.group(1))
        input_power_uw = 100.0
        output_power_uw = input_power_uw * throughput_pct / 100.0
    input_monitor_power_uw = input_power_uw * input_monitor_fraction
    power = compute_power_fields(input_monitor_power_uw, output_power_uw, input_monitor_fraction=input_monitor_fraction)
    power["source"] = str(card_path)
    return power


def read_power_log_row(context: dict[str, Any]) -> dict[str, Any] | None:
    log_path = context["die_dir"] / "output_power_log.csv"
    if not log_path.exists():
        return None
    with log_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row.get("cavity") != context["cavity"]:
                continue
            input_monitor_fraction = finite_from_text(row.get("input_monitor_fraction")) or 0.01
            input_monitor_power_uw = finite_from_text(row.get("input_monitor_power_uw"))
            output_power_uw = finite_from_text(row.get("output_power_uw"))
            if input_monitor_power_uw is None:
                input_monitor_power_uw = 1.0
            if output_power_uw is None:
                throughput_pct = finite_from_text(row.get("throughput_percent"))
                if throughput_pct is not None:
                    output_power_uw = (input_monitor_power_uw / input_monitor_fraction) * throughput_pct / 100.0
            power = compute_power_fields(
                input_monitor_power_uw,
                output_power_uw,
                input_monitor_fraction=input_monitor_fraction,
            )
            legacy_loss = finite_from_text(row.get("single_ended_insertion_loss_db"))
            if power["single_ended_loss_db"] is None and legacy_loss is not None:
                power["single_ended_loss_db"] = legacy_loss
            power["source"] = str(log_path)
            power["updated_at"] = row.get("updated_at")
            power["note"] = row.get("note")
            return power
    return None


def large_scan_status(cavity_dir_text: str, q_subdir: object = "Q") -> dict[str, Any]:
    context = infer_cavity_context(cavity_dir_text)
    cavity_dir = context["cavity_dir"]
    normalized_q_subdir = normalize_q_subdir(q_subdir)
    q_dir = cavity_dir / normalized_q_subdir
    power = read_power_log_row(context) or power_from_card(cavity_dir)
    preanalysis_path = q_dir / "array_preanalysis_summary.json"
    preanalysis: dict[str, Any] | None = None
    if preanalysis_path.exists():
        preanalysis = json.loads(preanalysis_path.read_text(encoding="utf-8"))
    q_table = q_dir / "q_by_mode.csv"
    q_rows = 0
    if q_table.exists():
        with q_table.open(newline="", encoding="utf-8") as handle:
            q_rows = sum(1 for row in csv.DictReader(handle) if row.get("fit_status") == "ok")
    return {
        "ok": True,
        "context": {
            "campaign": context["campaign"],
            "chip": context["chip"],
            "die": context["die"],
            "cavity": context["cavity"],
            "q_subdir": normalized_q_subdir,
            "results_root": str(context["results_root"]),
            "cavity_dir": str(cavity_dir),
        },
        "power": power,
        "q": {
            "q_dir": str(q_dir),
            "raw_npz": str(q_dir / "raw.npz") if (q_dir / "raw.npz").exists() else None,
            "array_preanalysis_summary": str(preanalysis_path) if preanalysis_path.exists() else None,
            "array_preanalysis": preanalysis,
            "array_spectrum": str(q_dir / "array_preanalysis_spectrum.png")
            if (q_dir / "array_preanalysis_spectrum.png").exists()
            else None,
            "array_one_fsr": str(q_dir / "array_preanalysis_one_fsr_modes.png")
            if (q_dir / "array_preanalysis_one_fsr_modes.png").exists()
            else None,
            "array_pair_fsr": str(q_dir / "array_preanalysis_pair_fsr.png")
            if (q_dir / "array_preanalysis_pair_fsr.png").exists()
            else None,
            "array_folded_families": str(q_dir / "array_preanalysis_folded_families.png")
            if (q_dir / "array_preanalysis_folded_families.png").exists()
            else None,
            "q_table": str(q_table) if q_table.exists() else None,
            "q_rows": q_rows,
            "interactive_q": str(q_dir / "interactive_q.html") if (q_dir / "interactive_q.html").exists() else None,
            "q_trend": str(q_dir / "q_trend.png") if (q_dir / "q_trend.png").exists() else None,
            "transmission_spectrum": str(q_dir / "transmission_spectrum.png")
            if (q_dir / "transmission_spectrum.png").exists()
            else None,
            "fsr_periodicity": str(q_dir / "fsr_periodicity.png") if (q_dir / "fsr_periodicity.png").exists() else None,
            "folded_dispersion": str(q_dir / "folded_dispersion.png") if (q_dir / "folded_dispersion.png").exists() else None,
        },
    }


def write_power_log(context: dict[str, Any], power: dict[str, Any], note: str = "") -> Path:
    log_path = context["die_dir"] / "output_power_log.csv"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "cavity",
        "input_monitor_power_uw",
        "input_monitor_fraction",
        "input_power_uw",
        "output_power_uw",
        "throughput",
        "throughput_pct",
        "single_ended_loss_db",
        "updated_at",
        "note",
    ]
    rows: list[dict[str, Any]] = []
    if log_path.exists():
        with log_path.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
    rows = [row for row in rows if row.get("cavity") != context["cavity"]]
    rows.append(
        {
            "cavity": context["cavity"],
            "input_monitor_power_uw": power["input_monitor_power_uw"],
            "input_monitor_fraction": power["input_monitor_fraction"],
            "input_power_uw": power["input_power_uw"],
            "output_power_uw": power["output_power_uw"],
            "throughput": power["throughput"],
            "throughput_pct": power["throughput_pct"],
            "single_ended_loss_db": power["single_ended_loss_db"],
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "note": note,
        }
    )
    rows.sort(key=lambda row: row.get("cavity", ""))
    with log_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return log_path


def update_power_and_card(body: dict[str, Any]) -> dict[str, Any]:
    context = infer_cavity_context(str(body.get("cavity_dir") or ""))
    input_monitor_power_uw = finite_from_text(str(body.get("input_monitor_power_uw", "")))
    output_power_uw = finite_from_text(str(body.get("output_power_uw", "")))
    input_monitor_fraction = finite_from_text(str(body.get("input_monitor_fraction", "0.01"))) or 0.01
    if input_monitor_power_uw is None or output_power_uw is None:
        raise ValueError("input_monitor_power_uw and output_power_uw are required")
    power = compute_power_fields(
        input_monitor_power_uw,
        output_power_uw,
        input_monitor_fraction=input_monitor_fraction,
    )
    if input_monitor_power_uw <= 0 or output_power_uw < 0:
        raise ValueError("power values must be finite and non-negative; input monitor must be positive")
    log_path = write_power_log(context, power, note=str(body.get("note") or ""))
    command = [
        package_python_executable(),
        str(DEFAULT_CARD_SCRIPT),
        "--chip",
        context["chip"],
        "--die",
        context["die"],
        "--cavity",
        context["cavity"],
        "--results-root",
        str(context["results_root"]),
        "--output-power-uw",
        f"{output_power_uw:g}",
        "--input-monitor-power-uw",
        f"{input_monitor_power_uw:g}",
        "--input-monitor-fraction",
        f"{input_monitor_fraction:g}",
    ]
    card_result = run_script(command, timeout_s=60.0)
    return {
        "ok": bool(card_result.get("ok")),
        "json": {
            "message": "power saved and cavity card refreshed" if card_result.get("ok") else "card refresh failed",
            "power": {**power, "source": str(log_path)},
            "context": {
                "chip": context["chip"],
                "die": context["die"],
                "cavity": context["cavity"],
                "results_root": str(context["results_root"]),
            },
            "card_result": card_result,
        },
    }


def large_scan_command(body: dict[str, Any], args: argparse.Namespace) -> tuple[list[str], float]:
    context = infer_cavity_context(str(body.get("cavity_dir") or ""))
    q_subdir = normalize_q_subdir(body.get("q_subdir"))
    config = instrument_config_from_mapping(body, args)
    if config["laser_type"] not in {"toptica_serial", "toptica_tcp"}:
        raise ValueError("Large-scan Q requires TOPTICA serial or TOPTICA TCP laser control.")
    if config["scope_type"] not in {"rs_rte", "tektronix_mso66b"}:
        raise ValueError("Large-scan Q requires a supported VISA oscilloscope resource.")
    laser_connection = "tcp" if config["laser_type"] == "toptica_tcp" else "serial"
    toptica_python = toptica_child_python(args, config["laser_type"]) if laser_connection == "tcp" else ""
    mode = str(body.get("mode") or "run")
    command = [
        package_python_executable(),
        str(DEFAULT_LARGE_SCAN_SCRIPT),
        "--campaign",
        context["campaign"],
        "--chip",
        context["chip"],
        "--die",
        context["die"],
        "--cavity",
        context["cavity"],
        "--q-subdir",
        q_subdir,
        "--results-root",
        str(context["results_root"]),
        "--laser-connection",
        laser_connection,
        "--laser-port",
        config["laser_port"],
        "--laser-host",
        config["toptica_host"],
        "--toptica-python",
        toptica_python,
        "--scope-type",
        config["scope_type"],
        "--scope-resource",
        config["scope_resource"],
    ]
    array_min_depth = body.get("array_min_depth")
    if array_min_depth is None:
        array_min_depth = getattr(args, "array_min_depth", None)
    if array_min_depth is not None:
        command.extend(["--array-min-depth", str(validate_array_min_depth(array_min_depth))])
    disk_fsr_mhz = finite_from_text(str(body.get("disk_fsr_mhz", "")))
    if disk_fsr_mhz is not None:
        command.extend(["--disk-fsr-mhz", f"{disk_fsr_mhz:g}"])
    mzi_d1_mhz = finite_from_text(str(body.get("mzi_d1_mhz", "")))
    if mzi_d1_mhz is not None:
        if mzi_d1_mhz <= 0:
            raise ValueError(f"mzi_d1_mhz must be positive, got {mzi_d1_mhz:g} MHz.")
        command.extend(["--mzi-d1-mhz", f"{mzi_d1_mhz:g}"])
    if bool_from_config(body.get("array_die_scan"), False):
        command.append("--array-preanalysis-only")
    channel_specs = (
        ("trigger_channel", "--trigger-channel", 1),
        ("trans_channel", "--trans-channel", 2),
        ("mzi_channel", "--mzi-channel", 3),
    )
    for body_key, cli_key, default_channel in channel_specs:
        channel = int(finite_from_text(str(body.get(body_key, ""))) or default_channel)
        if channel < 1 or channel > 6:
            raise ValueError(f"{body_key} must be CH1-CH6, got CH{channel}.")
        command.extend([cli_key, str(channel)])
    command.extend(
        [
            "--fine-trigger-channel",
            str(DEFAULT_FINE_TRIGGER_CHANNEL),
            "--fine-trigger-level-v",
            f"{DEFAULT_FINE_TRIGGER_LEVEL_V:g}",
            "--fine-trigger-slope",
            DEFAULT_FINE_TRIGGER_SLOPE,
        ]
    )
    timeout_s = 900.0
    if mode == "resume":
        command.append("--resume-existing-raw")
        timeout_s = 600.0
    elif mode == "standardize":
        command.append("--standardize-only")
        timeout_s = 240.0
    elif mode != "run":
        raise ValueError(f"Unknown large-scan mode: {mode}")
    return command, timeout_s


def pick_folder(initial_dir_text: str | None, fallback_dir: Path) -> dict[str, Any]:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception as exc:
        return {"ok": False, "error": f"Tk folder picker unavailable: {exc!r}"}

    initial_dir = Path(initial_dir_text).expanduser() if initial_dir_text else fallback_dir
    if initial_dir.is_file():
        initial_dir = initial_dir.parent
    if not initial_dir.exists():
        initial_dir = fallback_dir if fallback_dir.exists() else Path.cwd()

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        selected = filedialog.askdirectory(
            title="Select cavity directory",
            initialdir=str(initial_dir),
            mustexist=True,
        )
    finally:
        root.destroy()

    if not selected:
        return {"ok": True, "cancelled": True, "path": None}
    return {"ok": True, "cancelled": False, "path": selected}


def target_args(body: dict[str, Any], args: argparse.Namespace) -> list[str]:
    cavity_dir = str(body.get("cavity_dir") or "")
    if not cavity_dir:
        raise ValueError("Select a cavity directory first")
    target_kind = str(body.get("target_kind") or "candidate")
    config = instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("Selected-mode lock/move requires RP / PyRPL bridge")
    if config["laser_type"] not in {"toptica_tcp", "toptica_serial"}:
        raise ValueError("Selected-mode lock/move currently requires TOPTICA laser")
    laser_connection = "serial" if config["laser_type"] == "toptica_serial" else "tcp"
    command = [
        toptica_child_python(args, config["laser_type"]),
        str(DEFAULT_BEST_Q_SCRIPT),
        "--cavity-dir",
        cavity_dir,
        "--base",
        config["bridge_base"],
        "--host",
        config["toptica_host"],
        "--laser-connection",
        laser_connection,
        "--laser-port",
        config["laser_port"],
    ]
    if target_kind == "nearest_1550":
        command += ["--candidate-key", "nearest_1550_best_q_candidate"]
    elif target_kind == "manual":
        wavelength = body.get("wavelength_nm")
        if wavelength in (None, ""):
            raise ValueError("Manual target requires wavelength_nm")
        command += ["--wavelength-nm", str(wavelength)]
    elif target_kind == "candidate":
        command += ["--candidate-key", "candidate"]
    else:
        raise ValueError(f"Unknown target_kind: {target_kind}")
    return command
