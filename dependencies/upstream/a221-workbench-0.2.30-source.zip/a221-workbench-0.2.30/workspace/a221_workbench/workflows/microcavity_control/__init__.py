"""Single-cavity control interface."""
