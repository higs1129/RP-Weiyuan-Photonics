"""HTTP dashboard for stable microcavity Q/lock operations."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.microcavity_control'


from a221_workbench.workflows.instrument_backend import *  # noqa: F401,F403


def page(
    default_cavity: Path | None,
    bridge_base: str,
    rp_host: str,
    laser_type: str,
    toptica_host: str,
    *,
    large_scan_laser_port: str,
    toptica_port: str,
    weiyuan_port: str,
    scope_type: str,
    scope_resource: str,
) -> str:
    default_cavity_text = str(default_cavity) if default_cavity is not None else ""
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Microcavity Q/Lock Control</title>
  <style>
    :root {{ font-family: Arial, "Microsoft YaHei", sans-serif; color: #111; background: #f6f7f8; }}
    body {{ margin: 0; }}
    header {{ padding: 14px 18px; border-bottom: 1px solid #bbb; background: #fff; display: flex; justify-content: space-between; gap: 16px; align-items: center; }}
    h1 {{ margin: 0; font-size: 20px; }}
    .task-nav {{ position: sticky; top: 0; z-index: 10; display: flex; gap: 8px; align-items: center; padding: 10px 16px; background: #fff; border-bottom: 1px solid #d0d3d6; box-shadow: 0 1px 4px rgba(0,0,0,.04); }}
    .task-nav button {{ margin: 0; border-color: #aaa; background: #fff; font-weight: 700; }}
    .task-nav button.active {{ background: #0b65c2; color: #fff; border-color: #0b65c2; }}
    .task-nav .task-hint {{ margin-left: auto; font-size: 12px; color: #555; }}
    main {{
      padding: 16px;
      display: grid;
      grid-template-columns: minmax(520px, 1fr) minmax(520px, 1fr);
      grid-template-areas:
        "safety selected"
        "large selected"
        "qtable selected";
      gap: 14px;
      align-items: start;
    }}
    section {{ background: #fff; border: 1px solid #bbb; border-radius: 8px; padding: 14px; }}
    .safety-panel {{ grid-area: safety; }}
    .selected-panel {{ grid-area: selected; }}
    .large-scan-panel {{ grid-area: large; }}
    .q-table-panel {{ grid-area: qtable; }}
    h2 {{ margin: 0 0 10px; font-size: 17px; }}
    label {{ display: block; font-size: 13px; margin: 10px 0 4px; font-weight: 700; }}
    input, select {{ width: 100%; box-sizing: border-box; padding: 7px 8px; border: 1px solid #888; border-radius: 4px; font-size: 13px; }}
    button {{ padding: 7px 10px; margin: 6px 6px 0 0; border: 1px solid #555; border-radius: 4px; background: #f3f3f3; cursor: pointer; }}
    button.primary {{ background: #0b65c2; color: white; border-color: #0b65c2; }}
    button.danger {{ background: #fff1f1; border-color: #b00020; color: #8c001a; }}
    button:disabled {{ opacity: 0.55; cursor: wait; }}
    .row {{ display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }}
    .instrument-grid {{ display: grid; grid-template-columns: 130px minmax(150px, .8fr) minmax(180px, 1fr); gap: 8px; align-items: end; margin-bottom: 8px; }}
    .instrument-grid label {{ margin-top: 0; }}
    .instrument-grid .wide {{ grid-column: span 2; }}
    .mode-grid {{ display: grid; grid-template-columns: minmax(180px, .45fr) 1fr; gap: 10px; align-items: end; margin-bottom: 10px; }}
    .mode-note {{ border-left: 3px solid #0b65c2; padding: 7px 9px; background: #f4f8ff; font-size: 12px; line-height: 1.45; }}
    .path-row {{ display: grid; grid-template-columns: 1fr auto; gap: 8px; align-items: center; }}
    .path-row button {{ margin-top: 0; white-space: nowrap; }}
    .power-grid {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }}
    .power-grid input[readonly] {{ background: #f6f7f8; }}
    .button-row {{ display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin-top: 8px; }}
    .button-row button {{ margin: 0; }}
    .status {{ font-family: Consolas, monospace; font-size: 12px; white-space: normal; background: #f1f3f5; border: 1px solid #ccc; padding: 8px; min-height: 58px; }}
    .status .result-summary {{ white-space: pre-wrap; line-height: 1.45; }}
    .status .result-ok {{ color: #075b18; }}
    .status .result-bad {{ color: #8c001a; }}
    .status details {{ margin-top: 8px; color: #333; }}
    .status details pre {{ white-space: pre-wrap; overflow: auto; max-height: 260px; margin: 6px 0 0; }}
    .candidate {{ display: grid; grid-template-columns: 120px 1fr; gap: 4px 10px; font-size: 13px; border-top: 1px solid #ddd; padding-top: 8px; margin-top: 8px; }}
    .candidate b {{ font-family: Consolas, monospace; }}
    .preview-stack {{ display: grid; gap: 10px; margin-top: 10px; }}
    .rp-preview {{ border: 1px solid #ccc; background: #f8f9fa; padding: 8px; }}
    .selected-panel > .rp-preview {{ margin-top: 10px; }}
    .preview-head {{ display: flex; justify-content: space-between; gap: 10px; align-items: center; margin-bottom: 6px; flex-wrap: wrap; }}
    .preview-actions {{ display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }}
    .preview-actions button {{ margin: 0; }}
    .live-label {{ display: inline-flex; gap: 4px; align-items: center; margin: 0; font-weight: 400; }}
    .live-label input {{ width: auto; }}
    .rp-preview canvas {{ display: block; width: 100%; height: 240px; background: #fff; border: 1px solid #aaa; }}
    .modal-backdrop {{ position: fixed; inset: 0; background: rgba(0, 0, 0, .28); display: flex; align-items: center; justify-content: center; z-index: 50; padding: 20px; }}
    .modal-card {{ width: min(1180px, 96vw); max-height: 92vh; overflow: auto; background: #fff; border: 1px solid #111; border-radius: 8px; box-shadow: 0 12px 36px rgba(0,0,0,.28); padding: 16px; }}
    .modal-card h2 {{ font-size: 19px; margin-bottom: 4px; }}
    .settings-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(270px, 1fr)); gap: 10px 14px; margin: 10px 0; }}
    .settings-group {{ border: 1px solid #bbb; border-radius: 6px; padding: 10px; }}
    .settings-group h3 {{ margin: 0 0 6px; font-size: 15px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 12px; }}
    th, td {{ border-bottom: 1px solid #ddd; padding: 5px 6px; text-align: left; }}
    th {{ background: #f1f3f5; position: sticky; top: 0; }}
    tr:hover {{ background: #fff7db; }}
    .table-wrap {{ max-height: 380px; overflow: auto; border: 1px solid #ddd; }}
    .muted {{ color: #555; font-size: 12px; }}
    .hidden {{ display: none !important; }}
    body[data-task="lock"] main,
    body[data-task="sensitivity"] main,
    body[data-task="qscan"] main,
    body[data-task="coupling"] main,
    body[data-task="qtable"] main,
    body[data-task="settings"] main {{ grid-template-columns: minmax(680px, 1280px); grid-template-areas: "active"; justify-content: center; }}
    body[data-task="lock"] main {{
      grid-template-areas:
        "active"
        "qtable";
    }}
    body[data-task="lock"] .safety-panel,
    body[data-task="lock"] .large-scan-panel,
    body[data-task="sensitivity"] .safety-panel,
    body[data-task="sensitivity"] .large-scan-panel,
    body[data-task="sensitivity"] .q-table-panel,
    body[data-task="qscan"] .safety-panel,
    body[data-task="qscan"] .selected-panel,
    body[data-task="qscan"] .q-table-panel,
    body[data-task="coupling"] .safety-panel,
    body[data-task="coupling"] .selected-panel,
    body[data-task="coupling"] .q-table-panel,
    body[data-task="qtable"] .safety-panel,
    body[data-task="qtable"] .selected-panel,
    body[data-task="qtable"] .large-scan-panel,
    body[data-task="settings"] .selected-panel,
    body[data-task="settings"] .large-scan-panel,
    body[data-task="settings"] .q-table-panel {{ display: none; }}
    body[data-task="lock"] .selected-panel,
    body[data-task="sensitivity"] .selected-panel,
    body[data-task="qscan"] .large-scan-panel,
    body[data-task="coupling"] .large-scan-panel,
    body[data-task="qtable"] .q-table-panel,
    body[data-task="settings"] .safety-panel {{ grid-area: active; }}
    body[data-task="lock"] .q-table-panel {{ grid-area: qtable; }}
    body[data-task="lock"] .sensitivity-card,
    body[data-task="sensitivity"] .target-controls,
    body[data-task="sensitivity"] .lock-actions,
    body[data-task="sensitivity"] #targetResult,
    body[data-task="sensitivity"] .scope-card,
    body[data-task="coupling"] .large-scan-controls,
    body[data-task="qscan"] .scope-card,
    body[data-task="coupling"] .cavity-controls {{ display: none !important; }}
    body[data-task="coupling"] .coupling-card {{ display: block; }}
    @media (max-width: 980px) {{
      main {{
        grid-template-columns: 1fr;
        grid-template-areas:
          "safety"
          "large"
          "selected"
          "qtable";
      }}
    }}
  </style>
</head>
<body>
  <header>
    <h1>Microcavity Q/Lock Control</h1>
    <div class="muted">
      RP bridge: <span id="bridgeBase">{bridge_base}</span> |
      mode: <span id="headerMode">-</span> |
      laser: <span id="headerLaser">{laser_type}</span> |
      large scan: <span id="laserPort">{large_scan_laser_port}</span> + <span id="scopeResource">{scope_resource}</span>
    </div>
  </header>
  <nav class="task-nav" aria-label="workflow tasks">
    <button type="button" data-task-button="settings" onclick="setTask('settings')">仪器设置</button>
    <button type="button" data-task-button="qscan" onclick="setTask('qscan')">Q 大扫 / 插损</button>
    <button type="button" data-task-button="lock" onclick="setTask('lock')">锁模</button>
    <button type="button" data-task-button="sensitivity" onclick="setTask('sensitivity')">灵敏度</button>
    <button type="button" data-task-button="coupling" onclick="setTask('coupling')">自动耦合</button>
    <button type="button" data-task-button="qtable" onclick="setTask('qtable')">Q 表</button>
    <span id="taskHint" class="task-hint"></span>
  </nav>
  <main>
    <section class="safety-panel">
      <h2>Experiment Mode & Safety</h2>
      <div class="mode-grid">
        <div>
          <label>Experiment mode</label>
          <select id="experimentMode">
            <option value="toptica_q_lock">TOPTICA Q / Lock</option>
            <option value="weiyuan_lock">微源光子 Lock</option>
            <option value="rp_debug">RP spectrum / debug</option>
          </select>
        </div>
        <div id="modeNote" class="mode-note"></div>
      </div>
      <div class="instrument-grid rp-connection">
        <div>
          <label>RP / PyRPL</label>
          <select id="rpType">
            <option value="pyrpl_bridge">PyRPL bridge</option>
            <option value="none">none</option>
          </select>
        </div>
        <div class="wide">
          <label>Bridge URL</label>
          <input id="bridgeBaseInput" value="{bridge_base}" />
        </div>
        <div></div>
        <div class="wide">
          <label>RP host / IP (optional)</label>
          <input id="rpHostInput" value="{rp_host}" placeholder="RP-f0cb0d" />
        </div>
        <div>
          <label>RP bridge action</label>
          <select id="bridgeAction">
            <option value="check_rp_host">Check RP host</option>
            <option value="start_restart_bridge">Start / restart headless bridge</option>
            <option value="start_restart_bridge_gui">Start / restart GUI bridge</option>
            <option value="refresh_bridge_status">Refresh bridge status</option>
            <option value="stop_bridge">Stop managed bridge</option>
            <option value="stop_any_bridge">Stop any bridge on this URL</option>
          </select>
        </div>
        <div class="wide">
          <button onclick="runBridgeAction()">Run bridge action</button>
          <span class="muted">Default bridge is headless; GUI bridge is only for PyRPL-native debugging. Spectrum gain and scope power response come from config.local.json.</span>
        </div>
      </div>
      <div class="instrument-grid laser-connection">
        <div>
          <label>Laser</label>
          <select id="laserType">
            <option value="toptica_serial">TOPTICA Serial</option>
            <option value="toptica_tcp">TOPTICA TCP/IP</option>
            <option value="weiyuan">微源光子</option>
            <option value="none">none</option>
          </select>
        </div>
        <div id="topticaHostField">
          <label>Laser host / IP</label>
          <input id="topticaHostInput" value="{toptica_host}" />
        </div>
        <div>
          <label id="laserPortLabel">Laser COM / port</label>
          <input id="laserPortInput" value="{large_scan_laser_port}" />
        </div>
      </div>
      <div id="weiyuanPanel">
        <h3 style="margin: 10px 0 4px; font-size: 15px;">微源光子控制</h3>
        <div class="row">
          <div>
            <label>Slave address</label>
            <input id="weiyuanSlaveInput" type="number" step="1" value="255" />
          </div>
          <div></div>
        </div>
        <div class="row">
          <div>
            <label>TEC set temperature (C)</label>
            <input id="weiyuanTempInput" type="number" step="0.01" placeholder="temperature" />
          </div>
          <div>
            <label>LD set current (mA)</label>
            <input id="weiyuanCurrentInput" type="number" step="0.01" value="260" />
          </div>
        </div>
        <div class="button-row">
          <button onclick="runWeiyuan('status')">Read micro-source</button>
          <button onclick="runWeiyuan('set_temperature')">Set temperature</button>
          <button onclick="runWeiyuan('set_current')">Set current</button>
          <button onclick="runWeiyuan('set_initial_current')">Set 260 mA</button>
          <button onclick="runWeiyuan('tec_on')">TEC on</button>
          <button onclick="runWeiyuan('tec_off')">TEC off</button>
          <button onclick="runWeiyuan('ld_on')">LD on</button>
          <button onclick="runWeiyuan('ld_off')">LD off</button>
        </div>
        <pre id="weiyuanResult" class="status">choose 微源光子 and read status</pre>
      </div>
      <div class="instrument-grid scope-connection">
        <div>
          <label>Oscilloscope</label>
          <select id="scopeType">
            <option value="rs_rte">R&S RTE</option>
            <option value="tektronix_mso66b">Tektronix MSO66B</option>
            <option value="none">none</option>
          </select>
        </div>
        <div class="wide">
          <label>VISA resource</label>
          <input id="scopeResourceInput" value="{scope_resource}" />
        </div>
      </div>
      <button onclick="refreshHealth()">Refresh status</button>
      <button class="danger" onclick="safeOff()">Safe off PID/ASG</button>
      <pre id="health" class="status">not checked</pre>
    </section>

    <section class="selected-panel">
      <h2>Selected Mode</h2>
      <div class="target-controls">
        <label>Target source</label>
        <select id="targetKind" onchange="renderTarget()">
          <option value="candidate">highest Q0 candidate</option>
          <option value="nearest_1550">nearest 1550 nm candidate</option>
          <option value="manual">manual / selected row wavelength</option>
        </select>
        <label>Manual wavelength (nm)</label>
        <input id="manualWavelength" placeholder="1564.492182" oninput="manualSelectedRow=null; renderTarget()" />
        <div id="targetPreview" class="candidate"></div>
      </div>
      <div class="button-row lock-actions">
        <button class="target-controls" onclick="dryRunTarget()">Dry-run target</button>
        <button class="primary target-controls" onclick="moveTarget()">Move to target wavelength</button>
        <button onclick="lockCurrent()">Lock current mode</button>
        <button onclick="restoreLockSweep('targetResult')">Restore sweep / PID off</button>
      </div>
      <div id="targetResult" class="status"></div>
      <div class="rp-preview sensitivity-card">
        <div class="preview-head">
          <b>Sensitivity acquisition</b>
          <span class="muted">noise spectrum + network response</span>
        </div>
        <div class="row">
          <div>
            <label>Tag prefix</label>
            <input id="sensitivityTag" value="sensitivity" />
          </div>
          <div>
            <label>Acquisition mode</label>
            <select id="sensitivityMode">
              <option value="psd">PSD only</option>
              <option value="network">Network response only</option>
              <option value="both" selected>PSD then network response</option>
              <option value="compute">Compute sensitivity from existing raw</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div>
            <label>Max inline points</label>
            <input id="sensitivityMaxPoints" type="number" value="1500" min="100" step="100" />
          </div>
          <div>
            <label>Spectrum timeout (s)</label>
            <input id="sensitivitySpectrumTimeout" type="number" value="30" min="1" step="1" />
          </div>
        </div>
        <div class="row">
          <div>
            <label>Network timeout (s)</label>
            <input id="sensitivityNetworkTimeout" type="number" value="600" min="1" step="1" />
          </div>
        </div>
        <div class="button-row">
          <button id="runSensitivityButton" class="primary" onclick="runSensitivityAcquisition()">Run selected acquisition</button>
          <button id="cancelSensitivityButton" class="danger hidden" onclick="cancelSensitivityAcquisition()">Cancel acquisition</button>
        </div>
        <div id="sensitivityResult" class="status"></div>
      </div>
    </section>

    <section class="large-scan-panel">
      <h2>Large-Scan Q</h2>
      <div class="cavity-controls">
        <label>Cavity directory</label>
        <div class="path-row">
          <input id="cavityDir" value="{default_cavity_text}" placeholder="Choose a cavity directory when needed" />
          <button onclick="browseCavity()">Browse...</button>
        </div>
        <button onclick="loadCavity()">Load cavity</button>
      </div>
      <div class="rp-preview coupling-controls coupling-card">
        <div class="preview-head">
          <b>Auto coupling</b>
          <span class="muted">monotonic step search with instantaneous RP power</span>
        </div>
        <p class="muted">
          Pass 1: all axes use 20 V range with 1/0.3/0.1 V steps.
          Pass 2: all axes use 10 V range with 0.5/0.3/0.1 V steps.
        </p>
        <div class="button-row">
          <button id="runCouplingButton" class="primary" onclick="runStandardCoupling()">Run standard auto coupling</button>
        </div>
        <div id="couplingResult" class="status"></div>
      </div>
      <div class="large-scan-controls">
      <p class="muted">Fixed large scan: 1530-1570 nm, 2 nm/s. Power fields are used for card throughput / single-ended insertion loss.</p>
      <div class="power-grid">
        <div>
          <label>1% monitor power (uW)</label>
          <input id="inputMonitorPower" placeholder="1.0" oninput="updateLossPreview()" />
        </div>
        <div>
          <label>Out-coupled power (uW)</label>
          <input id="outputPower" placeholder="5.0" oninput="updateLossPreview()" />
        </div>
        <div>
          <label>Single-ended loss (dB)</label>
          <input id="singleEndedLoss" readonly placeholder="pending" />
        </div>
      </div>
      <div class="muted" id="powerSource">power record not loaded</div>
      <div class="button-row">
        <button onclick="savePower()">Save power + refresh card</button>
        <button class="primary" onclick="runLargeScan('run')">Run large scan Q</button>
        <button onclick="runLargeScan('resume')">Resume existing raw</button>
        <button onclick="runLargeScan('standardize')">Standardize only</button>
        <button class="danger" onclick="stopLargeScan()">Stop scan + restore idle</button>
      </div>
      <div id="largeScanResult" class="status"></div>
      </div>
    </section>

    <section class="q-table-panel">
      <h2>Q Table</h2>
      <p class="muted">Click a row to copy its wavelength into the manual target field.</p>
      <div class="table-wrap">
        <table>
          <thead><tr><th>family</th><th>mu</th><th>wavelength</th><th>Q0(M)</th><th>Q1(M)</th><th>QL(M)</th><th>depth</th></tr></thead>
          <tbody id="qRows"></tbody>
        </table>
      </div>
    </section>
  </main>
  <div id="sensitivitySettingsModal" class="modal-backdrop hidden">
    <div class="modal-card">
      <h2>Sensitivity acquisition settings</h2>
      <div id="sensitivitySettingsNote" class="muted">Review PyRPL settings before acquisition.</div>
      <div class="settings-grid">
        <div id="spectrumSettingsGroup" class="settings-group">
          <h3>Spectrum analyzer</h3>
          <label>Frequency span (Hz)</label>
          <select id="spectrumSpanHz" onchange="syncSpectrumRbwFromSpan()"></select>
          <label>RBW (Hz, derived)</label>
          <select id="spectrumRbwHz" disabled></select>
          <label>Average count</label>
          <input id="spectrumTraceAverage" type="number" min="1" step="1" />
          <div id="spectrumPointInfo" class="muted">Spectrum points are fixed by the PyRPL scope FFT path.</div>
        </div>
        <div id="networkSettingsGroup" class="settings-group">
          <h3>Network analyzer</h3>
          <label>Drive amplitude (Vpk)</label>
          <input id="networkAmplitudeVpk" type="number" step="0.001" />
          <label>Start frequency (Hz)</label>
          <input id="networkStartHz" type="number" step="1" />
          <label>Stop frequency (Hz)</label>
          <input id="networkStopHz" type="number" step="1" />
          <label>Points</label>
          <input id="networkPoints" type="number" step="1" min="2" />
          <label>RBW (Hz)</label>
          <select id="networkRbwHz"></select>
        </div>
        <div id="pressureSettingsGroup" class="settings-group">
          <h3>Pressure calibration</h3>
          <label>Pressure source</label>
          <select id="pressureSourceModel"></select>
          <label>Calibration file</label>
          <input id="pressureCalibrationPath" />
          <label>Calibration range</label>
          <input id="pressureCalibrationRange" readonly />
          <label>Calibration drive (Vpp)</label>
          <input id="pressureCalibrationDriveVpp" type="number" step="0.001" />
          <label>Pressure quantity</label>
          <select id="pressureQuantity">
            <option value="pk">peak pressure</option>
            <option value="rms">RMS pressure</option>
          </select>
          <label>Use start frequency (Hz)</label>
          <input id="pressureUseStartHz" type="number" step="1" />
          <label>Use stop frequency (Hz)</label>
          <input id="pressureUseStopHz" type="number" step="1" />
          <div id="pressureInfo" class="muted">Pressure calibration is used only when PSD and network response are both available.</div>
        </div>
      </div>
      <div class="button-row">
        <button class="primary" onclick="confirmSensitivityAcquisition()">Confirm and run</button>
        <button onclick="closeSensitivitySettings()">Cancel</button>
      </div>
    </div>
  </div>
<script>
let cavity = null;
let manualSelectedRow = null;
let pendingSensitivityBody = null;
let sensitivityAbortController = null;
const defaults = {{
  rpType: 'pyrpl_bridge',
  laserType: '{laser_type}',
  scopeType: '{scope_type}',
  topticaPort: '{toptica_port}',
  weiyuanPort: '{weiyuan_port}'
}};
const modeLabels = {{
  toptica_q_lock: 'TOPTICA Q / Lock',
  weiyuan_lock: '微源光子 Lock',
  rp_debug: 'RP spectrum / debug'
}};
const modeNotes = {{
  toptica_q_lock: '用于片上微腔大扫、Q 拟合、从 Q 表选模式并用 TOPTICA 锁模。',
  weiyuan_lock: '用于外场/微源光子实验：通过串口读写温度和 LD 电流，并对当前模式做电流居中锁定。',
  rp_debug: '只保留 Red Pitaya / PyRPL 桥、安全关闭和状态检查，用于频谱仪、scope 或临时调试。'
}};
const taskHints = {{
  lock: '手动选腔、移动到目标模式、锁定当前模式。',
  qscan: '先自动耦合或记录出腔功率，再运行大扫 / resume / standardize。',
  sensitivity: '锁好模式后采 PSD、网分响应，并计算灵敏度。',
  coupling: '只做 MDT693B 自动耦合优化；适合调光路时单独打开。',
  qtable: '查看当前腔的 Q 表，点行可把波长送到手动目标。',
  settings: '连接、安全关闭、仪器配置和诊断集中在这里。'
}};
function setTask(task) {{
  document.body.dataset.task = task;
  for (const button of document.querySelectorAll('[data-task-button]')) {{
    button.classList.toggle('active', button.dataset.taskButton === task);
  }}
  const hint = document.getElementById('taskHint');
  if (hint) hint.textContent = taskHints[task] || '';
}}
const api = async (path, body=null, options={{}}) => {{
  const opt = body ? {{method:'POST', headers:{{'Content-Type':'application/json'}}, body:JSON.stringify(body)}} : {{}};
  if (options.signal) opt.signal = options.signal;
  const r = await fetch(path, opt);
  const j = await r.json();
  if (!r.ok) throw j;
  return j;
}};
const fmt = (x, digits=6) => (x === null || x === undefined || x === '') ? '-' : Number(x).toFixed(digits);
const qfmt = x => (x === null || x === undefined || x === '') ? '-' : (Number(x)/1e6).toFixed(3);
function setSelectValue(id, value) {{
  const el = document.getElementById(id);
  if ([...el.options].some(option => option.value === value)) el.value = value;
}}
function instrumentBody() {{
  return {{
    rp_type: document.getElementById('rpType').value,
    bridge_base: document.getElementById('bridgeBaseInput').value.trim(),
    rp_host: document.getElementById('rpHostInput').value.trim(),
    laser_type: document.getElementById('laserType').value,
    toptica_host: document.getElementById('topticaHostInput').value.trim(),
    laser_port: document.getElementById('laserPortInput').value.trim(),
    weiyuan_slave: document.getElementById('weiyuanSlaveInput').value.trim(),
    scope_type: document.getElementById('scopeType').value,
    scope_resource: document.getElementById('scopeResourceInput').value.trim()
  }};
}}
function updateInstrumentHeader() {{
  const cfg = instrumentBody();
  const mode = document.getElementById('experimentMode').value;
  document.getElementById('bridgeBase').textContent = cfg.rp_type === 'none' ? 'none' : cfg.bridge_base;
  document.getElementById('headerMode').textContent = modeLabels[mode] || mode;
  document.getElementById('headerLaser').textContent = cfg.laser_type === 'none' ? 'none' : cfg.laser_type;
  document.getElementById('laserPort').textContent = cfg.laser_type === 'toptica_tcp' ? cfg.toptica_host : cfg.laser_port;
  document.getElementById('scopeResource').textContent = cfg.scope_type === 'none' ? 'none' : cfg.scope_resource;
}}
const bodyBase = () => ({{ cavity_dir: document.getElementById('cavityDir').value, ...instrumentBody() }});

function inferExperimentMode(laserType) {{
  if (laserType === 'weiyuan') return 'weiyuan_lock';
  if (laserType === 'none') return 'rp_debug';
  return 'toptica_q_lock';
}}
function setVisible(selector, visible) {{
  for (const el of document.querySelectorAll(selector)) {{
    el.classList.toggle('hidden', !visible);
  }}
}}
const sameText = (a, b) => String(a || '').trim().toUpperCase() === String(b || '').trim().toUpperCase();
function switchLaserPortDefault(laserType) {{
  const port = document.getElementById('laserPortInput');
  const current = port.value.trim();
  if (laserType === 'weiyuan') {{
    if (!current || sameText(current, defaults.topticaPort) || sameText(current, 'COM3')) port.value = defaults.weiyuanPort || 'COM5';
  }} else if (laserType === 'toptica_serial' || laserType === 'toptica_tcp') {{
    if (!current || sameText(current, defaults.weiyuanPort) || sameText(current, 'COM5')) port.value = defaults.topticaPort || 'COM3';
  }}
}}
function applyExperimentMode(fromUser=false) {{
  const mode = document.getElementById('experimentMode').value;
  if (mode === 'toptica_q_lock') {{
    if (fromUser || document.getElementById('laserType').value === 'none' || document.getElementById('laserType').value === 'weiyuan') {{
      setSelectValue('laserType', 'toptica_serial');
      setSelectValue('scopeType', defaults.scopeType && defaults.scopeType !== 'none' ? defaults.scopeType : 'rs_rte');
      switchLaserPortDefault('toptica_serial');
    }}
  }} else if (mode === 'weiyuan_lock') {{
    if (fromUser || document.getElementById('laserType').value !== 'weiyuan') {{
      setSelectValue('laserType', 'weiyuan');
      switchLaserPortDefault('weiyuan');
    }}
    setSelectValue('scopeType', 'none');
  }} else if (mode === 'rp_debug') {{
    if (fromUser || document.getElementById('laserType').value !== 'none') {{
      setSelectValue('laserType', 'none');
    }}
    setSelectValue('scopeType', 'none');
  }}
  const cfg = instrumentBody();
  const isTopticaMode = mode === 'toptica_q_lock';
  const isWeiyuanMode = mode === 'weiyuan_lock';
  const isDebugMode = mode === 'rp_debug';

  document.getElementById('modeNote').textContent = modeNotes[mode] || '';
  setVisible('.laser-connection', !isDebugMode);
  setVisible('.scope-connection', isTopticaMode);
  setVisible('.selected-panel', !isDebugMode);
  setVisible('.target-controls', isTopticaMode);
  setVisible('.large-scan-panel', isTopticaMode);
  setVisible('.q-table-panel', isTopticaMode);
  document.getElementById('weiyuanPanel').classList.toggle('hidden', !isWeiyuanMode);
  document.getElementById('topticaHostField').classList.toggle('hidden', cfg.laser_type !== 'toptica_tcp');
  document.getElementById('laserPortLabel').textContent = cfg.laser_type === 'weiyuan' ? 'Micro-source COM port' : 'Laser COM / port';
  updateInstrumentHeader();
  const currentTask = document.body.dataset.task;
  if (isDebugMode && currentTask !== 'settings') {{
    setTask('settings');
  }} else if (isWeiyuanMode && ['qscan', 'coupling', 'qtable'].includes(currentTask)) {{
    setTask('lock');
  }}
}}

function addLine(lines, label, value) {{
  if (value === null || value === undefined || value === '') return;
  lines.push(`${{label}}: ${{value}}`);
}}
function summarizePayload(payload) {{
  const lines = [];
  const ok = payload && payload.ok;
  lines.push(`ok: ${{ok ? 'true' : 'false'}}`);
  addLine(lines, 'elapsed', payload && payload.elapsed_s !== undefined ? `${{Number(payload.elapsed_s).toFixed(2)}} s` : null);
  addLine(lines, 'returncode', payload && payload.returncode);

  const j = payload && payload.json ? payload.json : payload;
  addLine(lines, 'message', j && j.message);
  addLine(lines, 'output dir', j && j.output_dir);
  addLine(lines, 'run json', j && j.run_json_path);
  addLine(lines, 'q rows', j && j.q_rows);
  addLine(lines, 'candidate source', j && j.candidate_source);
  const failure = j && j.failure;
  if (failure) {{
    addLine(lines, 'failure stage', failure.stage);
    addLine(lines, 'failure reason', failure.reason);
    addLine(lines, 'failure error', failure.error);
  }}
  if (j && j.error) addLine(lines, 'error', j.error);

  const device = j && j.device_profile;
  if (device) {{
    addLine(lines, 'PD model', device.photodetector_model);
    addLine(lines, 'scope CH1 response', device.scope_ch1_response_v_per_w !== null && device.scope_ch1_response_v_per_w !== undefined ? `${{Number(device.scope_ch1_response_v_per_w).toPrecision(5)}} V/W` : null);
    addLine(lines, 'scope CH2 response', device.scope_ch2_response_v_per_w !== null && device.scope_ch2_response_v_per_w !== undefined ? `${{Number(device.scope_ch2_response_v_per_w).toPrecision(5)}} V/W` : null);
    if (device.scope_zero_enabled) {{
      const z1 = device.scope_ch1_zero_offset_v !== null && device.scope_ch1_zero_offset_v !== undefined ? `${{(Number(device.scope_ch1_zero_offset_v) * 1e3).toFixed(3)}} mV` : '-';
      const z2 = device.scope_ch2_zero_offset_v !== null && device.scope_ch2_zero_offset_v !== undefined ? `${{(Number(device.scope_ch2_zero_offset_v) * 1e3).toFixed(3)}} mV` : '-';
      lines.push(`scope display zero: on, CH1 ${{z1}}, CH2 ${{z2}}`);
    }} else {{
      lines.push('scope display zero: off');
    }}
    addLine(lines, 'PD saturation', device.saturation_power_uw !== null && device.saturation_power_uw !== undefined ? `${{Number(device.saturation_power_uw).toPrecision(5)}} uW` : null);
    const rfParts = [];
    if (device.bias_tee_enabled) rfParts.push(`bias tee=${{device.bias_tee_model || 'on'}}`);
    if (device.amplifier_enabled) rfParts.push(`amp=${{device.amplifier_model || 'on'}}`);
    if (rfParts.length) lines.push(`RF path: ${{rfParts.join(', ')}}`);
    addLine(lines, 'spectrum external_gain', device.spectrum_external_gain_db !== null && device.spectrum_external_gain_db !== undefined ? `${{Number(device.spectrum_external_gain_db).toFixed(3)}} dB (${{device.spectrum_external_gain_source || 'config'}})` : null);
  }}

  const instruments = j && j.instruments;
  if (instruments) {{
    const rp = instruments.red_pitaya || {{}};
    const laser = instruments.laser || {{}};
    const scope = instruments.oscilloscope || {{}};
    lines.push(`RP / PyRPL: ${{rp.type || '-'}} ${{rp.bridge_base || ''}} (${{rp.ok === null || rp.ok === undefined ? 'skipped' : (rp.ok ? 'ok' : 'not responding')}})`);
    lines.push(`Laser: ${{laser.type || '-'}} ${{laser.host || laser.port || ''}} (${{laser.ok === null || laser.ok === undefined ? 'skipped' : (laser.ok ? 'ok' : 'not responding')}})`);
    lines.push(`Oscilloscope: ${{scope.type || '-'}} ${{scope.scope_resource || ''}} (${{scope.ok === null || scope.ok === undefined ? 'skipped' : (scope.ok ? 'ok' : 'not responding')}})`);
  }}

  const weiyuan = j && j.weiyuan;
  if (weiyuan) {{
    lines.push(`micro-source: ${{weiyuan.port || '-'}}, mode=${{weiyuan.mode_label || weiyuan.mode}}`);
    addLine(lines, 'TEC temp', weiyuan.tec_temp_c !== undefined ? `${{Number(weiyuan.tec_temp_c).toFixed(3)}} C` : null);
    addLine(lines, 'TEC set', weiyuan.tec_set_temp_c !== undefined ? `${{Number(weiyuan.tec_set_temp_c).toFixed(3)}} C` : null);
    addLine(lines, 'LD actual', weiyuan.ld_current_actual_ma !== undefined ? `${{Number(weiyuan.ld_current_actual_ma).toFixed(3)}} mA` : null);
    addLine(lines, 'LD set', weiyuan.ld_set_current_ma !== undefined ? `${{Number(weiyuan.ld_set_current_ma).toFixed(3)}} mA` : null);
    lines.push(`TEC/LD enabled: ${{weiyuan.tec_enabled ? 'on' : 'off'}} / ${{weiyuan.ld_enabled ? 'on' : 'off'}}`);
  }}

  const spectrum = j && j.spectrum;
  if (spectrum) {{
    addLine(lines, 'spectrum raw', spectrum.raw_path);
    addLine(lines, 'spectrum meta', spectrum.metadata_path);
    addLine(lines, 'spectrum html', spectrum.plot_html);
    addLine(lines, 'spectrum rbw', spectrum.rbw_hz !== undefined && spectrum.rbw_hz !== null ? `${{Number(spectrum.rbw_hz).toPrecision(6)}} Hz` : null);
    addLine(lines, 'spectrum n', spectrum.n);
    const specSummary = spectrum.summary || {{}};
    const specPower = specSummary.input1_dbm_per_hz || specSummary.dbm_per_hz || {{}};
    addLine(lines, 'spectrum median', specPower.median !== undefined ? `${{Number(specPower.median).toFixed(2)}} dBm/Hz` : null);
    const corr = spectrum.display_power_correction || {{}};
    addLine(lines, 'spectrum correction', corr.total_subtracted_db !== undefined ? `${{Number(corr.total_subtracted_db).toFixed(3)}} dB subtracted` : null);
  }}

  const network = j && j.network;
  if (network) {{
    addLine(lines, 'network raw', network.raw_path);
    addLine(lines, 'network meta', network.metadata_path);
    addLine(lines, 'network html', network.plot_html);
    addLine(lines, 'network input', network.input);
    addLine(lines, 'network output', network.output_direct);
    addLine(lines, 'network amplitude', network.amplitude_v !== undefined && network.amplitude_v !== null ? `${{Number(network.amplitude_v).toPrecision(5)}} ${{network.amplitude_unit || 'V'}}` : null);
    addLine(lines, 'network n', network.n);
    const display = network.power_display || {{}};
    addLine(lines, 'network display', display.display_unit ? `${{display.display_unit}}, correction=${{Number(display.total_subtracted_db || 0).toFixed(3)}} dB` : null);
    const netSummary = network.summary || {{}};
    const netDbm = netSummary.magnitude_dbm || {{}};
    const netDb = netSummary.magnitude_db || {{}};
    addLine(lines, 'network median', netDbm.median !== undefined ? `${{Number(netDbm.median).toFixed(2)}} dBm` : (netDb.median !== undefined ? `${{Number(netDb.median).toFixed(2)}} dB` : null));
  }}

  const hostCheck = j && j.host_check;
  if (hostCheck) {{
    addLine(lines, 'RP host', hostCheck.host);
    if (hostCheck.addresses && hostCheck.addresses.length) {{
      lines.push(`resolved: ${{hostCheck.addresses.map(item => `${{item.family}} ${{item.address}}`).join(', ')}}`);
    }}
    if (hostCheck.warnings && hostCheck.warnings.length) lines.push(`warning: ${{hostCheck.warnings.join('; ')}}`);
    addLine(lines, 'external_gain if started', hostCheck.external_gain_db_if_started !== undefined ? `${{hostCheck.external_gain_db_if_started}} dB` : null);
  }}

  const pyrplConfig = j && j.pyrpl_config;
  if (pyrplConfig) {{
    addLine(lines, 'PyRPL config', pyrplConfig.config_path);
    addLine(lines, 'PyRPL host/timeout', pyrplConfig.hostname ? `${{pyrplConfig.hostname}}, timeout=${{pyrplConfig.timeout_s}} s, reloadserver=${{pyrplConfig.reloadserver ? 'true' : 'false'}}` : null);
    addLine(lines, 'PyRPL spectrum window', pyrplConfig.spectrumanalyzer_window);
    if (pyrplConfig.actions && pyrplConfig.actions.length) lines.push(`PyRPL config actions: ${{pyrplConfig.actions.join(', ')}}`);
  }}

  const bridgeStatus = j && j.status;
  if (bridgeStatus) {{
    const process = bridgeStatus.process || {{}};
    const health = bridgeStatus.health || {{}};
    const bridge = health.bridge || {{}};
    const correction = health.spectrum_power_correction || {{}};
    lines.push(`bridge http: ${{bridgeStatus.ok ? 'ok' : 'not responding'}}`);
    lines.push(`bridge process: ${{process.managed ? 'dashboard-managed' : 'external/none'}}, ${{process.running ? 'running' : 'not running'}}${{process.pid ? ', pid=' + process.pid : ''}}`);
    addLine(lines, 'bridge python', process.python_executable);
    addLine(lines, 'bridge RP host', process.rp_host);
    addLine(lines, 'PyRPL connect host', process.pyrpl_host);
    addLine(lines, 'bridge external_gain', process.external_gain_db !== null && process.external_gain_db !== undefined ? `${{process.external_gain_db}} dB` : null);
    addLine(lines, 'bridge log', process.log_path);
    if (!bridgeStatus.ok && process.log_tail) {{
      lines.push(`bridge log tail:\\n${{String(process.log_tail).slice(-1600)}}`);
    }}
    addLine(lines, 'live bridge pid', bridge.pid);
    addLine(lines, 'live bridge python', bridge.python_executable);
    addLine(lines, 'live bridge PyRPL', bridge.pyrpl_version && bridge.pyrpl_file ? `${{bridge.pyrpl_version}} @ ${{bridge.pyrpl_file}}` : null);
    addLine(lines, 'live bridge config', bridge.config);
    addLine(lines, 'live bridge RP host', bridge.hostname);
    addLine(lines, 'live bridge mode', bridge.headless === true ? 'headless' : (bridge.headless === false ? 'GUI' : null));
    addLine(lines, 'live bridge uptime', bridge.uptime_s !== null && bridge.uptime_s !== undefined ? `${{Number(bridge.uptime_s).toFixed(1)}} s` : null);
    addLine(lines, 'live spectrum correction', correction.total_subtracted_db !== null && correction.total_subtracted_db !== undefined ? `${{Number(correction.total_subtracted_db).toFixed(3)}} dB subtracted` : null);
  }}

  const power = j && j.power;
  if (power) {{
    addLine(lines, '1% monitor', power.input_monitor_power_uw !== null && power.input_monitor_power_uw !== undefined ? `${{Number(power.input_monitor_power_uw).toFixed(4)}} uW` : null);
    addLine(lines, 'Pout', power.output_power_uw !== null && power.output_power_uw !== undefined ? `${{Number(power.output_power_uw).toFixed(4)}} uW` : null);
    addLine(lines, 'single-ended loss', power.single_ended_loss_db !== null && power.single_ended_loss_db !== undefined ? `${{Number(power.single_ended_loss_db).toFixed(2)}} dB` : null);
    addLine(lines, 'power source', power.source);
  }}

  const q = j && j.q;
  if (q) {{
    addLine(lines, 'Q rows', q.q_rows);
    addLine(lines, 'Q dir', q.q_dir);
  }}

  const c = j && j.candidate;
  if (c) {{
    const family = c.family_label || c.family || '-';
    lines.push(`target: ${{family}}, mu=${{c.mode_number ?? '-'}}, ${{fmt(c.wavelength_nm, 6)}} nm`);
    lines.push(`Q0 / Q1 / QL: ${{qfmt(c.Q0)}} / ${{qfmt(c.Q1)}} / ${{qfmt(c.QL)}} M`);
    addLine(lines, 'depth', fmt(c.depth, 3));
  }}

  const move = j && j.wavelength_move;
  if (move) {{
    const before = move.before_read_nm ?? move.before_set_nm;
    const after = move.after_read_nm ?? move.after_set_nm ?? move.target_nm;
    lines.push(`wavelength: ${{fmt(before, 6)}} -> ${{fmt(after, 6)}} nm`);
    addLine(lines, 'move ok', move.ok);
  }}

  const prelock = j && j.prelock;
  if (prelock) {{
    const pc = prelock.pc_start || {{}};
    const parts = [];
    if (pc.voltage_set !== undefined) parts.push(`PC=${{pc.voltage_set}} V`);
    if (prelock.arc_factor !== undefined) parts.push(`ARC=${{prelock.arc_factor}}`);
    if (prelock.pc_enabled !== undefined) parts.push(`PC enabled=${{prelock.pc_enabled}}`);
    if (parts.length) lines.push(`prelock: ${{parts.join(', ')}}`);
  }}

  if (payload && payload.stderr_tail && payload.stderr_tail.trim()) lines.push('stderr: see raw details');
  const restore = j && j.restore;
  if (restore) {{
    const good = (restore.steps || []).filter(step => step.ok).length;
    const total = (restore.steps || []).length;
    lines.push(`restore steps: ${{good}}/${{total}} ok`);
  }}
  return lines.join('\\n');
}}
function renderCompactResult(el, payload) {{
  el.innerHTML = '';
  const summary = document.createElement('div');
  summary.className = `result-summary ${{payload && payload.ok ? 'result-ok' : 'result-bad'}}`;
  summary.textContent = summarizePayload(payload);
  el.appendChild(summary);

  const details = document.createElement('details');
  const detailsTitle = document.createElement('summary');
  detailsTitle.textContent = 'raw details';
  const raw = document.createElement('pre');
  raw.textContent = JSON.stringify(payload, null, 2);
  details.appendChild(detailsTitle);
  details.appendChild(raw);
  el.appendChild(details);
}}
function renderErrorResult(el, error) {{
  if (error && typeof error === 'object' && error.ok !== undefined) {{
    renderCompactResult(el, error);
  }} else {{
    renderCompactResult(el, {{ok:false, error}});
  }}
}}
function renderStepResults(el, steps) {{
  const ok = steps.every(step => step.payload && step.payload.ok);
  renderCompactResult(el, {{
    ok,
    message: steps.map(step => `${{step.name}}: ${{step.payload && step.payload.ok ? 'ok' : 'failed'}}`).join('; '),
    steps
  }});
}}

async function refreshHealth() {{
  const el = document.getElementById('health');
  updateInstrumentHeader();
  el.textContent = 'checking...';
  try {{
    const params = new URLSearchParams(instrumentBody());
    renderCompactResult(el, await api('/api/health?' + params.toString()));
  }}
  catch(e) {{ el.textContent = JSON.stringify(e, null, 2); }}
}}
async function safeOff() {{
  const el = document.getElementById('health');
  el.textContent = 'safe-off running...';
  try {{ renderCompactResult(el, await api('/api/safe_off', instrumentBody())); }}
  catch(e) {{ el.textContent = JSON.stringify(e, null, 2); }}
}}
async function runBridgeAction() {{
  const el = document.getElementById('health');
  updateInstrumentHeader();
  const action = document.getElementById('bridgeAction').value;
  el.textContent = `bridge action: ${{action}}...`;
  try {{
    renderCompactResult(el, await api('/api/bridge/action', {{...instrumentBody(), bridge_action: action}}));
  }} catch(e) {{ renderErrorResult(el, e); }}
}}
async function runWeiyuan(action) {{
  const el = document.getElementById('weiyuanResult');
  updateInstrumentHeader();
  el.textContent = `micro-source action: ${{action}}...`;
  const body = {{
    ...instrumentBody(),
    weiyuan_action: action,
    temperature_c: document.getElementById('weiyuanTempInput').value,
    current_ma: document.getElementById('weiyuanCurrentInput').value,
    weiyuan_slave: document.getElementById('weiyuanSlaveInput').value
  }};
  try {{ renderCompactResult(el, await api('/api/weiyuan/action', body)); }}
  catch(e) {{ renderErrorResult(el, e); }}
}}
function setNumberInput(id, value, fallback='') {{
  const el = document.getElementById(id);
  if (!el) return;
  if (value === null || value === undefined || value === '' || Number.isNaN(Number(value))) {{
    el.value = fallback;
  }} else {{
    el.value = Number(value).toPrecision(8);
  }}
}}
function optionLabelHz(value) {{
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  if (Math.abs(n) >= 1e6) return `${{(n/1e6).toPrecision(7)}} MHz`;
  if (Math.abs(n) >= 1e3) return `${{(n/1e3).toPrecision(7)}} kHz`;
  return `${{n.toPrecision(7)}} Hz`;
}}
function setNumericOptions(id, options, current, fallbackOptions=[]) {{
  const el = document.getElementById(id);
  if (!el) return;
  const values = (Array.isArray(options) && options.length ? options : fallbackOptions)
    .map(v => Number(v))
    .filter(v => Number.isFinite(v));
  el.innerHTML = '';
  for (const v of values) {{
    const option = document.createElement('option');
    option.value = String(v);
    option.textContent = optionLabelHz(v);
    el.appendChild(option);
  }}
  if (!values.length) {{
    const option = document.createElement('option');
    option.value = current === null || current === undefined ? '' : String(current);
    option.textContent = current === null || current === undefined ? '-' : optionLabelHz(current);
    el.appendChild(option);
  }}
  setClosestNumericOption(id, current);
}}
function setClosestNumericOption(id, current) {{
  const el = document.getElementById(id);
  if (!el || !el.options.length) return;
  const target = Number(current);
  if (!Number.isFinite(target)) return;
  let best = el.options[0], bestErr = Math.abs(Number(best.value) - target);
  for (const option of el.options) {{
    const err = Math.abs(Number(option.value) - target);
    if (err < bestErr) {{ best = option; bestErr = err; }}
  }}
  el.value = best.value;
}}
function setSpectrumSpanOptions(pairs, currentSpan, currentRbw) {{
  const span = document.getElementById('spectrumSpanHz');
  span.innerHTML = '';
  const rows = Array.isArray(pairs) && pairs.length ? pairs : [
    {{span_hz:31250000, rbw_hz:5381}},
    {{span_hz:15625000, rbw_hz:2690}},
    {{span_hz:7812500, rbw_hz:1345}},
    {{span_hz:3906250, rbw_hz:672}},
  ];
  for (const row of rows) {{
    const option = document.createElement('option');
    option.value = String(Number(row.span_hz));
    option.dataset.rbw = String(Number(row.rbw_hz));
    option.textContent = `${{optionLabelHz(row.span_hz)}}  /  RBW ${{optionLabelHz(row.rbw_hz)}}`;
    span.appendChild(option);
  }}
  setClosestNumericOption('spectrumSpanHz', currentSpan);
  syncSpectrumRbwFromSpan(currentRbw);
}}
function syncSpectrumRbwFromSpan(preferredRbw=null) {{
  const span = document.getElementById('spectrumSpanHz');
  const rbw = document.getElementById('spectrumRbwHz');
  rbw.innerHTML = '';
  const selected = span.selectedOptions[0];
  const value = preferredRbw !== null && preferredRbw !== undefined ? preferredRbw : (selected ? selected.dataset.rbw : '');
  const option = document.createElement('option');
  option.value = String(value || '');
  option.textContent = value ? optionLabelHz(value) : '-';
  rbw.appendChild(option);
}}
function setPressureSourceOptions(sources, currentPath, currentSourceModel) {{
  const select = document.getElementById('pressureSourceModel');
  if (!select) return;
  const rows = Array.isArray(sources) ? sources : [];
  select.innerHTML = '';
  const manual = document.createElement('option');
  manual.value = '';
  manual.textContent = 'manual file path';
  select.appendChild(manual);
  const normalizedCurrent = String(currentPath || '').replaceAll('\\\\', '/').toLowerCase();
  let selectedValue = '';
  for (const source of rows) {{
    const option = document.createElement('option');
    option.value = source.id || source.model || source.label || '';
    option.textContent = source.label || source.model || source.id || option.value;
    option.dataset.path = source.path || '';
    option.dataset.drive = source.calibration_drive_vpp || '';
    option.dataset.quantity = source.pressure_quantity || 'pk';
    option.dataset.exists = source.exists ? '1' : '0';
    select.appendChild(option);
    const normalizedPath = String(source.path || '').replaceAll('\\\\', '/').toLowerCase();
    if (
      (currentSourceModel && option.value === currentSourceModel) ||
      (normalizedCurrent && normalizedPath && normalizedCurrent === normalizedPath)
    ) {{
      selectedValue = option.value;
    }}
  }}
  select.value = selectedValue;
  select.onchange = () => {{
    const option = select.selectedOptions[0];
    if (!option || !option.value) return;
    document.getElementById('pressureCalibrationPath').value = option.dataset.path || '';
    if (option.dataset.drive) setNumberInput('pressureCalibrationDriveVpp', option.dataset.drive, '10');
    document.getElementById('pressureQuantity').value = String(option.dataset.quantity || 'pk').toLowerCase().includes('rms') ? 'rms' : 'pk';
    document.getElementById('pressureInfo').textContent = option.dataset.exists === '1' ? 'Pressure source selected; calibration range will be read from the npz before acquisition.' : 'Selected pressure source has no readable default npz.';
  }};
}}
function openSensitivitySettings(mode, settings=null, note='Review PyRPL settings before acquisition.') {{
  document.getElementById('spectrumSettingsGroup').classList.toggle('hidden', !(mode === 'psd' || mode === 'both'));
  document.getElementById('networkSettingsGroup').classList.toggle('hidden', !(mode === 'network' || mode === 'both'));
  document.getElementById('pressureSettingsGroup').classList.toggle('hidden', !(mode === 'both' || mode === 'compute'));
  document.getElementById('sensitivitySettingsNote').textContent = note;
  const spectrum = (settings && settings.spectrum) || {{}};
  const network = (settings && settings.network) || {{}};
  const pressure = (settings && settings.pressure_calibration) || {{}};
  setSpectrumSpanOptions(spectrum.span_rbw_options, spectrum.span_hz, spectrum.rbw_hz);
  setNumberInput('spectrumTraceAverage', spectrum.trace_average, '1');
  const pointText = spectrum.display_points ? `Spectrum points: ${{spectrum.display_points}} shown by PyRPL before dashboard downsampling; data_length=${{spectrum.data_length || '-'}}, window=${{spectrum.window || '-'}}.` : 'Spectrum points are fixed by the PyRPL scope FFT path.';
  document.getElementById('spectrumPointInfo').textContent = pointText;
  setNumberInput('networkAmplitudeVpk', network.amplitude_vpk, '1');
  setNumberInput('networkStartHz', network.start_freq_hz, '1000');
  setNumberInput('networkStopHz', network.stop_freq_hz, '1000000');
  setNumberInput('networkPoints', network.points, '10001');
  setNumericOptions('networkRbwHz', network.rbw_options, network.rbw_hz, [151.78256, 303.56512, 607.13025, 1214.2605, 2428.521, 4857.042, 9714.084]);
  setPressureSourceOptions(settings && settings.pressure_sources, pressure.path, pressure.source_model);
  document.getElementById('pressureCalibrationPath').value = pressure.path || '';
  const pStart = Number(pressure.start_hz);
  const pStop = Number(pressure.stop_hz);
  const pPoints = pressure.points || '-';
  document.getElementById('pressureCalibrationRange').value = Number.isFinite(pStart) && Number.isFinite(pStop) ? `${{optionLabelHz(pStart)}} - ${{optionLabelHz(pStop)}} (${{pPoints}} pts)` : (pressure.error || 'not loaded');
  setNumberInput('pressureCalibrationDriveVpp', pressure.calibration_drive_vpp, '10');
  document.getElementById('pressureQuantity').value = (pressure.pressure_quantity || 'pk').toLowerCase().includes('rms') ? 'rms' : 'pk';
  setNumberInput('pressureUseStartHz', pressure.use_start_hz || pressure.start_hz, pressure.start_hz || '10000');
  setNumberInput('pressureUseStopHz', pressure.use_stop_hz || pressure.stop_hz, pressure.stop_hz || '1000000');
  document.getElementById('pressureInfo').textContent = pressure.error ? `Pressure calibration load failed: ${{pressure.error}}` : `Default use range follows calibration data; edit only when you want a narrower band.`;
  document.getElementById('sensitivitySettingsModal').classList.remove('hidden');
}}
function closeSensitivitySettings() {{
  document.getElementById('sensitivitySettingsModal').classList.add('hidden');
  pendingSensitivityBody = null;
}}
function sensitivitySettingBody() {{
  const mode = (pendingSensitivityBody && pendingSensitivityBody.acquisition_mode) || document.getElementById('sensitivityMode').value;
  const body = {{
    pressure_source_model: document.getElementById('pressureSourceModel').value,
    pressure_calibration_path: document.getElementById('pressureCalibrationPath').value,
    pressure_calibration_drive_vpp: document.getElementById('pressureCalibrationDriveVpp').value,
    pressure_quantity: document.getElementById('pressureQuantity').value,
    pressure_use_start_hz: document.getElementById('pressureUseStartHz').value,
    pressure_use_stop_hz: document.getElementById('pressureUseStopHz').value
  }};
  if (mode !== 'compute') {{
    Object.assign(body, {{
    spectrum_span_hz: document.getElementById('spectrumSpanHz').value,
    spectrum_rbw_hz: document.getElementById('spectrumRbwHz').value,
    spectrum_trace_average: document.getElementById('spectrumTraceAverage').value,
    network_amplitude_vpk: document.getElementById('networkAmplitudeVpk').value,
    network_start_freq_hz: document.getElementById('networkStartHz').value,
    network_stop_freq_hz: document.getElementById('networkStopHz').value,
    network_points: document.getElementById('networkPoints').value,
    network_rbw_hz: document.getElementById('networkRbwHz').value
    }});
  }}
  return body;
}}
async function runSensitivityAcquisition() {{
  const el = document.getElementById('sensitivityResult');
  updateInstrumentHeader();
  const mode = document.getElementById('sensitivityMode').value;
  pendingSensitivityBody = {{
    ...bodyBase(),
    tag_prefix: document.getElementById('sensitivityTag').value,
    acquisition_mode: mode,
    spectrum_timeout_s: document.getElementById('sensitivitySpectrumTimeout').value,
    network_timeout_s: document.getElementById('sensitivityNetworkTimeout').value,
    max_points: document.getElementById('sensitivityMaxPoints').value,
    optical_mode: chosenCandidate(),
    target_kind: document.getElementById('targetKind').value,
    acquire: true
  }};
  el.textContent = 'loading current PyRPL acquisition settings...';
  try {{
    const settings = await api('/api/sensitivity/settings', {{...bodyBase(), acquisition_mode: mode}});
    renderCompactResult(el, {{ok:true, json:{{message:'settings loaded; confirm to run'}}}});
    openSensitivitySettings(mode, settings, 'Current PyRPL settings loaded. Edit values, then confirm acquisition.');
  }} catch(e) {{
    renderCompactResult(el, {{ok:false, json:{{message:'could not read current settings; using editable defaults', error:e.error || JSON.stringify(e)}}}});
    openSensitivitySettings(mode, null, 'Could not read current PyRPL settings. Defaults are editable; confirm only if they are correct.');
  }}
}}
async function confirmSensitivityAcquisition() {{
  const el = document.getElementById('sensitivityResult');
  if (!pendingSensitivityBody) {{
    el.textContent = 'no pending sensitivity acquisition';
    return;
  }}
  const mode = pendingSensitivityBody.acquisition_mode;
  const modeText = mode === 'psd' ? 'noise PSD' : (mode === 'network' ? 'network response' : (mode === 'compute' ? 'sensitivity from existing raw data' : 'noise PSD, then network response'));
  const body = {{...pendingSensitivityBody, ...sensitivitySettingBody()}};
  closeSensitivitySettings();
  el.textContent = `applying settings and capturing ${{modeText}}...`;
  sensitivityAbortController = new AbortController();
  setSensitivityBusy(true);
  try {{
    const result = await api('/api/sensitivity/acquire', body, {{signal: sensitivityAbortController.signal}});
    renderCompactResult(el, result);
    if (result.no_cavity_dir && result.output_dir) {{
      alert(`No cavity directory was selected. Data saved to:\\n${{result.output_dir}}`);
    }}
  }} catch(e) {{
    if (e && e.name === 'AbortError') {{
      renderCompactResult(el, {{ok:false, json:{{message:'cancel requested; waiting for instrument call to unwind if PyRPL was already busy'}}}});
    }} else {{
      renderErrorResult(el, e);
    }}
  }} finally {{
    sensitivityAbortController = null;
    setSensitivityBusy(false);
  }}
}}
function setSensitivityBusy(isBusy) {{
  document.getElementById('runSensitivityButton').disabled = isBusy;
  document.getElementById('cancelSensitivityButton').classList.toggle('hidden', !isBusy);
}}
async function cancelSensitivityAcquisition() {{
  const el = document.getElementById('sensitivityResult');
  if (sensitivityAbortController) sensitivityAbortController.abort();
  renderCompactResult(el, {{ok:false, json:{{message:'cancel requested'}}}});
  try {{
    const result = await api('/api/sensitivity/cancel', bodyBase());
    renderCompactResult(el, result);
  }} catch(e) {{
    renderErrorResult(el, e);
  }}
}}
async function loadCavity() {{
  const el = document.getElementById('targetResult');
  const path = document.getElementById('cavityDir').value.trim();
  if (!path) {{
    cavity = null;
    manualSelectedRow = null;
    document.getElementById('qRows').innerHTML = '';
    document.getElementById('targetPreview').innerHTML = '<span class="muted">Choose a cavity directory when needed.</span>';
    renderCompactResult(el, {{ok:true, json:{{message:'no cavity selected'}}}});
    return;
  }}
  el.textContent = 'loading cavity...';
  try {{
    cavity = await api('/api/cavity?cavity_dir=' + encodeURIComponent(path));
    manualSelectedRow = null;
    renderRows();
    renderTarget();
    await loadLargeScanStatus();
    renderCompactResult(el, {{ok:true, json:{{message:'cavity loaded', q_rows:cavity.q_rows.length, manifest_path:cavity.manifest_path}}}});
  }} catch(e) {{ renderErrorResult(el, e); }}
}}
async function browseCavity() {{
  const el = document.getElementById('targetResult');
  el.textContent = 'opening folder picker...';
  try {{
    const result = await api('/api/pick_folder', {{initial_dir: document.getElementById('cavityDir').value}});
    if (result.cancelled) {{
      renderCompactResult(el, {{ok:true, json:{{message:'folder picker cancelled'}}}});
      return;
    }}
    if (result.path) {{
      document.getElementById('cavityDir').value = result.path;
      await loadCavity();
      return;
    }}
    renderCompactResult(el, result);
  }} catch(e) {{ renderErrorResult(el, e); }}
}}
function chosenCandidate() {{
  if (!cavity || !cavity.manifest) return null;
  const kind = document.getElementById('targetKind').value;
  if (kind === 'candidate') return cavity.manifest.candidate;
  if (kind === 'nearest_1550') return cavity.manifest.nearest_1550_best_q_candidate;
  const wl = Number(document.getElementById('manualWavelength').value);
  if (!Number.isFinite(wl)) return null;
  if (manualSelectedRow && Math.abs(Number(manualSelectedRow.wavelength_nm) - wl) < 1e-6) return manualSelectedRow;
  const matched = (cavity.q_rows || []).find(row => Math.abs(Number(row.wavelength_nm) - wl) < 1e-6);
  return matched || {{family:'manual', family_label:'manual', mode_number:'-', wavelength_nm:wl, Q0:null, Q1:null, QL:null, depth:null}};
}}
function renderTarget() {{
  const c = chosenCandidate();
  const el = document.getElementById('targetPreview');
  if (!c) {{ el.innerHTML = '<span class="muted">No target loaded.</span>'; return; }}
  el.innerHTML = `
    <span>family</span><b>${{c.family_label || c.family || '-'}}</b>
    <span>mu</span><b>${{c.mode_number ?? '-'}}</b>
    <span>wavelength</span><b>${{fmt(c.wavelength_nm, 6)}} nm</b>
    <span>Q0 / Q1 / QL</span><b>${{qfmt(c.Q0)}} / ${{qfmt(c.Q1)}} / ${{qfmt(c.QL)}} M</b>
    <span>depth</span><b>${{fmt(c.depth, 3)}}</b>`;
}}
function renderRows() {{
  const tbody = document.getElementById('qRows');
  tbody.innerHTML = '';
  if (!cavity) return;
  for (const row of cavity.q_rows) {{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${{row.family_label || row.family}}</td><td>${{row.mode_number}}</td><td>${{fmt(row.wavelength_nm,6)}}</td><td>${{qfmt(row.Q0)}}</td><td>${{qfmt(row.Q1)}}</td><td>${{qfmt(row.QL)}}</td><td>${{fmt(row.depth,3)}}</td>`;
    tr.onclick = () => {{
      manualSelectedRow = row;
      document.getElementById('targetKind').value = 'manual';
      document.getElementById('manualWavelength').value = fmt(row.wavelength_nm, 9);
      renderTarget();
    }};
    tbody.appendChild(tr);
  }}
}}
function targetBody() {{
  const kind = document.getElementById('targetKind').value;
  const body = {{...bodyBase(), target_kind: kind}};
  if (kind === 'manual') body.wavelength_nm = document.getElementById('manualWavelength').value;
  return body;
}}
function requireCavityPath(el) {{
  const path = document.getElementById('cavityDir').value.trim();
  if (!path) {{
    renderCompactResult(el, {{ok:false, error:'Select a cavity directory first. Use Browse... or paste the cavity folder path.'}});
    return null;
  }}
  return path;
}}
function powerBody() {{
  return {{
    ...bodyBase(),
    input_monitor_power_uw: document.getElementById('inputMonitorPower').value,
    input_monitor_fraction: 0.01,
    output_power_uw: document.getElementById('outputPower').value
  }};
}}
function updateLossPreview() {{
  const monitor = Number(document.getElementById('inputMonitorPower').value);
  const pout = Number(document.getElementById('outputPower').value);
  const loss = document.getElementById('singleEndedLoss');
  if (!Number.isFinite(monitor) || monitor <= 0 || !Number.isFinite(pout) || pout < 0) {{
    loss.value = '';
    return;
  }}
  const inputPower = monitor / 0.01;
  const throughput = pout / inputPower;
  loss.value = throughput > 0 ? (-10 * Math.log10(Math.sqrt(throughput))).toFixed(2) : 'undefined';
}}
function fillPower(power) {{
  const source = document.getElementById('powerSource');
  if (!power) {{
    document.getElementById('inputMonitorPower').value = '';
    document.getElementById('outputPower').value = '';
    document.getElementById('singleEndedLoss').value = '';
    source.textContent = 'no previous power record';
    return;
  }}
  document.getElementById('inputMonitorPower').value = power.input_monitor_power_uw ?? '';
  document.getElementById('outputPower').value = power.output_power_uw ?? '';
  updateLossPreview();
  source.textContent = power.source ? `loaded from ${{power.source}}` : 'loaded previous power record';
}}
async function loadLargeScanStatus() {{
  const el = document.getElementById('largeScanResult');
  const path = document.getElementById('cavityDir').value.trim();
  if (!path) {{
    fillPower(null);
    renderCompactResult(el, {{ok:true, json:{{message:'no cavity selected'}}}});
    return;
  }}
  try {{
    const status = await api('/api/large_scan/status?cavity_dir=' + encodeURIComponent(path));
    fillPower(status.power);
    renderCompactResult(el, {{ok:true, json:{{message:'large-scan status loaded', power:status.power, q:status.q}}}});
  }} catch(e) {{
    fillPower(null);
    renderErrorResult(el, e);
  }}
}}
async function savePower() {{
  const el = document.getElementById('largeScanResult');
  if (!requireCavityPath(el)) return;
  el.textContent = 'saving power and refreshing card...';
  try {{
    const result = await api('/api/power/update', powerBody());
    if (result.json && result.json.power) fillPower(result.json.power);
    renderCompactResult(el, result);
  }} catch(e) {{ renderErrorResult(el, e); }}
}}
async function runStandardCoupling() {{
  const el = document.getElementById('couplingResult');
  const button = document.getElementById('runCouplingButton');
  el.textContent = 'running standard auto coupling...';
  button.disabled = true;
  try {{
    renderCompactResult(el, await api('/api/coupling/standard', bodyBase()));
    await loadLargeScanStatus();
  }} catch(e) {{
    renderErrorResult(el, e);
  }} finally {{
    button.disabled = false;
  }}
}}
async function runLargeScan(mode) {{
  const el = document.getElementById('largeScanResult');
  if (!requireCavityPath(el)) return;
  const labels = {{run:'running large scan Q...', resume:'resuming from existing raw...', standardize:'standardizing existing outputs...'}};
  el.textContent = labels[mode] || 'running...';
  try {{
    renderCompactResult(el, await api('/api/large_scan/run', {{...bodyBase(), mode}}));
    await loadCavity();
  }} catch(e) {{ renderErrorResult(el, e); }}
}}
async function stopLargeScan() {{
  const el = document.getElementById('largeScanResult');
  if (!requireCavityPath(el)) return;
  el.textContent = 'stopping large scan and restoring idle state...';
  try {{
    renderCompactResult(el, await api('/api/large_scan/stop', {{...bodyBase()}}));
    await loadLargeScanStatus();
  }} catch(e) {{ renderErrorResult(el, e); }}
}}
async function dryRunTarget() {{
  const el = document.getElementById('targetResult');
  if (!requireCavityPath(el)) return;
  el.textContent = 'dry-run...';
  try {{ renderCompactResult(el, await api('/api/target/dry_run', targetBody())); }}
  catch(e) {{ renderErrorResult(el, e); }}
}}
async function moveTarget() {{
  const el = document.getElementById('targetResult');
  if (!requireCavityPath(el)) return;
  el.textContent = 'moving wavelength, then restoring sweep / PID off...';
  try {{
    const moveResult = await api('/api/target/move', targetBody());
    let restoreResult;
    try {{
      restoreResult = await api('/api/lock/restore_sweep', bodyBase());
    }} catch (restoreError) {{
      restoreResult = (restoreError && typeof restoreError === 'object')
        ? restoreError
        : {{ok: false, error: restoreError}};
    }}
    renderStepResults(el, [
      {{name: 'move target wavelength', payload: moveResult}},
      {{name: 'restore sweep / PID off', payload: restoreResult}}
    ]);
  }}
  catch(e) {{ renderErrorResult(el, e); }}
}}
async function lockCurrent() {{
  const el = document.getElementById('targetResult');
  el.textContent = 'locking current mode...';
  try {{ renderCompactResult(el, await api('/api/lock/current', bodyBase())); }}
  catch(e) {{ renderErrorResult(el, e); }}
}}
async function restoreLockSweep(resultId='targetResult') {{
  const el = document.getElementById(resultId);
  el.textContent = 'restoring sweep and disabling PID...';
  try {{ renderCompactResult(el, await api('/api/lock/restore_sweep', bodyBase())); }}
  catch(e) {{ renderErrorResult(el, e); }}
}}
function finiteArray(arr) {{
  return (arr || []).map(Number).filter(Number.isFinite);
}}
function drawAxes(ctx, w, h, padL, padR, padT, padB) {{
  ctx.strokeStyle = '#d0d0d0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 0; i <= 4; i++) {{
    const y = padT + i * (h - padT - padB) / 4;
    ctx.moveTo(padL, y); ctx.lineTo(w - padR, y);
  }}
  for (let i = 0; i <= 5; i++) {{
    const x = padL + i * (w - padL - padR) / 5;
    ctx.moveTo(x, padT); ctx.lineTo(x, h - padB);
  }}
  ctx.stroke();
  ctx.strokeStyle = '#111';
  ctx.beginPath();
  ctx.rect(padL, padT, w - padL - padR, h - padT - padB);
  ctx.stroke();
}}
function drawXYChart(canvasId, series, options) {{
  const canvas = document.getElementById(canvasId);
  const ctx = canvas.getContext('2d');
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);
  const allX = [];
  const allY = [];
  for (const item of series) {{
    for (let i = 0; i < item.x.length && i < item.y.length; i++) {{
      if (Number.isFinite(item.x[i]) && Number.isFinite(item.y[i])) {{
        allX.push(item.x[i]);
        allY.push(item.y[i]);
      }}
    }}
  }}
  if (!allX.length || !allY.length) {{
    ctx.fillStyle = '#333';
    ctx.font = '14px Arial';
    ctx.fillText(options.emptyText || 'no data returned', 20, 32);
    return;
  }}
  const padL = options.padL || 58, padR = options.padR || 18, padT = options.padT || 18, padB = options.padB || 34;
  let xMin = Math.min(...allX), xMax = Math.max(...allX);
  let yMin = Math.min(...allY), yMax = Math.max(...allY);
  if (!Number.isFinite(xMin) || !Number.isFinite(xMax) || xMin === xMax) {{ xMin -= 1; xMax += 1; }}
  if (!Number.isFinite(yMin) || !Number.isFinite(yMax) || yMin === yMax) {{ yMin -= 1; yMax += 1; }}
  const yPad = Math.max((yMax - yMin) * 0.08, 1e-9);
  yMin -= yPad;
  yMax += yPad;
  const sx = x => padL + (x - xMin) / (xMax - xMin || 1) * (w - padL - padR);
  const sy = y => padT + (yMax - y) / (yMax - yMin || 1) * (h - padT - padB);
  drawAxes(ctx, w, h, padL, padR, padT, padB);
  ctx.font = '12px Arial';
  let legendX = padL + 8;
  for (const item of series) {{
    ctx.strokeStyle = item.color || '#111';
    ctx.lineWidth = item.width || 1.5;
    ctx.beginPath();
    let started = false;
    for (let i = 0; i < item.x.length && i < item.y.length; i++) {{
      const x = item.x[i], y = item.y[i];
      if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
      if (!started) {{ ctx.moveTo(sx(x), sy(y)); started = true; }}
      else ctx.lineTo(sx(x), sy(y));
    }}
    ctx.stroke();
    ctx.fillStyle = '#111';
    ctx.fillText(item.label || '', legendX, padT + 14);
    ctx.fillStyle = item.color || '#111';
    ctx.fillRect(legendX + ctx.measureText(item.label || '').width + 5, padT + 5, 18, 3);
    legendX += Math.max(90, ctx.measureText(item.label || '').width + 34);
  }}
  ctx.fillStyle = '#111';
  ctx.font = '12px Arial';
  ctx.fillText(options.xlabel || '', Math.round(w / 2) - 32, h - 8);
  ctx.save();
  ctx.translate(14, Math.round(h / 2) + 38);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText(options.ylabel || '', 0, 0);
  ctx.restore();
  ctx.fillText(`${{xMin.toPrecision(4)}}`, padL, h - 10);
  ctx.fillText(`${{xMax.toPrecision(4)}}`, w - padR - 60, h - 10);
  ctx.fillText(`${{yMax.toPrecision(4)}}`, 18, padT + 5);
  ctx.fillText(`${{yMin.toPrecision(4)}}`, 18, h - padB);
}}
function drawScopePreview(payload) {{
  const meta = document.getElementById('scopePreviewMeta');
  const trace = payload && payload.trace;
  if (!trace || !trace.t || !trace.t.length) {{
    drawXYChart('scopePreviewCanvas', [], {{emptyText: 'no scope trace returned'}});
    meta.textContent = 'no trace';
    return;
  }}
  const t = trace.t.map(Number);
  const ch1 = trace.ch1.map(Number);
  const ch2 = trace.ch2.map(Number);
  const tMs = t.map(x => x * 1e3);
  drawXYChart('scopePreviewCanvas', [
    {{x: tMs, y: ch1, label: payload.input1 || 'ch1', color: '#168a2f'}},
    {{x: tMs, y: ch2, label: payload.input2 || 'ch2', color: '#c62828'}},
  ], {{xlabel: 'time (ms)', ylabel: 'voltage (V)', emptyText: 'no scope trace returned'}});
  meta.textContent = `${{payload.input1}} / ${{payload.input2}}, n=${{payload.n}}, shown=${{t.length}}, duration=${{Number(payload.duration || 0).toFixed(4)}} s`;
}}
const previewBusy = {{scope: false, spectrum: false, network: false}};
async function refreshScopePreview() {{
  if (previewBusy.scope) return;
  previewBusy.scope = true;
  const el = document.getElementById('targetResult');
  const meta = document.getElementById('scopePreviewMeta');
  meta.textContent = 'capturing...';
  try {{
    const payload = await api('/api/scope/single', {{...instrumentBody(), timeout_s: 5, max_points: 1500}});
    drawScopePreview(payload);
    renderCompactResult(el, {{ok:true, json:{{message:'scope preview refreshed', input1:payload.input1, input2:payload.input2, n:payload.n}}}});
  }} catch(e) {{
    meta.textContent = 'capture failed';
    renderErrorResult(el, e);
  }} finally {{
    previewBusy.scope = false;
  }}
}}
const previewTimers = {{scope: null}};
const previewIntervals = {{scope: 1000}};
const previewRefreshers = {{scope: refreshScopePreview}};
function togglePreviewLive(kind) {{
  const checkbox = document.getElementById(`${{kind}}Live`);
  if (previewTimers[kind]) {{
    clearInterval(previewTimers[kind]);
    previewTimers[kind] = null;
  }}
  if (checkbox && checkbox.checked) {{
    previewRefreshers[kind]();
    previewTimers[kind] = setInterval(() => {{
      if (document.hidden) return;
      previewRefreshers[kind]();
    }}, previewIntervals[kind]);
  }}
}}
setSelectValue('rpType', defaults.rpType);
setSelectValue('laserType', defaults.laserType);
setSelectValue('scopeType', defaults.scopeType);
setSelectValue('experimentMode', inferExperimentMode(defaults.laserType));
document.getElementById('experimentMode').addEventListener('change', () => applyExperimentMode(true));
document.getElementById('laserType').addEventListener('change', () => {{
  const laserType = document.getElementById('laserType').value;
  switchLaserPortDefault(laserType);
  setSelectValue('experimentMode', inferExperimentMode(laserType));
  applyExperimentMode(false);
}});
for (const id of ['rpType','bridgeBaseInput','rpHostInput','topticaHostInput','laserPortInput','weiyuanSlaveInput','scopeType','scopeResourceInput']) {{
  document.getElementById(id).addEventListener('change', updateInstrumentHeader);
  document.getElementById(id).addEventListener('input', updateInstrumentHeader);
}}
applyExperimentMode(false);
if (!document.body.dataset.task) {{
  setTask('settings');
}}
refreshHealth();
renderTarget();
</script>
</body>
</html>"""


def make_handler(args: argparse.Namespace) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *values: Any) -> None:
            return

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            try:
                if parsed.path == "/":
                    html_response(
                        self,
                        page(
                            args.default_cavity,
                            args.bridge_base,
                            args.rp_host,
                            args.laser_type,
                            args.toptica_host,
                            large_scan_laser_port=args.large_scan_laser_port,
                            toptica_port=args.toptica_port,
                            weiyuan_port=args.weiyuan_port,
                            scope_type=args.scope_type,
                            scope_resource=args.scope_resource,
                        ),
                    )
                elif parsed.path == "/api/health":
                    flat_qs = {key: values[0] for key, values in qs.items()}
                    config = instrument_config_from_mapping(flat_qs, args)
                    health = check_instruments(
                        config,
                        args.toptica_python,
                        getattr(args, "device_profile", {}),
                    )
                    payload = {
                        "ok": bool(health.get("ok")),
                        "bridge": health["instruments"].get("red_pitaya", {}).get("bridge"),
                        "bridge_base": config["bridge_base"],
                        "rp_host": config["rp_host"],
                        "laser_type": config["laser_type"],
                        "toptica_host": config["toptica_host"],
                        "laser_port": config["laser_port"],
                        "weiyuan_slave": config["weiyuan_slave"],
                        "toptica_python": str(args.toptica_python),
                        "scope_type": config["scope_type"],
                        "scope_resource": config["scope_resource"],
                        "instruments": health["instruments"],
                    }
                    json_response(self, 200, payload)
                elif parsed.path == "/api/cavity":
                    cavity_dir = qs.get("cavity_dir", [""])[0]
                    if not cavity_dir:
                        raise ValueError("Select a cavity directory first")
                    payload = load_cavity(cavity_dir)
                    json_response(self, 200, payload)
                elif parsed.path == "/api/large_scan/status":
                    cavity_dir = qs.get("cavity_dir", [""])[0]
                    if not cavity_dir:
                        raise ValueError("Select a cavity directory first")
                    payload = large_scan_status(cavity_dir)
                    json_response(self, 200, payload)
                else:
                    json_response(self, 404, {"ok": False, "error": "unknown route"})
            except Exception as exc:
                json_response(self, 400, {"ok": False, "error": repr(exc)})

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            try:
                body = read_json_body(self)
                if parsed.path == "/api/safe_off":
                    config = instrument_config_from_mapping(body, args)
                    if config["rp_type"] == "none":
                        payload = {"ok": True, "json": {"message": "RP / PyRPL not selected; safe-off skipped"}}
                    else:
                        payload = safe_off_with_bridge_recovery(config, args)
                elif parsed.path == "/api/bridge/action":
                    payload = run_bridge_action(body, args)
                elif parsed.path == "/api/weiyuan/action":
                    payload = run_weiyuan_action(body)
                elif parsed.path == "/api/coupling/standard":
                    payload = run_standard_auto_coupling(body, args)
                elif parsed.path == "/api/coupling/stop":
                    payload = stop_auto_coupling()
                elif parsed.path == "/api/scope/single":
                    payload = capture_scope_preview(body, args)
                elif parsed.path == "/api/sensitivity/settings":
                    payload = sensitivity_settings(body, args)
                elif parsed.path == "/api/sensitivity/acquire":
                    payload = run_sensitivity_acquisition(body, args)
                elif parsed.path == "/api/sensitivity/cancel":
                    payload = cancel_sensitivity_acquisition(body, args)
                elif parsed.path == "/api/pick_folder":
                    fallback_dir = args.default_cavity.parent if args.default_cavity is not None else Path.cwd()
                    payload = pick_folder(body.get("initial_dir"), fallback_dir)
                elif parsed.path == "/api/power/update":
                    payload = update_power_and_card(body)
                elif parsed.path == "/api/target/dry_run":
                    command = target_args(body, args) + ["--dry-run"]
                    payload = run_script(command, timeout_s=30.0)
                elif parsed.path == "/api/target/move":
                    command = target_args(body, args) + ["--move-only"]
                    payload = run_script(command, timeout_s=120.0)
                elif parsed.path == "/api/large_scan/run":
                    command, timeout_s = large_scan_command(body, args)
                    config = instrument_config_from_mapping(body, args)
                    payload = run_large_scan_script(
                        command,
                        timeout_s=timeout_s,
                        bridge_base=config["bridge_base"],
                        laser_connection="tcp" if config["laser_type"] == "toptica_tcp" else "serial",
                        laser_port=config["laser_port"],
                        laser_host=config["toptica_host"],
                        toptica_python=toptica_child_python(args, config["laser_type"]) if config["laser_type"] == "toptica_tcp" else "",
                        scope_type=config["scope_type"],
                        scope_resource=config["scope_resource"],
                    )
                elif parsed.path == "/api/large_scan/stop":
                    config = instrument_config_from_mapping(body, args)
                    payload = stop_large_scan_and_restore(
                        config["bridge_base"],
                        laser_connection="tcp" if config["laser_type"] == "toptica_tcp" else "serial",
                        laser_port=config["laser_port"],
                        laser_host=config["toptica_host"],
                        toptica_python=toptica_child_python(args, config["laser_type"]) if config["laser_type"] == "toptica_tcp" else "",
                        scope_type=config["scope_type"],
                        scope_resource=config["scope_resource"],
                    )
                elif parsed.path == "/api/lock/restore_sweep":
                    config = instrument_config_from_mapping(body, args)
                    if config["rp_type"] == "none":
                        payload = {"ok": True, "json": {"message": "RP / PyRPL not selected; restore skipped"}}
                    else:
                        restored = restore_lock_sweep_with_laser(config, args)
                        payload = {"ok": bool(restored.get("ok")), "json": restored}
                elif parsed.path == "/api/lock/current":
                    config = instrument_config_from_mapping(body, args)
                    if config["rp_type"] == "none":
                        raise ValueError("Current-mode lock requires RP / PyRPL bridge")
                    if config["laser_type"] in {"toptica_tcp", "toptica_serial"}:
                        laser_connection = "serial" if config["laser_type"] == "toptica_serial" else "tcp"
                        command = [
                            toptica_child_python(args, config["laser_type"]),
                            str(DEFAULT_LOCK_SCRIPT),
                            "--base",
                            config["bridge_base"],
                            "--host",
                            config["toptica_host"],
                            "--laser-connection",
                            laser_connection,
                            "--laser-port",
                            config["laser_port"],
                        ]
                    elif config["laser_type"] == "weiyuan":
                        command = [
                            package_python_executable(),
                            str(DEFAULT_WEIYUAN_LOCK_SCRIPT),
                            "--base",
                            config["bridge_base"],
                            "--laser-port",
                            config["laser_port"],
                            "--slave",
                            config["weiyuan_slave"],
                        ]
                    else:
                        raise ValueError("Current-mode lock requires TOPTICA or 微源光子 laser")
                    payload = run_script(command, timeout_s=180.0)
                else:
                    payload = {"ok": False, "error": "unknown route"}
                json_response(self, 200 if payload.get("ok") else 400, payload)
            except Exception as exc:
                json_response(self, 400, {"ok": False, "error": repr(exc)})

    return Handler


def main() -> int:
    args = parse_args()
    server = ThreadingHTTPServer((args.listen_host, args.listen_port), make_handler(args))
    print(f"Microcavity control panel listening on http://{args.listen_host}:{args.listen_port}", flush=True)
    print(f"Bridge base: {args.bridge_base}", flush=True)
    print(f"TOPTICA host: {args.toptica_host}", flush=True)
    if args.auto_start_bridge:
        headless = not args.auto_start_bridge_gui
        print(f"Auto-starting PyRPL bridge headless={headless}", flush=True)
        try:
            config = instrument_config_from_mapping({}, args)
            result = ensure_bridge_for_dashboard(config, args, headless=headless)
            print(
                "Auto-start bridge result: "
                f"ok={bool(result.get('ok'))} "
                f"message={result.get('message') or result.get('error')}",
                flush=True,
            )
        except Exception as exc:
            print(f"Auto-start bridge failed: {exc!r}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
