"""Read-only VISA discovery worker for the array-cavity dashboard."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.array_dashboard'


import json
import sys
from pathlib import Path
from typing import Any


def canonical_identity(value: object) -> str:
    return "".join(char for char in str(value or "").upper() if char.isalnum())


def parse_idn(value: str) -> dict[str, str]:
    fields = [field.strip() for field in value.strip().split(",")]
    fields.extend([""] * max(0, 4 - len(fields)))
    return {
        "vendor": fields[0],
        "model": fields[1],
        "serial_number": fields[2],
        "firmware": ",".join(fields[3:]).strip(),
        "idn": value.strip(),
    }


def discover_scopes(request: dict[str, Any]) -> dict[str, Any]:
    import pyvisa  # type: ignore

    expected = str(request.get("expected_serial") or "").strip()
    expected_key = canonical_identity(expected)
    preferred = str(request.get("preferred_resource") or "").strip()
    scope_type = str(request.get("scope_type") or "").strip()
    rm = pyvisa.ResourceManager("@py")
    candidates: list[dict[str, Any]] = []
    try:
        resources = list(rm.list_resources())
        ordered = ([preferred] if preferred else []) + [
            str(resource)
            for resource in resources
            if str(resource).upper().startswith(("TCPIP", "USB"))
        ]
        seen: set[str] = set()
        for resource in ordered:
            resource_key = resource.upper()
            if not resource or resource_key in seen:
                continue
            seen.add(resource_key)
            item: dict[str, Any] = {"resource": resource, "ok": False}
            try:
                inst = rm.open_resource(resource, open_timeout=1800)
                try:
                    inst.timeout = 1800
                    identity = parse_idn(str(inst.query("*IDN?")))
                finally:
                    inst.close()
                if scope_type == "tektronix_mso66b" and "TEKTRONIX" not in identity["vendor"].upper():
                    continue
                if scope_type == "rs_rte" and not any(
                    token in identity["vendor"].upper()
                    for token in ("ROHDE", "SCHWARZ")
                ):
                    continue
                item.update({"ok": True, **identity})
            except Exception as exc:
                item["error"] = repr(exc)
            candidates.append(item)
    finally:
        rm.close()

    matched = next(
        (
            item
            for item in candidates
            if item.get("ok")
            and (
                not expected_key
                or canonical_identity(item.get("serial_number")) == expected_key
            )
        ),
        None,
    )
    return {
        "ok": matched is not None,
        "expected_serial": expected,
        "matched": matched,
        "candidates": candidates,
    }


def main() -> int:
    request_path = Path(sys.argv[1])
    request = json.loads(request_path.read_text(encoding="utf-8"))
    try:
        action = str(request.get("action") or "")
        if action != "discover_scopes":
            raise ValueError(f"unsupported discovery action: {action}")
        result = discover_scopes(request)
    except Exception as exc:
        result = {"ok": False, "error": repr(exc)}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
