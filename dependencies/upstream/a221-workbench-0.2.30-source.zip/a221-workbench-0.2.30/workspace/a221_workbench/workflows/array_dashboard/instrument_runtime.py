from __future__ import annotations
from a221_workbench._shared.paths import module_file, project_root


import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from types import ModuleType
from typing import Any


SCRIPT_PATH = Path(__file__).resolve()
PACKAGE_DIR = SCRIPT_PATH.parent.parent
REPO_ROOT = project_root()

from a221_workbench._shared.runtime import terminate_process_tree as core_terminate_process_tree

INSTRUMENT_BACKEND_PATH = module_file("a221_workbench.workflows.instrument_backend")

_MODULE_LOCK = threading.Lock()
_CONTROL_MODULE: ModuleType | None = None
_LOCK_PROCESS_LOCK = threading.Lock()
_LOCK_MARKER_LOCK = threading.Lock()
_LOCK_MARKER_ROOT = Path(tempfile.gettempdir()) / "array_cavity_dashboard"
_ACTIVE_LOCK: dict[str, Any] = {
    "process": None,
    "command": None,
    "started_at": None,
    "cancel_requested": False,
}


def current_mode_lock_marker_path(bridge_base: str) -> Path:
    key = hashlib.sha256(bridge_base.rstrip("/").lower().encode("utf-8")).hexdigest()[:16]
    return _LOCK_MARKER_ROOT / f"current_mode_lock_{key}.json"


def read_current_mode_lock_marker(bridge_base: str) -> dict[str, Any]:
    path = current_mode_lock_marker_path(bridge_base)
    with _LOCK_MARKER_LOCK:
        if not path.exists():
            return {}
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
    return payload if isinstance(payload, dict) else {}


def write_current_mode_lock_marker(bridge_base: str, payload: dict[str, Any]) -> Path:
    path = current_mode_lock_marker_path(bridge_base)
    with _LOCK_MARKER_LOCK:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temp.replace(path)
    return path


def clear_current_mode_lock_marker(bridge_base: str, token: str | None = None) -> bool:
    path = current_mode_lock_marker_path(bridge_base)
    with _LOCK_MARKER_LOCK:
        if not path.exists():
            return False
        if token is not None:
            try:
                current = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                current = {}
            if not isinstance(current, dict) or current.get("token") != token:
                return False
        path.unlink(missing_ok=True)
    return True


def process_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if sys.platform.startswith("win"):
        import ctypes

        process_query_limited_information = 0x1000
        still_active = 259
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        kernel32.GetExitCodeProcess.restype = ctypes.c_int
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_int
        handle = kernel32.OpenProcess(
            process_query_limited_information,
            False,
            int(pid),
        )
        if not handle:
            return False
        try:
            exit_code = ctypes.c_ulong()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return False
            return exit_code.value == still_active
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def process_creation_id(pid: int) -> str | None:
    if pid <= 0:
        return None
    if sys.platform.startswith("win"):
        import ctypes

        class FileTime(ctypes.Structure):
            _fields_ = [("low", ctypes.c_ulong), ("high", ctypes.c_ulong)]

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.GetProcessTimes.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime),
        ]
        kernel32.GetProcessTimes.restype = ctypes.c_int
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_int
        handle = kernel32.OpenProcess(0x1000, False, int(pid))
        if not handle:
            return None
        try:
            creation = FileTime()
            exit_time = FileTime()
            kernel_time = FileTime()
            user_time = FileTime()
            if not kernel32.GetProcessTimes(
                handle,
                ctypes.byref(creation),
                ctypes.byref(exit_time),
                ctypes.byref(kernel_time),
                ctypes.byref(user_time),
            ):
                return None
            return str((int(creation.high) << 32) | int(creation.low))
        finally:
            kernel32.CloseHandle(handle)
    stat_path = Path(f"/proc/{pid}/stat")
    try:
        raw = stat_path.read_text(encoding="ascii")
        fields = raw[raw.rfind(")") + 2 :].split()
        return fields[19]
    except (OSError, IndexError):
        return None


def process_creation_match_state(pid: int, expected_creation_id: str | None) -> str:
    if not process_is_running(pid):
        return "not_running"
    if not expected_creation_id:
        return "unverified"
    actual_creation_id = process_creation_id(pid)
    if actual_creation_id is None:
        return "unknown"
    return "match" if actual_creation_id == str(expected_creation_id) else "mismatch"


def current_mode_lock_process_state(bridge_base: str) -> dict[str, Any]:
    marker = read_current_mode_lock_marker(bridge_base)
    if not marker:
        return {"active": False, "state": "idle", "marker_path": str(current_mode_lock_marker_path(bridge_base))}
    token = str(marker.get("token") or "")
    child_pid = int(marker.get("child_pid") or 0)
    owner_pid = int(marker.get("owner_pid") or 0)
    expires_at = float(marker.get("expires_at") or 0.0)
    if child_pid > 0:
        child_creation_id = str(marker.get("child_creation_id") or "") or None
        match_state = process_creation_match_state(child_pid, child_creation_id)
        if match_state in {"match", "unknown"} or (
            match_state == "unverified"
            and (expires_at <= 0.0 or time.time() <= expires_at)
        ):
            return {
                "active": True,
                "state": (
                    "child_running"
                    if match_state == "match"
                    else "child_identity_unknown"
                ),
                "pid": child_pid,
                "creation_id": child_creation_id,
                "marker": marker,
                "marker_path": str(current_mode_lock_marker_path(bridge_base)),
            }
        clear_current_mode_lock_marker(bridge_base, token or None)
        return {
            "active": False,
            "state": "pid_reused" if match_state == "mismatch" else "child_exited",
            "pid": child_pid,
            "marker_path": str(current_mode_lock_marker_path(bridge_base)),
        }
    owner_creation_id = str(marker.get("owner_creation_id") or "") or None
    owner_match_state = process_creation_match_state(owner_pid, owner_creation_id)
    if owner_pid > 0 and owner_match_state in {"match", "unknown"}:
        return {
            "active": True,
            "state": "launching",
            "pid": None,
            "marker": marker,
            "marker_path": str(current_mode_lock_marker_path(bridge_base)),
        }
    if expires_at <= 0.0 or time.time() <= expires_at:
        return {
            "active": True,
            "state": "orphaned_launch",
            "pid": None,
            "marker": marker,
            "marker_path": str(current_mode_lock_marker_path(bridge_base)),
        }
    clear_current_mode_lock_marker(bridge_base, token or None)
    return {
        "active": False,
        "state": "expired",
        "pid": None,
        "marker_path": str(current_mode_lock_marker_path(bridge_base)),
    }


def terminate_process_id_tree(
    pid: int,
    expected_creation_id: str | None = None,
) -> dict[str, Any]:
    if pid <= 0:
        return {"ok": True, "terminated": False, "pid": pid}
    match_state = process_creation_match_state(pid, expected_creation_id)
    if match_state in {"not_running", "mismatch"}:
        return {
            "ok": True,
            "terminated": False,
            "pid": pid,
            "identity_mismatch": match_state == "mismatch",
        }
    if match_state in {"unknown", "unverified"}:
        return {
            "ok": False,
            "terminated": False,
            "pid": pid,
            "identity_unverified": True,
        }
    if sys.platform.startswith("win"):
        import ctypes

        class FileTime(ctypes.Structure):
            _fields_ = [("low", ctypes.c_ulong), ("high", ctypes.c_ulong)]

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.GetProcessTimes.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime),
        ]
        kernel32.GetProcessTimes.restype = ctypes.c_int
        kernel32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        kernel32.TerminateProcess.restype = ctypes.c_int
        kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        kernel32.WaitForSingleObject.restype = ctypes.c_ulong
        kernel32.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        kernel32.GetExitCodeProcess.restype = ctypes.c_int
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_int
        handle = kernel32.OpenProcess(0x1001, False, int(pid))
        if not handle:
            return {
                "ok": False,
                "terminated": False,
                "pid": pid,
                "error": f"OpenProcess failed: {ctypes.get_last_error()}",
            }
        try:
            creation = FileTime()
            exit_time = FileTime()
            kernel_time = FileTime()
            user_time = FileTime()
            if not kernel32.GetProcessTimes(
                handle,
                ctypes.byref(creation),
                ctypes.byref(exit_time),
                ctypes.byref(kernel_time),
                ctypes.byref(user_time),
            ):
                return {
                    "ok": False,
                    "terminated": False,
                    "pid": pid,
                    "identity_unverified": True,
                }
            actual_creation_id = str((int(creation.high) << 32) | int(creation.low))
            if actual_creation_id != str(expected_creation_id):
                return {
                    "ok": True,
                    "terminated": False,
                    "pid": pid,
                    "identity_mismatch": True,
                }
            if not kernel32.TerminateProcess(handle, 1):
                return {
                    "ok": False,
                    "terminated": False,
                    "pid": pid,
                    "error": f"TerminateProcess failed: {ctypes.get_last_error()}",
                }
            kernel32.WaitForSingleObject(handle, 2000)
            exit_code = ctypes.c_ulong(259)
            stopped = bool(
                kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
                and exit_code.value != 259
            )
            return {
                "ok": stopped,
                "terminated": stopped,
                "pid": pid,
                "exit_code": int(exit_code.value),
            }
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
        return {"ok": True, "terminated": True, "pid": pid}
    except ProcessLookupError:
        return {"ok": True, "terminated": False, "pid": pid}
    except Exception as exc:
        return {"ok": False, "terminated": False, "pid": pid, "error": repr(exc)}


def control_module() -> ModuleType:
    from a221_workbench.workflows import instrument_backend
    return instrument_backend


def backend_args(array_config: dict[str, Any]) -> argparse.Namespace:
    backend = control_module()
    local_config = backend.load_config_file(backend.DEFAULT_CONFIG_FILE)
    merged = dict(local_config)
    key_map = {
        "bridge_base": "bridge_base",
        "rp_hostname": "rp_host",
        "laser_type": "laser_type",
        "laser_host": "toptica_host",
        "weiyuan_port": "weiyuan_port",
        "scope_type": "scope_type",
        "scope_resource": "scope_resource",
    }
    for source, target in key_map.items():
        value = array_config.get(source)
        if value not in (None, ""):
            merged[target] = value
    merged.pop("laser_port", None)

    defaults = backend.dashboard_defaults_from_config(merged)
    return argparse.Namespace(
        config_file=backend.DEFAULT_CONFIG_FILE,
        listen_host=defaults["listen_host"],
        listen_port=0,
        bridge_base=defaults["bridge_base"],
        rp_host=defaults["rp_host"],
        laser_type=defaults["laser_type"],
        toptica_host=defaults["toptica_host"],
        toptica_python=defaults["toptica_python"],
        large_scan_laser_port=defaults["large_scan_laser_port"],
        toptica_port=defaults["toptica_port"],
        weiyuan_port=defaults["weiyuan_port"],
        scope_type=defaults["scope_type"],
        scope_resource=defaults["scope_resource"],
        default_cavity=defaults["default_cavity"],
        auto_start_bridge=False,
        auto_start_bridge_gui=False,
        device_profile=defaults["device_profile"],
        sensitivity_defaults=defaults["sensitivity_defaults"],
        array_min_depth=array_config.get("array_min_depth", local_config.get("array_min_depth")),
    )


def instrument_health(array_config: dict[str, Any], params: dict[str, Any]) -> dict[str, Any]:
    backend = control_module()
    args = backend_args(array_config)
    config = backend.instrument_config_from_mapping(params, args)
    health = backend.check_instruments(config, args.toptica_python, args.device_profile)
    return {
        "ok": bool(health.get("ok")),
        "bridge": health["instruments"].get("red_pitaya", {}).get("bridge"),
        "bridge_base": config["bridge_base"],
        "rp_host": config["rp_host"],
        "laser_type": config["laser_type"],
        "toptica_host": config["toptica_host"],
        "laser_port": config["laser_port"],
        "weiyuan_slave": config["weiyuan_slave"],
        "toptica_python": str(args.toptica_python),
        "scope_type": config["scope_type"],
        "scope_resource": config["scope_resource"],
        "instruments": health["instruments"],
        "runtime": "array_dashboard_direct",
    }


def instrument_get(
    array_config: dict[str, Any],
    target_path: str,
    params: dict[str, Any],
) -> dict[str, Any]:
    backend = control_module()
    if target_path == "/api/health":
        return instrument_health(array_config, params)
    if target_path == "/api/cavity":
        cavity_dir = str(params.get("cavity_dir") or "")
        if not cavity_dir:
            raise ValueError("Select a cavity directory first")
        return backend.load_cavity(cavity_dir)
    if target_path == "/api/lock/status":
        args = backend_args(array_config)
        config = backend.instrument_config_from_mapping(params, args)
        if config["rp_type"] == "none":
            return {
                "ok": True,
                "state": "idle",
                "hardware_active": False,
                "probe_ok": True,
                "values": {},
                "steps": [],
            }
        process_state = current_mode_lock_process_state(config["bridge_base"])
        param = "pid0.output_direct"
        values: dict[str, Any] = {}
        steps: list[dict[str, Any]] = []
        try:
            result = backend.bridge_query(
                config["bridge_base"].rstrip("/"),
                "/get",
                {"param": param},
                timeout=1.0,
            )
            values[param] = result.get("value")
            steps.append({"param": param, "ok": bool(result.get("ok")), "result": result})
        except Exception as exc:
            steps.append({"param": param, "ok": False, "error": repr(exc)})
        pid_output = str(values.get("pid0.output_direct") or "").strip().lower()
        probe_ok = bool(steps and steps[0].get("ok") and values.get(param) is not None)
        if probe_ok and pid_output == "out2":
            state = "locked"
            hardware_active: bool | None = True
        elif process_state.get("active"):
            state = "starting"
            hardware_active = True
        elif probe_ok and pid_output == "off":
            state = "idle"
            hardware_active = False
        elif probe_ok:
            state = "unknown"
            hardware_active = True
        else:
            state = "unknown"
            hardware_active = None
        return {
            "ok": True,
            "state": state,
            "hardware_active": hardware_active,
            "probe_ok": probe_ok,
            "values": values,
            "steps": steps,
            "process_state": process_state,
        }
    if target_path == "/api/large_scan/status":
        cavity_dir = str(params.get("cavity_dir") or "")
        if not cavity_dir:
            raise ValueError("Select a cavity directory first")
        result = backend.large_scan_status(cavity_dir, params.get("q_subdir"))
        with backend.ACTIVE_LARGE_SCAN_LOCK:
            process = backend.ACTIVE_LARGE_SCAN.get("proc")
            active = process is not None and process.poll() is None
            result["run_state"] = {
                "active": active,
                "state": "running" if active else "idle",
                "started_at": backend.ACTIVE_LARGE_SCAN.get("started_at"),
            }
        return result
    raise ValueError(f"Unknown direct instrument GET route: {target_path}")


def _terminate_process_tree(process: subprocess.Popen[str]) -> dict[str, Any]:
    return core_terminate_process_tree(process)


def cancel_current_mode_lock(bridge_base: str | None = None) -> dict[str, Any]:
    with _LOCK_PROCESS_LOCK:
        process = _ACTIVE_LOCK.get("process")
        _ACTIVE_LOCK["cancel_requested"] = True
    if isinstance(process, subprocess.Popen):
        result = _terminate_process_tree(process)
        result["message"] = "已请求停止当前锁模子进程。"
        return result
    if bridge_base:
        process_state = current_mode_lock_process_state(bridge_base)
        child_pid = int(process_state.get("pid") or 0)
        if child_pid > 0:
            result = terminate_process_id_tree(
                child_pid,
                str(process_state.get("creation_id") or "") or None,
            )
            if result.get("ok"):
                clear_current_mode_lock_marker(bridge_base)
            result["message"] = "已请求停止由旧 Dashboard 启动的锁模子进程。"
            result["process_state"] = process_state
            return result
        if process_state.get("active"):
            return {
                "ok": False,
                "message": "检测到锁模启动标记，但尚无法确认子进程 PID；保持安全锁定。",
                "process_state": process_state,
            }
        clear_current_mode_lock_marker(bridge_base)
    return {"ok": True, "message": "当前没有正在运行的锁模子进程。"}


def run_current_mode_lock(array_config: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
    backend = control_module()
    args = backend_args(array_config)
    config = backend.instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("Current-mode lock requires RP / PyRPL bridge")
    if config["laser_type"] in {"toptica_tcp", "toptica_serial"}:
        laser_connection = "serial" if config["laser_type"] == "toptica_serial" else "tcp"
        command = [
            backend.toptica_child_python(args, config["laser_type"]),
            str(backend.DEFAULT_LOCK_SCRIPT),
            "--base",
            config["bridge_base"],
            "--host",
            config["toptica_host"],
            "--laser-connection",
            laser_connection,
            "--laser-port",
            config["laser_port"],
        ]
    elif config["laser_type"] == "weiyuan":
        command = [
            backend.package_python_executable(),
            str(backend.DEFAULT_WEIYUAN_LOCK_SCRIPT),
            "--base",
            config["bridge_base"],
            "--laser-port",
            config["laser_port"],
            "--slave",
            config["weiyuan_slave"],
        ]
    else:
        raise ValueError("Current-mode lock requires TOPTICA or 微源光子 laser")

    command.extend(
        [
            "--single-frame-handoff",
            "--presence-timeout",
            str(float(body.get("lock_presence_timeout_s") or 4.0)),
            "--presence-min-snr",
            str(float(body.get("lock_presence_min_snr") or 6.0)),
            "--presence-min-samples",
            str(int(body.get("lock_presence_min_samples") or 3)),
            "--post-handoff-settle-seconds",
            str(float(body.get("lock_settle_seconds") or 0.5)),
        ]
    )

    started = time.time()
    lock_timeout_s = float(body.get("lock_timeout_s") or 180.0)
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform.startswith("win") else 0
    with _LOCK_PROCESS_LOCK:
        previous = _ACTIVE_LOCK.get("process")
        if isinstance(previous, subprocess.Popen) and previous.poll() is None:
            return {"ok": False, "error": "另一个锁模子进程仍在运行。", "pid": previous.pid}
        marker_token = uuid.uuid4().hex
        marker = {
            "schema_version": 1,
            "token": marker_token,
            "bridge_base": config["bridge_base"].rstrip("/"),
            "owner_pid": os.getpid(),
            "owner_creation_id": process_creation_id(os.getpid()),
            "child_pid": None,
            "child_creation_id": None,
            "script_path": command[1] if len(command) > 1 else "",
            "command": command,
            "started_at": started,
            "expires_at": started + max(30.0, lock_timeout_s + 30.0),
        }
        write_current_mode_lock_marker(config["bridge_base"], marker)
        try:
            process = subprocess.Popen(
                command,
                cwd=backend.REPO_ROOT,
                env=backend.script_environment(),
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=creationflags,
            )
            marker["child_pid"] = process.pid
            marker["child_creation_id"] = process_creation_id(process.pid)
            write_current_mode_lock_marker(config["bridge_base"], marker)
        except Exception:
            clear_current_mode_lock_marker(config["bridge_base"], marker_token)
            raise
        _ACTIVE_LOCK.update(
            {
                "process": process,
                "command": command,
                "started_at": started,
                "cancel_requested": False,
            }
        )
    try:
        try:
            stdout, stderr = process.communicate(timeout=lock_timeout_s)
        except subprocess.TimeoutExpired:
            stop = _terminate_process_tree(process)
            stdout, stderr = process.communicate()
            return {
                "ok": False,
                "error": "锁模子进程超时。",
                "elapsed_s": time.time() - started,
                "command": command,
                "stop": stop,
                "stdout_tail": stdout[-4000:],
                "stderr_tail": stderr[-4000:],
            }
        with _LOCK_PROCESS_LOCK:
            cancelled = bool(_ACTIVE_LOCK.get("cancel_requested"))
        parsed = backend.parse_script_json(stdout)
        return {
            "ok": process.returncode == 0 and not cancelled and bool(parsed is None or parsed.get("ok", True)),
            "cancelled": cancelled,
            "returncode": process.returncode,
            "elapsed_s": time.time() - started,
            "command": command,
            "json": parsed,
            "stdout_tail": stdout[-4000:],
            "stderr_tail": stderr[-4000:],
        }
    finally:
        with _LOCK_PROCESS_LOCK:
            if _ACTIVE_LOCK.get("process") is process:
                _ACTIVE_LOCK.update(
                    {
                        "process": None,
                        "command": None,
                        "started_at": None,
                        "cancel_requested": False,
                    }
                )
        clear_current_mode_lock_marker(config["bridge_base"], marker_token)


def noise_spectrum_settings(array_config: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
    backend = control_module()
    args = backend_args(array_config)
    config = backend.instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("噪声功率谱测量需要 RP / PyRPL bridge")
    settings = backend.bridge_query(
        config["bridge_base"].rstrip("/"),
        "/acquisition/settings",
        {},
        timeout=8.0,
    )
    return {
        "ok": bool(settings.get("ok")),
        "bridge_base": config["bridge_base"],
        "spectrum": settings.get("spectrum") or {},
    }


def capture_noise_spectrum(array_config: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
    backend = control_module()
    args = backend_args(array_config)
    config = backend.instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        raise ValueError("噪声功率谱测量需要 RP / PyRPL bridge")
    output_text = str(body.get("output_dir") or "").strip()
    if not output_text:
        raise ValueError("缺少噪声功率谱 output_dir")
    output_dir = Path(output_text).expanduser().resolve()
    raw_dir = output_dir / "raw"
    figures_dir = output_dir / "figures"
    raw_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    base = config["bridge_base"].rstrip("/")
    requested = backend.sensitivity_requested_settings(body)
    applied = backend.apply_sensitivity_settings(base, "psd", requested)
    started = time.time()
    timestamp = datetime.now().isoformat(timespec="seconds")
    spectrum_timeout = max(5.0, float(body.get("spectrum_timeout_s") or 120.0))
    max_points = max(1000, int(float(body.get("max_points") or 12000)))
    spectrum: dict[str, Any] | None = None
    plots: dict[str, str] = {}
    error: str | None = None
    if applied.get("ok"):
        try:
            spectrum = backend.bridge_query(
                base,
                "/spectrum/single",
                {
                    "tag": "noise",
                    "timeout": spectrum_timeout,
                    "save": "true",
                    "save_csv": "false",
                    "inline": "false",
                    "acquire": "true",
                    "max_points": max_points,
                    "output_dir": str(raw_dir),
                },
                timeout=max(20.0, spectrum_timeout + 15.0),
            )
            spectrum["path"] = backend.copy_to_subdir_if_needed(spectrum.get("path"), raw_dir, "noise.npz")
            spectrum["metadata_path"] = backend.copy_to_subdir_if_needed(
                spectrum.get("metadata_path"), raw_dir, "noise.json"
            )
            if spectrum.get("ok"):
                mode = body.get("optical_mode") if isinstance(body.get("optical_mode"), dict) else {}
                label = str(body.get("tag_prefix") or mode.get("family") or "mode")
                plots = backend.write_sensitivity_preview_plots(
                    run_dir=figures_dir,
                    tag_prefix=label,
                    timestamp=timestamp,
                    spectrum=spectrum,
                    network=None,
                    max_points=max_points,
                )
        except Exception as exc:
            error = repr(exc)
    else:
        error = "频谱仪参数写入失败"

    payload = {
        "ok": bool(applied.get("ok") and spectrum and spectrum.get("ok") and plots.get("noise_psd_html")),
        "timestamp": timestamp,
        "elapsed_s": time.time() - started,
        "output_dir": str(output_dir),
        "raw_dir": str(raw_dir),
        "figures_dir": str(figures_dir),
        "optical_mode": body.get("optical_mode"),
        "requested_settings": requested,
        "applied_settings": applied,
        "spectrum": spectrum,
        "plots": plots,
        "error": error,
    }
    run_path = output_dir / "run.json"
    payload["run_json_path"] = str(run_path)
    run_path.write_text(json.dumps(backend.json_ready(payload), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return payload


def stop_noise_spectrum(array_config: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
    backend = control_module()
    args = backend_args(array_config)
    config = backend.instrument_config_from_mapping(body, args)
    if config["rp_type"] == "none":
        return {"ok": True, "message": "RP / PyRPL 未启用，无需停止频谱采集。"}
    try:
        result = backend.bridge_query(
            config["bridge_base"].rstrip("/"),
            "/acquisition/stop",
            {},
            timeout=5.0,
        )
    except Exception as exc:
        return {"ok": False, "error": repr(exc)}
    return {"ok": bool(result.get("ok")), "result": result}


def instrument_post(
    array_config: dict[str, Any],
    target_path: str,
    body: dict[str, Any],
) -> dict[str, Any]:
    backend = control_module()
    args = backend_args(array_config)
    if target_path == "/api/bridge/action":
        return backend.run_bridge_action(body, args)
    if target_path == "/api/safe_off":
        config = backend.instrument_config_from_mapping(body, args)
        if config["rp_type"] == "none":
            return {"ok": True, "json": {"message": "RP / PyRPL not selected; safe-off skipped"}}
        cancel = cancel_current_mode_lock(config["bridge_base"])
        result = backend.safe_off_with_bridge_recovery(config, args)
        return {**result, "ok": bool(result.get("ok")) and bool(cancel.get("ok")), "lock_cancel": cancel}
    if target_path == "/api/coupling/standard":
        return backend.run_standard_auto_coupling(body, args)
    if target_path == "/api/coupling/initialize_midpoint":
        return backend.run_mdt693b_midpoint_initialization(body)
    if target_path == "/api/coupling/stop":
        return backend.stop_auto_coupling()
    if target_path == "/api/target/move":
        command = backend.target_args(body, args) + ["--move-only"]
        return backend.run_script(command, timeout_s=120.0)
    if target_path == "/api/lock/current":
        return run_current_mode_lock(array_config, body)
    if target_path == "/api/lock/cancel":
        config = backend.instrument_config_from_mapping(body, args)
        return cancel_current_mode_lock(config.get("bridge_base"))
    if target_path == "/api/lock/restore_rp_sweep":
        config = backend.instrument_config_from_mapping(body, args)
        if config["rp_type"] == "none":
            return {"ok": True, "json": {"message": "RP / PyRPL not selected; RP sweep restore skipped"}}
        restored = backend.restore_lock_sweep(config["bridge_base"])
        return {"ok": bool(restored.get("ok")), "json": restored}
    if target_path == "/api/lock/restore_sweep":
        config = backend.instrument_config_from_mapping(body, args)
        if config["rp_type"] == "none":
            return {"ok": True, "json": {"message": "RP / PyRPL not selected; restore skipped"}}
        cancel = cancel_current_mode_lock(config["bridge_base"])
        restored = backend.restore_lock_sweep_with_laser(config, args)
        return {
            "ok": bool(restored.get("ok")) and bool(cancel.get("ok")),
            "json": restored,
            "lock_cancel": cancel,
        }
    if target_path == "/api/large_scan/run":
        command, timeout_s = backend.large_scan_command(body, args)
        config = backend.instrument_config_from_mapping(body, args)
        laser_connection = "tcp" if config["laser_type"] == "toptica_tcp" else "serial"
        return backend.run_large_scan_script(
            command,
            timeout_s=timeout_s,
            bridge_base=config["bridge_base"],
            laser_connection=laser_connection,
            laser_port=config["laser_port"],
            laser_host=config["toptica_host"],
            toptica_python=(
                backend.toptica_child_python(args, config["laser_type"])
                if laser_connection == "tcp"
                else ""
            ),
            scope_type=config["scope_type"],
            scope_resource=config["scope_resource"],
        )
    if target_path == "/api/large_scan/stop":
        config = backend.instrument_config_from_mapping(body, args)
        laser_connection = "tcp" if config["laser_type"] == "toptica_tcp" else "serial"
        return backend.stop_large_scan_and_restore(
            config["bridge_base"],
            laser_connection=laser_connection,
            laser_port=config["laser_port"],
            laser_host=config["toptica_host"],
            toptica_python=(
                backend.toptica_child_python(args, config["laser_type"])
                if laser_connection == "tcp"
                else ""
            ),
            scope_type=config["scope_type"],
            scope_resource=config["scope_resource"],
        )
    if target_path == "/api/spectrum/settings":
        return noise_spectrum_settings(array_config, body)
    if target_path == "/api/spectrum/capture":
        return capture_noise_spectrum(array_config, body)
    if target_path == "/api/spectrum/stop":
        return stop_noise_spectrum(array_config, body)
    raise ValueError(f"Unknown direct instrument POST route: {target_path}")
