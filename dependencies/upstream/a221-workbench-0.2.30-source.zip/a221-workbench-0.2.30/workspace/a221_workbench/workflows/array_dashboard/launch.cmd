@echo off
py -3 "%~dp0launch.py" %*
exit /b %errorlevel%
