from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.array_dashboard'


import json
import sys
from pathlib import Path

from a221_workbench.tasks.large_scan.restore_fine_scan_scope import RestoreOptions, restore_fine_scan

def run(request):
    options = RestoreOptions(scope_only=True, scope_type=request["scope_type"],
        scope_resource=request["scope_resource"], trigger_channel=int(request["trigger_channel"]),
        trigger_level_v=float(request["trigger_level_v"]), trigger_slope=str(request["trigger_slope"]),
        horizontal_delay_s=request.get("horizontal_delay_s"))
    restore_fine_scan(options)
    return dict(ok=True, **{k: request.get(k) for k in ("scope_type", "scope_resource", "trigger_channel", "trigger_level_v", "trigger_slope", "horizontal_delay_s")})

if __name__ == "__main__":
    print(json.dumps(run(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))), ensure_ascii=False))
