"""Compose locking and spectrum acquisition for array noise measurements."""
from __future__ import annotations
from a221_workbench.workflows.array_dashboard.instrument_runtime import instrument_post
from typing import Any
from pathlib import Path
from a221_workbench.workflows.array_dashboard.comb_measurement import (
    move_thermal_mode_to_wavelength,
    read_json_with_retry,
)

from a221_workbench.workflows.array_dashboard.quick_probe import (
    CURRENT_MODE_LOCK_STATE,
    CURRENT_MODE_LOCK_STATE_LOCK,
    WorkflowCancelled,
    raise_if_cancelled,
    set_sgm_voltage,
)

from a221_workbench.tasks.comb_planning import finite_int, load_reconstruction_mode_state, load_thermal_modes

from a221_workbench.tasks.array_records import (
    die_dir,
    finite_float,
    natural_key,
    normalize_q_slot,
    validate_name,
    write_json_atomic_with_retry,
)

import csv

import re

import threading

from datetime import datetime


from a221_workbench.tasks.analysis.spectra.noise_spectrum_comparison import write_noise_spectrum_comparison


NOISE_SPECTRUM_CANCEL_EVENT = threading.Event()


NOISE_SPECTRUM_RUN_LOCK = threading.Lock()


CURRENT_LOCK_SPECTRUM_CONDITIONS = {
    "noise_only": "仅噪声",
    "ultrasound_on": "加超声",
}


def noise_power_spectrum_dir(directory: Path) -> Path:
    path = directory / "noise_power_spectrum"
    path.mkdir(parents=True, exist_ok=True)
    return path


def noise_power_spectrum_progress_path(directory: Path) -> Path:
    return noise_power_spectrum_dir(directory) / "progress.json"


def write_noise_spectrum_progress(directory: Path, payload: dict[str, Any]) -> dict[str, Any]:
    progress = {
        "schema_version": 1,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        **payload,
        "ok": True,
    }
    path = noise_power_spectrum_progress_path(directory)
    write_json_atomic_with_retry(path, progress)
    return progress


def load_noise_spectrum_progress(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    directory = die_dir(config, validate_name(chip, "chip"), validate_name(die, "die"))
    path = noise_power_spectrum_progress_path(directory)
    if not path.exists():
        return {
            "ok": True,
            "state": "idle",
            "message": "尚未开始锁模噪声功率谱测量。",
            "path": str(path),
        }
    progress = read_json_with_retry(path)
    if isinstance(progress, dict):
        progress.setdefault("ok", True)
        progress["path"] = str(path)
        return progress
    return {"ok": False, "state": "invalid", "message": "progress.json 格式不正确。", "path": str(path)}


def noise_spectrum_run_dir(directory: Path) -> Path:
    root = noise_power_spectrum_dir(directory)
    stem = datetime.now().strftime("run_%Y%m%d_%H%M%S")
    candidate = root / stem
    suffix = 2
    while candidate.exists():
        candidate = root / f"{stem}_{suffix}"
        suffix += 1
    candidate.mkdir(parents=True, exist_ok=False)
    return candidate


def safe_measurement_name(value: Any, fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip()).strip("._")
    return cleaned or fallback


def noise_spectrum_modes(config: dict[str, Any], chip: str, die: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    thermal = load_thermal_modes(config, chip, die)
    modes = [
        dict(mode)
        for mode in thermal.get("modes", [])
        if isinstance(mode, dict) and bool(mode.get("reconstruction_participates"))
    ]
    eligible: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for mode in modes:
        reasons: list[str] = []
        if not str(mode.get("cavity") or "").strip():
            reasons.append("缺少归属腔")
        if finite_float(mode.get("reconstructed_wavelength_nm")) is None:
            reasons.append("缺少对齐后波长")
        if not bool(mode.get("reconstruction_passed")):
            reasons.append("对齐校验未通过")
        if reasons:
            skipped.append(
                {
                    "family": mode.get("family"),
                    "cavity": mode.get("cavity"),
                    "mu": mode.get("mode_number"),
                    "reason": "；".join(reasons),
                }
            )
        else:
            eligible.append(mode)
    eligible.sort(
        key=lambda mode: (
            finite_int(mode.get("reconstruction_comb_index")) or 0,
            natural_key(str(mode.get("family") or "")),
        )
    )
    return eligible, skipped, thermal


def write_noise_spectrum_summary_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "family",
        "cavity",
        "mu",
        "comb_index",
        "wavelength_nm",
        "status",
        "raw_npz",
        "metadata_json",
        "interactive_html",
        "detail_json",
        "error",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field) for field in fields})


def _run_locked_noise_spectrum_measurement(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    eligible, skipped, thermal = noise_spectrum_modes(config, chip, die)
    reconstruction = thermal.get("reconstruction_state")
    if not isinstance(reconstruction, dict):
        reconstruction = load_reconstruction_mode_state(directory)
    outputs_v = reconstruction.get("outputs_v") if isinstance(reconstruction.get("outputs_v"), dict) else {}
    if not outputs_v:
        raise RuntimeError("没有找到二轮对齐校验保存的最终 SGM 电压，请先完成对齐写入与校验。")
    if not eligible:
        raise RuntimeError("没有同时具备归属腔、对齐后波长和通过状态的模式可测量。")

    run_dir = noise_spectrum_run_dir(directory)
    started_at = datetime.now().isoformat(timespec="seconds")
    run_config = {
        "schema_version": 1,
        "started_at": started_at,
        "chip": chip,
        "die": die,
        "mode_count": len(eligible),
        "skipped_modes": skipped,
        "final_sgm_outputs_v": outputs_v,
        "spectrum_span_hz": finite_float(payload.get("spectrum_span_hz")),
        "spectrum_rbw_hz": finite_float(payload.get("spectrum_rbw_hz")),
        "spectrum_trace_average": finite_int(payload.get("spectrum_trace_average")),
        "spectrum_timeout_s": finite_float(payload.get("spectrum_timeout_s")),
    }
    write_json_atomic_with_retry(run_dir / "run_config.json", run_config)
    write_noise_spectrum_progress(
        directory,
        {
            "state": "running",
            "message": "正在恢复对齐后的 SGM 电压。",
            "run_dir": str(run_dir),
            "current_index": 0,
            "total": len(eligible),
            "completed": [],
            "skipped": skipped,
        },
    )

    measurements: list[dict[str, Any]] = []
    restore_result: dict[str, Any] | None = None
    cancelled = False
    fatal_error: str | None = None
    try:
        raise_if_cancelled(NOISE_SPECTRUM_CANCEL_EVENT)
        sgm_result = set_sgm_voltage(
            config,
            {
                "chip": chip,
                "die": die,
                "outputs_v": outputs_v,
                "write_mode": "full_state",
                "max_voltage_v": float(config.get("sgm_max_voltage_v") or 2.0),
                "note": "locked noise PSD batch: restore verified reconstruction voltages",
            },
        )
        if not sgm_result.get("ok"):
            raise RuntimeError(f"对齐 SGM 电压写入失败: {sgm_result}")

        for index, mode in enumerate(eligible, start=1):
            raise_if_cancelled(NOISE_SPECTRUM_CANCEL_EVENT)
            family = str(mode.get("family") or "")
            cavity = str(mode.get("cavity") or "")
            mu = finite_int(mode.get("mode_number")) or 0
            wavelength_nm = float(mode["reconstructed_wavelength_nm"])
            mode_name = safe_measurement_name(f"{cavity}_{family}_mu{mu}", f"mode_{index}")
            mode_dir = run_dir / mode_name
            mode_dir.mkdir(parents=True, exist_ok=False)
            write_noise_spectrum_progress(
                directory,
                {
                    "state": "running",
                    "message": f"正在测量 {family} / {cavity}：跳转到 {wavelength_nm:.6f} nm。",
                    "run_dir": str(run_dir),
                    "current_index": index,
                    "total": len(eligible),
                    "current_family": family,
                    "current_cavity": cavity,
                    "current_mu": mu,
                    "current_stage": "move",
                    "completed": measurements,
                    "skipped": skipped,
                },
            )
            detail: dict[str, Any] = {
                "schema_version": 1,
                "mode": mode,
                "started_at": datetime.now().isoformat(timespec="seconds"),
            }
            compact = {
                "family": family,
                "cavity": cavity,
                "mu": mu,
                "comb_index": mode.get("reconstruction_comb_index"),
                "wavelength_nm": wavelength_nm,
                "status": "failed",
                "raw_npz": None,
                "metadata_json": None,
                "interactive_html": None,
                "detail_json": str(mode_dir / "mode_measurement.json"),
                "error": None,
            }
            try:
                sweep_result = instrument_post(config, "/api/lock/restore_rp_sweep", payload)
                detail["rp_sweep_before_move"] = sweep_result
                if not sweep_result.get("ok"):
                    raise RuntimeError("模式跳转前恢复 RP 细扫失败")
                raise_if_cancelled(NOISE_SPECTRUM_CANCEL_EVENT)
                move_result = move_thermal_mode_to_wavelength(
                    config,
                    {
                        **payload,
                        "chip": chip,
                        "die": die,
                        "wavelength_nm": wavelength_nm,
                    },
                )
                detail["move"] = move_result
                if not move_result.get("ok"):
                    raise RuntimeError(f"模式跳转失败: {move_result.get('error') or move_result.get('message')}")

                raise_if_cancelled(NOISE_SPECTRUM_CANCEL_EVENT)
                write_noise_spectrum_progress(
                    directory,
                    {
                        "state": "running",
                        "message": f"正在锁定 {family} / {cavity}。",
                        "run_dir": str(run_dir),
                        "current_index": index,
                        "total": len(eligible),
                        "current_family": family,
                        "current_cavity": cavity,
                        "current_mu": mu,
                        "current_stage": "lock",
                        "completed": measurements,
                        "skipped": skipped,
                    },
                )
                lock_result = instrument_post(config, "/api/lock/current", payload)
                detail["lock"] = lock_result
                if not lock_result.get("ok"):
                    raise RuntimeError("PID 锁模失败或被停止")

                raise_if_cancelled(NOISE_SPECTRUM_CANCEL_EVENT)
                write_noise_spectrum_progress(
                    directory,
                    {
                        "state": "running",
                        "message": f"正在采集 {family} / {cavity} 的噪声功率谱。",
                        "run_dir": str(run_dir),
                        "current_index": index,
                        "total": len(eligible),
                        "current_family": family,
                        "current_cavity": cavity,
                        "current_mu": mu,
                        "current_stage": "spectrum",
                        "completed": measurements,
                        "skipped": skipped,
                    },
                )
                spectrum_result = instrument_post(
                    config,
                    "/api/spectrum/capture",
                    {
                        **payload,
                        "output_dir": str(mode_dir),
                        "tag_prefix": f"{cavity} {family} mu={mu}",
                        "optical_mode": mode,
                    },
                )
                detail["spectrum"] = spectrum_result
                if not spectrum_result.get("ok"):
                    raise RuntimeError(f"噪声功率谱采集失败: {spectrum_result.get('error') or 'unknown error'}")
                spectrum = spectrum_result.get("spectrum") or {}
                plots = spectrum_result.get("plots") or {}
                compact.update(
                    {
                        "status": "completed",
                        "raw_npz": spectrum.get("path"),
                        "metadata_json": spectrum.get("metadata_path"),
                        "interactive_html": plots.get("noise_psd_html"),
                    }
                )
            except WorkflowCancelled:
                compact["status"] = "cancelled"
                compact["error"] = "用户停止测量"
                detail["error"] = compact["error"]
                raise
            except Exception as exc:
                compact["error"] = str(exc)
                detail["error"] = repr(exc)
            finally:
                try:
                    detail["rp_sweep_after_measurement"] = instrument_post(
                        config, "/api/lock/restore_rp_sweep", payload
                    )
                except Exception as exc:
                    detail["rp_sweep_after_measurement"] = {"ok": False, "error": repr(exc)}
                detail["finished_at"] = datetime.now().isoformat(timespec="seconds")
                write_json_atomic_with_retry(mode_dir / "mode_measurement.json", detail)
                measurements.append(compact)

        write_noise_spectrum_progress(
            directory,
            {
                "state": "finishing",
                "message": "所有可测模式已处理，正在恢复细扫 / PID off 状态。",
                "run_dir": str(run_dir),
                "current_index": len(eligible),
                "total": len(eligible),
                "completed": measurements,
                "skipped": skipped,
            },
        )
    except WorkflowCancelled:
        cancelled = True
    except Exception as exc:
        fatal_error = repr(exc)
    finally:
        try:
            restore_result = instrument_post(config, "/api/lock/restore_sweep", payload)
        except Exception as exc:
            restore_result = {"ok": False, "error": repr(exc)}
        if restore_result.get("ok"):
            clear_current_mode_lock_state_after_restore()

    completed_count = sum(row.get("status") == "completed" for row in measurements)
    failed_count = sum(row.get("status") == "failed" for row in measurements)
    restore_failed = not bool(restore_result.get("ok"))
    summary = {
        "ok": (
            not cancelled
            and fatal_error is None
            and failed_count == 0
            and completed_count == len(eligible)
            and not restore_failed
        ),
        "state": "cancelled" if cancelled else "failed" if fatal_error or failed_count or restore_failed else "completed",
        "message": "用户已停止锁模噪声功率谱测量。"
        if cancelled
        else "锁模噪声功率谱批量测量完成，但自动恢复扫频失败。"
        if restore_failed
        else "锁模噪声功率谱批量测量完成。"
        if fatal_error is None and failed_count == 0
        else "锁模噪声功率谱批量测量完成，但有失败项。",
        "chip": chip,
        "die": die,
        "run_dir": str(run_dir),
        "started_at": started_at,
        "finished_at": datetime.now().isoformat(timespec="seconds"),
        "total": len(eligible),
        "completed_count": completed_count,
        "failed_count": failed_count,
        "measurements": measurements,
        "skipped": skipped,
        "restore": restore_result,
        "sgm_outputs_retained": True,
        "fatal_error": fatal_error,
    }
    summary_path = run_dir / "summary.json"
    summary_csv = run_dir / "summary.csv"
    summary["summary_path"] = str(summary_path)
    summary["summary_csv"] = str(summary_csv)
    write_noise_spectrum_summary_csv(summary_csv, measurements)
    try:
        comparison = write_noise_spectrum_comparison(run_dir, measurements, offset_db=10.0)
    except Exception as exc:
        comparison = {"ok": False, "error": repr(exc)}
    summary["comparison"] = comparison
    summary["comparison_html"] = comparison.get("path") if comparison.get("ok") else None
    write_json_atomic_with_retry(summary_path, summary)
    write_json_atomic_with_retry(
        noise_power_spectrum_dir(directory) / "latest.json",
        {
            "schema_version": 1,
            "updated_at": summary["finished_at"],
            "run_dir": str(run_dir),
            "summary_path": str(summary_path),
            "summary_csv": str(summary_csv),
            "comparison_html": summary.get("comparison_html"),
            "state": summary["state"],
        },
    )
    write_noise_spectrum_progress(directory, summary)
    return summary


def run_locked_noise_spectrum_measurement(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    if not NOISE_SPECTRUM_RUN_LOCK.acquire(blocking=False):
        return {"ok": False, "error": "锁模噪声功率谱测量已经在运行。"}
    NOISE_SPECTRUM_CANCEL_EVENT.clear()
    try:
        return _run_locked_noise_spectrum_measurement(config, payload)
    finally:
        NOISE_SPECTRUM_RUN_LOCK.release()


def capture_current_locked_noise_spectrum(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    condition = str(payload.get("measurement_condition") or "noise_only").strip().lower()
    if condition not in CURRENT_LOCK_SPECTRUM_CONDITIONS:
        raise ValueError("当前锁模功率谱条件只能选择“仅噪声”或“加超声”")

    with CURRENT_MODE_LOCK_STATE_LOCK:
        lock_state = dict(CURRENT_MODE_LOCK_STATE)
    if not lock_state.get("active") or lock_state.get("state") != "locked":
        raise ValueError("请先点击“锁定当前模式”，等待 PID 锁定成功后再提取功率谱")
    if lock_state.get("chip") != chip or lock_state.get("die") != die:
        raise ValueError("当前 PID 锁定属于其他 chip / die；请停止后在当前 die 重新锁模")
    if normalize_q_slot(lock_state.get("q_slot")) != "Q":
        raise ValueError("当前锁模功率谱仅支持 Q 偏振槽")
    optical_mode = lock_state.get("optical_mode")
    if not isinstance(optical_mode, dict):
        raise ValueError("当前 PID 锁定缺少模式记录；请停止后重新选择模式并锁定")

    family = str(optical_mode.get("family") or "").strip()
    cavity = str(optical_mode.get("cavity") or "").strip()
    mode_number = finite_int(optical_mode.get("mode_number"))
    if not family or not cavity:
        raise ValueError("当前锁定模式缺少模式家族或归属腔，不能按腔保存功率谱")

    directory = die_dir(config, chip, die, create=True)
    cavity_dir = (
        noise_power_spectrum_dir(directory)
        / "current_locked"
        / "cavities"
        / safe_measurement_name(cavity, "unknown_cavity")
        / safe_measurement_name(f"{family}_mu{mode_number if mode_number is not None else 'unknown'}", "unknown_mode")
        / condition
    )
    cavity_dir.mkdir(parents=True, exist_ok=True)
    started = datetime.now()
    stem = started.strftime("capture_%Y%m%d_%H%M%S_%f")
    output_dir = cavity_dir / stem
    suffix = 2
    while output_dir.exists():
        output_dir = cavity_dir / f"{stem}_{suffix}"
        suffix += 1
    output_dir.mkdir(parents=False, exist_ok=False)

    condition_label = CURRENT_LOCK_SPECTRUM_CONDITIONS[condition]
    capture_payload = {
        **payload,
        "chip": chip,
        "die": die,
        "q_slot": "Q",
        "output_dir": str(output_dir),
        "optical_mode": optical_mode,
        "tag_prefix": f"{cavity} {family} mu={mode_number if mode_number is not None else '?'} {condition_label}",
    }
    error: str | None = None
    try:
        capture = instrument_post(config, "/api/spectrum/capture", capture_payload)
    except Exception as exc:
        capture = {"ok": False, "error": repr(exc)}
        error = repr(exc)
    if not capture.get("ok") and error is None:
        error = str(capture.get("error") or "噪声功率谱采集失败")

    spectrum = capture.get("spectrum") if isinstance(capture.get("spectrum"), dict) else {}
    plots = capture.get("plots") if isinstance(capture.get("plots"), dict) else {}
    finished_at = datetime.now().isoformat(timespec="seconds")
    compact = {
        "family": family,
        "cavity": cavity,
        "mu": mode_number,
        "wavelength_nm": finite_float(optical_mode.get("reconstructed_wavelength_nm"))
        or finite_float(optical_mode.get("wavelength_nm")),
        "condition": condition,
        "condition_label": condition_label,
        "status": "completed" if capture.get("ok") else "failed",
        "raw_npz": spectrum.get("path"),
        "metadata_json": spectrum.get("metadata_path"),
        "interactive_html": plots.get("noise_psd_html"),
        "detail_json": str(output_dir / "measurement.json"),
        "error": error,
    }
    detail = {
        "schema_version": 1,
        "measurement_kind": "current_locked_noise_power_spectrum",
        "measurement_condition": condition,
        "measurement_condition_label": condition_label,
        "started_at": started.isoformat(timespec="seconds"),
        "finished_at": finished_at,
        "chip": chip,
        "die": die,
        "q_slot": "Q",
        "optical_mode": optical_mode,
        "lock_started_at": lock_state.get("started_at"),
        "lock_generation": lock_state.get("generation"),
        "capture": capture,
        "result": compact,
    }
    write_json_atomic_with_retry(output_dir / "measurement.json", detail)
    result = {
        "ok": bool(capture.get("ok")),
        "state": "completed" if capture.get("ok") else "failed",
        "message": (
            f"{cavity} / {family} 的“{condition_label}”功率谱已保存；PID 继续保持输出。"
            if capture.get("ok")
            else f"{cavity} / {family} 的“{condition_label}”功率谱采集失败；PID 仍保持输出。"
        ),
        "chip": chip,
        "die": die,
        "run_dir": str(output_dir),
        "measurements": [compact],
        "current_lock_retained": True,
        "finished_at": finished_at,
    }
    with CURRENT_MODE_LOCK_STATE_LOCK:
        if (
            CURRENT_MODE_LOCK_STATE.get("active")
            and CURRENT_MODE_LOCK_STATE.get("state") == "locked"
            and CURRENT_MODE_LOCK_STATE.get("generation") == lock_state.get("generation")
        ):
            CURRENT_MODE_LOCK_STATE["last_spectrum"] = result
    return result


def clear_current_mode_lock_state_after_restore() -> None:
    with CURRENT_MODE_LOCK_STATE_LOCK:
        CURRENT_MODE_LOCK_STATE.update(
            {
                "generation": int(CURRENT_MODE_LOCK_STATE.get("generation") or 0) + 1,
                "state": "idle",
                "active": False,
                "chip": "",
                "die": "",
                "q_slot": "",
                "optical_mode": None,
                "last_spectrum": None,
                "started_at": None,
                "stopped_at": datetime.now().isoformat(timespec="seconds"),
            }
        )


def stop_locked_noise_spectrum_measurement(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    NOISE_SPECTRUM_CANCEL_EVENT.set()
    steps: list[dict[str, Any]] = []
    for name, route in (
        ("cancel_lock_process", "/api/lock/cancel"),
        ("stop_spectrum_acquisition", "/api/spectrum/stop"),
        ("safe_off", "/api/safe_off"),
        ("restore_sweep", "/api/lock/restore_sweep"),
    ):
        try:
            result = instrument_post(config, route, payload)
        except Exception as exc:
            result = {"ok": False, "error": repr(exc)}
        steps.append({"name": name, "result": result})
    critical_names = {"cancel_lock_process", "safe_off", "restore_sweep"}
    stop_ok = all(
        bool(step["result"].get("ok"))
        for step in steps
        if step["name"] in critical_names
    )
    current = load_noise_spectrum_progress(config, chip, die)
    progress = write_noise_spectrum_progress(
        directory,
        {
            **current,
            "state": "stop_requested" if stop_ok else "stop_failed",
            "message": (
                "已请求停止；正在结束锁模 / 频谱采集并恢复 PID off。"
                if stop_ok
                else "停止/恢复未全部成功；保持安全锁定，请检查步骤并重试。"
            ),
            "stop_steps": steps,
        },
    )
    return {
        "ok": stop_ok,
        "message": progress["message"],
        "progress": progress,
        "steps": steps,
    }
