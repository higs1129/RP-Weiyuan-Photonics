"""Thermal quick probe orchestration, progress, cancellation and recovery."""
from __future__ import annotations
from a221_workbench.workflows.array_dashboard.instrument_runtime import instrument_get
from urllib.parse import urlparse
from typing import Any
from pathlib import Path
from a221_workbench.tasks.comb_planning import finite_int, thermal_tuning_dir, wavelength_nm_to_freq_ghz

from a221_workbench.tasks.array_records import (
    POLARIZATION_Q_SLOTS,
    Q_BY_MODE_FILE,
    VALID_NAME_RE,
    data_root,
    die_dir,
    electrode_sort_key,
    expand_path,
    finite_float,
    load_array_design,
    load_electrode_record,
    natural_key,
    normalize_q_slot,
    q_slot_dir,
    sgm_entry_from_electrode,
    validate_name,
)

import csv

import hashlib

import json

import math

import os

import shlex

import socket

import subprocess
import sys
from contextlib import nullcontext

import threading

import time

from datetime import datetime

from pathlib import Path

from typing import Any


from a221_workbench.instruments.tektronix import TekTimeToMinReader

from a221_workbench.instruments.sgm5348.client import apply_sgm_via_service, expected_rp
from a221_workbench.instruments.sgm5348.lifecycle import ensure_sgm_service


SGM_STATE_FILE = "current_sgm5348_state.json"


QUICK_PROBE_CANCEL_EVENT = threading.Event()


QUICK_PROBE_PROGRESS_LOCK = threading.Lock()


QUICK_PROBE_PROGRESS: dict[str, Any] = {
    "active": False,
    "state": "idle",
    "phase": "idle",
    "chip": "",
    "die": "",
    "q_slot": "",
    "message": "",
    "recovery_required": False,
    "recovery": None,
    "recovery_descriptor": None,
    "started_at": None,
    "updated_at": None,
}


CURRENT_MODE_LOCK_STATE_LOCK = threading.Lock()


CURRENT_MODE_LOCK_PROBE_LOCK = threading.Lock()


CURRENT_MODE_LOCK_STATE: dict[str, Any] = {
    "generation": 0,
    "state": "idle",
    "active": False,
    "chip": "",
    "die": "",
    "q_slot": "",
    "optical_mode": None,
    "last_spectrum": None,
    "started_at": None,
    "stopped_at": None,
}


GLOBAL_HARDWARE_TASK_RUN_LOCK = threading.Lock()


GLOBAL_HARDWARE_TASK_STATE_LOCK = threading.Lock()


GLOBAL_HARDWARE_TASK_STATE: dict[str, Any] = {
    "active": False,
    "action": "",
    "chip": "",
    "die": "",
    "started_at": None,
    "stop_active": False,
    "stop_label": "",
    "stop_started_at": None,
}


SGM_SERVICE_EFFECTIVE_URL_CACHE_LOCK = threading.Lock()


SGM_SERVICE_EFFECTIVE_URL_CACHE: dict[str, str] = {}


class WorkflowCancelled(RuntimeError):
    recovery: dict[str, Any] | None = None


class WorkflowCancelEvent(threading.Event):
    """An Event usable by SIGINT handlers, with the first request time retained."""
    requested_at: str | None = None
    requested_monotonic: float | None = None

    def set(self) -> None:
        if not self.is_set():
            self.requested_at = datetime.now().isoformat(timespec="milliseconds")
            self.requested_monotonic = time.monotonic()
        super().set()

    def clear(self) -> None:
        super().clear()
        self.requested_at = None
        self.requested_monotonic = None


class SgmWriteError(RuntimeError):
    def __init__(self, result: dict[str, Any]) -> None:
        stage = str(result.get("stage") or "unknown")
        if result.get("outcome_unknown") or result.get("post_started"):
            status = "SGM 写入结果未知，不自动重发或回退到旧 IP/SSH"
        elif result.get("post_started") is False:
            status = "SGM 电压请求尚未提交"
        else:
            status = "SGM 操作失败，未能确认提交状态"
        super().__init__(f"{status}（阶段 {stage}）：{result.get('error')}")
        self.result = result


def raise_if_cancelled(cancel_event: threading.Event | None, *, recovery: dict[str, Any] | None = None) -> None:
    if cancel_event is not None and cancel_event.is_set():
        error = WorkflowCancelled("用户请求停止轮询")
        error.recovery = recovery
        raise error


def wait_with_cancellation(delay_s: float, cancel_event: threading.Event | None) -> None:
    if delay_s <= 0:
        raise_if_cancelled(cancel_event)
        return
    if cancel_event is None:
        time.sleep(delay_s)
        return
    if cancel_event.wait(delay_s):
        raise WorkflowCancelled("用户请求停止轮询")


def raise_if_cancelled_or_timed_out(
    cancel_event: threading.Event | None,
    deadline_at: float | None,
    *,
    timeout_message: str,
) -> None:
    raise_if_cancelled(cancel_event)
    if deadline_at is not None and time.perf_counter() >= deadline_at:
        raise TimeoutError(timeout_message)


def payload_q_slot(payload: dict[str, Any]) -> str:
    return normalize_q_slot(payload.get("q_slot") or payload.get("q_subdir") or "Q")


def read_q_modes_csv_multi(path: Path, *, mode_numbers: set[int] | None = None) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(path)
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            mode_number = finite_int(row.get("mode_number"))
            if mode_number is None:
                continue
            if mode_numbers is not None and mode_number not in mode_numbers:
                continue
            if row.get("fit_status") and row.get("fit_status") != "ok":
                continue
            family = str(row.get("family_label") or row.get("family") or "").strip()
            wavelength_nm = finite_float(row.get("wavelength_nm"))
            if not family or wavelength_nm is None:
                continue
            rows.append(
                {
                    "family": family,
                    "mode_number": mode_number,
                    "wavelength_nm": wavelength_nm,
                    "frequency_ghz": wavelength_nm_to_freq_ghz(wavelength_nm),
                    "relative_freq_ghz": finite_float(row.get("relative_freq_ghz")),
                    "folded_freq_ghz": finite_float(row.get("folded_freq_ghz")),
                    "depth": finite_float(row.get("depth")),
                    "transmission": finite_float(row.get("transmission")),
                    "QL": finite_float(row.get("QL")),
                    "fit_status": row.get("fit_status") or "",
                }
            )
    return sorted(rows, key=lambda item: (int(item.get("mode_number") or 0), natural_key(str(item.get("family") or ""))))


def q_mode_close_neighbors(
    config: dict[str, Any],
    chip: str,
    die: str,
    selected_mode: dict[str, Any] | None,
    *,
    q_slot: object = "Q",
    max_delta_ghz: float = 30.0,
) -> dict[str, Any]:
    if not isinstance(selected_mode, dict):
        return {"ok": True, "neighbors": [], "message": "未选中模式，无法预判近邻。"}
    selected_family = str(selected_mode.get("family") or "").strip()
    selected_mu = finite_int(selected_mode.get("mode_number"))
    selected_wl = finite_float(selected_mode.get("wavelength_nm"))
    if not selected_family or selected_mu is None or selected_wl is None:
        return {"ok": True, "neighbors": [], "message": "选中模式信息不完整，无法预判近邻。"}
    q_table = q_slot_dir(die_dir(config, chip, die), q_slot) / Q_BY_MODE_FILE
    if not q_table.exists():
        return {"ok": True, "neighbors": [], "message": f"未找到 {Q_BY_MODE_FILE}，无法预判近邻。", "q_table": str(q_table)}
    try:
        modes = read_q_modes_csv_multi(q_table, mode_numbers={selected_mu})
    except Exception as exc:
        return {"ok": False, "neighbors": [], "error": repr(exc), "q_table": str(q_table)}
    selected_freq = wavelength_nm_to_freq_ghz(selected_wl)
    neighbors = []
    for row in modes:
        family = str(row.get("family") or "").strip()
        if family == selected_family:
            continue
        wl = finite_float(row.get("wavelength_nm"))
        if wl is None:
            continue
        delta_ghz = abs(wavelength_nm_to_freq_ghz(wl) - selected_freq)
        if delta_ghz <= max_delta_ghz:
            neighbors.append(
                {
                    "family": family,
                    "mode_number": selected_mu,
                    "wavelength_nm": wl,
                    "delta_nm": abs(wl - selected_wl),
                    "delta_ghz": delta_ghz,
                    "depth": row.get("depth"),
                    "QL": row.get("QL"),
                }
            )
    neighbors.sort(key=lambda item: float(item.get("delta_ghz") or math.inf))
    return {
        "ok": True,
        "q_table": str(q_table),
        "selected": {
            "family": selected_family,
            "mode_number": selected_mu,
            "wavelength_nm": selected_wl,
        },
        "max_delta_ghz": max_delta_ghz,
        "neighbors": neighbors,
    }


def expected_cavity_count(design: dict[str, Any]) -> int:
    count = finite_int(design.get("cavity_count"))
    if count and count > 0:
        return count
    shape = design.get("array_shape")
    if isinstance(shape, list) and len(shape) == 2:
        rows = finite_int(shape[0])
        cols = finite_int(shape[1])
        if rows and cols and rows > 0 and cols > 0:
            return rows * cols
    mapping = design.get("electrode_to_cavity")
    return len(mapping) if isinstance(mapping, dict) else 0


def build_thermal_auto_assignment_plan(
    config: dict[str, Any],
    chip: str,
    die: str,
    *,
    voltage_step_v: float | None = None,
    good_only: bool = True,
) -> dict[str, Any]:
    design = load_array_design(config, chip)
    record = load_electrode_record(config, chip, die)
    expected_count = expected_cavity_count(design)
    if expected_count not in {9, 16}:
        raise ValueError(f"自动归属目前只处理 3x3 或 4x4 阵列，当前 cavity_count={expected_count}")
    step_v = float(voltage_step_v if voltage_step_v is not None else config.get("sgm_auto_assignment_voltage_step_v") or 0.05)
    if step_v <= 0:
        raise ValueError("自动归属电压步进必须为正数")
    max_voltage_v = step_v * expected_count
    auto_limit = float(config.get("sgm_auto_assignment_max_voltage_v") or max_voltage_v)
    if max_voltage_v > auto_limit + 1e-12:
        raise ValueError(f"自动归属编码电压最高需要 {max_voltage_v:g} V，超过配置上限 {auto_limit:g} V")
    rows = record.get("rows") if isinstance(record.get("rows"), list) else []
    design_rows = [row for row in rows if isinstance(row, dict) and row.get("cavity")]
    design_rows = sorted(design_rows, key=lambda row: electrode_sort_key(str(row.get("electrode") or "")))
    if not design_rows:
        raise ValueError("当前 die 没有可用的电极-腔映射；请先保存电极记录")
    outputs = default_sgm_outputs()
    entries: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for rank, row in enumerate(design_rows, start=1):
        route = sgm_entry_from_electrode(row, good_only=good_only)
        out = route["out"]
        usable = route["usable"]
        voltage_v = step_v * rank
        code = voltage_v * voltage_v
        applied_voltage_v = voltage_v if usable else 0.0
        entry = {
            "rank": rank,
            **{key: value for key, value in route.items() if key != "reason"},
            "voltage_v": voltage_v,
            "voltage_code_v2": code,
            "applied_voltage_v": applied_voltage_v,
            "applied_voltage_code_v2": applied_voltage_v * applied_voltage_v,
            "usable": bool(usable),
        }
        entries.append(entry)
        if usable and out is not None:
            outputs[f"out{out}"] = voltage_v
        else:
            skipped.append(entry)
    active_entries = [entry for entry in entries if entry.get("usable")]
    if not active_entries:
        if config.get("sgm_cavity_to_out") is not None:
            raise ValueError("没有可用于自动归属的通道；请检查显式映射、sgm_enabled_cavities 或接触记录")
        raise ValueError("没有可用于自动归属的接触良好探针；请先检查并保存电极接触记录")
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "expected_cavity_count": expected_count,
        "voltage_rule": f"V(rank)={step_v:g}*rank V; plots and fits use V^2 because thermal tuning is approximately quadratic in voltage.",
        "voltage_step_v": step_v,
        "max_voltage_v": max_voltage_v,
        "configured_auto_limit_v": auto_limit,
        "good_only": good_only,
        "entries": entries,
        "active_entries": active_entries,
        "skipped_entries": skipped,
        "outputs_v": outputs,
        "nonzero_outputs_v": {key: value for key, value in outputs.items() if abs(float(value)) > 1e-12},
    }


def manual_sgm_tmp_dir(directory: Path) -> Path:
    path = thermal_tuning_dir(directory) / "manual_tmp"
    path.mkdir(parents=True, exist_ok=True)
    return path


def sgm_state_path(directory: Path) -> Path:
    return thermal_tuning_dir(directory) / SGM_STATE_FILE


def path_is_relative_to(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
    except ValueError:
        return False
    return True


def sgm_state_dir_for_payload(directory: Path, payload: dict[str, Any]) -> Path:
    tuning_root = thermal_tuning_dir(directory)
    if payload.get("manual_tmp"):
        return manual_sgm_tmp_dir(directory)
    explicit = str(payload.get("state_dir") or "").strip()
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_absolute():
            path = tuning_root / path
        path = path.resolve()
        if not path_is_relative_to(path, tuning_root):
            raise ValueError(f"SGM state_dir must stay under {tuning_root}, got {path}")
        path.mkdir(parents=True, exist_ok=True)
        return path
    subdir = str(payload.get("state_subdir") or "").strip()
    if subdir:
        if any(sep in subdir for sep in ("/", "\\")) or subdir in {".", ".."}:
            raise ValueError(f"Invalid SGM state_subdir: {subdir!r}")
        path = tuning_root / subdir
        path.mkdir(parents=True, exist_ok=True)
        return path
    return tuning_root


def default_sgm_outputs() -> dict[str, float]:
    return {f"out{index}": 0.0 for index in range(16)}


def load_sgm_outputs(directory: Path) -> dict[str, float]:
    path = sgm_state_path(directory)
    outputs = default_sgm_outputs()
    if not path.exists():
        return outputs
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    raw_outputs = data.get("outputs_v") if isinstance(data, dict) else None
    if not isinstance(raw_outputs, dict):
        return outputs
    for key, value in raw_outputs.items():
        text = str(key)
        if text.startswith("out"):
            text = text[3:]
        try:
            out = int(text)
            voltage = float(value)
        except (TypeError, ValueError):
            continue
        if 0 <= out < 16:
            outputs[f"out{out}"] = voltage
    return outputs


def write_sgm_state(path: Path, *, chip: str, die: str, outputs: dict[str, float], note: str) -> None:
    payload = {
        "schema_version": 1,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "chip": chip,
        "die": die,
        "outputs_v": outputs,
        "note": note,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def sgm_ssh_host(config: dict[str, Any]) -> str:
    explicit = str(config.get("sgm_ssh_host") or "").strip()
    if explicit:
        return explicit
    configured_host = str(config.get("rp_hostname") or "").strip()
    if configured_host:
        return configured_host
    rp = resolve_rp(config)
    addresses = rp.get("addresses") if isinstance(rp, dict) else None
    if isinstance(addresses, list) and addresses:
        return str(addresses[0])
    return ""


def run_external(command: list[str], timeout_s: float, input_text: str | None = None) -> dict[str, Any]:
    started = time.time()
    try:
        proc = subprocess.run(
            command,
            input=input_text,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_s,
        )
        return {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "elapsed_s": time.time() - started,
            "command": command,
            "stdout_tail": proc.stdout[-4000:],
            "stderr_tail": proc.stderr[-4000:],
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "ok": False,
            "returncode": None,
            "elapsed_s": time.time() - started,
            "command": command,
            "stdout_tail": (exc.stdout or "")[-4000:] if isinstance(exc.stdout, str) else "",
            "stderr_tail": (exc.stderr or "")[-4000:] if isinstance(exc.stderr, str) else "",
            "error": f"timeout after {timeout_s:g} s",
        }
    except OSError as exc:
        return {
            "ok": False,
            "returncode": None,
            "elapsed_s": time.time() - started,
            "command": command,
            "stdout_tail": "",
            "stderr_tail": "",
            "error": repr(exc),
        }


def config_with_cached_sgm_service_url(config: dict[str, Any]) -> tuple[dict[str, Any], str | None]:
    target = expected_rp(config)
    if target:
        parsed = urlparse(normalize_sgm_service_url(config.get("sgm_service_url")) or "http://placeholder:8091")
        identity_url = parsed._replace(netloc=f"{target}:{parsed.port or (443 if parsed.scheme == 'https' else 80)}").geturl()
        return {**config, "sgm_service_url": identity_url}, None
    configured_url = normalize_sgm_service_url(config.get("sgm_service_url"))
    if not configured_url:
        return config, None
    with SGM_SERVICE_EFFECTIVE_URL_CACHE_LOCK:
        cached_url = SGM_SERVICE_EFFECTIVE_URL_CACHE.get(configured_url)
    if not cached_url or cached_url == configured_url:
        return config, None
    return {**config, "sgm_service_url": cached_url}, cached_url


def resolve_sgm_service_url_from_ssh_host(
    config: dict[str, Any],
    current_url: str,
) -> dict[str, Any] | None:
    parsed = urlparse(normalize_sgm_service_url(current_url))
    ssh_host = sgm_ssh_host(config)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or not ssh_host:
        return None
    started = time.perf_counter()
    try:
        addresses = socket.getaddrinfo(
            ssh_host,
            parsed.port or (443 if parsed.scheme == "https" else 80),
            family=socket.AF_INET,
            type=socket.SOCK_STREAM,
        )
    except OSError as exc:
        return {
            "ok": False,
            "ssh_host": ssh_host,
            "current_url": current_url,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "error": repr(exc),
        }
    resolved_ip = next(
        (str(item[4][0]) for item in addresses if item[4] and item[4][0]),
        "",
    )
    if not resolved_ip:
        return {
            "ok": False,
            "ssh_host": ssh_host,
            "current_url": current_url,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            "error": "no IPv4 address returned",
        }
    port = parsed.port
    netloc = f"{resolved_ip}:{port}" if port is not None else resolved_ip
    resolved_url = parsed._replace(netloc=netloc).geturl().rstrip("/")
    configured_url = normalize_sgm_service_url(config.get("sgm_service_url"))
    if configured_url:
        with SGM_SERVICE_EFFECTIVE_URL_CACHE_LOCK:
            SGM_SERVICE_EFFECTIVE_URL_CACHE[configured_url] = resolved_url
    return {
        "ok": True,
        "ssh_host": ssh_host,
        "resolved_ip": resolved_ip,
        "current_url": normalize_sgm_service_url(current_url),
        "resolved_url": resolved_url,
        "changed": resolved_url != normalize_sgm_service_url(current_url),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }


def restart_sgm_service_via_ssh(config: dict[str, Any]) -> dict[str, Any] | None:
    base = str(config.get("sgm_service_url") or "").strip().rstrip("/")
    if not base or not bool(config.get("sgm_service_autorestart", True)):
        return None
    parsed = urlparse(base)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return {"ok": False, "error": f"invalid sgm_service_url: {base}"}
    port = int(parsed.port or (443 if parsed.scheme == "https" else 80))
    ssh_user = str(config.get("sgm_ssh_user") or "root").strip() or "root"
    host = sgm_ssh_host(config) or parsed.hostname
    remote_dir = str(config.get("sgm_remote_dir") or "/root/sgm5348_control").strip()
    token = str(config.get("sgm_service_token") or "").strip()
    max_voltage = float(config.get("sgm_max_voltage_v") or 1.0)
    log_path = f"/tmp/sgm5348_http_service_{port}.log"
    vref = float(config.get("sgm_vref_v", 2.048))
    quoted_token = shlex.quote(token)
    port_text = str(port)
    safe_port_pattern = f"[{port_text[0]}]{port_text[1:]}" if port_text else port_text
    kill_pattern = f"sgm5348_http_service.py.*--port {safe_port_pattern}"
    common_ssh = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=5",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "UserKnownHostsFile=NUL",
        f"{ssh_user}@{host}",
    ]
    kill_command = [
        *common_ssh,
        f"pkill -f {shlex.quote(kill_pattern)} >/dev/null 2>&1 || true",
    ]
    kill_result = run_external(kill_command, timeout_s=5.0)
    start_text = (
        f"cd {shlex.quote(remote_dir)} && "
        f"setsid -f env SGM5348_SERVICE_TOKEN={quoted_token} "
        f"python3 sgm5348_http_service.py --host 0.0.0.0 --port {port} --max-voltage {max_voltage:g} --vref {vref:g} "
        f"--pcb-map {shlex.quote(str(config.get('sgm_pcb_map', 'legacy16')))} "
        f"> {shlex.quote(log_path)} 2>&1 < /dev/null; "
        "sleep 0.2"
    )
    start_command = [
        *common_ssh,
        start_text,
    ]
    result = run_external(start_command, timeout_s=8.0)
    return {
        **result,
        "host": host,
        "remote_dir": remote_dir,
        "port": port,
        "log_path": log_path,
        "kill": kill_result,
    }


def set_sgm_voltage(
    config: dict[str, Any], payload: dict[str, Any], *, cancel_event: threading.Event | None = None,
) -> dict[str, Any]:
    raise_if_cancelled(cancel_event)
    q_slot = payload_q_slot(payload)
    total_started = time.perf_counter()
    timing_ms: dict[str, float] = {}
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    manual_max_voltage = float(config.get("sgm_max_voltage_v") or 0.2)
    all_zero = bool(payload.get("all_zero"))
    full_outputs = payload.get("outputs_v") if isinstance(payload.get("outputs_v"), dict) else None
    if q_slot != "Q" and full_outputs is not None:
        raise ValueError("Q' 第一阶段只允许单通道手动写入或全零，不允许加载完整重构电压状态。")
    out: int | None = None
    probe: int | None = None
    voltage = 0.0
    write_mode = "all_zero" if all_zero else str(payload.get("write_mode") or "single_channel").strip()
    if full_outputs is not None:
        write_mode = "full_state"
        max_voltage = float(payload.get("max_voltage_v") or manual_max_voltage)
        outputs = default_sgm_outputs()
        for raw_key, raw_value in full_outputs.items():
            key = str(raw_key).strip()
            if key.startswith("out"):
                key = key[3:]
            out_index = int(float(key))
            output_voltage = float(raw_value)
            if out_index < 0 or out_index > 15:
                raise ValueError(f"SGM out must be 0..15, got out{out_index}")
            if output_voltage < 0 or output_voltage > max_voltage:
                raise ValueError(f"SGM full-state voltage limit is 0..{max_voltage:g} V, got out{out_index}={output_voltage:g} V")
            outputs[f"out{out_index}"] = output_voltage
        note = str(payload.get("note") or "").strip() or "full_state write"
    elif all_zero:
        outputs = default_sgm_outputs()
        note = "all outputs -> 0 V"
    else:
        max_voltage = manual_max_voltage
        out = int(float(payload.get("out")))
        probe = int(float(payload.get("probe")))
        voltage = float(payload.get("voltage_v"))
        if out < 0 or out > 15:
            raise ValueError(f"SGM out must be 0..15, got out{out}")
        if probe < 1 or probe > 16:
            raise ValueError(f"probe must be 1..16, got {probe}")
        if voltage < 0 or voltage > max_voltage:
            raise ValueError(f"手动热调谐电压限制为 0..{max_voltage:g} V，当前请求 {voltage:g} V")
        if write_mode == "preserve":
            outputs = load_sgm_outputs(directory)
        else:
            write_mode = "single_channel"
            outputs = default_sgm_outputs()
        outputs[f"out{out}"] = voltage
        note = f"{write_mode}: probe {probe}, out{out} -> {voltage:g} V"
    nonzero_outputs = {key: value for key, value in outputs.items() if abs(float(value)) > 1e-12}
    state_dir = sgm_state_dir_for_payload(directory, payload)
    pending_path = state_dir / "pending_sgm5348_state.json"
    pending_started = time.perf_counter()
    write_sgm_state(
        pending_path,
        chip=chip,
        die=die,
        outputs=outputs,
        note=f"pending write: {note}",
    )
    timing_ms["write_pending_state"] = round((time.perf_counter() - pending_started) * 1000.0, 3)
    parse_started = time.perf_counter()
    state_payload = json.loads(pending_path.read_text(encoding="utf-8"))
    timing_ms["read_pending_state"] = round((time.perf_counter() - parse_started) * 1000.0, 3)

    configured_service_url = normalize_sgm_service_url(config.get("sgm_service_url"))
    service_config, cached_service_url = config_with_cached_sgm_service_url(config)
    service_resolution: dict[str, Any] | None = None
    if cached_service_url:
        service_resolution = {
            "ok": True,
            "cache_hit": True,
            "configured_url": configured_service_url,
            "resolved_url": cached_service_url,
        }
    service_result = apply_sgm_via_service(
        service_config, state_payload, check_cancel=lambda: raise_if_cancelled(cancel_event),
    )
    service_restart = None
    # Recovery only precedes the FIRST POST. Keep no_retry intact so the
    # legacy SSH voltage fallback below can never handle this identity path.
    if (service_result and not service_result.get("ok")
            and service_result.get("stage") == "health"
            and service_result.get("post_started") is False
            and not service_result.get("outcome_unknown")
            and service_result.get("service_recovery_allowed") is True
            and bool(config.get("sgm_service_autorestart", True))):
        first_attempt = service_result
        service_restart = ensure_sgm_service(
            service_config, allow_start=True,
            check_cancel=lambda: raise_if_cancelled(cancel_event),
        )
        raise_if_cancelled(cancel_event)
        if service_restart.get("ok"):
            service_result = apply_sgm_via_service(
                service_config, state_payload, check_cancel=lambda: raise_if_cancelled(cancel_event),
            )
            if service_result is None:
                service_result = {"ok": False, "stage": "pre_write", "post_started": False,
                                  "outcome_unknown": False, "no_retry": True,
                                  "error": "SGM service configuration disappeared before submission"}
        else:
            service_result = {**first_attempt, "stage": "pre_write", "failure_kind": "service_recovery",
                              "service_recovery_allowed": False,
                              "error": service_restart.get("error") or "SGM service recovery failed"}
        service_result.update(first_attempt=first_attempt, service_recovery=service_restart)
    if service_result and service_result.get("no_retry"):
        raise SgmWriteError(service_result)
    if service_result and not service_result.get("ok"):
        raise_if_cancelled(cancel_event)
        current_service_url = normalize_sgm_service_url(service_config.get("sgm_service_url"))
        resolved = resolve_sgm_service_url_from_ssh_host(config, current_service_url)
        if resolved is not None:
            service_resolution = resolved
        if resolved and resolved.get("ok") and resolved.get("changed"):
            resolved_config = {**config, "sgm_service_url": str(resolved["resolved_url"])}
            resolved_result = apply_sgm_via_service(
                resolved_config, state_payload, check_cancel=lambda: raise_if_cancelled(cancel_event),
            )
            if resolved_result is not None:
                resolved_result["first_attempt"] = service_result
                resolved_result["resolution"] = resolved
                service_result = resolved_result
                service_config = resolved_config
    if service_result and service_result.get("no_retry"):
        raise SgmWriteError(service_result)
    if service_result and not service_result.get("ok"):
        raise_if_cancelled(cancel_event)
        service_restart = restart_sgm_service_via_ssh(service_config)
        if service_restart and service_restart.get("ok"):
            retry_result = apply_sgm_via_service(
                service_config, state_payload, check_cancel=lambda: raise_if_cancelled(cancel_event),
            )
            if retry_result is not None:
                retry_result["first_attempt"] = service_result
                retry_result["restart"] = service_restart
                service_result = retry_result
    if service_result and service_result.get("no_retry"):
        raise SgmWriteError(service_result)
    if service_result and service_result.get("ok"):
        service_host = urlparse(str(service_result.get("url") or service_config.get("sgm_service_url") or "")).hostname or ""
        current_started = time.perf_counter()
        current_path = state_dir / SGM_STATE_FILE
        write_sgm_state(
            current_path,
            chip=chip,
            die=die,
            outputs=outputs,
            note=f"applied: {note}",
        )
        timing_ms["write_current_state"] = round((time.perf_counter() - current_started) * 1000.0, 3)
        timing_ms["total_server"] = round((time.perf_counter() - total_started) * 1000.0, 3)
        return {
            "ok": True,
            "chip": chip,
            "die": die,
            "q_slot": q_slot,
            "probe": probe,
            "out": out,
            "voltage_v": voltage,
            "write_mode": write_mode,
            "host": service_host,
            "state_dir": str(state_dir),
            "local_state": str(current_path),
            "transfer_mode": "sgm_http_service",
            "outputs_v": outputs,
            "nonzero_outputs_v": nonzero_outputs,
            "service": service_result,
            "service_restart": service_restart,
            "service_resolution": service_resolution,
            "timing_ms": timing_ms,
        }

    raise_if_cancelled(cancel_event)
    ssh_user = str(config.get("sgm_ssh_user") or "root").strip() or "root"
    host = sgm_ssh_host(config)
    if not host:
        raise ValueError("缺少 RedPitaya SSH host；请先在仪器设置里配置 RedPitaya hostname/IP")
    remote_user_host = f"{ssh_user}@{host}"
    remote_state = f"/tmp/array_dashboard_{chip}_{die}_sgm5348_state.json"
    remote_dir = str(config.get("sgm_remote_dir") or "/root/sgm5348_control").strip()
    max_voltage = float(config.get("sgm_max_voltage_v") or 1.0)
    ssh_options = [
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=5",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "UserKnownHostsFile=NUL",
    ]
    apply_command_text = (
        f"cat > {shlex.quote(remote_state)} && "
        f"cd {shlex.quote(remote_dir)} && "
        f"python3 sgm5348_redpitaya.py --from-state {shlex.quote(remote_state)} "
        f"--max-voltage {max_voltage:g} --vref {float(config.get('sgm_vref_v', 2.048)):g} --apply --print-json --quiet"
    )
    ssh_command = [
        "ssh",
        *ssh_options,
        remote_user_host,
        apply_command_text,
    ]

    state_json = pending_path.read_text(encoding="utf-8")
    apply_result = run_external(ssh_command, timeout_s=20.0, input_text=state_json)
    if not apply_result["ok"]:
        raise SgmWriteError({
            "ok": False,
            "outcome_unknown": True,
            "no_retry": True,
            "error": "SSH 写入未确认完成；远端结果未知",
            "stage": "ssh_transfer_apply",
            "q_slot": q_slot,
            "host": host,
            "remote_state": remote_state,
            "state_dir": str(state_dir),
            "local_state": str(pending_path),
            "transfer_mode": "ssh_stdin",
            "service": service_result,
            "service_restart": service_restart,
            "service_resolution": service_resolution,
            "apply": apply_result,
            "timing_ms": timing_ms,
        })

    current_started = time.perf_counter()
    current_path = state_dir / SGM_STATE_FILE
    write_sgm_state(
        current_path,
        chip=chip,
        die=die,
        outputs=outputs,
        note=f"applied: {note}",
    )
    timing_ms["write_current_state"] = round((time.perf_counter() - current_started) * 1000.0, 3)
    timing_ms["total_server"] = round((time.perf_counter() - total_started) * 1000.0, 3)
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "q_slot": q_slot,
        "probe": probe,
        "out": out,
        "voltage_v": voltage,
        "write_mode": write_mode,
        "host": host,
        "remote_dir": remote_dir,
        "remote_state": remote_state,
        "state_dir": str(state_dir),
        "local_state": str(current_path),
        "transfer_mode": "ssh_stdin",
        "outputs_v": outputs,
        "nonzero_outputs_v": nonzero_outputs,
        "service": service_result,
        "service_restart": service_restart,
        "service_resolution": service_resolution,
        "apply": apply_result,
        "timing_ms": timing_ms,
    }


def restore_tek_run_continuous(
    config: dict[str, Any], payload: dict[str, Any], *, reader: TekTimeToMinReader | None = None,
) -> dict[str, Any]:
    scope_type = str(payload.get("scope_type") or config.get("scope_type") or "").strip().lower()
    if scope_type != "tektronix_mso66b":
        return {"ok": True, "skipped": True, "reason": f"scope_type={scope_type or '<empty>'}"}
    scope_resource = str(payload.get("scope_resource") or config.get("scope_resource") or "").strip()
    if not scope_resource:
        return {"ok": False, "error": "未配置 Tektronix 示波器 IP，无法恢复 run continuous"}
    try:
        source_channel = int(float(
            payload.get("tek_source_channel")
            or payload.get("trans_channel")
            or config.get("trans_channel")
            or 2
        ))
    except (TypeError, ValueError):
        source_channel = 2
    started = time.perf_counter()
    steps: list[dict[str, Any]] = []
    try:
        with (nullcontext(reader) if reader is not None else TekTimeToMinReader(scope_resource, source_channel=source_channel)) as tek:
            for command in ("ACQuire:STOPAfter RUNSTop", "ACQuire:STATE RUN"):
                elapsed_ms = tek.write(command)
                steps.append({"cmd": command, "ok": True, "elapsed_ms": round(elapsed_ms, 3)})
        return {
            "ok": True,
            "scope_type": scope_type,
            "scope_resource": scope_resource,
            "steps": steps,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except Exception as exc:
        return {
            "ok": False,
            "scope_type": scope_type,
            "scope_resource": scope_resource,
            "steps": steps,
            "error": repr(exc),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }


def finish_thermal_io(
    config: dict[str, Any], payload: dict[str, Any], *,
    write_error: dict[str, Any] | None = None,
    reader: TekTimeToMinReader | None = None,
    scope_restore: dict[str, Any] | None = None,
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    """One ordered cleanup after synchronous writes; never replay an unknown write."""
    def report(phase: str, message: str) -> None:
        if progress_callback is not None:
            try:
                progress_callback({"phase": phase, "message": message})
            except Exception:
                pass

    report("restore_zero", "正在收尾：确认电压写入结果并清零。")
    if write_error and write_error.get("outcome_unknown"):
        zero = {"ok": False, "skipped": True, "outcome_unknown": True,
                "error": "前次写入结果未知；不能保证远端写入已结束，未重发或并发清零。", "previous_write": write_error}
    else:
        try:
            zero_payload = {key: payload[key] for key in ("chip", "die", "q_slot", "state_dir", "manual_tmp") if key in payload}
            zero = set_sgm_voltage({**config, "sgm_service_autorestart": False}, {**zero_payload, "all_zero": True})
        except Exception as exc:
            zero = {"ok": False, "error": repr(exc)}
            if isinstance(exc, SgmWriteError):
                zero.update(outcome_unknown=bool(exc.result.get("outcome_unknown")), service=exc.result)
    report("restore_scope_run_continuous", "正在收尾：恢复示波器连续扫描。")
    if scope_restore is None:
        scope_restore = restore_tek_run_continuous(config, payload, reader=reader)
    return {
        "ok": zero.get("ok") is True and scope_restore.get("ok") is True,
        "restore_zero": zero,
        "restore_scope_run_continuous": scope_restore,
    }


def update_quick_probe_progress(**changes: Any) -> dict[str, Any]:
    with QUICK_PROBE_PROGRESS_LOCK:
        QUICK_PROBE_PROGRESS.update(changes)
        QUICK_PROBE_PROGRESS["updated_at"] = datetime.now().isoformat(timespec="seconds")
        return dict(QUICK_PROBE_PROGRESS)


def dashboard_runtime_state_dir(config: dict[str, Any]) -> Path:
    explicit = expand_path(str(os.environ.get("ARRAY_CAVITY_DASHBOARD_RUNTIME_DIR") or ""))
    if explicit is not None:
        return explicit
    local_app_data = str(os.environ.get("LOCALAPPDATA") or "").strip()
    if local_app_data:
        return Path(local_app_data) / "daily_note_v2" / "array_cavity_dashboard" / "runtime"
    xdg_state_home = str(os.environ.get("XDG_STATE_HOME") or "").strip()
    if xdg_state_home:
        return Path(xdg_state_home) / "daily_note_v2" / "array_cavity_dashboard" / "runtime"
    return Path.home() / ".local" / "state" / "daily_note_v2" / "array_cavity_dashboard" / "runtime"


def acquire_dashboard_hardware_file_lock(config: dict[str, Any]) -> Any | None:
    path = dashboard_runtime_state_dir(config) / "hardware_task.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+b")
    try:
        if path.stat().st_size == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return handle
    except (OSError, IOError):
        handle.close()
        return None


def release_dashboard_hardware_file_lock(handle: Any | None) -> None:
    if handle is None:
        return
    try:
        handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    finally:
        handle.close()


def quick_probe_runtime_path(config: dict[str, Any], chip: str = "", die: str = "") -> Path:
    # This local registry is authoritative. It must not move when the experiment data root changes.
    return dashboard_runtime_state_dir(config) / "quick_probe_assignment.json"


def quick_probe_runtime_audit_path(config: dict[str, Any], chip: str, die: str) -> Path:
    return die_dir(config, chip, die, create=True) / "thermal_tuning" / "quick_probe_assignment" / "runtime.json"


def normalize_sgm_service_url(value: Any) -> str:
    return str(value or "").strip().rstrip("/")


def sgm_target_fingerprint(target: dict[str, Any]) -> str:
    identity = {
        key: target.get(key)
        for key in (
            "sgm_service_url",
            "sgm_ssh_user",
            "sgm_ssh_host",
            "sgm_remote_dir",
            "preferred_transfer_mode",
            "applied_service_url",
            "applied_host",
        )
    }
    # Preserve fingerprints of legacy descriptors; new descriptors bind the
    # stable device identity and reference as well as the historical address.
    for key in ("sgm_device_id", "sgm_vref_v", "sgm_pcb_map"):
        if key in target:
            identity[key] = target[key]
    encoded = json.dumps(identity, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def quick_probe_sgm_recovery_target(config: dict[str, Any]) -> dict[str, Any]:
    token = str(config.get("sgm_service_token") or "")
    target: dict[str, Any] = {
        "sgm_device_id": expected_rp(config),
        "sgm_vref_v": float(config.get("sgm_vref_v", 2.048)),
        "sgm_pcb_map": str(config.get("sgm_pcb_map", "legacy16")),
        "sgm_service_url": normalize_sgm_service_url(config.get("sgm_service_url")),
        "sgm_service_token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest(),
        "sgm_service_timeout_s": float(config.get("sgm_service_timeout_s") or 1.5),
        "sgm_service_autorestart": bool(config.get("sgm_service_autorestart", True)),
        "sgm_ssh_user": str(config.get("sgm_ssh_user") or "root").strip() or "root",
        "sgm_ssh_host": str(sgm_ssh_host(config) or "").strip(),
        "sgm_remote_dir": str(config.get("sgm_remote_dir") or "/root/sgm5348_control").strip(),
        "sgm_max_voltage_v": float(config.get("sgm_max_voltage_v") or 1.0),
        "preferred_transfer_mode": None,
        "applied_service_url": "",
        "applied_host": "",
    }
    target["sgm_device_fingerprint"] = sgm_target_fingerprint(target)
    return target


def quick_probe_recovery_descriptor(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    try:
        source_channel = int(float(
            payload.get("tek_source_channel")
            or payload.get("trans_channel")
            or config.get("trans_channel")
            or 2
        ))
    except (TypeError, ValueError):
        source_channel = 2
    return {
        "scope_type": str(payload.get("scope_type") or config.get("scope_type") or "").strip(),
        "scope_resource": str(payload.get("scope_resource") or config.get("scope_resource") or "").strip(),
        "tek_source_channel": source_channel,
        "sgm_target": quick_probe_sgm_recovery_target(config),
    }


def quick_probe_sgm_target_after_write(
    target: dict[str, Any],
    write_result: dict[str, Any],
) -> dict[str, Any]:
    updated = dict(target)
    transfer_mode = str(write_result.get("transfer_mode") or "").strip()
    if transfer_mode == "sgm_http_service":
        service = write_result.get("service") if isinstance(write_result.get("service"), dict) else {}
        applied_url = normalize_sgm_service_url(service.get("url") or target.get("sgm_service_url"))
        updated.update(
            {
                "preferred_transfer_mode": transfer_mode,
                "applied_service_url": applied_url,
                "applied_host": str(urlparse(applied_url).hostname or write_result.get("host") or "").strip(),
            }
        )
    elif transfer_mode == "ssh_stdin":
        updated.update(
            {
                "preferred_transfer_mode": transfer_mode,
                "applied_service_url": "",
                "applied_host": str(write_result.get("host") or target.get("sgm_ssh_host") or "").strip(),
            }
        )
    else:
        raise ValueError(f"无法记录 SGM 实际写入目标：transfer_mode={transfer_mode or '<empty>'}")
    if not updated.get("applied_host"):
        raise ValueError("无法记录 SGM 实际写入主机；为避免失去恢复目标，已停止继续加压")
    updated["sgm_device_fingerprint"] = sgm_target_fingerprint(updated)
    return updated


def quick_probe_sgm_recovery_config(
    config: dict[str, Any],
    target: dict[str, Any],
) -> dict[str, Any]:
    if not target:
        raise ValueError("缺少原 SGM 恢复目标，不能确认应归零哪台 DAC")
    expected_fingerprint = str(target.get("sgm_device_fingerprint") or "")
    actual_fingerprint = sgm_target_fingerprint(target)
    if not expected_fingerprint or expected_fingerprint != actual_fingerprint:
        raise ValueError("原 SGM 恢复目标指纹缺失或不一致，已拒绝向不确定的 DAC 写入")

    recovery_config = dict(config)
    # Do not inherit a different RP selected after the original write.
    recovery_config["sgm_device_id"] = expected_rp(target)
    recovery_config.pop("rp_device_id", None)
    recovery_config.pop("rp_hostname", None)
    for key in (
        "sgm_service_url",
        "sgm_service_timeout_s",
        "sgm_service_autorestart",
        "sgm_ssh_user",
        "sgm_ssh_host",
        "sgm_remote_dir",
        "sgm_max_voltage_v",
        "sgm_device_id",
        "sgm_vref_v",
        "sgm_pcb_map",
    ):
        if key in target:
            recovery_config[key] = target[key]

    preferred = str(target.get("preferred_transfer_mode") or "").strip()
    applied_host = str(target.get("applied_host") or "").strip()
    if preferred == "sgm_http_service":
        recovery_config["sgm_service_url"] = normalize_sgm_service_url(
            target.get("applied_service_url") or target.get("sgm_service_url")
        )
        # If HTTP recovery fails, SSH fallback must still point to the host that was actually written.
        recovery_config["sgm_ssh_host"] = applied_host
        current_token_hash = hashlib.sha256(
            str(config.get("sgm_service_token") or "").encode("utf-8")
        ).hexdigest()
        if current_token_hash != str(target.get("sgm_service_token_sha256") or ""):
            recovery_config["sgm_service_url"] = ""
    elif preferred == "ssh_stdin":
        recovery_config["sgm_service_url"] = ""
        recovery_config["sgm_ssh_host"] = applied_host

    service_url = normalize_sgm_service_url(recovery_config.get("sgm_service_url"))
    ssh_host = str(recovery_config.get("sgm_ssh_host") or "").strip()
    if not service_url and not ssh_host:
        raise ValueError("原 SGM 恢复描述符没有可用的 HTTP 或 SSH 目标")
    return recovery_config


def quick_probe_sgm_zero_result_matches_target(
    result: dict[str, Any],
    recovery_config: dict[str, Any],
) -> bool:
    if result.get("ok") is not True:
        return False
    outputs = result.get("outputs_v") if isinstance(result.get("outputs_v"), dict) else None
    if not outputs or len(outputs) != 16:
        return False
    try:
        if any(abs(float(outputs.get(f"out{index}"))) > 1e-12 for index in range(16)):
            return False
    except (TypeError, ValueError):
        return False

    transfer_mode = str(result.get("transfer_mode") or "").strip()
    if transfer_mode == "sgm_http_service":
        service = result.get("service") if isinstance(result.get("service"), dict) else {}
        actual_url = normalize_sgm_service_url(service.get("url"))
        expected_url = normalize_sgm_service_url(recovery_config.get("sgm_service_url"))
        return bool(actual_url and expected_url and actual_url.casefold() == expected_url.casefold())
    if transfer_mode == "ssh_stdin":
        actual_host = str(result.get("host") or "").strip().casefold()
        expected_host = str(recovery_config.get("sgm_ssh_host") or "").strip().casefold()
        return bool(actual_host and expected_host and actual_host == expected_host)
    return False


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def write_quick_probe_runtime(config: dict[str, Any], progress: dict[str, Any]) -> Path:
    chip = validate_name(str(progress.get("chip") or ""), "chip")
    die = validate_name(str(progress.get("die") or ""), "die")
    path = quick_probe_runtime_path(config, chip, die)
    payload = {
        "schema_version": 2,
        "active": bool(progress.get("active")),
        "state": str(progress.get("state") or "idle"),
        "phase": str(progress.get("phase") or "idle"),
        "chip": chip,
        "die": die,
        "q_slot": normalize_q_slot(progress.get("q_slot")),
        "message": str(progress.get("message") or ""),
        "recovery_required": bool(progress.get("recovery_required")),
        "recovery": progress.get("recovery") if isinstance(progress.get("recovery"), dict) else None,
        "recovery_descriptor": (
            progress.get("recovery_descriptor")
            if isinstance(progress.get("recovery_descriptor"), dict)
            else None
        ),
        "started_at": progress.get("started_at"),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "error": progress.get("error"),
        "data_root": str(data_root(config) or ""),
    }
    write_json_atomic(path, payload)
    # The die copy is useful for later audit, but it is never the safety authority.
    try:
        write_json_atomic(quick_probe_runtime_audit_path(config, chip, die), payload)
    except OSError:
        pass
    return path


def persist_current_quick_probe_progress(config: dict[str, Any]) -> Path:
    with QUICK_PROBE_PROGRESS_LOCK:
        progress = dict(QUICK_PROBE_PROGRESS)
    return write_quick_probe_runtime(config, progress)


def corrupt_quick_probe_runtime(path: Path, message: str, error: str) -> dict[str, Any]:
    return {
        "schema_version": 2,
        "active": False,
        "state": "runtime_corrupt",
        "phase": "runtime_corrupt",
        "chip": "",
        "die": "",
        "q_slot": "Q",
        "message": message,
        "recovery_required": True,
        "recovery": None,
        "recovery_descriptor": None,
        "error": error,
        "runtime_path": str(path),
    }


def read_quick_probe_runtime(path: Path) -> dict[str, Any] | None:
    if not path.exists() or not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        return corrupt_quick_probe_runtime(
            path,
            "单次模式归属运行标记无法读取；为避免跳过安全恢复，已保守锁住硬件任务。",
            repr(exc),
        )
    if not isinstance(payload, dict):
        return corrupt_quick_probe_runtime(
            path,
            "单次模式归属运行标记格式错误；为避免跳过安全恢复，已保守锁住硬件任务。",
            "runtime JSON must be an object",
        )
    required_types = {
        "active": bool,
        "recovery_required": bool,
        "state": str,
        "phase": str,
        "chip": str,
        "die": str,
        "q_slot": str,
    }
    invalid_fields = [
        key for key, expected_type in required_types.items()
        if key not in payload or not isinstance(payload.get(key), expected_type)
    ]
    active = payload.get("active") is True
    recovery_required = payload.get("recovery_required") is True
    state = str(payload.get("state") or "")
    state_ok = (
        (active and not recovery_required and state in {"starting", "running", "stopping"})
        or (not active and recovery_required and state == "recovery_failed")
        or (
            not active
            and not recovery_required
            and state in {"complete", "failed", "cancelled", "recovered"}
        )
    )
    chip = str(payload.get("chip") or "")
    die = str(payload.get("die") or "")
    descriptor = (
        payload.get("recovery_descriptor")
        if isinstance(payload.get("recovery_descriptor"), dict)
        else {}
    )
    target = descriptor.get("sgm_target") if isinstance(descriptor.get("sgm_target"), dict) else {}
    target_fingerprint_ok = bool(target) and str(target.get("sgm_device_fingerprint") or "") == sgm_target_fingerprint(target)
    semantic_error = None
    if payload.get("schema_version") != 2:
        semantic_error = f"unsupported schema_version={payload.get('schema_version')!r}"
    elif invalid_fields:
        semantic_error = f"missing or invalid fields: {', '.join(invalid_fields)}"
    elif not state_ok:
        semantic_error = f"invalid state combination: active={active}, recovery_required={recovery_required}, state={state!r}"
    elif not VALID_NAME_RE.fullmatch(chip) or not VALID_NAME_RE.fullmatch(die):
        semantic_error = f"invalid chip/die context: {chip!r}/{die!r}"
    elif payload.get("q_slot") not in POLARIZATION_Q_SLOTS:
        semantic_error = f"invalid q_slot={payload.get('q_slot')!r}"
    elif not target_fingerprint_ok:
        semantic_error = "missing or inconsistent SGM recovery target"
    if semantic_error:
        return corrupt_quick_probe_runtime(
            path,
            "单次模式归属运行标记内容不完整；为避免跳过安全恢复，已保守锁住硬件任务。",
            semantic_error,
        )
    return {**payload, "runtime_path": str(path)}


def unresolved_quick_probe_runtime(config: dict[str, Any]) -> dict[str, Any] | None:
    path = quick_probe_runtime_path(config)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = read_quick_probe_runtime(path)
    except OSError as exc:
        return corrupt_quick_probe_runtime(
            path,
            "无法访问本机单次模式归属安全状态目录；已保守锁住硬件任务。",
            repr(exc),
        )
    if not payload or not (bool(payload.get("active")) or bool(payload.get("recovery_required"))):
        return None
    return payload


def quick_probe_progress(
    config: dict[str, Any], chip: str, die: str, q_slot: object = "Q"
) -> dict[str, Any]:
    requested_chip = validate_name(chip, "chip")
    requested_die = validate_name(die, "die")
    requested_q_slot = normalize_q_slot(q_slot)
    with QUICK_PROBE_PROGRESS_LOCK:
        progress = dict(QUICK_PROBE_PROGRESS)
    with GLOBAL_HARDWARE_TASK_STATE_LOCK:
        hardware = dict(GLOBAL_HARDWARE_TASK_STATE)

    persisted = unresolved_quick_probe_runtime(config)
    if (
        persisted
        and not progress.get("active")
        and not progress.get("recovery_required")
        and not (
            bool(hardware.get("active"))
            and str(hardware.get("action") or "") in {"当前模式归属识别", "单次模式归属安全恢复"}
        )
    ):
        progress = update_quick_probe_progress(
            active=False,
            state="recovery_failed",
            phase="recovery_required_after_restart",
            chip=str(persisted.get("chip") or ""),
            die=str(persisted.get("die") or ""),
            q_slot=normalize_q_slot(persisted.get("q_slot")),
            message="检测到上次单次模式归属未确认安全恢复；请先点击“重试安全恢复”。",
            recovery_required=True,
            recovery=persisted.get("recovery"),
            recovery_descriptor=persisted.get("recovery_descriptor"),
            started_at=persisted.get("started_at"),
            error=str(persisted.get("error") or "上次任务未正常收口"),
        )

    hardware_action = str(hardware.get("action") or "")
    hardware_is_quick_probe_run = bool(hardware.get("active")) and hardware_action == "当前模式归属识别"
    hardware_is_quick_probe_recovery = bool(hardware.get("active")) and hardware_action == "单次模式归属安全恢复"
    hardware_is_quick_probe = hardware_is_quick_probe_run or hardware_is_quick_probe_recovery
    progress_matches = (
        str(progress.get("chip") or "") == requested_chip
        and str(progress.get("die") or "") == requested_die
        and str(progress.get("q_slot") or "Q") == requested_q_slot
    )
    hardware_matches = (
        str(hardware.get("chip") or "") == requested_chip
        and str(hardware.get("die") or "") == requested_die
        and str(hardware.get("q_slot") or "Q") == requested_q_slot
    )
    terminal_states = {"complete", "failed", "cancelled", "recovery_failed", "recovered"}
    if (
        hardware_is_quick_probe_run
        and not progress.get("active")
        and str(progress.get("state") or "idle") not in terminal_states
        and not progress.get("recovery_required")
    ):
        progress = update_quick_probe_progress(
            active=True,
            state="starting",
            phase="reserving_hardware",
            chip=str(hardware.get("chip") or ""),
            die=str(hardware.get("die") or ""),
            q_slot=str(hardware.get("q_slot") or "Q"),
            message="当前模式归属识别已登记，正在检查 PID / 仪器状态。",
            recovery_required=False,
            recovery=None,
            recovery_descriptor=None,
            started_at=hardware.get("started_at"),
        )
        progress_matches = hardware_matches
    elif hardware_is_quick_probe_recovery and not progress.get("active"):
        progress = update_quick_probe_progress(
            active=True,
            state="recovering",
            phase="recovering",
            chip=str(hardware.get("chip") or progress.get("chip") or ""),
            die=str(hardware.get("die") or progress.get("die") or ""),
            q_slot=str(hardware.get("q_slot") or progress.get("q_slot") or "Q"),
            message="正在重试 DAC 全零和示波器 continuous 恢复。",
            recovery_required=True,
            started_at=hardware.get("started_at"),
        )
        progress_matches = hardware_matches
    elif not hardware_is_quick_probe and progress.get("active"):
        if progress.get("recovery_required") or str(progress.get("state") or "") == "recovering":
            progress = update_quick_probe_progress(
                active=False,
                state="recovery_failed",
                phase="recovery_failed",
                message="安全恢复任务已不再占用硬件，但未确认恢复完成；请重试安全恢复。",
                recovery_required=True,
            )
        else:
            progress = update_quick_probe_progress(
                active=False,
                state="interrupted",
                phase="interrupted",
                message="单次模式归属任务已不再占用硬件；任务可能在仪器检查阶段结束，请重新启动。",
                recovery_required=False,
            )
        progress_matches = (
            str(progress.get("chip") or "") == requested_chip
            and str(progress.get("die") or "") == requested_die
            and str(progress.get("q_slot") or "Q") == requested_q_slot
        )
    elif not hardware_is_quick_probe and not progress_matches and not progress.get("recovery_required"):
        progress = {
            "active": False,
            "state": "idle",
            "phase": "idle",
            "chip": requested_chip,
            "die": requested_die,
            "q_slot": requested_q_slot,
            "message": "当前没有正在运行的单次模式归属识别。",
            "recovery_required": False,
            "recovery": None,
            "started_at": None,
            "updated_at": None,
        }

    return {
        "ok": True,
        **progress,
        "matches_context": bool(progress_matches),
        "hardware_action": hardware_action if hardware.get("active") else "",
    }


def tek_read_timetomin_samples(
    reader: TekTimeToMinReader,
    *,
    count: int,
    interval_s: float,
    baseline_time_s: float | None = None,
    min_valid: int = 1,
    max_attempts: int | None = None,
    prefer_positive_delta: bool = False,
    cancel_event: threading.Event | None = None,
    deadline_at: float | None = None,
) -> dict[str, Any]:
    samples: list[dict[str, Any]] = []
    started = time.perf_counter()
    requested_count = max(1, int(count))
    valid_target = max(1, int(min_valid))
    attempt_limit = max(requested_count, int(max_attempts if max_attempts is not None else requested_count))
    for index in range(attempt_limit):
        raise_if_cancelled_or_timed_out(
            cancel_event,
            deadline_at,
            timeout_message="当前模式归属识别超过总时限，已停止后续示波器采样。",
        )
        sample = reader.read_once()
        raise_if_cancelled_or_timed_out(
            cancel_event,
            deadline_at,
            timeout_message="当前模式归属识别超过总时限，已停止后续示波器采样。",
        )
        sample["index"] = index + 1
        sample["elapsed_since_start_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
        value = sample.get("time_to_min_s")
        if baseline_time_s is not None and isinstance(value, (int, float)) and math.isfinite(float(value)):
            delta = float(value) - float(baseline_time_s)
            sample["delta_time_s"] = delta
            sample["abs_delta_time_s"] = abs(delta)
        samples.append(sample)
        valid_count = sum(
            1 for item in samples
            if item.get("ok") and isinstance(item.get("time_to_min_s"), (int, float))
        )
        if index + 1 >= requested_count and valid_count >= valid_target:
            break
        if index + 1 < attempt_limit and interval_s > 0:
            wait_with_cancellation(interval_s, cancel_event)
    valid = [
        sample for sample in samples
        if sample.get("ok") and isinstance(sample.get("time_to_min_s"), (int, float))
    ]
    if baseline_time_s is not None:
        valid_with_delta = [
            sample for sample in valid
            if isinstance(sample.get("delta_time_s"), (int, float)) and math.isfinite(float(sample["delta_time_s"]))
        ]
        if prefer_positive_delta:
            selected = max(valid_with_delta, key=lambda item: float(item.get("delta_time_s") or -math.inf)) if valid_with_delta else None
        else:
            selected = max(valid_with_delta, key=lambda item: float(item.get("abs_delta_time_s") or 0.0)) if valid_with_delta else None
    else:
        selected = None
        if valid:
            values = sorted(float(sample["time_to_min_s"]) for sample in valid)
            median_value = values[len(values) // 2]
            selected = min(valid, key=lambda item: abs(float(item["time_to_min_s"]) - median_value))
    return {
        "ok": selected is not None,
        "count": len(samples),
        "requested_count": requested_count,
        "max_attempts": attempt_limit,
        "interval_s": interval_s,
        "num_valid_samples": len(valid),
        "selected": selected,
        "samples": samples,
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }


def run_thermal_quick_probe_shift(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    cancel_event: threading.Event | None = None,
    progress_callback: Any | None = None,
    cleanup_callback: Any | None = None,
    sgm_route_callback: Any | None = None,
) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = payload_q_slot(payload)
    voltage_v = float(payload.get("voltage_v") or 0.2)
    settle_s = min(2.0, max(0.0, float(payload.get("settle_s") or 0.02)))
    sample_count = min(20, max(1, int(float(payload.get("sample_count") or 5))))
    screen_sample_count = min(10, max(1, int(float(payload.get("screen_sample_count") or 3))))
    confirm_sample_count = min(20, max(1, int(float(payload.get("confirm_sample_count") or sample_count))))
    confirm_top_count = min(4, max(1, int(float(payload.get("confirm_top_count") or 2))))
    baseline_sample_count = min(10, max(1, int(float(payload.get("baseline_sample_count") or 3))))
    sample_interval_s = min(1.0, max(0.0, float(payload.get("sample_interval_s") or 0.02)))
    workflow_timeout_s = min(
        900.0,
        max(30.0, float(payload.get("workflow_timeout_s") or config.get("quick_probe_timeout_s") or 300.0)),
    )
    initial_gate_center_s = float(payload.get("initial_gate_center_s") or 0.0)
    initial_gate_half_width_s = abs(float(payload.get("initial_gate_half_width_s") or 0.0020))
    tracking_gate_left_s = abs(float(payload.get("tracking_gate_left_s") or 0.0001))
    tracking_gate_right_s = abs(float(
        payload.get("tracking_gate_right_s")
        or payload.get("tracking_gate_half_width_s")
        or 0.0024
    ))
    selected_mode = payload.get("selected_mode") if isinstance(payload.get("selected_mode"), dict) else None
    neighbor_risk = q_mode_close_neighbors(config, chip, die, selected_mode, q_slot=q_slot)
    try:
        tek_source_channel = int(float(
            payload.get("tek_source_channel")
            or payload.get("trans_channel")
            or config.get("trans_channel")
            or 2
        ))
    except (TypeError, ValueError):
        tek_source_channel = 2
    scope_type = str(payload.get("scope_type") or config.get("scope_type") or "").strip().lower()
    scope_resource = str(payload.get("scope_resource") or config.get("scope_resource") or "").strip()
    if scope_type != "tektronix_mso66b":
        raise ValueError(f"快速线型位移轮询现在使用 Tektronix TIMETOMIN；当前示波器类型是 {scope_type or '<empty>'}")
    if not scope_resource:
        raise ValueError("未配置 Tektronix 示波器 IP，无法读取 Time to Minimum")
    plan = build_thermal_auto_assignment_plan(config, chip, die, good_only=True)
    entries = sorted(
        [entry for entry in plan.get("active_entries", []) if entry.get("usable")],
        key=lambda item: (
            finite_int(item.get("probe")) if finite_int(item.get("probe")) is not None else 999,
            electrode_sort_key(str(item.get("electrode") or "")),
        ),
    )
    if not entries:
        raise ValueError("没有接触良好的探针可用于快速轮询")

    def report_progress(phase: str, message: str, **details: Any) -> None:
        if progress_callback is None:
            return
        try:
            progress_callback(
                {
                    "phase": phase,
                    "message": message,
                    "total_entries": len(entries),
                    **details,
                }
            )
        except Exception:
            pass

    started = time.perf_counter()
    deadline_at = started + workflow_timeout_s

    def check_workflow_deadline() -> None:
        raise_if_cancelled_or_timed_out(
            cancel_event,
            deadline_at,
            timeout_message=f"当前模式归属识别超过 {workflow_timeout_s:g} s 总时限，已停止后续轮询。",
        )

    steps: list[dict[str, Any]] = []
    restore: dict[str, Any] | None = None
    restore_scope_continuous: dict[str, Any] | None = None
    baseline: dict[str, Any] | None = None
    results: list[dict[str, Any]] = []
    provisional_ranked: list[dict[str, Any]] = []
    active_sgm_config = config
    tek = None
    write_error = None
    check_workflow_deadline()
    try:
        check_workflow_deadline()
        report_progress("zero_baseline_write", "正在将 DAC 全部通道归零。")
        zero = set_sgm_voltage(
            config,
            {"chip": chip, "die": die, "q_slot": q_slot, "all_zero": True, "manual_tmp": True},
            cancel_event=cancel_event,
        )
        steps.append({"name": "zero_baseline_write", "result": zero})
        if not zero.get("ok"):
            return {"ok": False, "stage": "zero_baseline_write", "steps": steps}
        active_sgm_config = quick_probe_sgm_recovery_config(
            config,
            quick_probe_sgm_target_after_write(quick_probe_sgm_recovery_target(config), zero),
        )
        if sgm_route_callback is not None:
            sgm_route_callback(zero)
        wait_with_cancellation(settle_s, cancel_event)
        report_progress("scope_setup", "正在配置示波器 Time to Minimum 测量窗口。")
        tek = TekTimeToMinReader(scope_resource, source_channel=tek_source_channel)
        check_workflow_deadline()
        setup = tek.setup(check_cancel=check_workflow_deadline)
        check_workflow_deadline()
        steps.append({"name": "tek_timetomin_setup", "result": setup})
        if not setup.get("ok"):
            return {"ok": False, "stage": "tek_timetomin_setup", "steps": steps, "setup": setup}
        initial_range = tek.set_measurement_range(initial_gate_center_s, initial_gate_half_width_s, check_cancel=check_workflow_deadline)
        check_workflow_deadline()
        steps.append({"name": "tek_timetomin_initial_gate", "result": initial_range})
        if not initial_range.get("ok"):
            return {"ok": False, "stage": "tek_timetomin_initial_gate", "steps": steps, "range": initial_range}

        report_progress("baseline_sampling", "正在读取全零基线。")
        baseline = tek_read_timetomin_samples(
            tek,
            count=baseline_sample_count,
            interval_s=sample_interval_s,
            min_valid=1,
            max_attempts=max(baseline_sample_count, baseline_sample_count + 5),
            cancel_event=cancel_event,
            deadline_at=deadline_at,
        )
        check_workflow_deadline()
        steps.append({"name": "zero_baseline_timetomin", "result": baseline})
        baseline_selected = baseline.get("selected") if isinstance(baseline.get("selected"), dict) else None
        baseline_t = (
            float(baseline_selected["time_to_min_s"])
            if baseline_selected and isinstance(baseline_selected.get("time_to_min_s"), (int, float))
            else math.nan
        )
        if not baseline.get("ok") or not math.isfinite(baseline_t):
            return {
                "ok": False,
                "stage": "zero_baseline_timetomin",
                "error": "TEK Time to Min 在指定 gating 时间窗口内没有读到有效 minimum；请把目标模式放进 gating 窗口，或调整窗口中心/宽度。程序不会退到全屏最小值，以免被邻近更深模式抢走。",
                "baseline": baseline,
                "initial_gate_center_s": initial_gate_center_s,
                "initial_gate_half_width_s": initial_gate_half_width_s,
                "neighbor_risk": neighbor_risk,
                "steps": steps,
            }
        tracking_range = tek.set_measurement_range_bounds(
            baseline_t - tracking_gate_left_s,
            baseline_t + tracking_gate_right_s,
            check_cancel=check_workflow_deadline,
        )
        steps.append({"name": "tek_timetomin_tracking_gate", "result": tracking_range})
        if not tracking_range.get("ok"):
            return {"ok": False, "stage": "tek_timetomin_tracking_gate", "baseline": baseline, "steps": steps}

        for entry_index, entry in enumerate(entries, start=1):
            check_workflow_deadline()
            probe = finite_int(entry.get("probe"))
            out = finite_int(entry.get("out"))
            if probe is None or out is None:
                continue
            report_progress(
                "screening",
                f"正在快速轮询 Probe {probe} / out{out} ({entry_index}/{len(entries)})。",
                current_index=entry_index,
                current_probe=probe,
                current_out=out,
                current_electrode=entry.get("electrode"),
                current_cavity=entry.get("cavity"),
            )
            item: dict[str, Any] = {
                "probe": probe,
                "out": out,
                "electrode": entry.get("electrode"),
                "design_cavity": entry.get("cavity"),
                "contact_status": entry.get("contact_status"),
                "voltage_v": voltage_v,
            }
            write_started = time.perf_counter()
            write = set_sgm_voltage(
                active_sgm_config,
                {
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "probe": probe,
                    "out": out,
                    "voltage_v": voltage_v,
                    "write_mode": "single_channel",
                    "manual_tmp": True,
                },
                cancel_event=cancel_event,
            )
            write_elapsed_ms = round((time.perf_counter() - write_started) * 1000.0, 3)
            item["write"] = write
            item["write_elapsed_ms"] = write_elapsed_ms
            if not write.get("ok"):
                item["ok"] = False
                item["stage"] = "write_sgm"
                results.append(item)
                return {
                    "ok": False,
                    "stage": "write_sgm",
                    "failed_item": item,
                    "baseline": baseline,
                    "results": results,
                    "steps": steps,
                }
            if sgm_route_callback is not None:
                sgm_route_callback(write)
            wait_with_cancellation(settle_s, cancel_event)
            report_progress("probe_sampling", f"正在读取 Probe {probe} / out{out} 的初筛样本。", current_probe=probe, current_out=out)
            reading = tek_read_timetomin_samples(
                tek,
                count=screen_sample_count,
                interval_s=sample_interval_s,
                baseline_time_s=baseline_t,
                min_valid=1,
                max_attempts=max(screen_sample_count, screen_sample_count + 3),
                prefer_positive_delta=True,
                cancel_event=cancel_event,
                deadline_at=deadline_at,
            )
            check_workflow_deadline()
            selected = reading.get("selected") if isinstance(reading.get("selected"), dict) else None
            loaded_t = (
                float(selected["time_to_min_s"])
                if selected and isinstance(selected.get("time_to_min_s"), (int, float))
                else None
            )
            delta_t = loaded_t - baseline_t if loaded_t is not None else None
            item.update(
                {
                    "ok": bool(reading.get("ok") and loaded_t is not None),
                    "reading": reading,
                    "baseline_dip_time_s": baseline_t,
                    "loaded_dip_time_s": loaded_t,
                    "delta_time_s": delta_t,
                    "abs_delta_time_s": abs(delta_t) if delta_t is not None else None,
                    "dip_read_elapsed_ms": reading.get("elapsed_ms") if isinstance(reading, dict) else None,
                    "sgm_total_ms": (write.get("timing_ms") or {}).get("total_server") if isinstance(write, dict) else None,
                    "screening_reading": reading,
                    "screening_loaded_dip_time_s": loaded_t,
                    "screening_delta_time_s": delta_t,
                    "screening_sample_count": screen_sample_count,
                    "confirmation_ok": False,
                }
            )
            results.append(item)

        provisional_candidates = sorted(
            [item for item in results if item.get("delta_time_s") is not None],
            key=lambda item: (
                float(item["delta_time_s"])
                if item.get("delta_time_s") is not None
                else -math.inf
            ),
            reverse=True,
        )
        provisional_ranked = [dict(item) for item in provisional_candidates]
        for confirmation_rank, item in enumerate(provisional_candidates[:confirm_top_count], start=1):
            check_workflow_deadline()
            probe = finite_int(item.get("probe"))
            out = finite_int(item.get("out"))
            if probe is None or out is None:
                continue
            report_progress(
                "confirmation",
                f"正在复核候选 Probe {probe} / out{out} ({confirmation_rank}/{min(confirm_top_count, len(provisional_candidates))})。",
                confirmation_index=confirmation_rank,
                confirmation_total=min(confirm_top_count, len(provisional_candidates)),
                current_probe=probe,
                current_out=out,
                current_electrode=item.get("electrode"),
                current_cavity=item.get("design_cavity"),
            )
            confirm_write_started = time.perf_counter()
            confirm_write = set_sgm_voltage(
                active_sgm_config,
                {
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "probe": probe,
                    "out": out,
                    "voltage_v": voltage_v,
                    "write_mode": "single_channel",
                    "manual_tmp": True,
                },
                cancel_event=cancel_event,
            )
            item["confirmation_rank"] = confirmation_rank
            item["confirmation_write"] = confirm_write
            item["confirmation_write_elapsed_ms"] = round(
                (time.perf_counter() - confirm_write_started) * 1000.0,
                3,
            )
            if not confirm_write.get("ok"):
                item["ok"] = False
                item["stage"] = "confirm_write_sgm"
                return {
                    "ok": False,
                    "stage": "confirm_write_sgm",
                    "failed_item": item,
                    "baseline": baseline,
                    "results": results,
                    "steps": steps,
                }
            if sgm_route_callback is not None:
                sgm_route_callback(confirm_write)
            wait_with_cancellation(settle_s, cancel_event)
            report_progress("confirmation_sampling", f"正在读取 Probe {probe} / out{out} 的复核样本。", current_probe=probe, current_out=out)
            confirmation_reading = tek_read_timetomin_samples(
                tek,
                count=confirm_sample_count,
                interval_s=sample_interval_s,
                baseline_time_s=baseline_t,
                min_valid=1,
                max_attempts=max(confirm_sample_count, confirm_sample_count + 3),
                prefer_positive_delta=True,
                cancel_event=cancel_event,
                deadline_at=deadline_at,
            )
            check_workflow_deadline()
            confirmation_selected = (
                confirmation_reading.get("selected")
                if isinstance(confirmation_reading.get("selected"), dict)
                else None
            )
            confirmation_loaded_t = (
                float(confirmation_selected["time_to_min_s"])
                if confirmation_selected
                and isinstance(confirmation_selected.get("time_to_min_s"), (int, float))
                else None
            )
            confirmation_delta_t = (
                confirmation_loaded_t - baseline_t
                if confirmation_loaded_t is not None
                else None
            )
            item.update(
                {
                    "ok": bool(confirmation_reading.get("ok") and confirmation_loaded_t is not None),
                    "reading": confirmation_reading,
                    "loaded_dip_time_s": confirmation_loaded_t,
                    "delta_time_s": confirmation_delta_t,
                    "abs_delta_time_s": (
                        abs(confirmation_delta_t)
                        if confirmation_delta_t is not None
                        else None
                    ),
                    "dip_read_elapsed_ms": confirmation_reading.get("elapsed_ms"),
                    "confirmation_reading": confirmation_reading,
                    "confirmation_loaded_dip_time_s": confirmation_loaded_t,
                    "confirmation_delta_time_s": confirmation_delta_t,
                    "confirmation_sample_count": confirm_sample_count,
                    "confirmation_ok": bool(
                        confirmation_reading.get("ok")
                        and confirmation_loaded_t is not None
                    ),
                }
            )
    except SgmWriteError as exc:
        write_error = exc.result
        if cancel_event is not None and cancel_event.is_set():
            raise WorkflowCancelled("停止请求已收到；电压写入返回失败或结果未知") from exc
        raise
    finally:
        pending_error = sys.exc_info()[1]
        recovery = finish_thermal_io(
            active_sgm_config,
            {**payload, "chip": chip, "die": die, "q_slot": q_slot, "manual_tmp": True},
            write_error=write_error, reader=tek,
            scope_restore={"ok": True, "skipped": True, "reason": "尚未打开示波器连接"} if tek is None else None,
            progress_callback=lambda details: report_progress(**details),
        )
        restore = recovery["restore_zero"]
        restore_scope_continuous = recovery["restore_scope_run_continuous"]
        steps.append({"name": "restore_zero", "result": restore})
        steps.append({"name": "restore_scope_run_continuous", "result": restore_scope_continuous})
        if tek is not None:
            try:
                tek.close()
            except Exception as exc:
                recovery["ok"] = False
                recovery["scope_close_error"] = repr(exc)
        if pending_error is not None:
            pending_error.recovery = recovery
        if cleanup_callback is not None:
            try:
                cleanup_callback(recovery)
            except Exception:
                pass
    raise_if_cancelled(cancel_event, recovery=recovery)

    ranked = sorted(
        [item for item in results if item.get("delta_time_s") is not None],
        key=lambda item: (
            float(item["delta_time_s"])
            if item.get("delta_time_s") is not None
            else -math.inf
        ),
        reverse=True,
    )
    return {
        "ok": bool(
            baseline
            and baseline.get("ok")
            and results
            and restore
            and restore.get("ok")
            and restore_scope_continuous
            and restore_scope_continuous.get("ok")
        ),
        "message": f"快速线型位移轮询完成；全零 baseline 只测一次，全部通道先快速初筛，再复核初筛前 {confirm_top_count} 名。",
        "chip": chip,
        "die": die,
        "q_slot": q_slot,
        "voltage_v": voltage_v,
        "settle_s": settle_s,
        "measurement_method": "tektronix_timetomin",
        "scope_type": scope_type,
        "scope_resource": scope_resource,
        "tek_source_channel": tek_source_channel,
        "baseline_sample_count": baseline_sample_count,
        "sample_count": sample_count,
        "screen_sample_count": screen_sample_count,
        "confirm_sample_count": confirm_sample_count,
        "confirm_top_count": confirm_top_count,
        "sample_interval_s": sample_interval_s,
        "workflow_timeout_s": workflow_timeout_s,
        "initial_gate_center_s": initial_gate_center_s,
        "initial_gate_half_width_s": initial_gate_half_width_s,
        "tracking_gate_left_s": tracking_gate_left_s,
        "tracking_gate_right_s": tracking_gate_right_s,
        "tracking_gate_half_width_s": max(tracking_gate_left_s, tracking_gate_right_s),
        "expected_shift_direction": "right",
        "neighbor_risk": neighbor_risk,
        "elapsed_s": time.perf_counter() - started,
        "baseline": baseline,
        "results": results,
        "provisional_ranked": provisional_ranked,
        "ranked": ranked,
        "best": ranked[0] if ranked else None,
        "restore_zero": restore,
        "restore_scope_run_continuous": restore_scope_continuous,
        "steps": steps,
        "note": f"这里的 Δt 来自 Tektronix MSO66B 的 TIMETOMIN + Gating(Time) 测量；全部可用通道各读 {screen_sample_count} 次初筛，初筛前 {confirm_top_count} 路各读 {confirm_sample_count} 次复核，最终排序优先使用复核读数。",
    }


def run_standalone_thermal_quick_probe_shift(
    config: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = normalize_q_slot(payload.get("q_slot"))
    started_at = datetime.now().isoformat(timespec="seconds")
    recovery_descriptor = quick_probe_recovery_descriptor(config, payload)
    update_quick_probe_progress(
        active=True,
        state="running",
        phase="starting",
        chip=chip,
        die=die,
        q_slot=q_slot,
        message="正在启动当前模式归属识别。",
        recovery_required=False,
        recovery=None,
        recovery_descriptor=recovery_descriptor,
        started_at=started_at,
        error=None,
    )
    persist_current_quick_probe_progress(config)
    cleanup: dict[str, Any] = {}

    def report(progress: dict[str, Any]) -> None:
        update_quick_probe_progress(
            active=True,
            state="stopping" if QUICK_PROBE_CANCEL_EVENT.is_set() else "running",
            chip=chip,
            die=die,
            q_slot=q_slot,
            **progress,
        )

    def capture_cleanup(recovery: dict[str, Any]) -> None:
        cleanup.clear()
        cleanup.update(recovery)

    def capture_sgm_route(write_result: dict[str, Any]) -> None:
        current_target = (
            recovery_descriptor.get("sgm_target")
            if isinstance(recovery_descriptor.get("sgm_target"), dict)
            else {}
        )
        updated_target = quick_probe_sgm_target_after_write(current_target, write_result)
        if updated_target.get("sgm_device_fingerprint") == current_target.get("sgm_device_fingerprint"):
            return
        recovery_descriptor["sgm_target"] = updated_target
        update_quick_probe_progress(recovery_descriptor=dict(recovery_descriptor))
        # Persist the actual route before any subsequent non-zero write.
        persist_current_quick_probe_progress(config)

    try:
        result = run_thermal_quick_probe_shift(
            config,
            payload,
            cancel_event=QUICK_PROBE_CANCEL_EVENT,
            progress_callback=report,
            cleanup_callback=capture_cleanup,
            sgm_route_callback=capture_sgm_route,
        )
    except WorkflowCancelled:
        recovery_ok = cleanup.get("ok") is True
        state = "cancelled" if recovery_ok else "recovery_failed"
        message = (
            "当前模式归属识别已停止；DAC 已归零，示波器已恢复 continuous 扫描。"
            if recovery_ok
            else "当前模式归属识别已停止，但安全恢复未全部成功；请点击“重试安全恢复”。"
        )
        update_quick_probe_progress(
            active=False,
            state=state,
            phase=state,
            chip=chip,
            die=die,
            q_slot=q_slot,
            message=message,
            recovery_required=not recovery_ok,
            recovery=cleanup or None,
            error=None if recovery_ok else "DAC 全零或示波器 continuous 恢复失败",
        )
        persist_current_quick_probe_progress(config)
        return {
            "ok": recovery_ok,
            "cancelled": True,
            "message": message,
            "chip": chip,
            "die": die,
            "recovery_required": not recovery_ok,
            "recovery": cleanup or None,
        }
    except Exception as exc:
        recovery_failed = bool(cleanup) and cleanup.get("ok") is not True
        state = "recovery_failed" if recovery_failed else "failed"
        message = (
            "当前模式归属识别失败，且安全恢复未全部成功；请点击“重试安全恢复”。"
            if recovery_failed
            else "当前模式归属识别失败。"
        )
        update_quick_probe_progress(
            active=False,
            state=state,
            phase=state,
            chip=chip,
            die=die,
            q_slot=q_slot,
            message=message,
            recovery_required=recovery_failed,
            recovery=cleanup or None,
            error=repr(exc),
        )
        persist_current_quick_probe_progress(config)
        return {
            "ok": False,
            "message": message,
            "error": repr(exc),
            "chip": chip,
            "die": die,
            "timed_out": isinstance(exc, TimeoutError),
            "recovery_required": recovery_failed,
            "recovery": cleanup or None,
        }

    recovery_failed = bool(cleanup) and cleanup.get("ok") is not True
    if recovery_failed:
        result = {
            **result,
            "ok": False,
            "stage": "recovery_failed",
            "message": "识别流程已结束，但安全恢复未全部成功；请点击“重试安全恢复”。",
            "recovery_required": True,
            "recovery": cleanup,
        }
    state = "recovery_failed" if recovery_failed else "complete" if result.get("ok") else "failed"
    update_quick_probe_progress(
        active=False,
        state=state,
        phase=state,
        chip=chip,
        die=die,
        q_slot=q_slot,
        message=str(result.get("message") or ("当前模式归属识别完成。" if result.get("ok") else "当前模式归属识别失败。")),
        recovery_required=recovery_failed,
        recovery=cleanup or None,
        error=None if result.get("ok") else str(result.get("error") or result.get("stage") or "运行结果未通过"),
    )
    persist_current_quick_probe_progress(config)
    return result


def reserve_thermal_quick_probe_shift(payload: dict[str, Any]) -> None:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = normalize_q_slot(payload.get("q_slot"))
    QUICK_PROBE_CANCEL_EVENT.clear()
    update_quick_probe_progress(
        active=True,
        state="starting",
        phase="reserving_hardware",
        chip=chip,
        die=die,
        q_slot=q_slot,
        message="当前模式归属识别已登记，正在检查 PID / 仪器状态。",
        recovery_required=False,
        recovery=None,
        recovery_descriptor=None,
        started_at=datetime.now().isoformat(timespec="seconds"),
        error=None,
    )


def recover_thermal_quick_probe_hardware(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = payload_q_slot(payload)
    target = payload.get("sgm_target") if isinstance(payload.get("sgm_target"), dict) else {}
    try:
        recovery_config = quick_probe_sgm_recovery_config(config, target)
        restore_zero = set_sgm_voltage(
            recovery_config,
            {"chip": chip, "die": die, "q_slot": q_slot, "all_zero": True, "manual_tmp": True},
        )
        target_verified = quick_probe_sgm_zero_result_matches_target(restore_zero, recovery_config)
        if restore_zero.get("ok") and not target_verified:
            restore_zero = {
                **restore_zero,
                "ok": False,
                "target_verified": False,
                "error": "DAC 返回成功，但无法确认归零结果来自原 SGM 目标",
            }
    except Exception as exc:
        restore_zero = {"ok": False, "error": repr(exc)}
        target_verified = False
    try:
        restore_scope = restore_tek_run_continuous(config, payload)
    except Exception as exc:
        restore_scope = {"ok": False, "error": repr(exc)}
    recovery = {
        "ok": bool(restore_zero.get("ok") and target_verified and restore_scope.get("ok")),
        "restore_zero": restore_zero,
        "restore_scope_run_continuous": restore_scope,
        "sgm_target_verified": target_verified,
    }
    if recovery["ok"]:
        message = "安全恢复完成：DAC 已归零，示波器已恢复 continuous 扫描。"
        update_quick_probe_progress(
            active=False,
            state="recovered",
            phase="recovered",
            chip=chip,
            die=die,
            q_slot=q_slot,
            message=message,
            recovery_required=False,
            recovery=recovery,
            error=None,
        )
    else:
        message = "安全恢复仍未全部成功；已保持其他硬件任务禁用，请检查 DAC / 示波器连接后重试。"
        update_quick_probe_progress(
            active=False,
            state="recovery_failed",
            phase="recovery_failed",
            chip=chip,
            die=die,
            q_slot=q_slot,
            message=message,
            recovery_required=True,
            recovery=recovery,
            error="DAC 全零或示波器 continuous 恢复失败",
        )
    persist_current_quick_probe_progress(config)
    return {
        "ok": recovery["ok"],
        "recovered": recovery["ok"],
        "message": message,
        "recovery_required": not recovery["ok"],
        "recovery": recovery,
    }


def stop_thermal_quick_probe_shift(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    try:
        quick_probe_progress(
            config,
            validate_name(str(payload.get("chip") or ""), "chip"),
            validate_name(str(payload.get("die") or ""), "die"),
        )
    except (ValueError, FileNotFoundError):
        pass
    stop_registered = False
    registered_terminal = False
    terminal_recovery_required = False
    with GLOBAL_HARDWARE_TASK_STATE_LOCK:
        hardware = dict(GLOBAL_HARDWARE_TASK_STATE)
        registered = bool(hardware.get("active")) and str(
            hardware.get("action") or ""
        ) == "当前模式归属识别"
        if registered:
            with QUICK_PROBE_PROGRESS_LOCK:
                progress_during_run = dict(QUICK_PROBE_PROGRESS)
            terminal_recovery_required = bool(progress_during_run.get("recovery_required"))
            registered_terminal = (
                not bool(progress_during_run.get("active"))
                or str(progress_during_run.get("state") or "")
                in {"complete", "failed", "cancelled", "recovery_failed", "recovered"}
            )
            if not registered_terminal and not terminal_recovery_required:
                QUICK_PROBE_CANCEL_EVENT.set()
                update_quick_probe_progress(
                    active=True,
                    state="stopping",
                    phase="stopping",
                    chip=str(hardware.get("chip") or ""),
                    die=str(hardware.get("die") or ""),
                    message="已请求停止；等待当前单次仪器读写返回后，将执行 DAC 全零和示波器 continuous 恢复。",
                    recovery_required=False,
                )
                stop_registered = True
    if stop_registered:
        return {
            "ok": True,
            "stop_requested": True,
            "message": "已发送停止请求；正在结束当前仪器操作并执行安全恢复。",
        }
    if registered and (registered_terminal or terminal_recovery_required):
        return {
            "ok": True,
            "stop_requested": False,
            "recovery_required": terminal_recovery_required,
            "message": (
                "识别已结束，正在释放硬件任务；安全恢复状态不会被新的停止请求覆盖。"
                if terminal_recovery_required
                else "识别已结束，正在释放硬件任务。"
            ),
        }

    with QUICK_PROBE_PROGRESS_LOCK:
        progress = dict(QUICK_PROBE_PROGRESS)
    if progress.get("recovery_required"):
        descriptor = (
            dict(progress.get("recovery_descriptor"))
            if isinstance(progress.get("recovery_descriptor"), dict)
            else {}
        )
        recovery_payload = {
            **payload,
            "chip": str(progress.get("chip") or payload.get("chip") or ""),
            "die": str(progress.get("die") or payload.get("die") or ""),
            "q_slot": str(progress.get("q_slot") or payload.get("q_slot") or "Q"),
            **descriptor,
        }
        return run_exclusive_hardware_task(
            "单次模式归属安全恢复",
            recovery_payload,
            lambda: recover_thermal_quick_probe_hardware(config, recovery_payload),
            config=config,
            allow_active_pid=True,
            on_reserved=lambda: update_quick_probe_progress(
                active=True,
                state="recovering",
                phase="recovering",
                chip=str(recovery_payload.get("chip") or ""),
                die=str(recovery_payload.get("die") or ""),
                q_slot="Q",
                message="正在重试 DAC 全零和示波器 continuous 恢复。",
                recovery_required=True,
            ),
        )

    if progress.get("active"):
        update_quick_probe_progress(
            active=False,
            state="interrupted",
            phase="interrupted",
            message="单次模式归属任务已不再占用硬件；无需发送停止请求。",
            recovery_required=False,
        )
    return {
        "ok": True,
        "stop_requested": False,
        "message": "当前没有正在运行的单次模式归属识别。",
    }


def run_exclusive_hardware_task(
    action: str,
    payload: dict[str, Any],
    operation: Any,
    *,
    config: dict[str, Any] | None = None,
    allow_active_pid: bool = False,
    on_reserved: Any | None = None,
) -> dict[str, Any]:
    if not GLOBAL_HARDWARE_TASK_RUN_LOCK.acquire(blocking=False):
        with GLOBAL_HARDWARE_TASK_STATE_LOCK:
            active_action = str(GLOBAL_HARDWARE_TASK_STATE.get("action") or "其他硬件任务")
        raise ValueError(f"已有硬件任务正在运行：{active_action}")
    reserved = False
    hardware_file_lock = None
    try:
        if config is not None:
            hardware_file_lock = acquire_dashboard_hardware_file_lock(config)
            if hardware_file_lock is None:
                raise ValueError("另一 Dashboard 进程正在执行硬件任务；请回到启动任务的面板查看或停止")
        with GLOBAL_HARDWARE_TASK_STATE_LOCK:
            if GLOBAL_HARDWARE_TASK_STATE.get("stop_active"):
                stop_label = str(GLOBAL_HARDWARE_TASK_STATE.get("stop_label") or "硬件停止/恢复")
                raise ValueError(f"{stop_label}仍在执行；完成前不能启动“{action}”")
            with QUICK_PROBE_PROGRESS_LOCK:
                quick_probe_recovery_required = bool(QUICK_PROBE_PROGRESS.get("recovery_required"))
            persisted_quick_probe = unresolved_quick_probe_runtime(config) if config is not None else None
            if (quick_probe_recovery_required or persisted_quick_probe) and action != "单次模式归属安全恢复":
                persisted_context = ""
                if persisted_quick_probe:
                    persisted_context = (
                        f"（{persisted_quick_probe.get('chip') or '?'} / "
                        f"{persisted_quick_probe.get('die') or '?'}）"
                    )
                raise ValueError(f"单次模式归属的安全恢复尚未完成{persisted_context}；请先点击“重试安全恢复”")
            GLOBAL_HARDWARE_TASK_STATE.update(
                {
                    "active": True,
                    "action": action,
                    "chip": str(payload.get("chip") or ""),
                    "die": str(payload.get("die") or ""),
                    "q_slot": payload_q_slot(payload),
                    "started_at": datetime.now().isoformat(timespec="seconds"),
                }
            )
            reserved = True
            if on_reserved is not None:
                on_reserved()
        if config is not None:
            with CURRENT_MODE_LOCK_STATE_LOCK:
                memory_active = bool(CURRENT_MODE_LOCK_STATE.get("active"))
            if not memory_active:
                current_mode_lock_status(
                    config,
                    str(payload.get("chip") or ""),
                    str(payload.get("die") or ""),
                )
        if not allow_active_pid:
            with CURRENT_MODE_LOCK_STATE_LOCK:
                if CURRENT_MODE_LOCK_STATE.get("active"):
                    state = str(CURRENT_MODE_LOCK_STATE.get("state") or "unknown")
                    raise ValueError(
                        f"PID 当前处于 {state} 状态；请先点击“停止测量”恢复扫频，再执行“{action}”"
                    )
        return operation()
    finally:
        if reserved:
            with GLOBAL_HARDWARE_TASK_STATE_LOCK:
                GLOBAL_HARDWARE_TASK_STATE.update(
                    {
                        "active": False,
                        "action": "",
                        "chip": "",
                        "die": "",
                        "q_slot": "",
                        "started_at": None,
                    }
                )
        try:
            release_dashboard_hardware_file_lock(hardware_file_lock)
        finally:
            GLOBAL_HARDWARE_TASK_RUN_LOCK.release()


def current_mode_lock_status(
    config: dict[str, Any],
    chip: str = "",
    die: str = "",
) -> dict[str, Any]:
    with CURRENT_MODE_LOCK_PROBE_LOCK:
        with CURRENT_MODE_LOCK_STATE_LOCK:
            probe_generation = int(CURRENT_MODE_LOCK_STATE.get("generation") or 0)
        try:
            instrument_state = instrument_get(config, "/api/lock/status", {})
        except Exception as exc:
            instrument_state = {
                "ok": False,
                "state": "unknown",
                "hardware_active": None,
                "probe_ok": False,
                "error": repr(exc),
            }
        with CURRENT_MODE_LOCK_STATE_LOCK:
            stale_probe = int(CURRENT_MODE_LOCK_STATE.get("generation") or 0) != probe_generation
            if not stale_probe:
                memory_state = str(CURRENT_MODE_LOCK_STATE.get("state") or "idle")
                hardware_active = instrument_state.get("hardware_active")
                if hardware_active is True:
                    probed_state = (
                        str(instrument_state.get("state"))
                        if instrument_state.get("state") in {"locked", "starting"}
                        else "unknown"
                    )
                    if not CURRENT_MODE_LOCK_STATE.get("active"):
                        CURRENT_MODE_LOCK_STATE.update(
                            {
                                "generation": probe_generation + 1,
                                "state": probed_state,
                                "active": True,
                                "chip": "",
                                "die": "",
                                "q_slot": "Q",
                                "optical_mode": None,
                                "last_spectrum": None,
                                "started_at": None,
                                "stopped_at": None,
                            }
                        )
                    elif memory_state == "starting" and probed_state == "locked":
                        CURRENT_MODE_LOCK_STATE.update(
                            {
                                "generation": probe_generation + 1,
                                "state": "locked",
                            }
                        )
                elif (
                    hardware_active is False
                    and CURRENT_MODE_LOCK_STATE.get("active")
                    and memory_state not in {"starting", "stopping"}
                ):
                    CURRENT_MODE_LOCK_STATE.update(
                        {
                            "generation": probe_generation + 1,
                            "state": "idle",
                            "active": False,
                            "chip": "",
                            "die": "",
                            "q_slot": "",
                            "optical_mode": None,
                            "last_spectrum": None,
                            "started_at": None,
                        }
                    )
                elif hardware_active is None and not CURRENT_MODE_LOCK_STATE.get("active"):
                    CURRENT_MODE_LOCK_STATE.update(
                        {
                            "generation": probe_generation + 1,
                            "state": "unknown",
                            "active": True,
                            "chip": "",
                            "die": "",
                            "q_slot": "Q",
                            "optical_mode": None,
                            "last_spectrum": None,
                            "started_at": None,
                            "stopped_at": None,
                        }
                    )
            else:
                instrument_state = {**instrument_state, "ignored_stale": True}
            state = dict(CURRENT_MODE_LOCK_STATE)
    state["matches_context"] = bool(
        state.get("active")
        and chip
        and die
        and state.get("chip") == chip
        and state.get("die") == die
    )
    return {"ok": True, **state, "instrument_state": instrument_state}


def resolve_rp(config: dict[str, Any]) -> dict[str, Any]:
    host = str(config.get("rp_hostname") or "").strip()
    if not host:
        return {"ok": False, "message": "未配置 RP host"}
    try:
        infos = socket.getaddrinfo(host, None)
        addresses = sorted({item[4][0] for item in infos})
        return {"ok": True, "host": host, "addresses": addresses}
    except Exception as exc:
        return {"ok": False, "host": host, "message": repr(exc)}
