"""Find configured instruments and check their identities; no measurement workflow."""
from __future__ import annotations
from a221_workbench._shared.paths import module_file
from urllib.parse import urlparse, urlunparse
from typing import Any
from a221_workbench.workflows.array_dashboard.comb_measurement import (
    parse_external_json,
    resolve_scope_python,
    resolve_toptica_python,
    run_python_worker_with_json_request,
)


from a221_workbench.tasks.array_records import (
    CONFIG_FILE,
    DEFAULT_CONFIG,
    EXPERIMENT_CONTEXT_FILE,
    data_root,
    list_chips,
    save_config,
)


import concurrent.futures

import importlib.util

import ipaddress

import json

import re

import socket

import subprocess

import sys


def active_experiment_context(config: dict[str, Any]) -> dict[str, Any] | None:
    root = data_root(config)
    if root is None:
        return None
    path = root / EXPERIMENT_CONTEXT_FILE
    if not path.exists() or not path.is_file():
        return None
    try:
        context = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(context, dict) or context.get("kind") != "array_cavity_reference_experiment":
        return None
    return {**context, "context_path": str(path)}


def canonical_instrument_identity(value: object) -> str:
    return "".join(char for char in str(value or "").upper() if char.isalnum())


def instrument_identity_matches(expected: object, actual: object) -> bool:
    expected_key = canonical_instrument_identity(expected)
    actual_key = canonical_instrument_identity(actual)
    if not expected_key:
        return bool(actual_key)
    if expected_key == actual_key:
        return True
    return min(len(expected_key), len(actual_key)) >= 6 and (
        expected_key.endswith(actual_key) or actual_key.endswith(expected_key)
    )


def mac_address_for_ipv4(address: str) -> str:
    try:
        proc = subprocess.run(
            ["arp", "-a", address],
            text=True,
            capture_output=True,
            timeout=2.0,
            check=False,
        )
    except Exception:
        return ""
    address_pattern = re.escape(str(address))
    match = re.search(
        rf"(?im)^\s*{address_pattern}\s+([0-9a-f]{{2}}(?:[-:][0-9a-f]{{2}}){{5}})\s+",
        proc.stdout,
    )
    if not match:
        return ""
    return match.group(1).replace("-", ":").lower()


def discover_redpitaya_identity(config: dict[str, Any], expected_device_id: str) -> dict[str, Any]:
    from a221_workbench.instruments.redpitaya.network import resolve_host
    expected = str(expected_device_id or config.get("rp_hostname") or "").strip()
    try:
        host, address = resolve_host(expected)
        mac = mac_address_for_ipv4(address)
        from a221_workbench.instruments.redpitaya.network import identity_matches
        if not identity_matches(expected, mac):
            raise RuntimeError("RP MAC 身份未能核验；不根据主机名猜测设备身份")
        matched = dict(ok=True, host=host, address=address, mac_address=mac,
                       device_id="RP-" + canonical_instrument_identity(mac))
        return dict(ok=True, expected_device_id=expected, matched=matched, candidates=[matched])
    except Exception as exc:
        return dict(ok=False, expected_device_id=expected, matched=None,
                    candidates=[dict(ok=False, host=expected, error=str(exc))])


def local_private_ipv4_networks() -> list[ipaddress.IPv4Network]:
    networks: list[ipaddress.IPv4Network] = []
    lab_ranges = (
        ipaddress.ip_network("10.0.0.0/8"),
        ipaddress.ip_network("172.16.0.0/12"),
        ipaddress.ip_network("192.168.0.0/16"),
    )
    if sys.platform.startswith("win"):
        command = (
            "Get-NetIPAddress -AddressFamily IPv4 | "
            "Where-Object {$_.IPAddress -notlike '127.*' -and $_.AddressState -eq 'Preferred'} | "
            "Select-Object IPAddress,PrefixLength | ConvertTo-Json -Compress"
        )
        try:
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-Command", command],
                text=True,
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=4.0,
                check=False,
            )
            payload = json.loads(proc.stdout or "[]")
            rows = payload if isinstance(payload, list) else [payload]
            for row in rows:
                address = ipaddress.ip_address(str(row.get("IPAddress") or ""))
                prefix = max(24, int(row.get("PrefixLength") or 24))
                network = ipaddress.ip_network(f"{address}/{prefix}", strict=False)
                if (
                    any(address in lab_range for lab_range in lab_ranges)
                    and network.num_addresses <= 256
                    and network not in networks
                ):
                    networks.append(network)
        except Exception:
            pass
    return networks


def tcp_port_open(host: str, port: int, timeout_s: float = 0.12) -> bool:
    try:
        with socket.create_connection((host, int(port)), timeout=timeout_s):
            return True
    except OSError:
        return False


def resolve_ipv4_hosts(host: str) -> list[str]:
    if not host:
        return []
    try:
        return sorted(
            {
                str(item[4][0])
                for item in socket.getaddrinfo(host, 1998, family=socket.AF_INET)
            }
        )
    except Exception:
        return [host]


def scan_toptica_hosts(exclude: set[str] | None = None) -> list[str]:
    excluded = set(exclude or ())
    candidates: list[str] = []
    scan_hosts = [
        str(address)
        for network in local_private_ipv4_networks()
        for address in network.hosts()
        if str(address) not in excluded
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=48) as executor:
        future_hosts = {
            executor.submit(tcp_port_open, host, 1998): host
            for host in scan_hosts
        }
        for future in concurrent.futures.as_completed(future_hosts):
            if future.result():
                candidates.append(future_hosts[future])
    return candidates


def query_toptica_identity(config: dict[str, Any], host: str) -> dict[str, Any]:
    worker = module_file('a221_workbench.instruments.toptica.tcp_worker')
    command = [
        str(resolve_toptica_python(config)),
        str(worker),
        "--action",
        "read_arc_factor",
        "--host",
        host,
    ]
    proc = subprocess.run(
        command,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        timeout=8.0,
        check=False,
    )
    result = parse_external_json(proc.stdout)
    result["host"] = host
    if proc.returncode != 0 or not result.get("ok"):
        raise RuntimeError(result)
    return result


def discover_toptica_identity(config: dict[str, Any], expected_serial: str) -> dict[str, Any]:
    expected = str(expected_serial or "").strip()
    candidates: list[dict[str, Any]] = []
    preferred_hosts = resolve_ipv4_hosts(str(config.get("laser_host") or "").strip())
    for host in preferred_hosts:
        try:
            candidates.append(query_toptica_identity(config, host))
        except Exception as exc:
            candidates.append({"ok": False, "host": host, "error": repr(exc)})
    matched = next(
        (
            item
            for item in candidates
            if item.get("ok")
            and (
                not expected
                or instrument_identity_matches(expected, item.get("serial_number"))
            )
        ),
        None,
    )
    if matched is not None:
        return {
            "ok": True,
            "expected_serial": expected,
            "matched": matched,
            "candidates": candidates,
            "network_scan_used": False,
        }

    scan_hosts = scan_toptica_hosts(set(preferred_hosts))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        future_hosts = {
            executor.submit(query_toptica_identity, config, host): host
            for host in scan_hosts
        }
        for future in concurrent.futures.as_completed(future_hosts):
            host = future_hosts[future]
            try:
                candidates.append(future.result())
            except Exception as exc:
                candidates.append({"ok": False, "host": host, "error": repr(exc)})
    matched = next(
        (
            item
            for item in candidates
            if item.get("ok")
            and (
                not expected
                or instrument_identity_matches(expected, item.get("serial_number"))
            )
        ),
        None,
    )
    return {
        "ok": matched is not None,
        "expected_serial": expected,
        "matched": matched,
        "candidates": candidates,
        "network_scan_used": True,
    }


def discover_scope_identity(config: dict[str, Any], expected_serial: str) -> dict[str, Any]:
    python_exe = resolve_scope_python(config)
    request = {
        "action": "discover_scopes",
        "expected_serial": str(expected_serial or "").strip(),
        "preferred_resource": str(config.get("scope_resource") or "").strip(),
        "scope_type": str(config.get("scope_type") or "").strip(),
    }
    proc = run_python_worker_with_json_request(
        python_exe,
        module_file('a221_workbench.workflows.array_dashboard.instrument_discovery_worker'),
        request,
        timeout_s=18.0,
    )
    try:
        result = parse_external_json(proc.stdout)
    except Exception:
        result = {
            "ok": False,
            "error": "示波器 VISA 发现未返回有效结果",
            "stderr_tail": proc.stderr[-1200:],
        }
    result["scope_python"] = str(python_exe)
    return result


def replace_url_host(value: str, host: str) -> str:
    parsed = urlparse(str(value or "").strip())
    if not parsed.scheme or not parsed.netloc:
        return value
    port = f":{parsed.port}" if parsed.port is not None else ""
    return urlunparse(parsed._replace(netloc=f"{host}{port}"))


def discover_instrument_bindings(config: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    probe_config = dict(config)
    for key in DEFAULT_CONFIG:
        if key in request:
            probe_config[key] = request[key]
    rp_device_id = str(request.get("rp_device_id") or probe_config.get("rp_device_id") or "").strip()
    laser_serial = str(request.get("laser_serial") or probe_config.get("laser_serial") or "").strip()
    scope_serial = str(request.get("scope_serial") or probe_config.get("scope_serial") or "").strip()
    laser_type = str(probe_config.get("laser_type") or "none")
    scope_type = str(probe_config.get("scope_type") or "none")

    tasks: dict[str, Any] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        tasks["red_pitaya"] = executor.submit(discover_redpitaya_identity, probe_config, rp_device_id)
        if laser_type == "toptica_tcp":
            tasks["laser"] = executor.submit(discover_toptica_identity, probe_config, laser_serial)
        if scope_type != "none":
            tasks["scope"] = executor.submit(discover_scope_identity, probe_config, scope_serial)
        results: dict[str, Any] = {}
        for name, future in tasks.items():
            try:
                results[name] = future.result()
            except Exception as exc:
                results[name] = {"ok": False, "error": repr(exc)}

    required = ["red_pitaya"]
    if laser_type == "toptica_tcp":
        required.append("laser")
    if scope_type != "none":
        required.append("scope")
    ok = all(bool(results.get(name, {}).get("ok")) for name in required)
    if not ok:
        return {
            "ok": False,
            "message": "未能按设备身份匹配全部仪器；连接地址未更新。",
            "instruments": results,
        }

    updated = dict(probe_config)
    rp = results["red_pitaya"]["matched"]
    updated["rp_device_id"] = rp["device_id"]
    updated["rp_hostname"] = rp["host"]
    updated["sgm_ssh_host"] = rp["host"]
    if str(updated.get("sgm_service_url") or "").strip():
        updated["sgm_service_url"] = replace_url_host(
            str(updated["sgm_service_url"]),
            str(rp["host"]),
        )
    if laser_type == "toptica_tcp":
        laser = results["laser"]["matched"]
        updated["laser_serial"] = str(laser["serial_number"])
        updated["laser_host"] = str(laser["host"])
    if scope_type != "none":
        scope = results["scope"]["matched"]
        updated["scope_serial"] = str(scope["serial_number"])
        updated["scope_resource"] = str(scope["resource"])

    persisted = bool(request.get("persist", True))
    if persisted:
        updated = save_config(updated)
    return {
        "ok": True,
        "message": "已按设备身份核验并建立连接。",
        "persisted": persisted,
        "instruments": results,
        "state": state_payload(updated),
    }


def state_payload(config: dict[str, Any]) -> dict[str, Any]:
    root = data_root(config)
    return {
        "ok": True,
        "config": config,
        "config_path": str(CONFIG_FILE),
        "runtime": {
            "python_executable": sys.executable,
            "sys_prefix": sys.prefix,
            "base_prefix": getattr(sys, "base_prefix", ""),
            "pyvisa_available": importlib.util.find_spec("pyvisa") is not None,
            "instrument_backend": "array_dashboard_direct",
            "legacy_dashboard_required": False,
        },
        "data_root_resolved": str(root) if root else "",
        "data_root_exists": bool(root and root.exists() and root.is_dir()),
        "experiment_context": active_experiment_context(config),
        "chips": list_chips(config),
    }
