"""Compose calibrated thermal tasks to measure and verify a comb reconstruction."""
from __future__ import annotations
from typing import Any
from pathlib import Path
from a221_workbench.workflows.array_dashboard.quick_probe import (
    GLOBAL_HARDWARE_TASK_STATE,
    GLOBAL_HARDWARE_TASK_STATE_LOCK,
    WorkflowCancelled,
    WorkflowCancelEvent,
    SgmWriteError,
    finish_thermal_io,
    default_sgm_outputs,
    path_is_relative_to,
    payload_q_slot,
    raise_if_cancelled,
    restore_tek_run_continuous,
    run_external,
    run_thermal_quick_probe_shift,
    set_sgm_voltage,
    wait_with_cancellation,
)

from a221_workbench.tasks.comb_planning import (
    DEFAULT_THERMAL_MZI_D1_MHZ,
    THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN,
    finite_int,
    load_thermal_modes,
    mode_wavelength_for_basis_py,
    plan_comb_reconstruction,
    positive_quadratic_voltage_for_shift,
    thermal_comb_reconstruction_check_dir,
    thermal_current_fsr_assignment_dir,
    thermal_q_slot_dir,
    thermal_tuning_dir,
    wavelength_nm_to_freq_ghz,
)

from a221_workbench.tasks.array_records import (
    Q_BY_MODE_FILE,
    die_dir,
    finite_float,
    load_electrode_record,
    natural_key,
    normalize_q_slot,
    save_family_assignments,
    sgm_entry_from_electrode,
    validate_name,
    write_json_atomic_with_retry,
)

from a221_workbench._shared.paths import module_file, project_root
from a221_workbench.tasks.analysis.large_scan import validate_array_min_depth

import csv

import json

import math
import queue

import os

import shutil

import subprocess

import sys

import tempfile

import threading

import time

import traceback

from datetime import datetime

from pathlib import Path

from a221_workbench._shared.runtime import (
    expand_optional_path as core_expand_optional_path,
    python_has_module as core_python_has_module,
    read_json_retry as core_read_json_retry,
)


REPO_ROOT = project_root()


LARGE_SCAN_FLOW = module_file('a221_workbench.workflows.large_scan.large_scan_flow')


TOPTICA_MOTOR_CONTROL_SMILE_PARAM = "laser1:ctl:mode-control:loop-enabled"


SMILE_OFF_SETTLE_S = 1.0


SMILE_ON_SETTLE_S = 1.0


CURRENT_FSR_CANCEL_EVENT = WorkflowCancelEvent()


CURRENT_FSR_RUN_LOCK = threading.Lock()


COMB_RECONSTRUCTION_CANCEL_EVENT = threading.Event()


COMB_RECONSTRUCTION_RUN_LOCK = threading.Lock()


def expand_optional_path(value: Any) -> Path | None:
    return core_expand_optional_path(value)


def python_has_module(python_exe: Path, module_name: str) -> bool:
    return core_python_has_module(python_exe, module_name)


def resolve_toptica_python(config: dict[str, Any]) -> Path:
    candidates: list[Path] = []
    for raw in (
        config.get("toptica_python"),
        os.environ.get("TOPTICA_PYTHON_EXE"),
        Path.home() / "python311_embed" / "python.exe",
        Path.home() / "toptica_lasersdk_venv" / "Scripts" / "python.exe",
        sys.executable,
    ):
        path = expand_optional_path(raw)
        if path is not None and path.exists() and path not in candidates:
            candidates.append(path)
    for path in candidates:
        if python_has_module(path, "toptica"):
            return path
    tried = ", ".join(str(path) for path in candidates) or "<none>"
    raise RuntimeError(f"No Python with TOPTICA SDK found for TCP laser control. Tried: {tried}")


def parse_external_json(stdout: str) -> dict[str, Any]:
    for start in (idx for idx, char in reversed(list(enumerate(stdout))) if char == "{"):
        try:
            payload = json.loads(stdout[start:].strip())
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            return payload
    raise RuntimeError(f"external command did not return JSON. stdout tail={stdout[-1000:]!r}")


def _stop_owned_worker(proc: subprocess.Popen) -> dict[str, Any]:
    """Stop only the child handle created by this workflow, with bounded waits."""
    try:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2.0)
        return {"ok": proc.poll() is not None, "closed": proc.poll() is not None,
                "worker_pid": proc.pid, "returncode": proc.poll(), "terminated": True}
    except Exception as exc:
        return {"ok": False, "closed": proc.poll() is not None, "worker_pid": proc.pid, "error": repr(exc)}


def run_python_worker_with_json_request(
    python_exe: Path,
    worker_path: Path,
    request: dict[str, Any],
    *,
    timeout_s: float,
    cancel_event: threading.Event | None = None,
) -> subprocess.CompletedProcess[str]:
    if not worker_path.exists():
        raise FileNotFoundError(worker_path)
    with tempfile.TemporaryDirectory(prefix="array_dashboard_worker_") as tmp_raw:
        request_path = Path(tmp_raw) / "request.json"
        request_path.write_text(json.dumps(request, ensure_ascii=False), encoding="utf-8")
        command = [str(python_exe), str(worker_path), str(request_path)]
        if cancel_event is not None:
            raise_if_cancelled(cancel_event)
            proc = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                encoding="utf-8", errors="replace",
                **({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}),
            )
            deadline = time.monotonic() + timeout_s
            try:
                while True:
                    raise_if_cancelled(cancel_event)
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise subprocess.TimeoutExpired(command, timeout_s)
                    try:
                        stdout, stderr = proc.communicate(timeout=min(0.1, remaining))
                        raise_if_cancelled(cancel_event)
                        return subprocess.CompletedProcess(command, proc.returncode, stdout, stderr)
                    except subprocess.TimeoutExpired:
                        continue
            finally:
                if proc.poll() is None:
                    _stop_owned_worker(proc)
                if proc.poll() is not None:
                    for stream in (proc.stdout, proc.stderr):
                        if stream is not None:
                            stream.close()
        try:
            return subprocess.run(
                command,
                text=True,
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout_s,
                check=False,
            )
        except OSError as exc:
            return subprocess.CompletedProcess(
                command,
                206 if getattr(exc, "winerror", None) == 206 else -1,
                "",
                repr(exc),
            )


def run_toptica_tcp_worker(config: dict[str, Any], action: str, extra: list[str], *, timeout_s: float) -> dict[str, Any]:
    host = ""
    for idx, item in enumerate(extra):
        if item == "--host" and idx + 1 < len(extra):
            host = str(extra[idx + 1]).strip()
            break
    if not host:
        return {"ok": False, "error": "missing --host for TOPTICA service"}
    adapter = load_toptica_adapter()
    payload = adapter.worker_args_to_payload(action, extra)
    return adapter.run_tcp_action(
        host=host,
        action=action,
        payload=payload,
        extra=extra,
        timeout_s=timeout_s,
        python_exe=resolve_toptica_python(config),
    )


def load_toptica_adapter() -> Any:

    import a221_workbench.instruments.toptica.control as toptica_laser_adapter
    return toptica_laser_adapter


def load_serial_toptica_adapter() -> Any:
    adapter = load_toptica_adapter()

    return adapter.TopticaDlcPro


def cycle_serial_motor_control_smile(laser: Any) -> dict[str, Any]:
    laser.set(f"{TOPTICA_MOTOR_CONTROL_SMILE_PARAM} #f")
    time.sleep(SMILE_OFF_SETTLE_S)
    laser.set(f"{TOPTICA_MOTOR_CONTROL_SMILE_PARAM} #t")
    time.sleep(SMILE_ON_SETTLE_S)
    return {
        "ok": True,
        "param": TOPTICA_MOTOR_CONTROL_SMILE_PARAM,
        "before": "not_read_fast_cycle",
        "after_off": "not_read_fast_cycle",
        "after_on": "not_read_fast_cycle",
        "off_settle_s": SMILE_OFF_SETTLE_S,
        "on_settle_s": SMILE_ON_SETTLE_S,
        "assumed_ok": True,
    }


def move_serial_thermal_mode(port: str, target_nm: float, *, timeout_s: float, tolerance_nm: float) -> dict[str, Any]:
    TopticaDlcPro = load_serial_toptica_adapter()
    laser = TopticaDlcPro(port)
    try:
        before = laser.wavelength_nm()
        laser.move_to_wavelength(target_nm, timeout_s, tolerance_nm=tolerance_nm)
        after = laser.wavelength_nm()
    finally:
        laser.close()
    ok = abs(after - target_nm) <= tolerance_nm
    return {
        "ok": ok,
        "connection": "serial",
        "port": port,
        "pc_voltage": {"skipped": True, "reason": "selected mode move does not modify PC voltage"},
        "wavelength_move": {
            "ok": ok,
            "target_nm": target_nm,
            "tolerance_nm": tolerance_nm,
            "before_nm": before,
            "after_read_nm": after,
        },
        "remote_control_modified": False,
    }


def move_tcp_thermal_mode(
    config: dict[str, Any],
    host: str,
    target_nm: float,
    *,
    timeout_s: float,
    tolerance_nm: float,
) -> dict[str, Any]:
    result = run_toptica_tcp_worker(
        config,
        "move_to_wavelength",
        [
            "--host",
            host,
            "--target-nm",
            f"{target_nm:.9f}",
            "--timeout-s",
            f"{timeout_s:.6g}",
            "--tolerance-nm",
            f"{tolerance_nm:.6g}",
        ],
        timeout_s=min(max(timeout_s + 15.0, 15.0), 135.0),
    )
    result.setdefault("connection", "tcp")
    result.setdefault("host", host)
    return result


def configured_fine_arc_factor(config: dict[str, Any], payload: dict[str, Any]) -> float:
    return float(finite_float(payload.get("fine_arc_factor_v_per_v") or config.get("fine_arc_factor_v_per_v")) or 25.0)


def configure_serial_fine_scan_arc(port: str, factor_v_per_v: float) -> dict[str, Any]:
    TopticaDlcPro = load_serial_toptica_adapter()
    laser = TopticaDlcPro(port)
    try:
        laser.configure_fine_scan_arc_factor(factor_v_per_v)
    finally:
        laser.close()
    return {
        "ok": True,
        "connection": "serial",
        "port": port,
        "factor_v_per_v": factor_v_per_v,
        "enabled": True,
    }


def configure_tcp_fine_scan_arc(config: dict[str, Any], host: str, factor_v_per_v: float) -> dict[str, Any]:
    result = run_toptica_tcp_worker(
        config,
        "configure_fine_scan_arc",
        [
            "--host",
            host,
            "--factor-v-per-v",
            f"{factor_v_per_v:.9g}",
        ],
        timeout_s=10.0,
    )
    result.setdefault("connection", "tcp")
    result.setdefault("host", host)
    return result


def cycle_serial_motor_control_smile_for_port(port: str) -> dict[str, Any]:
    TopticaDlcPro = load_serial_toptica_adapter()
    laser = TopticaDlcPro(port)
    try:
        result = cycle_serial_motor_control_smile(laser)
    finally:
        laser.close()
    result.setdefault("connection", "serial")
    result.setdefault("port", port)
    return result


def cycle_tcp_motor_control_smile(config: dict[str, Any], host: str) -> dict[str, Any]:
    result = run_toptica_tcp_worker(
        config,
        "cycle_smile",
        [
            "--host",
            host,
            "--readback",
            "--smile-off-settle-s",
            f"{SMILE_OFF_SETTLE_S:.6g}",
            "--smile-on-settle-s",
            f"{SMILE_ON_SETTLE_S:.6g}",
        ],
        timeout_s=max(10.0, SMILE_OFF_SETTLE_S + SMILE_ON_SETTLE_S + 8.0),
    )
    result.setdefault("connection", "tcp")
    result.setdefault("host", host)
    return result


def restore_toptica_fine_scan_arc(config: dict[str, Any], payload: dict[str, Any], laser_type: str) -> dict[str, Any]:
    factor = configured_fine_arc_factor(config, payload)
    if laser_type == "toptica_tcp":
        host = str(payload.get("toptica_host") or payload.get("laser_host") or config.get("laser_host") or "").strip()
        if not host:
            raise ValueError("TOPTICA TCP fine-scan restore requires laser_host")
        return configure_tcp_fine_scan_arc(config, host, factor)
    if laser_type == "toptica_serial":
        port = str(payload.get("laser_port") or config.get("laser_port") or "").strip()
        if not port:
            raise ValueError("TOPTICA serial fine-scan restore requires laser_port")
        return configure_serial_fine_scan_arc(port, factor)
    return {"ok": True, "skipped": True, "reason": f"laser type {laser_type!r} does not use TOPTICA fine ARC"}


def cycle_toptica_motor_control_smile(config: dict[str, Any], payload: dict[str, Any], laser_type: str) -> dict[str, Any]:
    if laser_type == "toptica_tcp":
        host = str(payload.get("toptica_host") or payload.get("laser_host") or config.get("laser_host") or "").strip()
        if not host:
            raise ValueError("TOPTICA TCP SMILE cycle requires laser_host")
        return cycle_tcp_motor_control_smile(config, host)
    if laser_type == "toptica_serial":
        port = str(payload.get("laser_port") or config.get("laser_port") or "").strip()
        if not port:
            raise ValueError("TOPTICA serial SMILE cycle requires laser_port")
        return cycle_serial_motor_control_smile_for_port(port)
    return {"ok": True, "skipped": True, "reason": f"laser type {laser_type!r} does not use TOPTICA SMILE"}


def fine_horizontal_delay_s(config: dict[str, Any], payload: dict[str, Any]) -> float | None:
    # The dashboard should leave the TEK fine-scan horizontal delay disabled.
    # Older browser state may still submit the removed fine_horizontal_delay_s
    # field, so ignore it at the server boundary instead of trusting the page.
    return None


def configure_fine_scope_idle(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    scope_type = str(payload.get("scope_type") or config.get("scope_type") or "").strip()
    scope_resource = str(payload.get("scope_resource") or config.get("scope_resource") or "").strip()
    if not scope_type or scope_type == "none" or not scope_resource:
        return {"ok": True, "skipped": True, "reason": "scope not configured"}
    trigger_channel = int(finite_float(payload.get("fine_trigger_channel") or config.get("fine_trigger_channel") or 4) or 4)
    trigger_level_v = float(finite_float(payload.get("fine_trigger_level_v") or config.get("fine_trigger_level_v") or 0.0) or 0.0)
    trigger_slope = str(payload.get("fine_trigger_slope") or config.get("fine_trigger_slope") or "negative")
    horizontal_delay = fine_horizontal_delay_s(config, payload)
    try:
        from a221_workbench.tasks.large_scan.acquire_large_scan import create_scope
    except (ImportError, ModuleNotFoundError) as exc:
        return configure_fine_scope_idle_subprocess(
            config,
            scope_type=scope_type,
            scope_resource=scope_resource,
            trigger_channel=trigger_channel,
            trigger_level_v=trigger_level_v,
            trigger_slope=trigger_slope,
            horizontal_delay=horizontal_delay,
            fallback_reason=repr(exc),
        )
    scope = create_scope(scope_type, scope_resource)
    try:
        scope.configure_fine_scan_idle(
            trigger_channel=trigger_channel,
            trigger_level_v=trigger_level_v,
            trigger_slope=trigger_slope,
            trigger_mode="auto",
            horizontal_delay_s=horizontal_delay,
        )
        return {
            "ok": True,
            "scope_type": scope_type,
            "scope_resource": scope_resource,
            "trigger_channel": trigger_channel,
            "trigger_level_v": trigger_level_v,
            "trigger_slope": trigger_slope,
            "horizontal_delay_s": horizontal_delay,
        }
    finally:
        scope.close()


def resolve_scope_python(config: dict[str, Any]) -> Path:
    candidates: list[Path] = []
    for raw in (
        Path.home() / "AppData" / "Local" / "MicrocavityControl" / "envs" / "pyrpl-0.9.8.0-py310" / "Scripts" / "python.exe",
        sys.executable,
        config.get("scope_python"),
    ):
        path = expand_optional_path(raw)
        if path is not None and path.exists() and path not in candidates:
            candidates.append(path)
    for path in candidates:
        if python_has_module(path, "numpy") and python_has_module(path, "pyvisa"):
            return path
    tried = ", ".join(str(path) for path in candidates) or "<none>"
    raise RuntimeError(f"No Python with numpy and pyvisa found for scope control. Tried: {tried}")


def configure_fine_scope_idle_subprocess(
    config: dict[str, Any],
    *,
    scope_type: str,
    scope_resource: str,
    trigger_channel: int,
    trigger_level_v: float,
    trigger_slope: str,
    horizontal_delay: float | None,
    fallback_reason: str,
) -> dict[str, Any]:
    python_exe = resolve_scope_python(config)
    request = {
        "repo_root": str(REPO_ROOT),
        "scope_type": scope_type,
        "scope_resource": scope_resource,
        "trigger_channel": trigger_channel,
        "trigger_level_v": trigger_level_v,
        "trigger_slope": trigger_slope,
        "horizontal_delay_s": horizontal_delay,
    }
    proc = run_python_worker_with_json_request(
        python_exe,
        module_file('a221_workbench.workflows.array_dashboard.fine_scope_idle_worker'),
        request,
        timeout_s=15.0,
    )
    try:
        result = parse_external_json(proc.stdout)
    except Exception:
        result = {
            "ok": False,
            "stdout_tail": proc.stdout[-1200:],
            "stderr_tail": proc.stderr[-1200:],
        }
    result.setdefault("ok", proc.returncode == 0)
    result["fallback_subprocess"] = True
    result["fallback_reason"] = fallback_reason
    result["scope_python"] = str(python_exe)
    if proc.returncode != 0:
        result["ok"] = False
        result.setdefault("returncode", proc.returncode)
        result.setdefault("stderr_tail", proc.stderr[-1200:])
    return result


def move_thermal_mode_to_wavelength(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    q_slot = payload_q_slot(payload)
    target_nm = finite_float(payload.get("wavelength_nm"))
    if target_nm is None:
        raise ValueError("thermal mode move requires wavelength_nm")
    laser_type = str(payload.get("laser_type") or config.get("laser_type") or "").strip()
    timeout_s = finite_float(payload.get("wavelength_timeout_s")) or 90.0
    tolerance_nm = finite_float(payload.get("wavelength_tolerance_nm")) or 0.01
    started = time.perf_counter()
    if laser_type == "toptica_tcp":
        host = str(payload.get("toptica_host") or payload.get("laser_host") or config.get("laser_host") or "").strip()
        if not host:
            raise ValueError("TOPTICA TCP move requires laser_host")
        result = move_tcp_thermal_mode(config, host, target_nm, timeout_s=timeout_s, tolerance_nm=tolerance_nm)
    elif laser_type == "toptica_serial":
        port = str(payload.get("laser_port") or config.get("laser_port") or "").strip()
        if not port:
            raise ValueError("TOPTICA serial move requires laser_port")
        result = move_serial_thermal_mode(port, target_nm, timeout_s=timeout_s, tolerance_nm=tolerance_nm)
    else:
        raise ValueError(f"thermal mode move currently requires TOPTICA laser, got {laser_type!r}")
    if not bool(result.get("ok")):
        result.update(
            {
                "ok": False,
                "q_slot": q_slot,
                "laser_type": laser_type,
                "target_nm": target_nm,
                "elapsed_s": time.perf_counter() - started,
                "laser_fine_scan_arc": {"ok": False, "skipped": True, "reason": "wavelength move did not reach target"},
                "scope_fine_scan_idle": {"ok": False, "skipped": True, "reason": "wavelength move did not reach target"},
                "motor_control_smile": {"ok": False, "skipped": True, "reason": "wavelength move did not reach target"},
                "pc_center_after_move": {
                    "ok": True,
                    "skipped": True,
                    "reason": "selected mode move only writes wavelength; PC centering disabled",
                },
                "action_order": [
                    "move_wavelength_and_wait_until_actual_within_tolerance",
                    "stop_before_fine_state_restore_and_smile",
                ],
            }
        )
        return result
    try:
        laser_fine_result = restore_toptica_fine_scan_arc(config, payload, laser_type)
    except Exception as exc:
        laser_fine_result = {"ok": False, "warning": repr(exc)}
    try:
        scope_result = configure_fine_scope_idle(config, payload)
    except Exception as exc:
        scope_result = {"ok": False, "warning": repr(exc)}
    if bool(laser_fine_result.get("ok")) and bool(scope_result.get("ok")):
        try:
            smile_result = cycle_toptica_motor_control_smile(config, payload, laser_type)
        except Exception as exc:
            smile_result = {"ok": False, "warning": repr(exc)}
    else:
        smile_result = {"ok": False, "skipped": True, "reason": "fine-scan state restore failed"}
    center_result: dict[str, Any] = {
        "ok": True,
        "skipped": True,
        "reason": "selected mode move only writes wavelength; PC centering disabled",
    }
    ok = bool(result.get("ok")) and bool(laser_fine_result.get("ok")) and bool(scope_result.get("ok")) and bool(
        smile_result.get("ok")
    )
    result.update(
        {
            "ok": ok,
            "q_slot": q_slot,
            "laser_type": laser_type,
            "target_nm": target_nm,
            "elapsed_s": time.perf_counter() - started,
            "laser_fine_scan_arc": laser_fine_result,
            "scope_fine_scan_idle": scope_result,
            "motor_control_smile": smile_result,
            "pc_center_after_move": center_result,
            "action_order": [
                "move_wavelength_and_wait_until_actual_within_tolerance",
                "restore_toptica_fine_scan_arc",
                "restore_scope_fine_scan_trigger_and_horizontal_delay",
                "cycle_motor_control_smile_off_on",
            ],
        }
    )
    return result


def sgm_entries_by_cavity(config: dict[str, Any], chip: str, die: str) -> dict[str, dict[str, Any]]:
    record = load_electrode_record(config, chip, die)
    rows = record.get("rows") if isinstance(record.get("rows"), list) else []
    entries: dict[str, dict[str, Any]] = {}
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        cavity = str(raw.get("cavity") or "").strip()
        if not cavity:
            continue
        entries[cavity] = sgm_entry_from_electrode(raw)
        entries[cavity]["cavity"] = cavity
    return entries


def comb_reconstruction_outputs_from_plan(
    config: dict[str, Any],
    plan: dict[str, Any],
) -> dict[str, Any]:
    chip = validate_name(str(plan.get("chip") or ""), "chip")
    die = validate_name(str(plan.get("die") or ""), "die")
    max_voltage_value = finite_float(config.get("sgm_max_voltage_v"))
    if max_voltage_value is None or max_voltage_value <= 0:
        raise ValueError("仪器配置 sgm_max_voltage_v 必须为正数")
    max_voltage = float(max_voltage_value)
    approach_guard_ghz = finite_float(plan.get("initial_approach_guard_ghz"))
    if approach_guard_ghz is None:
        approach_guard_ghz = finite_float(config.get("comb_reconstruction_initial_approach_guard_ghz"))
    if approach_guard_ghz is None:
        approach_guard_ghz = 1.6
    approach_guard_ghz = max(0.0, float(approach_guard_ghz))
    outputs = default_sgm_outputs()
    by_cavity = sgm_entries_by_cavity(config, chip, die)
    writable_rows: list[dict[str, Any]] = []
    skipped_rows: list[dict[str, Any]] = []
    used_outputs: set[str] = set()
    rows = plan.get("plan_rows") if isinstance(plan.get("plan_rows"), list) else []
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        if not row.get("matched"):
            row["write_status"] = "skipped"
            row["write_reason"] = row.get("reason") or "对齐预览中未匹配"
            skipped_rows.append(row)
            continue
        cavity = str(row.get("cavity") or "").strip()
        entry = by_cavity.get(cavity)
        if not entry:
            row["write_status"] = "skipped"
            row["write_reason"] = f"找不到 {cavity or '<empty>'} 的 SGM 探针映射"
            skipped_rows.append(row)
            continue
        if not entry.get("usable"):
            row["write_status"] = "skipped"
            row["write_reason"] = entry.get("reason") or "该腔对应探针当前不可写入"
            row["probe"] = entry.get("probe")
            row["out"] = entry.get("out")
            row["electrode"] = entry.get("electrode")
            row["contact_status"] = entry.get("contact_status")
            skipped_rows.append(row)
            continue
        out = finite_int(entry.get("out"))
        target_voltage = finite_float(row.get("voltage_v"))
        required_redshift_ghz = finite_float(row.get("required_redshift_ghz"))
        if required_redshift_ghz is None:
            delta_frequency_ghz = finite_float(row.get("delta_freq_ghz"))
            if delta_frequency_ghz is not None:
                required_redshift_ghz = -float(delta_frequency_ghz)
        slope_ghz_per_v2 = finite_float(row.get("slope_ghz_per_v2"))
        if out is None or target_voltage is None or required_redshift_ghz is None or slope_ghz_per_v2 is None:
            row["write_status"] = "skipped"
            row["write_reason"] = "缺少有效 SGM out、目标红移或热调谐斜率"
            skipped_rows.append(row)
            continue
        initial_redshift_ghz = max(float(required_redshift_ghz) - approach_guard_ghz, 0.0)
        initial_voltage = positive_quadratic_voltage_for_shift(
            -initial_redshift_ghz,
            float(slope_ghz_per_v2),
        )
        if initial_voltage is None:
            row["write_status"] = "skipped"
            row["write_reason"] = "无法由目标红移和热调谐斜率计算蓝侧接近电压"
            skipped_rows.append(row)
            continue
        out_key = f"out{out}"
        if out_key in used_outputs:
            row["write_status"] = "skipped"
            row["write_reason"] = f"{out_key} 已被前一个模式使用，跳过重复映射"
            skipped_rows.append(row)
            continue
        if target_voltage < 0 or target_voltage > max_voltage + 1e-12:
            row["write_status"] = "skipped"
            row["write_reason"] = f"目标电压 {target_voltage:g} V 超过 0..{max_voltage:g} V 写入范围"
            skipped_rows.append(row)
            continue
        used_outputs.add(out_key)
        outputs[out_key] = initial_voltage
        row.update(
            {
                "write_status": "will_write",
                "write_reason": "",
                "probe": entry.get("probe"),
                "out": out,
                "sgm_out": out_key,
                "electrode": entry.get("electrode"),
                "contact_status": entry.get("contact_status"),
                "model_target_voltage_v": target_voltage,
                "initial_voltage_v": initial_voltage,
                "initial_required_redshift_ghz": initial_redshift_ghz,
                "initial_blue_offset_from_target_ghz": float(required_redshift_ghz) - initial_redshift_ghz,
                "final_voltage_v": initial_voltage,
            }
        )
        writable_rows.append(row)
    return {
        "ok": True,
        "outputs_v": outputs,
        "nonzero_outputs_v": {key: value for key, value in outputs.items() if abs(float(value)) > 1e-12},
        "writable_rows": writable_rows,
        "skipped_rows": skipped_rows,
        "writable_count": len(writable_rows),
        "skipped_count": len(skipped_rows),
        "initial_approach_guard_ghz": approach_guard_ghz,
    }


def read_q_modes_csv_for_basis(path: Path, *, mode_number: int | None, basis: str) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(path)
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for raw in csv.DictReader(handle):
            row_mode = finite_int(raw.get("mode_number"))
            if row_mode is None:
                continue
            if mode_number is not None and row_mode != mode_number:
                continue
            if raw.get("fit_status") and raw.get("fit_status") != "ok":
                continue
            family = str(raw.get("family_label") or raw.get("family") or "").strip()
            wavelength_nm = mode_wavelength_for_basis_py(raw, basis)
            if not family or wavelength_nm is None:
                continue
            row = dict(raw)
            row.update(
                {
                    "family": family,
                    "mode_number": row_mode,
                    "wavelength_nm_for_basis": wavelength_nm,
                    "frequency_ghz_for_basis": wavelength_nm_to_freq_ghz(wavelength_nm),
                    "relative_freq_ghz": finite_float(raw.get("relative_freq_ghz")),
                    "folded_freq_ghz": finite_float(raw.get("folded_freq_ghz")),
                    "depth": finite_float(raw.get("depth")),
                    "transmission": finite_float(raw.get("transmission")),
                    "QL": finite_float(raw.get("QL")),
                    "fit_status": raw.get("fit_status") or "",
                }
            )
            rows.append(row)
    return sorted(rows, key=lambda item: (int(item.get("mode_number") or 0), natural_key(str(item.get("family") or ""))))


def latest_raw_npz(q_dir: Path) -> Path:
    stable = q_dir / "raw.npz"
    if stable.exists():
        return stable
    candidates = sorted(q_dir.glob("large_scan_*.npz"), key=lambda path: path.stat().st_mtime, reverse=True)
    if candidates:
        return candidates[0]
    raise FileNotFoundError(f"No raw large-scan npz found in {q_dir}")


def acquisition_json_for_q_dir(q_dir: Path, raw_path: Path) -> Path | None:
    stable = q_dir / "acquisition.json"
    if stable.exists():
        return stable
    candidate = raw_path.with_suffix(".json")
    return candidate if candidate.exists() else None


def load_preanalysis_trace_data(q_dir: Path, summary_path: Path) -> dict[str, Any]:


    from a221_workbench.tasks.analysis.large_scan.analyze_array_large_scan import sample_mzi_mu  # type: ignore
    from a221_workbench.tasks.analysis.large_scan.process_large_scan import (  # type: ignore
        find_mzi_index,
        normalize_transmission_with_baseline,
        read_large_scan_data,
        relative_frequency_mhz,
    )

    import numpy as np  # type: ignore

    summary = json.loads(summary_path.read_text(encoding="utf-8-sig")) if summary_path.exists() else {}
    mzi = summary.get("mzi") if isinstance(summary.get("mzi"), dict) else {}
    raw_path = latest_raw_npz(q_dir)
    acquisition_path = acquisition_json_for_q_dir(q_dir, raw_path)
    acquisition = json.loads(acquisition_path.read_text(encoding="utf-8-sig")) if acquisition_path else {}
    config = acquisition.get("config") if isinstance(acquisition.get("config"), dict) else {}
    time_s, _trigger, trans_raw, mzi_raw = read_large_scan_data(raw_path)
    mzi_index = find_mzi_index(mzi_raw, 0.0)
    valid_idx, valid_mu = sample_mzi_mu(len(trans_raw), mzi_index)
    rel_freq_mhz, _mu_center = relative_frequency_mhz(
        valid_mu,
        start_nm=float(config.get("start_nm") or 1530.0),
        center_nm=float(config.get("center_nm") or 1550.0),
        stop_nm=float(config.get("stop_nm") or 1570.0),
        d1=float(mzi.get("d1_mhz") or 40.46318),
        d2=float(mzi.get("d2_mhz") or 4e-8),
        d3=float(mzi.get("d3_mhz") or -3e-14),
        offset_mhz=0.0,
    )
    trans_norm_full, _baseline = normalize_transmission_with_baseline(trans_raw)
    if len(valid_idx) == 0:
        raise RuntimeError(f"MZI 校准后没有有效采样点: {raw_path}")
    return {
        "raw_path": raw_path,
        "valid_start": int(valid_idx[0]),
        "freq_mhz": np.asarray(rel_freq_mhz, dtype=float),
        "trans_norm": np.asarray(trans_norm_full[valid_idx], dtype=np.float32),
    }


def load_preanalysis_trace(q_dir: Path, summary_path: Path) -> tuple[Any, Any]:
    data = load_preanalysis_trace_data(q_dir, summary_path)
    return data["freq_mhz"] / 1000.0, data["trans_norm"]


def thin_xy(x: Any, y: Any, *, max_points: int = 30000) -> tuple[Any, Any]:
    import numpy as np  # type: ignore

    if len(x) <= max_points:
        return x, y
    stride = max(1, int(math.ceil(len(x) / max_points)))
    return np.asarray(x)[::stride], np.asarray(y)[::stride]


def infer_campaign_from_directory(directory: Path) -> str:
    parts = list(directory.resolve().parts)
    lowered = [part.lower() for part in parts]
    if "experiments" in lowered and "results" in lowered:
        exp_idx = lowered.index("experiments")
        res_idx = lowered.index("results")
        if exp_idx < res_idx:
            campaign_parts = parts[exp_idx + 1 : res_idx]
            if campaign_parts:
                return "/".join(campaign_parts)
    return "wafer_measuement/Batch_260515"


def run_assignment_large_scan(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    run_dir: Path,
    source_directory: Path,
    chip: str,
    die: str,
    reference_fsr_mhz: float | None = None,
    reference_family_points: Path | None = None,
    reference_family_plan: Path | None = None,
) -> dict[str, Any]:
    laser_type = str(payload.get("laser_type") or config.get("laser_type") or "toptica_tcp")
    if laser_type not in {"toptica_serial", "toptica_tcp"}:
        raise ValueError(f"自动归属大扫需要 TOPTICA 激光器，当前 laser_type={laser_type!r}")
    laser_connection = "tcp" if laser_type == "toptica_tcp" else "serial"
    command = [
        sys.executable,
        str(LARGE_SCAN_FLOW),
        "--campaign",
        infer_campaign_from_directory(source_directory),
        "--chip",
        chip,
        "--die",
        die,
        "--cavity",
        "loaded_scan",
        "--results-root",
        str(run_dir),
        "--laser-connection",
        laser_connection,
        "--laser-port",
        str(payload.get("laser_port") or config.get("laser_port") or "COM11"),
        "--laser-host",
        str(payload.get("toptica_host") or config.get("laser_host") or "192.168.1.13"),
        "--toptica-python",
        str(config.get("toptica_python") or ""),
        "--scope-type",
        str(payload.get("scope_type") or config.get("scope_type") or "tektronix_mso66b"),
        "--scope-resource",
        str(payload.get("scope_resource") or config.get("scope_resource") or ""),
        "--array-preanalysis-only",
        "--trigger-channel",
        str(payload.get("trigger_channel") or config.get("trigger_channel") or "1"),
        "--trans-channel",
        str(payload.get("trans_channel") or config.get("trans_channel") or "2"),
        "--mzi-channel",
        str(payload.get("mzi_channel") or config.get("mzi_channel") or "3"),
        "--mzi-d1-mhz",
        str(payload.get("mzi_d1_mhz") or config.get("mzi_d1_mhz") or DEFAULT_THERMAL_MZI_D1_MHZ),
        "--fine-trigger-channel",
        str(payload.get("fine_trigger_channel") or config.get("fine_trigger_channel") or "4"),
        "--fine-trigger-level-v",
        str(payload.get("fine_trigger_level_v") or config.get("fine_trigger_level_v") or "0"),
        "--fine-trigger-slope",
        str(payload.get("fine_trigger_slope") or config.get("fine_trigger_slope") or "negative"),
    ]
    array_min_depth = payload.get("array_min_depth")
    if array_min_depth is None:
        array_min_depth = config.get("array_min_depth")
    if array_min_depth is not None:
        command.extend(["--array-min-depth", str(validate_array_min_depth(array_min_depth))])
    disk_fsr_mhz = reference_fsr_mhz
    if disk_fsr_mhz is None:
        disk_fsr_mhz = finite_float(payload.get("disk_fsr_mhz"))
    if disk_fsr_mhz is not None:
        command.extend(["--disk-fsr-mhz", f"{disk_fsr_mhz:.12g}"])
    if reference_family_points is not None:
        command.extend(["--reference-family-points", str(reference_family_points)])
    if reference_family_plan is not None:
        command.extend(["--reference-family-plan", str(reference_family_plan)])
    result = run_external(command, timeout_s=1800.0)
    try:
        result["json"] = parse_external_json(result.get("stdout_tail") or "")
    except Exception:
        result["json"] = None
    result["q_dir"] = str(run_dir / die / "loaded_scan" / "Q")
    return result


def comb_reconstruction_reference_inputs(
    plan: dict[str, Any],
    plan_path: Path,
) -> tuple[float, Path, Path]:
    q_table_value = str(plan.get("q_table") or "").strip()
    if not q_table_value:
        raise ValueError("梳齿重构计划缺少调谐前 q_table，无法复用原始分族。")
    baseline_q_dir = Path(q_table_value).resolve().parent
    summary_path = baseline_q_dir / "array_preanalysis_summary.json"
    family_points_path = baseline_q_dir / "family_points.csv"
    if not summary_path.exists():
        raise FileNotFoundError(summary_path)
    if not family_points_path.exists():
        raise FileNotFoundError(family_points_path)
    baseline_summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
    fsr_mhz = finite_float(baseline_summary.get("selected_fsr_mhz"))
    if fsr_mhz is None or fsr_mhz <= 0:
        raise ValueError(f"调谐前分析缺少有效 selected_fsr_mhz：{summary_path}")
    return float(fsr_mhz), family_points_path, plan_path.resolve()


def flatten_assignment_loaded_scan_dir(run_dir: Path, die: str) -> tuple[Path, dict[str, Any] | None]:
    nested = run_dir / die / "loaded_scan"
    direct = run_dir / "loaded_scan"
    if direct.exists():
        return direct, {"ok": True, "message": "loaded_scan already flattened", "path": str(direct)}
    if not nested.exists():
        return nested, {
            "ok": False,
            "message": "nested loaded_scan not found; leaving path unchanged",
            "nested": str(nested),
            "direct": str(direct),
        }
    shutil.move(str(nested), str(direct))
    cleanup: dict[str, Any] = {"ok": True, "from": str(nested), "to": str(direct)}
    nested_die_dir = run_dir / die
    try:
        nested_die_dir.rmdir()
        cleanup["removed_empty_die_wrapper"] = str(nested_die_dir)
    except OSError:
        cleanup["removed_empty_die_wrapper"] = None
    return direct, cleanup


def write_comb_match_modes_table(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "family",
        "cavity",
        "comb_index",
        "target_wavelength_nm",
        "target_frequency_ghz",
        "target_relative_freq_ghz",
        "observed_family",
        "observed_mode_number",
        "observed_wavelength_nm",
        "observed_frequency_ghz",
        "observed_relative_freq_ghz",
        "target_error_ghz",
        "comb_center_fit_offset_ghz",
        "comb_residual_ghz",
        "observed_depth",
        "participated",
        "second_pass_passed",
        "final_voltage_v",
        "status",
        "reason",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_comb_match_pair_spacing_table(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "pair",
        "family_a",
        "family_b",
        "observed_family_a",
        "observed_family_b",
        "cavity_a",
        "cavity_b",
        "comb_index_a",
        "comb_index_b",
        "comb_index_delta",
        "target_spacing_ghz",
        "observed_spacing_ghz",
        "spacing_error_ghz",
        "per_tooth_spacing_ghz",
        "per_tooth_spacing_error_ghz",
        "valid",
        "reason",
        "participated_a",
        "participated_b",
        "second_pass_passed_a",
        "second_pass_passed_b",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def generate_comb_match_large_scan_verification(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    chip: str,
    die: str,
    plan: dict[str, Any],
    output_plan: dict[str, Any],
    verification_rows: list[dict[str, Any]],
    loaded_q_dir: Path,
    output_dir: Path,
) -> dict[str, Any]:
    basis = str(plan.get("wavelength_basis") or payload.get("wavelength_basis") or "mzi").strip() or "mzi"
    source_mode_numbers = sorted(
        {
            int(value)
            for value in (
                plan.get("selected_mode_numbers")
                if isinstance(plan.get("selected_mode_numbers"), list)
                else [plan.get("selected_mode_number")]
            )
            if finite_int(value) is not None
        }
    )
    mode_number = source_mode_numbers[0] if len(source_mode_numbers) == 1 else None
    source_mu_label = ", ".join(str(value) for value in source_mode_numbers) or "none"
    q_table = loaded_q_dir / Q_BY_MODE_FILE
    summary_path = loaded_q_dir / "array_preanalysis_summary.json"
    if not q_table.exists():
        raise FileNotFoundError(q_table)
    if not summary_path.exists():
        raise FileNotFoundError(summary_path)

    verify_dir = output_dir / "comb_match_verification"
    verify_dir.mkdir(parents=True, exist_ok=True)
    # The target comb group can cross the post-scan mu boundary. Match by
    # calibrated frequency across all post-scan groups; their F/mu labels are
    # diagnostic only and do not redefine the original cavity identity.
    observed_modes = read_q_modes_csv_for_basis(q_table, mode_number=None, basis=basis)
    writable_by_family = {
        str(row.get("family") or ""): row
        for row in (output_plan.get("writable_rows") if isinstance(output_plan.get("writable_rows"), list) else [])
        if str(row.get("family") or "").strip()
    }
    second_pass_by_family = {
        str(row.get("family") or ""): row
        for row in verification_rows
        if int(row.get("pass_index") or 0) == 2 and str(row.get("family") or "").strip()
    }

    plan_rows_raw = plan.get("plan_rows") if isinstance(plan.get("plan_rows"), list) else []
    plan_rows = sorted(
        [dict(row) for row in plan_rows_raw if isinstance(row, dict)],
        key=lambda row: (
            finite_int(row.get("comb_index")) is None,
            finite_int(row.get("comb_index")) or 0,
            natural_key(str(row.get("family") or "")),
        ),
    )
    def median_value(values: list[float]) -> float | None:
        finite = sorted(value for value in values if math.isfinite(value))
        if not finite:
            return None
        middle = len(finite) // 2
        if len(finite) % 2:
            return finite[middle]
        return 0.5 * (finite[middle - 1] + finite[middle])

    freq_to_rel_offset = median_value(
        [
            float(abs_freq) - float(rel_freq)
            for mode in observed_modes
            for abs_freq, rel_freq in [(finite_float(mode.get("frequency_ghz_for_basis")), finite_float(mode.get("relative_freq_ghz")))]
            if abs_freq is not None and rel_freq is not None
        ]
    )
    target_match_threshold_ghz = max(1.0, 0.55 * float(plan.get("comb_spacing_ghz") or 0.0))
    used_observed_indices: set[int] = set()
    match_by_family: dict[str, tuple[int, dict[str, Any], float]] = {}
    nearest_by_family: dict[str, tuple[dict[str, Any], float]] = {}
    active_plan_rows = [
        row for row in plan_rows
        if str(row.get("family") or "").strip() in writable_by_family
        and finite_float(row.get("target_frequency_ghz")) is not None
    ]
    for row in sorted(active_plan_rows, key=lambda item: float(finite_float(item.get("target_frequency_ghz")) or 0.0)):
        family = str(row.get("family") or "").strip()
        target_freq = float(finite_float(row.get("target_frequency_ghz")) or 0.0)
        candidates: list[tuple[float, int, dict[str, Any]]] = []
        for obs_index, observed in enumerate(observed_modes):
            if obs_index in used_observed_indices:
                continue
            observed_freq = finite_float(observed.get("frequency_ghz_for_basis"))
            if observed_freq is None:
                continue
            candidates.append((abs(float(observed_freq) - target_freq), obs_index, observed))
        if not candidates:
            continue
        distance, obs_index, observed = min(candidates, key=lambda item: item[0])
        nearest_by_family[family] = (observed, distance)
        if distance <= target_match_threshold_ghz:
            match_by_family[family] = (obs_index, observed, distance)
            used_observed_indices.add(obs_index)

    mode_rows: list[dict[str, Any]] = []
    for row in plan_rows:
        family = str(row.get("family") or "").strip()
        participated = family in writable_by_family
        pass_row = second_pass_by_family.get(family)
        matched = match_by_family.get(family)
        observed = matched[1] if matched else None
        target_freq = finite_float(row.get("target_frequency_ghz"))
        target_rel = target_freq - freq_to_rel_offset if target_freq is not None and freq_to_rel_offset is not None else None
        observed_wavelength = finite_float(observed.get("wavelength_nm_for_basis")) if observed else None
        observed_freq = finite_float(observed.get("frequency_ghz_for_basis")) if observed else None
        observed_family = str(observed.get("family") or "") if observed else ""
        observed_mode_number = finite_int(observed.get("mode_number")) if observed else None
        target_error = observed_freq - target_freq if observed_freq is not None and target_freq is not None else None
        reason = ""
        if not participated:
            reason = "该模式未参与 SGM 调谐"
        elif observed is None:
            nearest = nearest_by_family.get(family)
            if nearest:
                nearest_obs, nearest_distance = nearest
                reason = (
                    f"对齐后大扫没有在目标梳齿附近找到 dip；最近的是 "
                    f"{nearest_obs.get('family')}，距离 {nearest_distance:.3f} GHz，超过匹配窗口 {target_match_threshold_ghz:.3f} GHz"
                )
            else:
                reason = "对齐后大扫没有可用于匹配的 dip"
        mode_rows.append(
            {
                "family": family,
                "cavity": row.get("cavity") or "",
                "comb_index": row.get("comb_index"),
                "target_wavelength_nm": row.get("target_wavelength_nm"),
                "target_frequency_ghz": row.get("target_frequency_ghz"),
                "target_relative_freq_ghz": target_rel,
                "observed_family": observed_family,
                "observed_mode_number": observed_mode_number,
                "observed_wavelength_nm": observed_wavelength,
                "observed_frequency_ghz": observed_freq,
                "observed_relative_freq_ghz": finite_float(observed.get("relative_freq_ghz")) if observed else None,
                "target_error_ghz": target_error,
                "observed_depth": finite_float(observed.get("depth")) if observed else None,
                "participated": participated,
                "second_pass_passed": bool(pass_row.get("passed")) if pass_row else False,
                "final_voltage_v": finite_float((pass_row or {}).get("final_voltage_v")),
                "status": (pass_row or {}).get("status") or ("not_participated" if not participated else "not_observed" if observed is None else ""),
                "reason": reason or (pass_row or {}).get("reason") or "",
            }
        )

    matched_errors = [
        float(error)
        for row in mode_rows
        for error in [finite_float(row.get("target_error_ghz"))]
        if bool(row.get("participated")) and error is not None
    ]
    comb_center_fit_offset_ghz = (
        sum(matched_errors) / len(matched_errors)
        if matched_errors
        else 0.0
    )
    for row in mode_rows:
        error = finite_float(row.get("target_error_ghz"))
        row["comb_center_fit_offset_ghz"] = comb_center_fit_offset_ghz
        row["comb_residual_ghz"] = error - comb_center_fit_offset_ghz if error is not None else None

    matched_fit_rows = [
        row
        for row in mode_rows
        if bool(row.get("participated"))
        and finite_int(row.get("comb_index")) is not None
        and finite_float(row.get("observed_relative_freq_ghz")) is not None
    ]
    target_comb_spacing_ghz = float(plan.get("comb_spacing_ghz") or 0.0)
    fitted_spacing_ghz = None
    if len(matched_fit_rows) >= 2:
        fit_x = [float(finite_int(row.get("comb_index")) or 0) for row in matched_fit_rows]
        fit_y = [float(finite_float(row.get("observed_relative_freq_ghz")) or 0.0) for row in matched_fit_rows]
        mean_x = sum(fit_x) / len(fit_x)
        mean_y = sum(fit_y) / len(fit_y)
        denominator = sum((value - mean_x) ** 2 for value in fit_x)
        if denominator > 0:
            fitted_spacing_ghz = sum(
                (x_value - mean_x) * (y_value - mean_y)
                for x_value, y_value in zip(fit_x, fit_y)
            ) / denominator

    comb_residuals_ghz = [
        float(residual)
        for row in matched_fit_rows
        for residual in [finite_float(row.get("comb_residual_ghz"))]
        if residual is not None
    ]
    comb_residual_rms_mhz = (
        1000.0 * math.sqrt(sum(value * value for value in comb_residuals_ghz) / len(comb_residuals_ghz))
        if comb_residuals_ghz
        else None
    )
    comb_residual_max_abs_mhz = (
        1000.0 * max(abs(value) for value in comb_residuals_ghz)
        if comb_residuals_ghz
        else None
    )

    # The planner owns the complete contiguous comb segment.  Plan rows only
    # describe cavity assignments, so unfilled teeth must not disappear from
    # the verification plots or collapse onto comb index zero.
    comb_segment_indices = [
        comb_index
        for raw_index in (plan.get("comb_segment_indices") or [])
        if (comb_index := finite_int(raw_index)) is not None
    ]
    if not comb_segment_indices:
        comb_segment_indices = sorted(
            {
                comb_index
                for row in mode_rows
                if (comb_index := finite_int(row.get("comb_index"))) is not None
            }
        )
    comb_center_frequency_ghz = finite_float(plan.get("center_frequency_ghz"))
    if comb_center_frequency_ghz is None:
        inferred_centers = [
            float(target_frequency) - float(comb_index) * target_comb_spacing_ghz
            for row in mode_rows
            for comb_index, target_frequency in [
                (finite_int(row.get("comb_index")), finite_float(row.get("target_frequency_ghz")))
            ]
            if comb_index is not None and target_frequency is not None
        ]
        comb_center_frequency_ghz = median_value(inferred_centers)
    mode_by_comb_index = {
        comb_index: row
        for row in mode_rows
        if (comb_index := finite_int(row.get("comb_index"))) is not None
    }
    comb_target_rows: list[dict[str, Any]] = []
    for comb_index in comb_segment_indices:
        mode_row = mode_by_comb_index.get(comb_index)
        target_frequency = (
            float(comb_center_frequency_ghz) + float(comb_index) * target_comb_spacing_ghz
            if comb_center_frequency_ghz is not None
            else finite_float((mode_row or {}).get("target_frequency_ghz"))
        )
        target_relative_frequency = (
            float(target_frequency) - float(freq_to_rel_offset)
            if target_frequency is not None and freq_to_rel_offset is not None
            else finite_float((mode_row or {}).get("target_relative_freq_ghz"))
        )
        comb_target_rows.append(
            {
                "comb_index": comb_index,
                "target_frequency_ghz": target_frequency,
                "target_relative_freq_ghz": target_relative_frequency,
                "mode_row": mode_row,
            }
        )

    pair_rows: list[dict[str, Any]] = []
    for left_index, left in enumerate(mode_rows):
        for right in mode_rows[left_index + 1:]:
            left_idx = finite_int(left.get("comb_index"))
            right_idx = finite_int(right.get("comb_index"))
            target_spacing = None
            if left_idx is not None and right_idx is not None:
                target_spacing = abs(right_idx - left_idx) * float(plan.get("comb_spacing_ghz") or 0.0)
            comb_index_delta = abs(right_idx - left_idx) if left_idx is not None and right_idx is not None else None
            left_freq = finite_float(left.get("observed_frequency_ghz"))
            right_freq = finite_float(right.get("observed_frequency_ghz"))
            observed_spacing = abs(right_freq - left_freq) if left_freq is not None and right_freq is not None else None
            participated_left = bool(left.get("participated"))
            participated_right = bool(right.get("participated"))
            matched_left = left_freq is not None
            matched_right = right_freq is not None
            valid = participated_left and participated_right and observed_spacing is not None and target_spacing is not None
            per_tooth_spacing = (
                observed_spacing / comb_index_delta
                if observed_spacing is not None and comb_index_delta is not None and comb_index_delta > 0
                else None
            )
            reasons = []
            if not participated_left:
                reasons.append(f"{left.get('family')} 未参与调谐")
            if not participated_right:
                reasons.append(f"{right.get('family')} 未参与调谐")
            if not matched_left:
                reasons.append(f"{left.get('family')} 未在目标附近匹配到大扫 dip")
            if not matched_right:
                reasons.append(f"{right.get('family')} 未在目标附近匹配到大扫 dip")
            pair_rows.append(
                {
                    "pair": f"{left.get('family')}-{right.get('family')}",
                    "family_a": left.get("family"),
                    "family_b": right.get("family"),
                    "observed_family_a": left.get("observed_family"),
                    "observed_family_b": right.get("observed_family"),
                    "cavity_a": left.get("cavity"),
                    "cavity_b": right.get("cavity"),
                    "comb_index_a": left.get("comb_index"),
                    "comb_index_b": right.get("comb_index"),
                    "comb_index_delta": comb_index_delta,
                    "target_spacing_ghz": target_spacing,
                    "observed_spacing_ghz": observed_spacing,
                    "spacing_error_ghz": observed_spacing - target_spacing if observed_spacing is not None and target_spacing is not None else None,
                    "per_tooth_spacing_ghz": per_tooth_spacing,
                    "per_tooth_spacing_error_ghz": per_tooth_spacing - target_comb_spacing_ghz if per_tooth_spacing is not None else None,
                    "valid": valid,
                    "reason": "；".join(reasons),
                    "participated_a": participated_left,
                    "participated_b": participated_right,
                    "second_pass_passed_a": bool(left.get("second_pass_passed")),
                    "second_pass_passed_b": bool(right.get("second_pass_passed")),
                }
            )

    modes_table = verify_dir / "comb_match_modes.csv"
    pair_table = verify_dir / "comb_match_pair_spacing.csv"
    write_comb_match_modes_table(modes_table, mode_rows)
    write_comb_match_pair_spacing_table(pair_table, pair_rows)

    spectrum_path = verify_dir / "comb_match_mu_spectrum.png"
    spacing_path = verify_dir / "comb_match_pair_spacing.png"
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt  # type: ignore
        import numpy as np  # type: ignore

        freq_trace, trans_norm = load_preanalysis_trace(loaded_q_dir, summary_path)
        finite_trace = np.isfinite(freq_trace) & np.isfinite(trans_norm)
        freq_trace = np.asarray(freq_trace)[finite_trace]
        trans_norm = np.asarray(trans_norm)[finite_trace]
        target_rel_freqs = [
            value
            for row in comb_target_rows
            for value in [finite_float(row.get("target_relative_freq_ghz"))]
            if value is not None
        ]
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        plot_fsr_ghz = finite_float(summary.get("selected_fsr_ghz"))
        if target_rel_freqs and plot_fsr_ghz is not None and plot_fsr_ghz > 0:
            x_min = min(target_rel_freqs) - plot_fsr_ghz
            x_max = max(target_rel_freqs) + plot_fsr_ghz
            window = (freq_trace >= x_min) & (freq_trace <= x_max)
        elif target_rel_freqs:
            margin = max(5.0, float(plan.get("comb_spacing_ghz") or 0.0) * 0.75)
            x_min = min(target_rel_freqs) - margin
            x_max = max(target_rel_freqs) + margin
            window = (freq_trace >= x_min) & (freq_trace <= x_max)
        else:
            window = np.ones_like(freq_trace, dtype=bool)
        plot_x, plot_y = thin_xy(freq_trace[window], trans_norm[window], max_points=45000)
        spectrum_height = max(5.6, 3.2 + 0.32 * len(comb_target_rows))
        fig, (ax, ax_info) = plt.subplots(
            1,
            2,
            figsize=(14.5, spectrum_height),
            gridspec_kw={"width_ratios": [4.8, 1.7]},
            constrained_layout=True,
        )
        ax.plot(plot_x, plot_y, color="#1f77b4", lw=1.0, label="loaded scan transmission")
        target_line_seen = False
        inactive_line_seen = False
        spectrum_info_rows: list[tuple[int, str, str, str, bool, bool]] = []
        for target_row in comb_target_rows:
            comb_index = int(target_row["comb_index"])
            row = target_row.get("mode_row")
            family = str((row or {}).get("family") or "")
            cavity = str((row or {}).get("cavity") or "")
            target_x = finite_float(target_row.get("target_relative_freq_ghz"))
            aligned_target_x = target_x + comb_center_fit_offset_ghz if target_x is not None else None
            participated = bool(row and row.get("participated"))
            if aligned_target_x is not None:
                ax.axvline(
                    aligned_target_x,
                    color="#d62728" if participated else "#999999",
                    ls="--",
                    lw=0.8,
                    alpha=0.45 if participated else 0.35,
                    label="comb line after center alignment" if participated and not target_line_seen else "inactive comb line" if (not participated and not inactive_line_seen) else None,
                )
                target_line_seen = target_line_seen or participated
                inactive_line_seen = inactive_line_seen or not participated
            x = finite_float((row or {}).get("observed_relative_freq_ghz"))
            if x is None:
                if aligned_target_x is not None:
                    color = "#d97706" if participated else "#777777"
                    ax.scatter(
                        [aligned_target_x],
                        [0.04],
                        marker="x",
                        s=64,
                        color=color,
                        zorder=4,
                    )
                    ax.text(
                        aligned_target_x,
                        0.04,
                        f" k={comb_index}" if row is None else f" {family}x",
                        fontsize=8,
                        va="bottom",
                        color=color,
                    )
                    spectrum_info_rows.append(
                        (comb_index, f"{family}/{cavity}" if family else "empty", "no", "", participated, False)
                    )
                continue
            marker = "o" if participated else "x"
            color = "#2ca02c" if participated else "#777777"
            y = 1.0 - (finite_float((row or {}).get("observed_depth")) or 0.0)
            ax.scatter([x], [y], marker=marker, s=58, color=color, zorder=4)
            residual = finite_float((row or {}).get("comb_residual_ghz"))
            residual_text = f"{1000.0 * residual:+.0f}" if residual is not None else ""
            ax.text(x, y, f" {family}/{cavity}", fontsize=8, va="bottom", color=color)
            spectrum_info_rows.append((comb_index, f"{family}/{cavity}", "yes", residual_text, participated, True))
        ax.set_title(f"Loaded spectrum: target comb group ±1 FSR (source mu={source_mu_label})", fontsize=14)
        ax.set_xlabel("MZI-calibrated relative frequency (GHz)")
        ax.set_ylabel("Normalized transmission")
        ax.grid(True, alpha=0.25)
        ax.legend(loc="upper center", fontsize=9)
        ax.text(
            0.01,
            0.02,
            "Blue: all measured resonances. Labels: original target family/cavity only.",
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=9,
            color="#555555",
        )
        ax_info.axis("off")
        ax_info.set_title("Comb compatibility", fontsize=11, loc="left")
        ax_info.text(
            0.0,
            0.94,
            "tooth  target    dip  residual(MHz)",
            transform=ax_info.transAxes,
            ha="left",
            va="top",
            fontsize=9,
            family="monospace",
            fontweight="bold",
        )
        y_pos = 0.88
        row_step = min(0.07, 0.72 / max(1, len(spectrum_info_rows)))
        for comb_index, target_label, dip_text, residual_text, participated, matched in spectrum_info_rows:
            marker = "" if participated else "*"
            line = f"{comb_index:>+3}   {target_label:<9} {dip_text:<4} {residual_text:>8}{marker}"
            color = "#222222" if participated and matched else "#777777"
            ax_info.text(
                0.0,
                y_pos,
                line,
                transform=ax_info.transAxes,
                ha="left",
                va="top",
                fontsize=9,
                family="monospace",
                color=color,
            )
            y_pos -= row_step
        ax_info.text(
            0.0,
            max(0.02, y_pos - 0.02),
            (
                f"* empty / inactive tooth\n"
                f"center shift: {comb_center_fit_offset_ghz:+.3f} GHz\n"
                f"full comb segment: {len(comb_target_rows)} teeth\n"
                f"matched active: {len(matched_fit_rows)}/{len(active_plan_rows)}\n"
                f"RMS residual: {comb_residual_rms_mhz:.1f} MHz"
                if comb_residual_rms_mhz is not None
                else "* empty / inactive tooth"
            ),
            transform=ax_info.transAxes,
            ha="left",
            va="top",
            fontsize=8,
            color="#666666",
        )
        fig.savefig(spectrum_path)
        plt.close(fig)

        plot_rows = comb_target_rows
        comb_indices = [float(row["comb_index"]) for row in plot_rows]
        labels = [
            (
                f"k={int(row['comb_index']):+d}\n"
                f"{row['mode_row'].get('family')}/{row['mode_row'].get('cavity') or '?'}"
            )
            if row.get("mode_row") is not None
            else f"k={int(row['comb_index']):+d}\nempty"
            for row in plot_rows
        ]
        aligned_targets = [
            float(finite_float(row.get("target_relative_freq_ghz")) or 0.0) + comb_center_fit_offset_ghz
            for row in plot_rows
        ]
        fitted_text = f"{fitted_spacing_ghz:.6f} GHz" if fitted_spacing_ghz is not None else "unavailable"
        summary_text = (
            f"center shift {comb_center_fit_offset_ghz:+.6f} GHz; "
            f"free-fit spacing {fitted_text}; "
            f"RMS residual {comb_residual_rms_mhz:.1f} MHz"
            if comb_residual_rms_mhz is not None
            else "No matched modes available for comb residual analysis."
        )
        comb_plot_width = max(10.8, 3.2 + 0.7 * len(plot_rows))
        fig, (ax_fit, ax_residual) = plt.subplots(
            2,
            1,
            figsize=(comb_plot_width, 7.6),
            sharex=True,
            gridspec_kw={"height_ratios": [2.2, 1.0]},
            constrained_layout=True,
        )
        ax_fit.plot(
            comb_indices,
            aligned_targets,
            color="#d62728",
            ls="--",
            marker="|",
            ms=12,
            label=f"ideal comb, fixed spacing {target_comb_spacing_ghz:.3f} GHz",
        )
        for x_value, target_value, target_row in zip(comb_indices, aligned_targets, plot_rows):
            row = target_row.get("mode_row")
            observed_value = finite_float((row or {}).get("observed_relative_freq_ghz"))
            if observed_value is None:
                color = "#d97706" if row and row.get("participated") else "#888888"
                ax_fit.scatter([x_value], [target_value], marker="x", s=75, color=color, zorder=4)
                ax_fit.text(x_value, target_value, " empty", fontsize=8, va="bottom", ha="left", color=color)
                continue
            ax_fit.scatter([x_value], [observed_value], s=60, color="#2ca02c", zorder=4)
            point_label = f"{row.get('family')}/{row.get('cavity') or '?'}"
            ax_fit.text(x_value, observed_value, f" {point_label}", fontsize=9, va="bottom", ha="left")
        ax_fit.set_ylabel("Relative frequency (GHz)")
        ax_fit.set_title(
            f"Reconstructed cavity modes against the full {len(comb_indices)}-tooth "
            f"{target_comb_spacing_ghz:.3f} GHz comb\n{summary_text}"
        )
        ax_fit.grid(True, alpha=0.25)
        ax_fit.legend(loc="upper left")

        residual_points: list[tuple[float, float, dict[str, Any]]] = []
        for x_value, target_row in zip(comb_indices, plot_rows):
            row = target_row.get("mode_row")
            residual = finite_float((row or {}).get("comb_residual_ghz"))
            if residual is None:
                continue
            residual_points.append((x_value, 1000.0 * residual, row))
        residual_x = [point[0] for point in residual_points]
        residual_y_mhz = [point[1] for point in residual_points]
        ax_residual.axhline(0.0, color="#555555", ls="--", lw=1.0)
        ax_residual.scatter(residual_x, residual_y_mhz, s=58, color="#2ca02c", zorder=4)
        for x_value, residual_mhz, row in residual_points:
            ax_residual.text(
                x_value,
                residual_mhz,
                f" {row.get('family')}",
                fontsize=8,
                va="bottom" if residual_mhz >= 0 else "top",
            )
        ax_residual.set_ylabel("Comb residual (MHz)")
        ax_residual.set_xlabel("Comb tooth and assigned mode")
        ax_residual.set_xticks(comb_indices)
        ax_residual.set_xticklabels(labels)
        ax_residual.grid(True, alpha=0.25)
        fig.savefig(spacing_path)
        plt.close(fig)
    except Exception as exc:
        return {
            "ok": False,
            "stage": "plot_comb_match_verification",
            "error": repr(exc),
            "verify_dir": str(verify_dir),
            "modes_table": str(modes_table),
            "pair_spacing_table": str(pair_table),
            "mode_rows": mode_rows,
            "pair_rows": pair_rows,
        }

    valid_pair_count = sum(1 for row in pair_rows if row.get("valid"))
    summary = {
        "ok": True,
        "chip": chip,
        "die": die,
        "mode_number": mode_number,
        "source_mode_numbers": source_mode_numbers,
        "wavelength_basis": basis,
        "loaded_q_dir": str(loaded_q_dir),
        "q_table": str(q_table),
        "summary_path": str(summary_path),
        "verify_dir": str(verify_dir),
        "mu_spectrum_png": str(spectrum_path),
        "pair_spacing_png": str(spacing_path),
        "modes_table": str(modes_table),
        "pair_spacing_table": str(pair_table),
        "mode_rows": mode_rows,
        "pair_rows": pair_rows,
        "target_comb_spacing_ghz": target_comb_spacing_ghz,
        "comb_center_fit_offset_ghz": comb_center_fit_offset_ghz,
        "fitted_spacing_ghz": fitted_spacing_ghz,
        "comb_residual_rms_mhz": comb_residual_rms_mhz,
        "comb_residual_max_abs_mhz": comb_residual_max_abs_mhz,
        "matched_active_count": len(matched_fit_rows),
        "active_target_count": len(active_plan_rows),
        "valid_pair_count": valid_pair_count,
        "pair_count": len(pair_rows),
        "note": "对齐后标签仅作 dip 诊断；光梳兼容性按初始 family/cavity 目标、跨 post-scan mu 的一对一频率匹配，以及扣除可调光梳中心频偏后的残差判断。",
    }
    summary_path_out = verify_dir / "comb_match_verification_summary.json"
    summary_path_out.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    summary["comb_match_summary_path"] = str(summary_path_out)
    return summary


def thermal_comb_reconstruction_progress_path(directory: Path) -> Path:
    return thermal_comb_reconstruction_check_dir(directory) / "progress.json"


def thermal_current_fsr_progress_path(directory: Path, q_slot: object = "Q") -> Path:
    return thermal_current_fsr_assignment_dir(directory, q_slot) / "progress.json"


def read_json_with_retry(path: Path, *, retries: int = 5, delay_s: float = 0.02) -> Any:
    return core_read_json_retry(path, retries=retries, delay_s=delay_s)


def write_current_fsr_progress(
    directory: Path, payload: dict[str, Any], q_slot: object | None = None
) -> dict[str, Any]:
    normalized_q_slot = normalize_q_slot(payload.get("q_slot") if q_slot is None else q_slot)
    progress = {
        "ok": True,
        "schema_version": 1,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "q_slot": normalized_q_slot,
        **payload,
    }
    if CURRENT_FSR_CANCEL_EVENT.is_set():
        progress["cancel_requested_at"] = CURRENT_FSR_CANCEL_EVENT.requested_at
        requested = CURRENT_FSR_CANCEL_EVENT.requested_monotonic
        progress["cancel_elapsed_s"] = time.monotonic() - requested if requested is not None else None
        if progress.get("state") == "running":
            progress["state"] = "stopping"
    path = thermal_current_fsr_progress_path(directory, normalized_q_slot)
    write_json_atomic_with_retry(path, progress)
    return progress


def load_current_fsr_progress(
    config: dict[str, Any], chip: str, die: str, q_slot: object = "Q"
) -> dict[str, Any]:
    requested_chip = validate_name(chip, "chip")
    requested_die = validate_name(die, "die")
    requested_q_slot = normalize_q_slot(q_slot)
    with GLOBAL_HARDWARE_TASK_STATE_LOCK:
        hardware = dict(GLOBAL_HARDWARE_TASK_STATE)
    active = bool(hardware.get("active")) and str(hardware.get("action") or "") == "批量 FSR 模式归属"
    active_chip = str(hardware.get("chip") or "")
    active_die = str(hardware.get("die") or "")
    active_q_slot = normalize_q_slot(hardware.get("q_slot") or "Q")
    progress_chip = active_chip if active and active_chip else requested_chip
    progress_die = active_die if active and active_die else requested_die
    normalized_q_slot = active_q_slot if active else requested_q_slot
    directory = die_dir(config, progress_chip, progress_die)
    path = thermal_current_fsr_progress_path(directory, normalized_q_slot)
    matches_context = (
        progress_chip == requested_chip
        and progress_die == requested_die
        and normalized_q_slot == requested_q_slot
    )
    if not path.exists():
        return {
            "ok": True,
            "state": "starting" if active else "idle",
            "chip": progress_chip,
            "die": progress_die,
            "q_slot": normalized_q_slot,
            "matches_context": matches_context,
            "message": "批量 FSR 模式归属已登记，正在等待首个进度。" if active else "尚未开始当前 FSR 批量轮询。",
            "path": str(path),
        }
    progress = read_json_with_retry(path)
    if isinstance(progress, dict):
        progress.setdefault("ok", True)
        progress["path"] = str(path)
        progress["matches_context"] = matches_context
        return progress
    return {"ok": False, "state": "invalid", "message": "progress.json 格式不正确。", "path": str(path)}


def write_comb_reconstruction_progress(directory: Path, payload: dict[str, Any]) -> dict[str, Any]:
    progress = {
        "ok": True,
        "schema_version": 1,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        **payload,
    }
    path = thermal_comb_reconstruction_progress_path(directory)
    write_json_atomic_with_retry(path, progress)
    return progress


def load_comb_reconstruction_progress(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    directory = die_dir(config, validate_name(chip, "chip"), validate_name(die, "die"))
    path = thermal_comb_reconstruction_progress_path(directory)
    if not path.exists():
        return {
            "ok": True,
            "state": "idle",
            "message": "尚未开始对齐写入校验。",
            "path": str(path),
        }
    progress = read_json_with_retry(path)
    if isinstance(progress, dict):
        progress.setdefault("ok", True)
        progress["path"] = str(path)
        return progress
    return {"ok": False, "state": "invalid", "message": "progress.json 格式不正确。", "path": str(path)}


def reset_temp_directory(path: Path, parent: Path) -> Path:
    path = path.resolve()
    parent = parent.resolve()
    if not path_is_relative_to(path, parent):
        raise ValueError(f"Temporary output directory must stay under {parent}, got {path}")
    path.mkdir(parents=True, exist_ok=True)
    for child in path.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()
    return path


def thermal_mzi_d1_mhz(config: dict[str, Any], chip: str, die: str) -> tuple[float, dict[str, Any]]:
    configured = finite_float(config.get("mzi_d1_mhz"))
    if configured is not None and configured > 0:
        return configured, {"source": "config.mzi_d1_mhz"}
    summary_path = die_dir(config, chip, die) / "Q" / "array_preanalysis_summary.json"
    if summary_path.exists():
        try:
            summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
            mzi = summary.get("mzi") if isinstance(summary.get("mzi"), dict) else {}
            d1 = finite_float(mzi.get("d1_mhz"))
            if d1 is not None and d1 > 0:
                return d1, {"source": str(summary_path), "key": "mzi.d1_mhz"}
        except Exception as exc:
            return DEFAULT_THERMAL_MZI_D1_MHZ, {"source": str(summary_path), "warning": repr(exc)}
    return DEFAULT_THERMAL_MZI_D1_MHZ, {"source": "DEFAULT_THERMAL_MZI_D1_MHZ"}


def quick_probe_best_summary(result: dict[str, Any]) -> dict[str, Any]:
    ranked = result.get("ranked") if isinstance(result.get("ranked"), list) else []
    best = ranked[0] if ranked and isinstance(ranked[0], dict) else None
    second = ranked[1] if len(ranked) > 1 and isinstance(ranked[1], dict) else None
    if not best:
        return {
            "ok": False,
            "confidence": "none",
            "status": "no_valid_probe_shift",
            "message": "快速轮询没有读到有效右移通道",
        }
    delta = finite_float(best.get("delta_time_s")) or 0.0
    second_delta = finite_float(second.get("delta_time_s")) if second else None
    ratio = delta / max(second_delta, 1e-12) if second_delta is not None and second_delta > 0 else math.inf
    if delta >= 5e-4 and ratio >= 1.35:
        confidence = "high"
    elif delta >= 2e-4 and ratio >= 1.15:
        confidence = "medium"
    elif delta > 5e-5:
        confidence = "low"
    else:
        confidence = "uncertain"
    return {
        "ok": delta > 0,
        "confidence": confidence,
        "status": "probe_shift_rank",
        "best": best,
        "second": second,
        "delta_time_s": delta,
        "second_delta_time_s": second_delta,
        "ratio_to_second": ratio if math.isfinite(ratio) else None,
        "message": f"{quickShiftLabel_py(best)}；右移 {delta * 1e3:.3f} ms",
    }


def quickShiftLabel_py(item: dict[str, Any] | None) -> str:
    if not item:
        return "无有效判定"
    probe = f"Probe {item.get('probe')}" if item.get("probe") is not None else "Probe ?"
    out = f"out{item.get('out')}" if item.get("out") is not None else "out?"
    electrode = str(item.get("electrode") or "")
    cavity = str(item.get("design_cavity") or item.get("cavity") or "")
    parts = [probe, out]
    if electrode:
        parts.append(electrode)
    if cavity:
        parts.append(f"-> {cavity}")
    return " / ".join(parts)


def thermal_fit_assignment_confidence(assignment: dict[str, Any], tuning_fit: dict[str, Any]) -> dict[str, Any]:
    candidate_cavity = str(assignment.get("cavity") or assignment.get("candidate_cavity") or "").strip()
    r2 = finite_float(tuning_fit.get("r2")) if isinstance(tuning_fit, dict) else None
    fit_ok = bool(tuning_fit.get("ok")) if isinstance(tuning_fit, dict) else False
    if not fit_ok or r2 is None:
        confidence = "low"
        status = "thermal_fit_r2_missing"
    elif r2 >= 0.98:
        confidence = "high"
        status = "thermal_fit_r2_high"
    elif r2 >= 0.90:
        confidence = "medium"
        status = "thermal_fit_r2_medium"
    else:
        confidence = "low"
        status = "thermal_fit_r2_low"
    accepted = confidence in {"high", "medium"} and bool(candidate_cavity)
    return {
        "candidate_cavity": candidate_cavity,
        "cavity": candidate_cavity if accepted else "",
        "confidence": confidence,
        "confidence_basis": "thermal_tuning_fit_r2",
        "thermal_tuning_fit_r2": r2,
        "thermal_tuning_assignment_accepted": accepted,
        "status": status,
        "note": (
            f"按 Δf-V² 线性拟合 R²={r2:.4f} 判定归属"
            if r2 is not None
            else "Δf-V² 线性拟合无有效 R²，归属留空"
        ),
    }


def thermal_scope_capture_request(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    trans_channel: int,
    mzi_channel: int,
    trigger_channel: int | None = None,
    output_path: Path | None = None,
) -> dict[str, Any]:
    resolved_trigger_channel = int(
        trigger_channel
        if trigger_channel is not None
        else finite_float(payload.get("fine_trigger_channel") or config.get("fine_trigger_channel") or 4) or 4
    )
    if len({int(trans_channel), int(mzi_channel), resolved_trigger_channel}) != 3:
        raise ValueError("热调谐采帧要求过腔光、MZI 和细扫触发使用三个不同的示波器通道")
    request = {
        "repo_root": str(REPO_ROOT),
        "scope_type": str(payload.get("scope_type") or config.get("scope_type") or "tektronix_mso66b"),
        "scope_resource": str(payload.get("scope_resource") or config.get("scope_resource") or ""),
        "trans_channel": int(trans_channel),
        "mzi_channel": int(mzi_channel),
        "trigger_channel": resolved_trigger_channel,
        "single_timeout_s": float(payload.get("scope_single_timeout_s") or 5.0),
    }
    if output_path is not None:
        request["output_path"] = str(output_path)
    return request


class ThermalScopeCaptureSession:
    RESPONSE_TIMEOUT_S = 180.0
    CLOSE_TIMEOUT_S = 3.0

    def __init__(
        self, config: dict[str, Any], payload: dict[str, Any], *,
        trans_channel: int, mzi_channel: int, trigger_channel: int | None = None,
        cancel_event: threading.Event | None = None,
    ) -> None:
        self.cancel_event = cancel_event
        self._close_result = None
        self._inflight = False
        self._responses = queue.Queue()
        raise_if_cancelled(cancel_event)
        self.python_exe = resolve_scope_python(config)
        raise_if_cancelled(cancel_event)
        self.request = thermal_scope_capture_request(
            config, payload, trans_channel=trans_channel, mzi_channel=mzi_channel,
            trigger_channel=trigger_channel,
        )
        self.request["stream_commands"] = True
        self._tmp = tempfile.TemporaryDirectory(prefix="array_dashboard_scope_session_")
        self._stderr_path = Path(self._tmp.name) / "stderr.txt"
        self._stderr_handle = self._stderr_path.open("w+", encoding="utf-8")
        request_path = Path(self._tmp.name) / "request.json"
        request_path.write_text(json.dumps(self.request, ensure_ascii=False), encoding="utf-8")
        command = [str(self.python_exe), str(module_file('a221_workbench.workflows.thermal_tuning.thermal_scope_capture_worker')), str(request_path)]
        try:
            raise_if_cancelled(cancel_event)
            self._proc = subprocess.Popen(
                command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self._stderr_handle,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
                **({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}),
            )
            self._reader = threading.Thread(target=self._receive_lines, daemon=True)
            self._reader.start()
            self._inflight = True
            ready = self._read_response()
            self._inflight = False
            if not ready.get("ok") or not ready.get("ready"):
                raise RuntimeError(f"thermal scope capture session failed to start: {ready}")
            self.ready = {**ready, "scope_python": str(self.python_exe),
                          "worker_pid": self._proc.pid, "persistent_session": True}
        except BaseException as exc:
            exc.worker_close = self.close(force=True)
            raise

    def _receive_lines(self) -> None:
        try:
            for line in self._proc.stdout:
                self._responses.put(line)
        except Exception as exc:
            self._responses.put(exc)
        finally:
            self._responses.put(None)

    def _read_response(self, *, timeout_s: float | None = None, check_cancel: bool = True) -> dict[str, Any]:
        deadline = time.monotonic() + (self.RESPONSE_TIMEOUT_S if timeout_s is None else timeout_s)
        while True:
            if check_cancel:
                raise_if_cancelled(self.cancel_event)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("thermal scope worker response deadline exceeded")
            try:
                line = self._responses.get(timeout=min(0.1, remaining))
            except queue.Empty:
                continue
            if check_cancel:
                raise_if_cancelled(self.cancel_event)
            if line is None:
                raise RuntimeError(f"thermal scope worker ended without a response: {self._stderr_tail()!r}")
            if isinstance(line, Exception):
                raise line
            payload = json.loads(line)
            if not isinstance(payload, dict):
                raise RuntimeError(f"invalid thermal scope session response: {payload!r}")
            return payload

    def _stderr_tail(self) -> str:
        try:
            self._stderr_handle.flush()
            return self._stderr_path.read_text(encoding="utf-8", errors="replace")[-3000:]
        except Exception:
            return ""

    def capture(self, output_path: Path) -> dict[str, Any]:
        raise_if_cancelled(self.cancel_event)
        started = time.perf_counter()
        try:
            if self._close_result is not None or self._proc.poll() is not None:
                raise RuntimeError("thermal scope capture worker is closed")
            self._inflight = True
            self._proc.stdin.write(json.dumps({"op": "capture", "output_path": str(output_path)}, ensure_ascii=False) + "\n")
            self._proc.stdin.flush()
            result = self._read_response()
            self._inflight = False
        except WorkflowCancelled as exc:
            exc.worker_close = self.close(force=True)
            raise
        except Exception as exc:
            result = {"ok": False, "error": repr(exc), "stderr_tail": self._stderr_tail(),
                      "worker_close": self.close(force=True)}
        result.update(scope_python=str(self.python_exe), worker_pid=self._proc.pid,
                      persistent_session=True, request_elapsed_s=time.perf_counter() - started)
        return result

    def close(self, *, force: bool = False, restore_continuous: bool = False) -> dict[str, Any]:
        if self._close_result is not None:
            return dict(self._close_result)
        proc = getattr(self, "_proc", None)
        result = {"ok": True, "closed": True}
        try:
            if proc is not None and proc.poll() is None:
                if force or self._inflight:
                    result = _stop_owned_worker(proc)
                else:
                    self._proc.stdin.write(json.dumps({"op": "close", "restore_continuous": restore_continuous}) + "\n")
                    self._proc.stdin.flush()
                    result = self._read_response(timeout_s=self.CLOSE_TIMEOUT_S, check_cancel=False)
                    proc.wait(timeout=2.0)
        except Exception as exc:
            previous = result
            result = {"ok": False, "error": repr(exc), "stderr_tail": self._stderr_tail()}
            if "restore_scope_run_continuous" in previous:
                result["restore_scope_run_continuous"] = previous["restore_scope_run_continuous"]
            elif restore_continuous and not force:
                result["restore_scope_run_continuous"] = {"ok": False, "outcome_unknown": True,
                    "error": "worker 恢复请求未确认；不重复发送恢复"}
            if proc is not None:
                result.update(worker_stop=_stop_owned_worker(proc))
        finally:
            closed = proc is None or proc.poll() is not None
            result["closed"] = closed
            result["ok"] = bool(result.get("ok") and closed)
            if closed:
                reader = getattr(self, "_reader", None)
                if reader is not None:
                    reader.join(timeout=0.2)
                for stream_name in ("stdin", "stdout"):
                    stream = getattr(proc, stream_name, None)
                    if stream is not None and (stream_name != "stdout" or reader is None or not reader.is_alive()):
                        stream.close()
                self._stderr_handle.close()
                self._tmp.cleanup()
                self._tmp = None
        if proc is not None:
            result.update(returncode=proc.poll(), worker_pid=proc.pid)
        result["persistent_session"] = True
        self._close_result = result
        return dict(result)


def capture_thermal_scope_frame(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    output_path: Path,
    trans_channel: int,
    mzi_channel: int,
    trigger_channel: int | None = None,
) -> dict[str, Any]:
    python_exe = resolve_scope_python(config)
    request = thermal_scope_capture_request(
        config,
        payload,
        trans_channel=trans_channel,
        mzi_channel=mzi_channel,
        trigger_channel=trigger_channel,
        output_path=output_path,
    )
    proc = run_python_worker_with_json_request(
        python_exe,
        module_file('a221_workbench.workflows.thermal_tuning.thermal_scope_capture_worker'),
        request,
        timeout_s=180.0,
    )
    try:
        result = parse_external_json(proc.stdout)
    except Exception:
        result = {
            "ok": False,
            "stdout_tail": proc.stdout[-1200:],
            "stderr_tail": proc.stderr[-1200:],
        }
    result.setdefault("ok", proc.returncode == 0)
    result["scope_python"] = str(python_exe)
    result["returncode"] = proc.returncode
    if proc.returncode != 0:
        result["ok"] = False
        result.setdefault("stderr_tail", proc.stderr[-2000:])
    return result


def analyze_comb_reconstruction_frame_subprocess(
    config: dict[str, Any],
    *,
    frame_path: Path,
    output_dir: Path,
    row: dict[str, Any],
    mzi_d1_mhz: float,
    tolerance_ghz: float,
    search_half_ghz: float,
    trigger_channel: int,
    trigger_level_v: float,
    trigger_slope: str,
) -> dict[str, Any]:
    python_exe = resolve_scope_python(config)
    request = {
        "repo_root": str(REPO_ROOT),
        "frame_path": str(frame_path),
        "output_dir": str(output_dir),
        "row": row,
        "mzi_d1_mhz": float(mzi_d1_mhz),
        "tolerance_ghz": float(tolerance_ghz),
        "search_half_ghz": float(search_half_ghz),
        "frequency_axis_sign": THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN,
        "trigger_channel": int(trigger_channel),
        "trigger_level_v": float(trigger_level_v),
        "trigger_slope": str(trigger_slope),
    }
    proc = run_python_worker_with_json_request(
        python_exe,
        module_file('a221_workbench.workflows.thermal_tuning.thermal_comb_frame_worker'),
        request,
        timeout_s=120.0,
    )
    try:
        result = parse_external_json(proc.stdout)
    except Exception:
        result = {
            "ok": False,
            "stdout_tail": proc.stdout[-2000:],
            "stderr_tail": proc.stderr[-3000:],
        }
    result.setdefault("ok", proc.returncode == 0)
    result["analysis_python"] = str(python_exe)
    result["returncode"] = proc.returncode
    if proc.returncode != 0:
        result["ok"] = False
        result.setdefault("stderr_tail", proc.stderr[-3000:])
    return result


def analyze_thermal_voltage_sweep_subprocess(
    config: dict[str, Any],
    *,
    output_dir: Path,
    frames: list[dict[str, Any]],
    selected_mode: dict[str, Any],
    assignment: dict[str, Any],
    mzi_d1_mhz: float,
    initial_gate_center_s: float = 0.0,
    initial_gate_half_width_s: float = 0.0020,
    tracking_gate_left_s: float = 0.0001,
    tracking_gate_right_s: float = 0.0024,
    cancel_event: threading.Event | None = None,
) -> dict[str, Any]:
    python_exe = resolve_scope_python(config)
    request = {
        "repo_root": str(REPO_ROOT),
        "output_dir": str(output_dir),
        "frames": frames,
        "selected_mode": selected_mode,
        "assignment": assignment,
        "mzi_d1_mhz": float(mzi_d1_mhz),
        "frequency_axis_sign": THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN,
        "initial_gate_center_s": float(initial_gate_center_s),
        "initial_gate_half_width_s": float(initial_gate_half_width_s),
        "tracking_gate_left_s": float(tracking_gate_left_s),
        "tracking_gate_right_s": float(tracking_gate_right_s),
    }
    proc = run_python_worker_with_json_request(
        python_exe,
        module_file('a221_workbench.workflows.thermal_tuning.thermal_voltage_sweep_worker'),
        request,
        timeout_s=240.0,
        cancel_event=cancel_event,
    )
    try:
        result = parse_external_json(proc.stdout)
    except Exception:
        result = {
            "ok": False,
            "stdout_tail": proc.stdout[-2000:],
            "stderr_tail": proc.stderr[-3000:],
        }
    result.setdefault("ok", proc.returncode == 0)
    result["analysis_python"] = str(python_exe)
    result["returncode"] = proc.returncode
    if proc.returncode != 0:
        result["ok"] = False
        result.setdefault("stderr_tail", proc.stderr[-3000:])
    return result


def run_thermal_voltage_sweep_for_assignment(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    output_dir: Path,
    selected_mode: dict[str, Any],
    assignment: dict[str, Any],
    cancel_event: threading.Event | None = None,
    progress_callback: Any | None = None,
    cleanup_callback: Any | None = None,
    analyze: bool = True,
) -> dict[str, Any]:
    """Acquire the eleven 0..0.5 V frames; optionally skip automatic analysis.

    With analyze=False, current_mode_sweep.json is checkpointed after each
    captured frame, including on cancellation. Cancellation still propagates
    after the existing worker close, zeroing and scope recovery sequence.
    """
    raise_if_cancelled(cancel_event)
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = payload_q_slot(payload)
    max_voltage = float(config.get("sgm_max_voltage_v") or 0.2)
    if max_voltage < 0.5 - 1e-12:
        raise ValueError(f"当前 SGM 保护上限为 {max_voltage:g} V；0..0.5 V 扫描需要先把 sgm_max_voltage_v 提到至少 0.5 V")
    try:
        trans_channel = int(float(payload.get("tek_source_channel") or payload.get("trans_channel") or config.get("trans_channel") or 2))
    except (TypeError, ValueError):
        trans_channel = 2
    try:
        mzi_channel = int(float(payload.get("mzi_channel") or config.get("mzi_channel") or 3))
    except (TypeError, ValueError):
        mzi_channel = 3
    mzi_d1, mzi_source = thermal_mzi_d1_mhz(config, chip, die)
    output_dir.mkdir(parents=True, exist_ok=True)
    frame_dir = output_dir / "frames"
    frame_dir.mkdir(parents=True, exist_ok=True)
    voltages = [round(index * 0.05, 10) for index in range(11)]
    frames: list[dict[str, Any]] = []
    steps: list[dict[str, Any]] = []
    started = time.perf_counter()
    restore_scope_continuous: dict[str, Any] | None = None
    scope_session: ThermalScopeCaptureSession | None = None
    write_error = None
    worker_close = None

    def report(phase: str, message: str, **details: Any) -> None:
        if progress_callback is not None:
            try:
                progress_callback({"phase": phase, "message": message, **details})
            except Exception:
                pass

    probe = finite_int(assignment.get("probe"))
    out = finite_int(assignment.get("out"))
    if probe is None or out is None:
        raise ValueError("电压扫描需要 quick polling 给出的 probe/out")
    manual_result: dict[str, Any] = {
        "ok": False,
        "state": "acquiring",
        "acquisition_complete": False,
        "analysis_skipped": True,
        "output_dir": str(output_dir),
        "q_slot": q_slot,
        "frames_dir": str(frame_dir),
        "voltage_points_v": voltages,
        "frames": frames,
        "trans_channel": trans_channel,
        "mzi_channel": mzi_channel,
        "mzi_d1_mhz": mzi_d1,
        "mzi_d1_source": mzi_source,
        "frequency_axis_sign": THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN,
        "selected_mode": selected_mode,
        "assignment": assignment,
        "steps": steps,
        "detail_path": str(output_dir / "current_mode_sweep.json"),
    }

    def save_acquisition(**updates: Any) -> dict[str, Any]:
        manual_result.update(updates)
        manual_result["elapsed_s"] = time.perf_counter() - started
        write_json_atomic_with_retry(Path(manual_result["detail_path"]), manual_result)
        return manual_result

    if not analyze:
        save_acquisition()
    raise_if_cancelled(cancel_event)
    try:
        report("sweep_scope_start", "正在启动细扫采集连接。")
        raise_if_cancelled(cancel_event)
        scope_session = ThermalScopeCaptureSession(
            config,
            payload,
            trans_channel=trans_channel,
            mzi_channel=mzi_channel,
            cancel_event=cancel_event,
        )
        steps.append({"name": "scope_capture_session_start", "ok": True, "result": scope_session.ready})
        for index, voltage in enumerate(voltages):
            raise_if_cancelled(cancel_event)
            report("sweep_voltage_write", f"正在写入第 {index + 1}/{len(voltages)} 个电压点：{voltage:g} V。", voltage_v=voltage, voltage_index=index + 1)
            raise_if_cancelled(cancel_event)
            if abs(voltage) < 1e-12:
                write = set_sgm_voltage(
                    config,
                    {"chip": chip, "die": die, "q_slot": q_slot, "all_zero": True, "state_dir": str(output_dir)},
                    cancel_event=cancel_event,
                )
            else:
                write = set_sgm_voltage(
                    config,
                    {
                        "chip": chip,
                        "die": die,
                        "q_slot": q_slot,
                        "probe": probe,
                        "out": out,
                        "voltage_v": voltage,
                        "write_mode": "single_channel",
                        "state_dir": str(output_dir),
                    },
                    cancel_event=cancel_event,
                )
            steps.append({"name": f"write_{voltage:.2f}V", "ok": bool(write.get("ok")), "result": write})
            raise_if_cancelled(cancel_event)
            if not write.get("ok"):
                if not analyze:
                    return save_acquisition(state="failed", stage="write_sgm", voltage_v=voltage)
                return {"ok": False, "stage": "write_sgm", "voltage_v": voltage, "steps": steps}
            settle_s = float(payload.get("sweep_settle_s") or 0.08)
            wait_with_cancellation(settle_s, cancel_event)
            frame_path = frame_dir / f"V_{index:02d}_{voltage:.2f}V.npz"
            report("sweep_capture", f"正在采集 {voltage:g} V 的细扫帧。", voltage_v=voltage, voltage_index=index + 1)
            raise_if_cancelled(cancel_event)
            capture = scope_session.capture(frame_path)
            steps.append({"name": f"capture_{voltage:.2f}V", "ok": bool(capture.get("ok")), "result": capture})
            if not analyze and capture.get("ok"):
                # Preserve a just-finished raw frame before observing a stop
                # request that arrived while capture was returning.
                frames.append({"voltage_v": voltage, "frame_path": str(frame_path), "capture": capture})
                save_acquisition()
            raise_if_cancelled(cancel_event)
            if not capture.get("ok"):
                if not analyze:
                    return save_acquisition(state="failed", stage="capture_scope", voltage_v=voltage)
                return {"ok": False, "stage": "capture_scope", "voltage_v": voltage, "steps": steps}
            raise_if_cancelled(cancel_event)
            if analyze:
                frames.append(
                    {
                        "voltage_v": voltage,
                        "frame_path": str(frame_path),
                        "capture": capture,
                    }
                )
    except SgmWriteError as exc:
        write_error = exc.result
        if cancel_event is not None and cancel_event.is_set():
            raise WorkflowCancelled("停止请求已收到；电压写入返回失败或结果未知") from exc
        raise
    finally:
        pending_error = sys.exc_info()[1]
        report("scope_worker_close", "正在收尾：停止本次采集 worker。")
        if scope_session is not None:
            worker_close = scope_session.close(restore_continuous=True)
        elif pending_error is not None:
            worker_close = getattr(pending_error, "worker_close", None)
        scope_restore = None
        if worker_close is not None:
            steps.append({"name": "scope_capture_session_close", "result": worker_close})
            scope_restore = worker_close.get("restore_scope_run_continuous")
            if not worker_close.get("closed"):
                scope_restore = {"ok": False, "outcome_unknown": True, "error": "本次采集 worker 尚未确认退出；未并发恢复示波器"}
        recovery = finish_thermal_io(
            config, {**payload, "chip": chip, "die": die, "q_slot": q_slot, "state_dir": str(output_dir)},
            write_error=write_error, scope_restore=scope_restore, progress_callback=progress_callback,
        )
        recovery["scope_worker_close"] = worker_close
        if worker_close is not None and not worker_close.get("closed"):
            recovery["ok"] = False
        restore_scope_continuous = recovery["restore_scope_run_continuous"]
        steps.append({"name": "restore_zero", "result": recovery["restore_zero"]})
        steps.append({"name": "restore_scope_run_continuous", "result": restore_scope_continuous})
        if pending_error is not None:
            pending_error.recovery = recovery
        if cleanup_callback is not None:
            try:
                cleanup_callback(recovery)
            except Exception:
                pass
        if not analyze:
            cancelled = isinstance(pending_error, (WorkflowCancelled, KeyboardInterrupt)) or (
                cancel_event is not None and cancel_event.is_set()
            )
            try:
                save_acquisition(
                    state="cancelled" if cancelled else (
                        "failed" if pending_error is not None or not recovery["ok"]
                        or len(frames) != len(voltages) else "acquired"
                    ),
                    cancelled=cancelled,
                    acquisition_complete=len(frames) == len(voltages),
                    recovery=recovery,
                    restore_scope_run_continuous=restore_scope_continuous,
                    error=str(pending_error) if pending_error is not None else None,
                )
            except Exception as manifest_error:
                if pending_error is None:
                    raise
                # Do not replace Ctrl+C / cancellation with a manifest error.
                pending_error.manifest_error = str(manifest_error)
            if pending_error is not None:
                pending_error.detail_path = manual_result["detail_path"]
                pending_error.frames = list(frames)
    raise_if_cancelled(cancel_event, recovery=recovery)
    if not recovery["ok"]:
        if not analyze:
            return save_acquisition(state="failed", stage="cleanup")
        return {"ok": False, "stage": "cleanup", "recovery": recovery, "steps": steps}
    if not analyze:
        return save_acquisition(ok=True, state="completed")
    report("sweep_analysis", "正在分析已完成的热调谐细扫。")
    raise_if_cancelled(cancel_event)
    analysis = analyze_thermal_voltage_sweep_subprocess(
        config,
        cancel_event=cancel_event,
        output_dir=output_dir,
        frames=frames,
        selected_mode=selected_mode,
        assignment=assignment,
        mzi_d1_mhz=mzi_d1,
        initial_gate_center_s=float(payload.get("initial_gate_center_s") or 0.0),
        initial_gate_half_width_s=abs(float(payload.get("initial_gate_half_width_s") or 0.0020)),
        tracking_gate_left_s=abs(float(payload.get("tracking_gate_left_s") or 0.0001)),
        tracking_gate_right_s=abs(float(payload.get("tracking_gate_right_s") or 0.0024)),
    )
    raise_if_cancelled(cancel_event)
    tuning_fit = analysis.get("thermal_tuning_fit") if isinstance(analysis.get("thermal_tuning_fit"), dict) else {}
    final_assignment = {
        **assignment,
        "quick_confidence": assignment.get("confidence"),
        "quick_status": assignment.get("status"),
        **thermal_fit_assignment_confidence(assignment, tuning_fit),
    }
    result = {
        "ok": bool(analysis.get("ok")),
        "output_dir": str(output_dir),
        "q_slot": q_slot,
        "frames_dir": str(frame_dir),
        "voltage_points_v": voltages,
        "trans_channel": trans_channel,
        "mzi_channel": mzi_channel,
        "mzi_d1_mhz": mzi_d1,
        "mzi_d1_source": mzi_source,
        "assignment": final_assignment,
        "analysis": analysis,
        "recovery": recovery,
        "restore_scope_run_continuous": restore_scope_continuous,
        "steps": steps,
        "elapsed_s": time.perf_counter() - started,
    }
    summary_path = output_dir / "current_mode_sweep.json"
    summary_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    result["detail_path"] = str(summary_path)
    return result


def run_current_mode_probe_and_sweep(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    output_dir: Path,
    reset_output: bool,
    cancel_event: threading.Event | None = None,
    progress_callback: Any | None = None,
    cleanup_callback: Any | None = None,
) -> dict[str, Any]:
    raise_if_cancelled(cancel_event)
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = payload_q_slot(payload)
    directory = die_dir(config, chip, die, create=True)
    if reset_output:
        reset_temp_directory(output_dir, thermal_q_slot_dir(directory, q_slot))
    output_dir.mkdir(parents=True, exist_ok=True)
    selected_mode = payload.get("selected_mode") if isinstance(payload.get("selected_mode"), dict) else None
    if not selected_mode:
        raise ValueError("请先选中一个模式")
    quick_payload = {
        **payload,
        "voltage_v": float(payload.get("quick_voltage_v") or 0.2),
        "settle_s": float(payload.get("quick_settle_s") or 0.02),
        "baseline_sample_count": int(float(payload.get("baseline_sample_count") or 3)),
        "sample_count": int(float(payload.get("sample_count") or 5)),
        "sample_interval_s": float(payload.get("sample_interval_s") or 0.02),
        "initial_gate_center_s": float(payload.get("initial_gate_center_s") or 0.0),
        "initial_gate_half_width_s": abs(float(payload.get("initial_gate_half_width_s") or 0.0020)),
        "tracking_gate_left_s": abs(float(payload.get("tracking_gate_left_s") or 0.0001)),
        "tracking_gate_right_s": abs(float(payload.get("tracking_gate_right_s") or 0.0024)),
    }
    quick = run_thermal_quick_probe_shift(
        config, quick_payload, cancel_event=cancel_event,
        progress_callback=progress_callback, cleanup_callback=cleanup_callback,
    )
    raise_if_cancelled(cancel_event)
    best_summary = quick_probe_best_summary(quick)
    if not quick.get("ok") or not best_summary.get("best"):
        return {
            "ok": False,
            "stage": "quick_probe_shift",
            "output_dir": str(output_dir),
            "quick": quick,
            "best_summary": best_summary,
        }
    best = dict(best_summary["best"])
    quick_baseline_time_s = finite_float(best.get("baseline_dip_time_s"))
    if quick_baseline_time_s is None:
        quick_baseline = quick.get("baseline") if isinstance(quick.get("baseline"), dict) else {}
        quick_baseline_selected = quick_baseline.get("selected") if isinstance(quick_baseline.get("selected"), dict) else {}
        quick_baseline_time_s = finite_float(quick_baseline_selected.get("time_to_min_s"))
    assignment = {
        "family": selected_mode.get("family"),
        "mode_number": selected_mode.get("mode_number"),
        "probe": best.get("probe"),
        "out": best.get("out"),
        "electrode": best.get("electrode"),
        "cavity": best.get("design_cavity"),
        "contact_status": best.get("contact_status"),
        "confidence": best_summary.get("confidence"),
        "quick_delta_time_s": best_summary.get("delta_time_s"),
        "quick_ratio_to_second": best_summary.get("ratio_to_second"),
        "status": best_summary.get("status"),
        "quick_baseline_time_s": quick_baseline_time_s,
        "quick_loaded_time_s": finite_float(best.get("loaded_dip_time_s")),
        "quick_tracking_gate_left_s": quick_payload["tracking_gate_left_s"],
        "quick_tracking_gate_right_s": quick_payload["tracking_gate_right_s"],
        "quick_initial_gate_half_width_s": quick_payload["initial_gate_half_width_s"],
    }
    sweep = run_thermal_voltage_sweep_for_assignment(
        config,
        payload,
        output_dir=output_dir,
        selected_mode=selected_mode,
        assignment=assignment,
        cancel_event=cancel_event,
        progress_callback=progress_callback, cleanup_callback=cleanup_callback,
    )
    raise_if_cancelled(cancel_event)
    final_assignment = sweep.get("assignment") if isinstance(sweep.get("assignment"), dict) else {
        **assignment,
        "quick_confidence": assignment.get("confidence"),
        "quick_status": assignment.get("status"),
        **thermal_fit_assignment_confidence(assignment, {}),
    }
    result = {
        "ok": bool(sweep.get("ok")),
        "message": "当前模式轮询和 0..0.5 V 热调谐扫完成" if sweep.get("ok") else "当前模式热调谐扫失败",
        "chip": chip,
        "die": die,
        "q_slot": q_slot,
        "selected_mode": selected_mode,
        "output_dir": str(output_dir),
        "quick": quick,
        "best_summary": best_summary,
        "assignment": final_assignment,
        "sweep": sweep,
    }
    detail_path = output_dir / "current_mode_probe_and_sweep.json"
    detail_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    result["detail_path"] = str(detail_path)
    return result


def write_comb_reconstruction_verification_table(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "pass_index",
        "pass_label",
        "family",
        "cavity",
        "comb_index",
        "target_wavelength_nm",
        "sgm_out",
        "probe",
        "electrode",
        "initial_voltage_v",
        "final_voltage_v",
        "slope_ghz_per_v2",
        "attempts",
        "final_dip_offset_ghz",
        "abs_final_dip_offset_ghz",
        "tolerance_ghz",
        "passed",
        "status",
        "reason",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _run_comb_reconstruction_write_verify(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
    plan = plan_comb_reconstruction(config, payload)
    chip = validate_name(str(plan.get("chip") or ""), "chip")
    die = validate_name(str(plan.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    output_dir = reset_temp_directory(thermal_comb_reconstruction_check_dir(directory), thermal_tuning_dir(directory))
    frames_dir = output_dir / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)
    plan_path = output_dir / "plan.json"
    plan_path.write_text(json.dumps(plan, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    output_plan = comb_reconstruction_outputs_from_plan(config, plan)
    max_voltage_value = finite_float(config.get("sgm_max_voltage_v"))
    if max_voltage_value is None or max_voltage_value <= 0:
        raise ValueError("仪器配置 sgm_max_voltage_v 必须为正数")
    max_voltage = float(max_voltage_value)
    min_adjust_step_v = abs(float(payload.get("min_adjust_step_v") or config.get("comb_reconstruction_verify_min_adjust_step_v") or 0.002))
    settle_s = max(0.0, float(payload.get("settle_s") or config.get("comb_reconstruction_verify_settle_s") or 0.08))
    tolerance_periods = abs(float(payload.get("tolerance_mzi_periods") or config.get("comb_reconstruction_verify_tolerance_mzi_periods") or 3.0))
    search_half_ghz = abs(float(payload.get("search_half_ghz") or config.get("comb_reconstruction_verify_search_half_ghz") or 2.0))
    mzi_d1_mhz, mzi_source = thermal_mzi_d1_mhz(config, chip, die)
    tolerance_ghz = tolerance_periods * mzi_d1_mhz / 1000.0
    outputs = dict(output_plan["outputs_v"])
    writable_rows = [dict(row) for row in output_plan.get("writable_rows", [])]
    skipped_rows = output_plan.get("skipped_rows", []) if isinstance(output_plan.get("skipped_rows"), list) else []
    steps: list[dict[str, Any]] = []
    verification_rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    write_comb_reconstruction_progress(
        directory,
        {
            "state": "running",
            "phase": "prepared_plan",
            "chip": chip,
            "die": die,
            "output_dir": str(output_dir),
            "total_targets": len(writable_rows),
            "current_index": 0,
            "current_family": None,
            "matched_count": plan.get("matched_count"),
            "writable_count": len(writable_rows),
            "message": f"对齐方案已生成：{len(writable_rows)} 个目标会写入并校验。",
        },
    )

    if not writable_rows:
        summary = {
            "ok": True,
            "all_passed": False,
            "message": "没有可写入的对齐通道；请先检查模式家族归属、热调谐斜率和电极接触记录。",
            "chip": chip,
            "die": die,
            "plan": plan,
            "output_plan": output_plan,
            "output_dir": str(output_dir),
            "plan_path": str(plan_path),
            "verification_rows": [],
            "skipped_rows": skipped_rows,
        }
        summary_path = output_dir / "verification_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        summary["summary_path"] = str(summary_path)
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "complete",
                "phase": "no_writable_targets",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "summary_path": str(summary_path),
                "total_targets": 0,
                "current_index": 0,
                "current_family": None,
                "message": summary["message"],
            },
        )
        return summary

    write_comb_reconstruction_progress(
        directory,
        {
            "state": "running",
            "phase": "initial_sgm_full_state_write",
            "chip": chip,
            "die": die,
            "output_dir": str(output_dir),
            "total_targets": len(writable_rows),
            "current_index": 0,
            "current_family": None,
            "nonzero_outputs_v": output_plan.get("nonzero_outputs_v"),
            "message": (
                f"正在写入蓝侧接近 SGM 全状态（预留 {output_plan.get('initial_approach_guard_ghz', 0):.3f} GHz），"
                f"随后开始逐个校验 {len(writable_rows)} 个目标。"
            ),
        },
    )
    raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
    initial_write = set_sgm_voltage(
        config,
        {
            "chip": chip,
            "die": die,
            "outputs_v": outputs,
            "max_voltage_v": max_voltage,
            "state_dir": str(output_dir),
            "note": "comb reconstruction initial full-state write",
        },
    )
    raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
    steps.append({"name": "initial_sgm_full_state_write", "ok": bool(initial_write.get("ok")), "result": initial_write})
    if not initial_write.get("ok"):
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "failed",
                "phase": "initial_sgm_full_state_write",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "total_targets": len(writable_rows),
                "current_index": 0,
                "current_family": None,
                "message": "对齐 SGM 全状态写入失败。",
                "error": initial_write.get("error") or initial_write.get("stage") or "initial write failed",
            },
        )
        return {
            "ok": False,
            "stage": "initial_sgm_full_state_write",
            "chip": chip,
            "die": die,
            "output_dir": str(output_dir),
            "plan": plan,
            "output_plan": output_plan,
            "steps": steps,
        }
    wait_with_cancellation(settle_s, COMB_RECONSTRUCTION_CANCEL_EVENT)

    pass_specs = [(1, "第一轮校准"), (2, "第二轮串扰复查")]
    pass_results: list[dict[str, Any]] = []
    all_verification_rows: list[dict[str, Any]] = []

    def verify_reconstruction_target(row: dict[str, Any], row_index: int, pass_index: int, pass_label: str) -> dict[str, Any]:
        family = validate_name(str(row.get("family") or f"row{row_index}"), "family")
        out = finite_int(row.get("out"))
        out_key = f"out{out}" if out is not None else ""
        target_nm = finite_float(row.get("target_wavelength_nm"))
        slope = finite_float(row.get("slope_ghz_per_v2"))
        item: dict[str, Any] = {
            "pass_index": pass_index,
            "pass_label": pass_label,
            "family": row.get("family"),
            "cavity": row.get("cavity"),
            "comb_index": row.get("comb_index"),
            "target_wavelength_nm": target_nm,
            "sgm_out": out_key,
            "probe": row.get("probe"),
            "electrode": row.get("electrode"),
            "initial_voltage_v": row.get("initial_voltage_v"),
            "final_voltage_v": outputs.get(out_key) if out_key else None,
            "slope_ghz_per_v2": slope,
            "tolerance_ghz": tolerance_ghz,
            "passed": False,
            "status": "not_run",
            "reason": "",
            "attempts": 0,
            "attempt_details": [],
        }
        if out is None or target_nm is None or slope is None or not out_key:
            item.update({"status": "skipped", "reason": "缺少 out、目标波长或热调谐斜率"})
            return item

        attempt = 0
        while True:
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            attempt += 1
            current_voltage = float(outputs.get(out_key) or 0.0)
            item["attempts"] = attempt
            item["final_voltage_v"] = current_voltage
            write_comb_reconstruction_progress(
                directory,
                {
                    "state": "running",
                    "phase": "move_target",
                    "chip": chip,
                    "die": die,
                    "output_dir": str(output_dir),
                    "total_targets": len(writable_rows),
                    "current_index": row_index,
                    "current_family": row.get("family"),
                    "current_cavity": row.get("cavity"),
                    "comb_index": row.get("comb_index"),
                    "pass_index": pass_index,
                    "pass_label": pass_label,
                    "attempt": attempt,
                    "target_wavelength_nm": target_nm,
                    "current_voltage_v": current_voltage,
                    "message": f"{pass_label}：正在校验 {row.get('family')} ({row_index}/{len(writable_rows)})，跳到 {target_nm:.6f} nm，第 {attempt} 次尝试。",
                },
            )
            move_payload = {
                **payload,
                "chip": chip,
                "die": die,
                "selected_mode": row,
                "wavelength_nm": target_nm,
                "wavelength_basis": plan.get("wavelength_basis") or payload.get("wavelength_basis") or "mzi",
            }
            move = move_thermal_mode_to_wavelength(config, move_payload)
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            steps.append({"name": f"pass{pass_index}_move_{family}_attempt_{attempt}", "ok": bool(move.get("ok")), "result": move})
            if not move.get("ok"):
                item.update({"status": "move_failed", "reason": "激光器跳转或细扫状态恢复失败", "move": move})
                write_comb_reconstruction_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "target_failed",
                        "chip": chip,
                        "die": die,
                        "output_dir": str(output_dir),
                        "total_targets": len(writable_rows),
                        "current_index": row_index,
                        "current_family": row.get("family"),
                        "current_cavity": row.get("cavity"),
                        "pass_index": pass_index,
                        "pass_label": pass_label,
                        "attempt": attempt,
                        "message": f"{pass_label}：{row.get('family')} 跳波长/恢复细扫失败，继续下一个目标。",
                        "error": item["reason"],
                    },
                )
                break

            frame_path = frames_dir / f"pass{pass_index:02d}_{row_index:02d}_{family}_try{attempt:03d}.npz"
            fine_trigger_channel = int(float(payload.get("fine_trigger_channel") or config.get("fine_trigger_channel") or 4))
            fine_trigger_level_v = float(payload.get("fine_trigger_level_v") or config.get("fine_trigger_level_v") or 0.0)
            fine_trigger_slope = str(payload.get("fine_trigger_slope") or config.get("fine_trigger_slope") or "negative")
            write_comb_reconstruction_progress(
                directory,
                {
                    "state": "running",
                    "phase": "capture_target",
                    "chip": chip,
                    "die": die,
                    "output_dir": str(output_dir),
                    "total_targets": len(writable_rows),
                    "current_index": row_index,
                    "current_family": row.get("family"),
                    "current_cavity": row.get("cavity"),
                    "comb_index": row.get("comb_index"),
                    "pass_index": pass_index,
                    "pass_label": pass_label,
                    "attempt": attempt,
                    "target_wavelength_nm": target_nm,
                    "current_voltage_v": current_voltage,
                    "message": f"{pass_label}：正在校验 {row.get('family')} ({row_index}/{len(writable_rows)})，TEK run single 采帧。",
                },
            )
            capture = capture_thermal_scope_frame(
                config,
                payload,
                output_path=frame_path,
                trans_channel=int(float(payload.get("trans_channel") or payload.get("tek_source_channel") or config.get("trans_channel") or 2)),
                mzi_channel=int(float(payload.get("mzi_channel") or config.get("mzi_channel") or 3)),
                trigger_channel=fine_trigger_channel,
            )
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            steps.append({"name": f"pass{pass_index}_capture_{family}_attempt_{attempt}", "ok": bool(capture.get("ok")), "result": capture})
            if not capture.get("ok"):
                item.update({"status": "capture_failed", "reason": "TEK single 采帧失败", "capture": capture})
                write_comb_reconstruction_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "target_failed",
                        "chip": chip,
                        "die": die,
                        "output_dir": str(output_dir),
                        "total_targets": len(writable_rows),
                        "current_index": row_index,
                        "current_family": row.get("family"),
                        "current_cavity": row.get("cavity"),
                        "pass_index": pass_index,
                        "pass_label": pass_label,
                        "attempt": attempt,
                        "message": f"{pass_label}：{row.get('family')} TEK 采帧失败，继续下一个目标。",
                        "error": item["reason"],
                    },
                )
                break

            write_comb_reconstruction_progress(
                directory,
                {
                    "state": "running",
                    "phase": "analyze_target",
                    "chip": chip,
                    "die": die,
                    "output_dir": str(output_dir),
                    "total_targets": len(writable_rows),
                    "current_index": row_index,
                    "current_family": row.get("family"),
                    "current_cavity": row.get("cavity"),
                    "comb_index": row.get("comb_index"),
                    "pass_index": pass_index,
                    "pass_label": pass_label,
                    "attempt": attempt,
                    "target_wavelength_nm": target_nm,
                    "frame_path": str(frame_path),
                    "message": f"{pass_label}：正在校验 {row.get('family')} ({row_index}/{len(writable_rows)})，MZI 定标并拟合目标模式中心。",
                },
            )
            analysis = analyze_comb_reconstruction_frame_subprocess(
                config,
                frame_path=frame_path,
                output_dir=output_dir,
                row=row,
                mzi_d1_mhz=mzi_d1_mhz,
                tolerance_ghz=tolerance_ghz,
                search_half_ghz=search_half_ghz,
                trigger_channel=fine_trigger_channel,
                trigger_level_v=fine_trigger_level_v,
                trigger_slope=fine_trigger_slope,
            )
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            attempt_detail = {
                "attempt": attempt,
                "voltage_v": current_voltage,
                "frame_path": str(frame_path),
                "capture": capture,
                "analysis": analysis,
            }
            item["attempt_details"].append(attempt_detail)
            if not analysis.get("ok"):
                item.update({"status": "analysis_failed", "reason": "TEK/MZI 帧分析失败", "analysis": analysis})
                write_comb_reconstruction_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "target_failed",
                        "chip": chip,
                        "die": die,
                        "output_dir": str(output_dir),
                        "total_targets": len(writable_rows),
                        "current_index": row_index,
                        "current_family": row.get("family"),
                        "current_cavity": row.get("cavity"),
                        "pass_index": pass_index,
                        "pass_label": pass_label,
                        "attempt": attempt,
                        "message": f"{pass_label}：{row.get('family')} 帧分析失败，继续下一个目标。",
                        "error": item["reason"],
                    },
                )
                break

            offset = finite_float(analysis.get("dip_offset_ghz"))
            item.update(
                {
                    "final_dip_offset_ghz": offset,
                    "abs_final_dip_offset_ghz": abs(offset) if offset is not None else None,
                    "final_voltage_v": current_voltage,
                    "last_analysis": analysis,
                }
            )
            if offset is not None and abs(offset) <= tolerance_ghz:
                item.update({"passed": True, "status": "passed", "reason": "目标模式洛伦兹拟合中心已在容许窗口内"})
                write_comb_reconstruction_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "target_passed",
                        "chip": chip,
                        "die": die,
                        "output_dir": str(output_dir),
                        "total_targets": len(writable_rows),
                        "current_index": row_index,
                        "current_family": row.get("family"),
                        "current_cavity": row.get("cavity"),
                        "pass_index": pass_index,
                        "pass_label": pass_label,
                        "attempt": attempt,
                        "dip_offset_ghz": offset,
                        "tolerance_ghz": tolerance_ghz,
                        "current_voltage_v": current_voltage,
                        "message": f"{pass_label}：{row.get('family')} ({row_index}/{len(writable_rows)}) 已通过，偏移 {offset:+.4f} GHz。",
                    },
                )
                break

            if offset is None or abs(slope) < 1e-12:
                item.update({"status": "adjustment_unavailable", "reason": "缺少有效偏移或热调谐斜率，无法微调"})
                break
            new_voltage_sq = current_voltage * current_voltage + (-float(offset)) / float(slope)
            if not math.isfinite(new_voltage_sq) or new_voltage_sq < -1e-12:
                item.update(
                    {
                        "status": "unreachable_by_positive_voltage",
                        "reason": "根据当前偏移和热调谐斜率，修正需要负的 V²，正向加热无法到达",
                        "requested_voltage_squared_v2": new_voltage_sq,
                    }
                )
                break
            new_voltage = math.sqrt(max(0.0, new_voltage_sq))
            if new_voltage > max_voltage + 1e-12:
                item.update(
                    {
                        "status": "adjustment_exceeds_limit",
                        "reason": f"微调需要 {new_voltage:.4f} V，超过 SGM 硬件上限 {max_voltage:g} V",
                        "requested_voltage_v": new_voltage,
                    }
                )
                break
            if abs(new_voltage - current_voltage) < min_adjust_step_v:
                item.update(
                    {
                        "status": "adjustment_too_small",
                        "reason": f"计算微调步长 {abs(new_voltage - current_voltage):.4f} V 小于最小步长 {min_adjust_step_v:g} V",
                        "requested_voltage_v": new_voltage,
                    }
                )
                break

            old_voltage = current_voltage
            outputs[out_key] = new_voltage
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            write_comb_reconstruction_progress(
                directory,
                {
                    "state": "running",
                    "phase": "adjust_target",
                    "chip": chip,
                    "die": die,
                    "output_dir": str(output_dir),
                    "total_targets": len(writable_rows),
                    "current_index": row_index,
                    "current_family": row.get("family"),
                    "current_cavity": row.get("cavity"),
                    "comb_index": row.get("comb_index"),
                    "pass_index": pass_index,
                    "pass_label": pass_label,
                    "attempt": attempt,
                    "dip_offset_ghz": offset,
                    "old_voltage_v": old_voltage,
                    "new_voltage_v": new_voltage,
                    "message": f"{pass_label}：{row.get('family')} 偏移 {offset:+.4f} GHz，微调 {out_key}: {old_voltage:.4f} -> {new_voltage:.4f} V。",
                },
            )
            adjust_write = set_sgm_voltage(
                config,
                {
                    "chip": chip,
                    "die": die,
                    "outputs_v": outputs,
                    "max_voltage_v": max_voltage,
                    "state_dir": str(output_dir),
                    "note": f"comb reconstruction {pass_label} adjust {family} attempt {attempt}: {out_key} -> {new_voltage:.6g} V",
                },
            )
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            attempt_detail["adjustment"] = {
                "old_voltage_v": old_voltage,
                "new_voltage_v": new_voltage,
                "new_voltage_squared_v2": new_voltage_sq,
                "write": adjust_write,
            }
            steps.append({"name": f"pass{pass_index}_adjust_{family}_attempt_{attempt}", "ok": bool(adjust_write.get("ok")), "result": adjust_write})
            if not adjust_write.get("ok"):
                outputs[out_key] = old_voltage
                item.update({"status": "adjust_write_failed", "reason": "微调 SGM 写入失败", "adjust_write": adjust_write})
                write_comb_reconstruction_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "target_failed",
                        "chip": chip,
                        "die": die,
                        "output_dir": str(output_dir),
                        "total_targets": len(writable_rows),
                        "current_index": row_index,
                        "current_family": row.get("family"),
                        "current_cavity": row.get("cavity"),
                        "pass_index": pass_index,
                        "pass_label": pass_label,
                        "attempt": attempt,
                        "message": f"{pass_label}：{row.get('family')} 微调 SGM 写入失败，继续下一个目标。",
                        "error": item["reason"],
                    },
                )
                break
            wait_with_cancellation(settle_s, COMB_RECONSTRUCTION_CANCEL_EVENT)
        return item

    for pass_index, pass_label in pass_specs:
        raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "running",
                "phase": "pass_start",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "total_targets": len(writable_rows),
                "current_index": 0,
                "current_family": None,
                "pass_index": pass_index,
                "pass_label": pass_label,
                "message": f"{pass_label}开始：将逐个模式校正到目标窗口；不设固定轮询次数，只在不可达或硬件失败时停止当前目标。",
            },
        )
        pass_rows: list[dict[str, Any]] = []
        for row_index, row in enumerate(writable_rows, start=1):
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            item = verify_reconstruction_target(row, row_index, pass_index, pass_label)
            pass_rows.append(item)
            all_verification_rows.append(item)
            if not item.get("passed"):
                write_comb_reconstruction_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "target_done_not_passed",
                        "chip": chip,
                        "die": die,
                        "output_dir": str(output_dir),
                        "total_targets": len(writable_rows),
                        "current_index": row_index,
                        "current_family": row.get("family"),
                        "current_cavity": row.get("cavity"),
                        "pass_index": pass_index,
                        "pass_label": pass_label,
                        "status": item.get("status"),
                        "reason": item.get("reason"),
                        "message": f"{pass_label}：{row.get('family')} ({row_index}/{len(writable_rows)}) 未通过：{item.get('reason') or item.get('status') or '未知原因'}。",
                    },
                )
        pass_results.append(
            {
                "pass_index": pass_index,
                "pass_label": pass_label,
                "rows": pass_rows,
                "passed_count": sum(1 for row in pass_rows if row.get("passed")),
                "checked_count": len(pass_rows),
            }
        )
        verification_rows = pass_rows

    raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
    try:
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "running",
                "phase": "restore_scope_run_continuous",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "total_targets": len(writable_rows),
                "current_index": len(writable_rows),
                "current_family": None,
                "message": "轮询校验完成，正在恢复 TEK continuous；SGM 保持最终电压。",
            },
        )
        restore_scope_continuous = restore_tek_run_continuous(config, payload)
    except Exception as exc:
        restore_scope_continuous = {"ok": False, "error": repr(exc)}
    steps.append({"name": "restore_scope_run_continuous", "ok": bool(restore_scope_continuous.get("ok")), "result": restore_scope_continuous})

    post_large_scan: dict[str, Any] | None = None
    post_scan_flatten: dict[str, Any] | None = None
    comb_match_verification: dict[str, Any] | None = None
    write_comb_reconstruction_progress(
        directory,
        {
            "state": "running",
            "phase": "post_reconstruction_large_scan",
            "chip": chip,
            "die": die,
            "output_dir": str(output_dir),
            "total_targets": len(writable_rows),
            "current_index": len(writable_rows),
            "current_family": None,
            "message": "两轮局部轮询完成，正在保持最终 SGM 电压并做一次对齐后大扫。",
        },
    )
    raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
    try:
        reference_fsr_mhz, reference_family_points, reference_family_plan = comb_reconstruction_reference_inputs(
            plan,
            plan_path,
        )
        post_large_scan = run_assignment_large_scan(
            config,
            payload,
            run_dir=output_dir,
            source_directory=directory,
            chip=chip,
            die=die,
            reference_fsr_mhz=reference_fsr_mhz,
            reference_family_points=reference_family_points,
            reference_family_plan=reference_family_plan,
        )
        raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
    except WorkflowCancelled:
        raise
    except Exception as exc:
        post_large_scan = {
            "ok": False,
            "stage": "post_reconstruction_large_scan",
            "error": repr(exc),
            "traceback_tail": traceback.format_exc()[-3000:],
        }
    steps.append({"name": "post_reconstruction_large_scan", "ok": bool(post_large_scan.get("ok")), "result": post_large_scan})
    if post_large_scan.get("ok"):
        loaded_scan_dir, post_scan_flatten = flatten_assignment_loaded_scan_dir(output_dir, die)
        post_large_scan["loaded_scan_dir"] = str(loaded_scan_dir)
        post_large_scan["q_dir"] = str(loaded_scan_dir / "Q")
        steps.append(
            {
                "name": "flatten_post_reconstruction_large_scan",
                "ok": bool(post_scan_flatten is None or post_scan_flatten.get("ok")),
                "result": post_scan_flatten,
            }
        )
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "running",
                "phase": "post_reconstruction_comb_match_analysis",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "loaded_scan_dir": str(loaded_scan_dir),
                "message": "对齐后大扫完成，正在提取光梳匹配模式和相邻间隔图。",
            },
        )
        try:
            raise_if_cancelled(COMB_RECONSTRUCTION_CANCEL_EVENT)
            comb_match_verification = generate_comb_match_large_scan_verification(
                config,
                payload,
                chip=chip,
                die=die,
                plan=plan,
                output_plan=output_plan,
                verification_rows=verification_rows,
                loaded_q_dir=loaded_scan_dir / "Q",
                output_dir=output_dir,
            )
        except WorkflowCancelled:
            raise
        except Exception as exc:
            comb_match_verification = {
                "ok": False,
                "stage": "post_reconstruction_comb_match_analysis",
                "error": repr(exc),
                "traceback_tail": traceback.format_exc()[-3000:],
                "loaded_q_dir": str(loaded_scan_dir / "Q"),
            }
        steps.append(
            {
                "name": "post_reconstruction_comb_match_analysis",
                "ok": bool(comb_match_verification.get("ok")),
                "result": comb_match_verification,
            }
        )
    else:
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "running",
                "phase": "post_reconstruction_large_scan_failed",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "message": "对齐后大扫失败；局部轮询结果已保留，但没有生成光梳匹配验证图。",
                "error": post_large_scan.get("error") or post_large_scan.get("stderr_tail") or "post large scan failed",
            },
        )

    table_path = output_dir / "verification_table.csv"
    write_comb_reconstruction_verification_table(table_path, all_verification_rows)
    final_state_path = output_dir / "final_sgm_outputs.json"
    final_state_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
                "chip": chip,
                "die": die,
                "outputs_v": outputs,
                "nonzero_outputs_v": {key: value for key, value in outputs.items() if abs(float(value)) > 1e-12},
                "note": "comb reconstruction verification leaves these voltages applied",
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    passed_count = sum(1 for row in verification_rows if row.get("passed"))
    all_passed = bool(verification_rows) and passed_count == len(verification_rows)
    summary = {
        "ok": True,
        "all_passed": all_passed,
        "message": "对齐方案已写入并完成两轮轮询校验；第二轮用于复查后加电压带来的热串扰，SGM 保持最终电压，未自动清零。",
        "chip": chip,
        "die": die,
        "output_dir": str(output_dir),
        "frames_dir": str(frames_dir),
        "plan_path": str(plan_path),
        "verification_table": str(table_path),
        "final_sgm_outputs_path": str(final_state_path),
        "plan": plan,
        "output_plan": output_plan,
        "mzi_d1_mhz": mzi_d1_mhz,
        "mzi_d1_source": mzi_source,
        "tolerance_mzi_periods": tolerance_periods,
        "tolerance_ghz": tolerance_ghz,
        "search_half_ghz": search_half_ghz,
        "target_stop_policy": "loop_until_within_tolerance_or_physical_guard",
        "settle_s": settle_s,
        "initial_write": initial_write,
        "restore_scope_run_continuous": restore_scope_continuous,
        "post_large_scan": post_large_scan,
        "post_scan_flatten": post_scan_flatten,
        "comb_match_verification": comb_match_verification,
        "verification_rows": verification_rows,
        "all_verification_rows": all_verification_rows,
        "passes": pass_results,
        "pass_count": len(pass_results),
        "skipped_rows": skipped_rows,
        "final_outputs_v": outputs,
        "nonzero_outputs_v": {key: value for key, value in outputs.items() if abs(float(value)) > 1e-12},
        "passed_count": passed_count,
        "checked_count": len(verification_rows),
        "steps": steps,
        "elapsed_s": time.perf_counter() - started,
    }
    summary_path = output_dir / "verification_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    summary["summary_path"] = str(summary_path)
    write_comb_reconstruction_progress(
        directory,
        {
            "state": "complete",
            "phase": "complete",
            "chip": chip,
            "die": die,
            "output_dir": str(output_dir),
            "summary_path": str(summary_path),
            "verification_table": str(table_path),
            "total_targets": len(writable_rows),
            "current_index": len(writable_rows),
            "current_family": None,
            "passed_count": passed_count,
            "checked_count": len(verification_rows),
            "all_passed": all_passed,
            "message": (
                f"两轮对齐轮询校验完成；第二轮 {passed_count}/{len(verification_rows)} 通过。"
                + (
                    f" 对齐后大扫验证完成：{comb_match_verification.get('valid_pair_count')}/{comb_match_verification.get('pair_count')} 个相邻间隔有效。"
                    if isinstance(comb_match_verification, dict) and comb_match_verification.get("ok")
                    else " 对齐后大扫验证未完成或失败。"
                )
                + " SGM 保持最终电压。"
            ),
        },
    )
    return summary


def run_comb_reconstruction_write_verify(
    config: dict[str, Any],
    payload: dict[str, Any],
    *,
    cancel_event_prepared: bool = False,
) -> dict[str, Any]:
    if not COMB_RECONSTRUCTION_RUN_LOCK.acquire(blocking=False):
        return {"ok": False, "busy": True, "error": "对齐轮询校验已在运行"}
    if not cancel_event_prepared:
        COMB_RECONSTRUCTION_CANCEL_EVENT.clear()
    try:
        return _run_comb_reconstruction_write_verify(config, payload)
    except WorkflowCancelled:
        chip = validate_name(str(payload.get("chip") or ""), "chip")
        die = validate_name(str(payload.get("die") or ""), "die")
        directory = die_dir(config, chip, die, create=True)
        output_dir = thermal_comb_reconstruction_check_dir(directory)
        try:
            restore_scope = restore_tek_run_continuous(config, payload)
        except Exception as exc:
            restore_scope = {"ok": False, "error": repr(exc)}
        progress = write_comb_reconstruction_progress(
            directory,
            {
                "state": "cancelled",
                "phase": "cancelled",
                "chip": chip,
                "die": die,
                "output_dir": str(output_dir),
                "message": "已停止对齐轮询校验；TEK 已请求恢复 continuous，SGM 保持停止时已经写入的电压。",
                "restore_scope_run_continuous": restore_scope,
            },
        )
        return {
            "ok": True,
            "cancelled": True,
            "message": progress["message"],
            "chip": chip,
            "die": die,
            "output_dir": str(output_dir),
            "restore_scope_run_continuous": restore_scope,
        }
    finally:
        COMB_RECONSTRUCTION_RUN_LOCK.release()


def stop_comb_reconstruction_write_verify(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    with GLOBAL_HARDWARE_TASK_STATE_LOCK:
        registered_to_start = bool(GLOBAL_HARDWARE_TASK_STATE.get("active")) and str(
            GLOBAL_HARDWARE_TASK_STATE.get("action") or ""
        ) == "光梳对齐写入校验"
    running = COMB_RECONSTRUCTION_RUN_LOCK.locked() or registered_to_start
    if not running:
        return {"ok": True, "stop_requested": False, "message": "当前没有正在运行的对齐轮询校验。"}
    COMB_RECONSTRUCTION_CANCEL_EVENT.set()
    try:
        chip = validate_name(str(payload.get("chip") or ""), "chip")
        die = validate_name(str(payload.get("die") or ""), "die")
        directory = die_dir(config, chip, die, create=True)
        current = load_comb_reconstruction_progress(config, chip, die)
        write_comb_reconstruction_progress(
            directory,
            {
                "state": "stopping",
                "phase": current.get("phase") or "stopping",
                "chip": chip,
                "die": die,
                "output_dir": current.get("output_dir"),
                "total_targets": current.get("total_targets"),
                "current_index": current.get("current_index"),
                "current_family": current.get("current_family"),
                "pass_index": current.get("pass_index"),
                "pass_label": current.get("pass_label"),
                "message": "已请求停止；当前单次仪器操作返回后将终止后续校验，SGM 电压保持不变。",
            },
        )
    except Exception:
        pass
    return {
        "ok": True,
        "stop_requested": True,
        "message": "已发送停止请求；当前单次仪器操作结束后停止。",
    }


def thermal_modes_for_current_fsr(
    config: dict[str, Any],
    chip: str,
    die: str,
    selected_mode: dict[str, Any],
    q_slot: object = "Q",
) -> list[dict[str, Any]]:
    mode_number = finite_int(selected_mode.get("mode_number"))
    if mode_number is None:
        raise ValueError("当前 FSR 批量归属需要一个已选中的 mu / FSR index")
    loaded = load_thermal_modes(config, chip, die, q_slot)
    modes = loaded.get("modes") if isinstance(loaded.get("modes"), list) else []
    group = [mode for mode in modes if finite_int(mode.get("mode_number")) == mode_number]
    if not group:
        raise ValueError(f"没有找到 mu={mode_number} 的模式")
    return sorted(group, key=lambda item: natural_key(str(item.get("family") or "")))


def _run_current_fsr_probe_assignment(config: dict[str, Any], payload: dict[str, Any], run_state: dict[str, Any]) -> dict[str, Any]:
    raise_if_cancelled(CURRENT_FSR_CANCEL_EVENT)
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = payload_q_slot(payload)
    directory = die_dir(config, chip, die, create=True)
    def emit_progress(directory: Path, details: dict[str, Any]) -> dict[str, Any]:
        progress = write_current_fsr_progress(directory, details)
        run_state["progress"] = progress
        callback = run_state.get("progress_callback")
        if callback is not None:
            try:
                callback(progress)
            except Exception:
                pass
        return progress

    def capture_cleanup(recovery: dict[str, Any]) -> None:
        run_state["recovery"] = recovery

    def report_detail(details: dict[str, Any]) -> None:
        details = dict(details)
        if "current_index" in details:
            details["current_probe_index"] = details.pop("current_index")
        if details.get("phase") in {"zero_baseline_write", "sweep_scope_start"}:
            run_state["recovery"] = None
            run_state["hardware_started"] = True
        progress = {**run_state.get("progress", {}), **details, "state": "running"}
        progress.pop("updated_at", None)
        emit_progress(directory, progress)

    selected_mode = payload.get("selected_mode") if isinstance(payload.get("selected_mode"), dict) else None
    if not selected_mode:
        raise ValueError("请先选中当前 FSR 内的一个模式")
    basis = str(payload.get("wavelength_basis") or selected_mode.get("wavelength_basis") or "mzi")
    root = reset_temp_directory(
        thermal_current_fsr_assignment_dir(directory, q_slot), thermal_q_slot_dir(directory, q_slot)
    )
    modes = thermal_modes_for_current_fsr(config, chip, die, selected_mode, q_slot)
    total_modes = len(modes)
    emit_progress(
        directory,
        {
            "state": "running",
            "phase": "start",
            "chip": chip,
            "die": die,
            "q_slot": q_slot,
            "mode_number": selected_mode.get("mode_number"),
            "wavelength_basis": basis,
            "total_families": total_modes,
            "current_index": 0,
            "current_family": None,
            "output_dir": str(root),
            "message": f"当前 FSR 模式家族归属开始，共 {total_modes} 个模式家族。",
        },
    )
    results: list[dict[str, Any]] = []
    steps: list[dict[str, Any]] = []
    started = time.perf_counter()
    for index, mode in enumerate(modes, start=1):
        raise_if_cancelled(CURRENT_FSR_CANCEL_EVENT)
        family = validate_name(str(mode.get("family") or ""), "family")
        mode_dir = root / family
        mode_dir.mkdir(parents=True, exist_ok=True)
        emit_progress(
            directory,
            {
                "state": "running",
                "phase": "prepare_family",
                "chip": chip,
                "die": die,
                "q_slot": q_slot,
                "mode_number": selected_mode.get("mode_number"),
                "wavelength_basis": basis,
                "total_families": total_modes,
                "current_index": index,
                "current_family": family,
                "output_dir": str(root),
                "family_output_dir": str(mode_dir),
                "message": f"正在准备 {family} ({index}/{total_modes})。",
            },
        )
        target_nm = mode_wavelength_for_basis_py(mode, basis)
        if target_nm is None:
            item = {
                "ok": False,
                "family": family,
                "stage": "missing_wavelength",
                "mode": mode,
                "output_dir": str(mode_dir),
            }
            results.append(item)
            emit_progress(
                directory,
                {
                    "state": "running",
                    "phase": "skip_family",
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "mode_number": selected_mode.get("mode_number"),
                    "wavelength_basis": basis,
                    "total_families": total_modes,
                    "current_index": index,
                    "current_family": family,
                    "output_dir": str(root),
                    "family_output_dir": str(mode_dir),
                    "message": f"{family} 缺少可用波长，已跳过。",
                },
            )
            continue
        move_payload = {
            **payload,
            "selected_mode": mode,
            "wavelength_nm": target_nm,
            "wavelength_basis": basis,
        }
        try:
            emit_progress(
                directory,
                {
                    "state": "running",
                    "phase": "move_family",
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "mode_number": selected_mode.get("mode_number"),
                    "wavelength_basis": basis,
                    "total_families": total_modes,
                    "current_index": index,
                    "current_family": family,
                    "target_wavelength_nm": target_nm,
                    "output_dir": str(root),
                    "family_output_dir": str(mode_dir),
                    "message": f"正在跳转 {family} ({index}/{total_modes}) 到 {target_nm:.6f} nm。",
                },
            )
            raise_if_cancelled(CURRENT_FSR_CANCEL_EVENT)
            run_state["hardware_started"] = True
            run_state["recovery"] = None
            move = move_thermal_mode_to_wavelength(config, move_payload)
            raise_if_cancelled(CURRENT_FSR_CANCEL_EVENT)
            steps.append({"name": f"move_{family}", "ok": bool(move.get("ok")), "result": move})
            if not move.get("ok"):
                results.append(
                    {
                        "ok": False,
                        "family": family,
                        "stage": "mode_move",
                        "mode": mode,
                        "move": move,
                        "output_dir": str(mode_dir),
                    }
                )
                emit_progress(
                    directory,
                    {
                        "state": "running",
                        "phase": "family_failed",
                        "chip": chip,
                        "die": die,
                        "q_slot": q_slot,
                        "mode_number": selected_mode.get("mode_number"),
                        "wavelength_basis": basis,
                        "total_families": total_modes,
                        "current_index": index,
                        "current_family": family,
                        "output_dir": str(root),
                        "family_output_dir": str(mode_dir),
                        "message": f"{family} 跳转失败，继续下一个模式家族。",
                    },
                )
                continue
            emit_progress(
                directory,
                {
                    "state": "running",
                    "phase": "poll_family",
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "mode_number": selected_mode.get("mode_number"),
                    "wavelength_basis": basis,
                    "total_families": total_modes,
                    "current_index": index,
                    "current_family": family,
                    "target_wavelength_nm": target_nm,
                    "output_dir": str(root),
                    "family_output_dir": str(mode_dir),
                    "message": f"正在轮询 {family} ({index}/{total_modes})：快速判定通道并采集 0..0.5 V 细扫。",
                },
            )
            sweep_payload = {**payload, "selected_mode": mode, "wavelength_basis": basis}
            item = run_current_mode_probe_and_sweep(
                config,
                sweep_payload,
                output_dir=mode_dir,
                reset_output=False,
                cancel_event=CURRENT_FSR_CANCEL_EVENT,
                progress_callback=report_detail, cleanup_callback=capture_cleanup,
            )
            raise_if_cancelled(CURRENT_FSR_CANCEL_EVENT)
            if run_state.get("recovery") and not run_state["recovery"].get("ok"):
                raise RuntimeError("当前模式清零或恢复失败，已停止后续 family")
            item["family"] = family
            item["mode"] = mode
            results.append(item)
            emit_progress(
                directory,
                {
                    "state": "running",
                    "phase": "family_done",
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "mode_number": selected_mode.get("mode_number"),
                    "wavelength_basis": basis,
                    "total_families": total_modes,
                    "current_index": index,
                    "current_family": family,
                    "output_dir": str(root),
                    "family_output_dir": str(mode_dir),
                    "message": f"{family} ({index}/{total_modes}) 轮询完成。",
                },
            )
        except WorkflowCancelled:
            raise
        except Exception as exc:
            emit_progress(
                directory,
                {
                    "state": "failed",
                    "phase": "family_exception",
                    "chip": chip,
                    "die": die,
                    "q_slot": q_slot,
                    "mode_number": selected_mode.get("mode_number"),
                    "wavelength_basis": basis,
                    "total_families": total_modes,
                    "current_index": index,
                    "current_family": family,
                    "output_dir": str(root),
                    "family_output_dir": str(mode_dir),
                    "error": repr(exc),
                    "message": f"{family} ({index}/{total_modes}) 轮询报错。",
                },
            )
            raise
    raise_if_cancelled(CURRENT_FSR_CANCEL_EVENT)
    proposed: list[dict[str, Any]] = []
    for item in results:
        assignment = item.get("assignment") if isinstance(item.get("assignment"), dict) else {}
        sweep = item.get("sweep") if isinstance(item.get("sweep"), dict) else {}
        analysis = sweep.get("analysis") if isinstance(sweep.get("analysis"), dict) else {}
        tuning_fit = analysis.get("thermal_tuning_fit") if isinstance(analysis.get("thermal_tuning_fit"), dict) else {}
        family = str(item.get("family") or assignment.get("family") or "")
        cavity = str(assignment.get("cavity") or "")
        candidate_cavity = str(assignment.get("candidate_cavity") or "")
        confidence = str(assignment.get("confidence") or "uncertain")
        if not item.get("ok") or confidence in {"low", "uncertain", "none"}:
            cavity = ""
        proposed.append(
            {
                "family": family,
                "cavity": cavity,
                "candidate_cavity": candidate_cavity,
                "confidence": confidence,
                "confidence_basis": assignment.get("confidence_basis") or "thermal_tuning_fit_r2",
                "thermal_tuning_assignment_accepted": bool(assignment.get("thermal_tuning_assignment_accepted")),
                "status": assignment.get("status") or ("current_fsr_probe_sweep" if item.get("ok") else str(item.get("stage") or "failed")),
                "note": assignment.get("note") or "当前 FSR 逐模式快速轮询 + 0..0.5 V 细扫热调谐归属",
                "evidence": str(item.get("detail_path") or item.get("output_dir") or ""),
                "thermal_tuning_slope_ghz_per_v2": tuning_fit.get("slope_ghz_per_v2"),
                "thermal_tuning_slope_mhz_per_v2": tuning_fit.get("slope_mhz_per_v2"),
                "thermal_tuning_frequency_axis_sign": tuning_fit.get("frequency_axis_sign"),
                "thermal_tuning_fit_r2": tuning_fit.get("r2"),
            }
        )
    table_path = root / "assignment_table.csv"
    with table_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "family",
                "cavity",
                "candidate_cavity",
                "confidence",
                "confidence_basis",
                "thermal_tuning_assignment_accepted",
                "status",
                "thermal_tuning_slope_ghz_per_v2",
                "thermal_tuning_slope_mhz_per_v2",
                "thermal_tuning_frequency_axis_sign",
                "thermal_tuning_fit_r2",
                "note",
                "evidence",
            ],
        )
        writer.writeheader()
        for row in proposed:
            writer.writerow(row)
    summary = {
        "ok": any(item.get("ok") for item in results),
        "message": "当前 FSR 模式家族归属完成；请确认建议结果后再写入模式家族归属。",
        "chip": chip,
        "die": die,
        "q_slot": q_slot,
        "mode_number": selected_mode.get("mode_number"),
        "wavelength_basis": basis,
        "output_dir": str(root),
        "assignment_table": str(table_path),
        "proposed_assignments": proposed,
        "results": results,
        "steps": steps,
        "elapsed_s": time.perf_counter() - started,
    }
    summary_path = root / "assignment_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    summary["summary_path"] = str(summary_path)
    emit_progress(
        directory,
        {
            "state": "complete",
            "phase": "complete",
            "chip": chip,
            "die": die,
            "q_slot": q_slot,
            "mode_number": selected_mode.get("mode_number"),
            "wavelength_basis": basis,
            "total_families": total_modes,
            "current_index": total_modes,
            "current_family": None,
            "output_dir": str(root),
            "assignment_table": str(table_path),
            "summary_path": str(summary_path),
            "message": f"当前 FSR 模式家族归属完成，共处理 {total_modes} 个模式家族。",
        },
    )
    return summary


def run_current_fsr_probe_assignment(
    config: dict[str, Any], payload: dict[str, Any], *,
    cancel_event_prepared: bool = False,
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    if not CURRENT_FSR_RUN_LOCK.acquire(blocking=False):
        return {"ok": False, "busy": True, "error": "当前 FSR 逐模式轮询已在运行"}
    if not cancel_event_prepared:
        CURRENT_FSR_CANCEL_EVENT.clear()
    run_state = {"hardware_started": False, "recovery": None, "progress_callback": progress_callback}
    try:
        return _run_current_fsr_probe_assignment(config, payload, run_state)
    except Exception as exc:
        if not isinstance(exc, WorkflowCancelled) and not CURRENT_FSR_CANCEL_EVENT.is_set():
            raise
        chip = validate_name(str(payload.get("chip") or ""), "chip")
        die = validate_name(str(payload.get("die") or ""), "die")
        q_slot = payload_q_slot(payload)
        directory = die_dir(config, chip, die, create=True)
        output_dir = thermal_current_fsr_assignment_dir(directory, q_slot)
        recovery = getattr(exc, "recovery", None) or run_state.get("recovery")
        if recovery is None:
            if run_state["hardware_started"]:
                def report_cleanup(details: dict[str, Any]) -> None:
                    progress = {**run_state.get("progress", {}), **details, "state": "stopping", "chip": chip, "die": die, "q_slot": q_slot}
                    progress.pop("updated_at", None)
                    written = write_current_fsr_progress(directory, progress)
                    if progress_callback is not None:
                        try:
                            progress_callback(written)
                        except Exception:
                            pass
                recovery = finish_thermal_io(config, {**payload, "chip": chip, "die": die, "q_slot": q_slot, "manual_tmp": True},
                    write_error=exc.result if isinstance(exc, SgmWriteError) else None, progress_callback=report_cleanup)
            else:
                recovery = {"ok": True, "skipped": True, "reason": "取消发生在仪器操作前"}
        recovery_ok = recovery.get("ok") is True
        requested = CURRENT_FSR_CANCEL_EVENT.requested_monotonic
        result = {
            **{key:value for key,value in run_state.get("progress", {}).items() if key != "updated_at"},
            "ok": recovery_ok, "cancelled": True, "state": "cancelled", "phase": "cancelled",
            "chip": chip, "die": die, "q_slot": q_slot, "output_dir": str(output_dir),
            "message": "已停止后续轮询；必要收尾已完成。" if recovery_ok else "已停止后续轮询；清零或恢复未确认成功，请查看收尾结果。",
            "cancel_requested_at": CURRENT_FSR_CANCEL_EVENT.requested_at,
            "cancel_to_finish_s": time.monotonic() - requested if requested is not None else None,
            "recovery_required": not recovery_ok, "recovery": recovery,
            "restore_zero": recovery.get("restore_zero"),
            "restore_scope_run_continuous": recovery.get("restore_scope_run_continuous"),
            "proposed_assignments": [],
        }
        write_current_fsr_progress(directory, result)
        write_json_atomic_with_retry(output_dir / "cancellation.json", result)
        if progress_callback is not None:
            try:
                progress_callback(result)
            except Exception:
                pass
        return result
    finally:
        CURRENT_FSR_RUN_LOCK.release()


def stop_current_fsr_probe_assignment(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    with GLOBAL_HARDWARE_TASK_STATE_LOCK:
        hardware = dict(GLOBAL_HARDWARE_TASK_STATE)
        registered_to_start = bool(hardware.get("active")) and str(
            hardware.get("action") or ""
        ) == "批量 FSR 模式归属"
    running = CURRENT_FSR_RUN_LOCK.locked() or registered_to_start
    if not running:
        return {"ok": True, "stop_requested": False, "message": "当前没有正在运行的 FSR 逐模式轮询。"}
    CURRENT_FSR_CANCEL_EVENT.set()
    try:
        chip = validate_name(
            str(hardware.get("chip") if registered_to_start else payload.get("chip") or ""), "chip"
        )
        die = validate_name(
            str(hardware.get("die") if registered_to_start else payload.get("die") or ""), "die"
        )
        q_slot = normalize_q_slot(
            hardware.get("q_slot") if registered_to_start else payload.get("q_slot")
        )
        directory = die_dir(config, chip, die, create=True)
        current = load_current_fsr_progress(config, chip, die, q_slot)
        write_current_fsr_progress(
            directory,
            {
                "state": "stopping",
                "phase": current.get("phase") or "stopping",
                "chip": chip,
                "die": die,
                "q_slot": q_slot,
                "output_dir": current.get("output_dir"),
                "total_families": current.get("total_families"),
                "current_index": current.get("current_index"),
                "current_family": current.get("current_family"),
                "message": "已请求停止；当前单次仪器操作返回后将终止后续探针、电压点和 family。",
            },
        )
    except Exception:
        pass
    return {
        "ok": True,
        "stop_requested": True,
        "message": "已发送停止请求；当前单次仪器操作结束后停止。",
    }


def accept_current_fsr_assignments(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = payload_q_slot(payload)
    assignments = payload.get("assignments") if isinstance(payload.get("assignments"), list) else None
    if assignments is None:
        summary_path = thermal_current_fsr_assignment_dir(
            die_dir(config, chip, die), q_slot
        ) / "assignment_summary.json"
        if not summary_path.exists():
            raise FileNotFoundError(summary_path)
        summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
        assignments = summary.get("proposed_assignments") if isinstance(summary.get("proposed_assignments"), list) else []
    cleaned = []
    for raw in assignments:
        if not isinstance(raw, dict):
            continue
        family = str(raw.get("family") or "").strip()
        cavity = str(raw.get("cavity") or "").strip()
        if not family:
            continue
        cleaned.append(
            {
                "family": family,
                "cavity": cavity,
                "note": str(raw.get("note") or "当前 FSR 细扫热调谐归属").strip(),
                "evidence": str(raw.get("evidence") or "").strip(),
                "confidence": str(raw.get("confidence") or "").strip(),
                "status": str(raw.get("status") or "accepted_current_fsr_probe_sweep").strip(),
            }
        )
    return save_family_assignments(
        config,
        {"chip": chip, "die": die, "q_slot": q_slot, "assignments": cleaned},
    )
