"""Local dashboard for array-cavity characterization notes.

This is intentionally a small stdlib-only dashboard. It records structured die
observations under an explicit external data root, then renders the same content
into the die-level README.md used by the existing wafer-measurement workflow.
"""

from __future__ import annotations
from urllib.parse import urlencode, urlparse, parse_qs
from a221_workbench.workflows.array_dashboard.discovery import discover_instrument_bindings, state_payload
from a221_workbench.workflows.array_dashboard.noise_measurement import (
    NOISE_SPECTRUM_CANCEL_EVENT,
    capture_current_locked_noise_spectrum,
    load_noise_spectrum_progress,
    run_locked_noise_spectrum_measurement,
    stop_locked_noise_spectrum_measurement,
)
from a221_workbench.workflows.array_dashboard.comb_measurement import (
    COMB_RECONSTRUCTION_CANCEL_EVENT,
    CURRENT_FSR_CANCEL_EVENT,
    accept_current_fsr_assignments,
    acquisition_json_for_q_dir,
    flatten_assignment_loaded_scan_dir,
    latest_raw_npz,
    load_comb_reconstruction_progress,
    load_current_fsr_progress,
    load_preanalysis_trace,
    load_preanalysis_trace_data,
    move_thermal_mode_to_wavelength,
    run_assignment_large_scan,
    run_comb_reconstruction_write_verify,
    run_current_fsr_probe_assignment,
    run_current_mode_probe_and_sweep,
    run_toptica_tcp_worker,
    stop_comb_reconstruction_write_verify,
    stop_current_fsr_probe_assignment,
    thin_xy,
)
from a221_workbench.workflows.array_dashboard.quick_probe import (
    CURRENT_MODE_LOCK_STATE,
    CURRENT_MODE_LOCK_STATE_LOCK,
    GLOBAL_HARDWARE_TASK_STATE,
    GLOBAL_HARDWARE_TASK_STATE_LOCK,
    build_thermal_auto_assignment_plan,
    current_mode_lock_status,
    payload_q_slot,
    quick_probe_progress,
    read_q_modes_csv_multi,
    reserve_thermal_quick_probe_shift,
    resolve_rp,
    run_exclusive_hardware_task,
    run_standalone_thermal_quick_probe_shift,
    set_sgm_voltage,
    stop_thermal_quick_probe_shift,
)
from a221_workbench.tasks.comb_planning import (
    finite_int,
    load_thermal_modes,
    plan_comb_reconstruction,
    solve_min_cost_mode_matching,
    thermal_q_slot_dir,
    thermal_tuning_dir,
    wavelength_nm_to_freq_ghz,
)
from a221_workbench.tasks.array_records import (
    CONFIG_FILE,
    Q_BY_MODE_FILE,
    README_FILE,
    array_die_card_status,
    chip_dir,
    create_experiment_workspace,
    data_root,
    delete_observation_image,
    die_dir,
    electrode_path,
    electrode_sort_key,
    empty_observation,
    ensure_config_file,
    expand_path,
    finite_float,
    list_chips_at_root,
    list_dies,
    list_dies_at_chip_dir,
    load_electrode_record,
    load_family_assignments,
    load_observation,
    load_optical_power_record,
    load_polarization_manifest,
    natural_key,
    normalize_q_slot,
    observation_path,
    q_slot_dir,
    read_config,
    reference_results_root,
    save_array_die_card,
    save_config,
    save_electrode_record,
    save_family_assignments,
    save_manual_polarization_assignment,
    save_observation,
    save_optical_power_record,
    save_polarization_workflow_decisions,
    save_uploaded_observation_image,
    update_die_readme,
    validate_name,
)
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.array_dashboard'


import argparse
import csv
import json
import math
import mimetypes
import shutil
import sys
import threading
import time
import traceback
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.error import HTTPError
from urllib.request import urlopen

from a221_workbench.workflows.array_dashboard.instrument_runtime import instrument_get, instrument_post


SCRIPT_PATH = Path(__file__).resolve()
SRC_DIR = SCRIPT_PATH.parent
PACKAGE_DIR = SRC_DIR.parent

from a221_workbench.instruments.redpitaya.bridge_client import BridgeClient

THERMAL_MODE_PC_VOLTAGE_V = 75.0

MODE_REVIEW_TRACE_CACHE_LOCK = threading.Lock()
GLOBAL_HARDWARE_STOP_RUN_LOCK = threading.Lock()
MODE_REVIEW_TRACE_CACHE: dict[str, dict[str, Any]] = {}

MODE_REVIEW_COLORS = [
    "#1f77b4",
    "#aec7e8",
    "#ff7f0e",
    "#ffbb78",
    "#2ca02c",
    "#98df8a",
    "#d62728",
    "#ff9896",
    "#9467bd",
    "#8c564b",
    "#17becf",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#393b79",
    "#637939",
]

ONE_FSR_FAMILY_COLORS = [
    "#1f77b4",
    "#aec7e8",
    "#ff7f0e",
    "#ffbb78",
    "#2ca02c",
    "#98df8a",
    "#d62728",
    "#ff9896",
    "#9467bd",
    "#c5b0d5",
    "#8c564b",
    "#c49c94",
    "#e377c2",
    "#f7b6d2",
    "#7f7f7f",
    "#c7c7c7",
]


def reference_chips(value: object) -> list[str]:
    return list_chips_at_root(reference_results_root(value))


def reference_dies(value: object, chip: object) -> list[str]:
    root = reference_results_root(value)
    chip_name = validate_name(str(chip or ""), "chip")
    directory = root / chip_name
    if not directory.exists() or not directory.is_dir():
        raise FileNotFoundError(f"参考 chip 不存在: {chip_name}")
    return list_dies_at_chip_dir(directory)


def require_primary_q_workflow(payload: dict[str, Any], operation: str) -> None:
    q_slot = payload_q_slot(payload)
    if q_slot != "Q":
        raise ValueError(
            f"{operation} 当前仅支持 Q 槽；Q' 已支持独立大扫、Q 分析、人工偏振归属和模式浏览，"
            "但热调谐与噪声结果目录尚未完成独立命名空间。"
        )


def tcp_read_pc(config: dict[str, Any], host: str) -> dict[str, Any]:
    return run_toptica_tcp_worker(config, "read_pc", ["--host", host], timeout_s=5.0)


def tcp_set_pc_voltage(config: dict[str, Any], host: str, voltage_v: float) -> dict[str, Any]:
    return run_toptica_tcp_worker(
        config,
        "set_pc_voltage",
        ["--host", host, "--pc-voltage-v", f"{float(voltage_v):.9g}", "--no-readback"],
        timeout_s=5.0,
    )


def center_thermal_mode_with_pc(config: dict[str, Any], payload: dict[str, Any], host: str) -> dict[str, Any]:
    if not bool(config.get("thermal_move_center_after_jump", True)):
        return {"ok": True, "skipped": True, "reason": "thermal_move_center_after_jump disabled"}
    branch = str(config.get("thermal_move_center_branch") or "negative").strip() or "negative"
    tolerance_v = float(config.get("thermal_move_center_tolerance_v") or 0.03)
    gain = float(config.get("thermal_move_center_gain") or 0.8)
    max_step_v = abs(float(config.get("thermal_move_center_max_step_v") or 3.0))
    iterations = max(0, int(float(config.get("thermal_move_center_iterations") or 1)))
    if iterations <= 0:
        return {"ok": True, "skipped": True, "reason": "thermal_move_center_iterations <= 0"}
    steps: list[dict[str, Any]] = []
    ok = True
    time.sleep(0.2)
    for index in range(iterations):
        reading = bridge_scope_dip_position(
            config,
            timeout_s=2.0,
            branch=branch,
            smooth_points=7,
            source="single",
        )
        dip_v = dip_position_sweep_voltage(reading)
        step: dict[str, Any] = {
            "iteration": index + 1,
            "branch": branch,
            "dip_sweep_voltage_v": dip_v,
            "reading": reading,
        }
        if dip_v is None:
            step["ok"] = False
            step["error"] = "dip position unavailable"
            steps.append(step)
            ok = False
            break
        if abs(dip_v) <= tolerance_v:
            step["ok"] = True
            step["centered"] = True
            step["tolerance_v"] = tolerance_v
            steps.append(step)
            break
        pc = tcp_read_pc(config, host)
        if not pc.get("ok"):
            step["ok"] = False
            step["pc_read"] = pc
            steps.append(step)
            ok = False
            break
        pc_set = finite_float(pc.get("voltage_set"))
        arc_factor = finite_float(pc.get("arc_factor"))
        if pc_set is None or arc_factor is None:
            step["ok"] = False
            step["pc_read"] = pc
            step["error"] = "PC voltage_set or arc_factor unavailable"
            steps.append(step)
            ok = False
            break
        raw_delta = gain * arc_factor * dip_v
        limited_delta = max(-max_step_v, min(max_step_v, raw_delta))
        target_pc = pc_set + limited_delta
        write = tcp_set_pc_voltage(config, host, target_pc)
        step.update(
            {
                "ok": bool(write.get("ok")),
                "centered": False,
                "pc_voltage_before_v": pc_set,
                "arc_factor": arc_factor,
                "gain": gain,
                "raw_delta_pc_v": raw_delta,
                "limited_delta_pc_v": limited_delta,
                "target_pc_voltage_v": target_pc,
                "pc_write": write,
            }
        )
        steps.append(step)
        ok = ok and bool(write.get("ok"))
        time.sleep(0.15)
    return {
        "ok": ok,
        "method": "PC centering from RP scope dip_sweep_voltage_v",
        "branch": branch,
        "tolerance_v": tolerance_v,
        "max_step_v": max_step_v,
        "iterations": iterations,
        "steps": steps,
    }


def read_q_modes_csv(path: Path, *, mode_number: int = 0) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(path)
    by_family: dict[str, dict[str, Any]] = {}
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            row_mode = finite_int(row.get("mode_number"))
            if row_mode != mode_number:
                continue
            if row.get("fit_status") and row.get("fit_status") != "ok":
                continue
            family = str(row.get("family_label") or row.get("family") or "").strip()
            wavelength_nm = finite_float(row.get("wavelength_nm"))
            if not family or wavelength_nm is None:
                continue
            by_family[family] = {
                "family": family,
                "mode_number": mode_number,
                "wavelength_nm": wavelength_nm,
                "frequency_ghz": wavelength_nm_to_freq_ghz(wavelength_nm),
                "relative_freq_ghz": finite_float(row.get("relative_freq_ghz")),
                "folded_freq_ghz": finite_float(row.get("folded_freq_ghz")),
                "depth": finite_float(row.get("depth")),
                "transmission": finite_float(row.get("transmission")),
                "QL": finite_float(row.get("QL")),
                "fit_status": row.get("fit_status") or "",
            }
    return sorted(by_family.values(), key=lambda item: natural_key(str(item.get("family") or "")))


def q_mode_match_frequency(row: dict[str, Any]) -> tuple[float | None, str]:
    rel = finite_float(row.get("relative_freq_ghz"))
    if rel is not None:
        return rel, "relative_freq_ghz"
    absolute = finite_float(row.get("frequency_ghz"))
    if absolute is not None:
        return absolute, "absolute_wavelength_frequency"
    return None, "missing"


def q_mode_identity(row: dict[str, Any]) -> str:
    family = str(row.get("family") or "").strip() or "unknown"
    mode_number = finite_int(row.get("mode_number"))
    return f"{family}/mu={mode_number if mode_number is not None else '?'}"


def compare_thermal_mu0_relative_shifts(
    baseline_modes: list[dict[str, Any]],
    loaded_modes: list[dict[str, Any]],
    plan: dict[str, Any],
    *,
    fsr_ghz: float | None = None,
) -> dict[str, Any]:
    baseline_rows = sorted(
        [row for row in baseline_modes if q_mode_match_frequency(row)[0] is not None],
        key=lambda row: natural_key(str(row.get("family") or "")),
    )
    loaded_rows = sorted(
        [row for row in loaded_modes if q_mode_match_frequency(row)[0] is not None],
        key=lambda row: (abs(int(row.get("mode_number") or 0)), int(row.get("mode_number") or 0), natural_key(str(row.get("family") or ""))),
    )
    shift_limit_ghz = None
    if fsr_ghz is not None and math.isfinite(float(fsr_ghz)) and float(fsr_ghz) > 0:
        shift_limit_ghz = 0.45 * float(fsr_ghz)
    large_penalty = 1_000_000.0
    costs: list[list[float]] = []
    for base in baseline_rows:
        base_freq, _source = q_mode_match_frequency(base)
        row_costs: list[float] = []
        for loaded in loaded_rows:
            loaded_freq, _loaded_source = q_mode_match_frequency(loaded)
            if base_freq is None or loaded_freq is None:
                row_costs.append(large_penalty * 10.0)
                continue
            abs_delta = abs(float(loaded_freq) - float(base_freq))
            penalty = large_penalty if shift_limit_ghz is not None and abs_delta > shift_limit_ghz else 0.0
            row_costs.append(abs_delta + penalty)
        costs.append(row_costs)
    raw_matches = solve_min_cost_mode_matching(costs)
    matched_by_base_index = {base_idx: (loaded_idx, cost) for base_idx, loaded_idx, cost in raw_matches}
    used_loaded_indices = {loaded_idx for _base_idx, loaded_idx, _cost in raw_matches}
    comparisons: list[dict[str, Any]] = []
    for base_idx, base in enumerate(baseline_rows):
        if base_idx not in matched_by_base_index:
            continue
        loaded_idx, match_cost = matched_by_base_index[base_idx]
        if loaded_idx >= len(loaded_rows):
            continue
        loaded = loaded_rows[loaded_idx]
        family = str(base.get("family") or "")
        base_rel = base.get("relative_freq_ghz")
        loaded_rel = loaded.get("relative_freq_ghz")
        if base_rel is not None and loaded_rel is not None:
            delta_freq_ghz = float(loaded_rel) - float(base_rel)
            frequency_source = "relative_freq_ghz"
        else:
            delta_freq_ghz = float(loaded["frequency_ghz"]) - float(base["frequency_ghz"])
            frequency_source = "absolute_wavelength_frequency"
        comparisons.append(
            {
                "family": family,
                "mode_number": 0,
                "baseline_wavelength_nm": base["wavelength_nm"],
                "loaded_wavelength_nm": loaded["wavelength_nm"],
                "loaded_observed_family": loaded.get("family"),
                "loaded_mode_number": loaded.get("mode_number"),
                "loaded_identity": q_mode_identity(loaded),
                "baseline_relative_freq_ghz": base_rel,
                "loaded_relative_freq_ghz": loaded_rel,
                "delta_freq_ghz": delta_freq_ghz,
                "abs_shift_ghz": abs(delta_freq_ghz),
                "delta_wavelength_nm": float(loaded["wavelength_nm"]) - float(base["wavelength_nm"]),
                "frequency_source": frequency_source,
                "match_method": "global_nearest_loaded_resonance_mu_minus1_0_plus1",
                "match_cost_ghz": match_cost if match_cost < large_penalty else match_cost - large_penalty,
                "match_status": "large_shift_suspect"
                if shift_limit_ghz is not None and abs(delta_freq_ghz) > shift_limit_ghz
                else "ok",
                "match_shift_limit_ghz": shift_limit_ghz,
                "baseline": base,
                "loaded": loaded,
            }
        )
    entries = sorted(
        plan.get("entries") or [],
        key=lambda item: (float(item.get("applied_voltage_code_v2") or 0.0), electrode_sort_key(str(item.get("electrode") or ""))),
    )
    sorted_comparisons = sorted(comparisons, key=lambda item: float(item["abs_shift_ghz"]))
    assignable_count = min(len(entries), len(sorted_comparisons))
    pairs = list(zip(entries[:assignable_count], sorted_comparisons[:assignable_count]))
    codes = [float(entry.get("applied_voltage_code_v2") or 0.0) for entry, _item in pairs]
    shifts = [float(item.get("abs_shift_ghz") or 0.0) for _entry, item in pairs]
    nonzero = [(code, shift) for code, shift in zip(codes, shifts) if code > 1e-12]
    denominator = sum(code * code for code, _shift in nonzero)
    scale_ghz_per_v2 = (sum(code * shift for code, shift in nonzero) / denominator) if denominator > 0 else 0.0
    assignments: list[dict[str, Any]] = []
    detailed_pairs: list[dict[str, Any]] = []
    for entry, item in pairs:
        code = float(entry.get("applied_voltage_code_v2") or 0.0)
        shift = float(item.get("abs_shift_ghz") or 0.0)
        predicted = scale_ghz_per_v2 * code
        residual = shift - predicted
        relative_error = abs(residual) / max(abs(predicted), 1.0)
        if item.get("match_status") != "ok":
            confidence = "low"
            status = "matched_peak_shift_suspect"
            note = "加压后候选峰位移超过 FSR 限制，需人工复核"
        elif not entry.get("usable"):
            confidence = "low"
            status = "inferred_unpowered_or_open"
            note = "该腔对应电极未加压，按最小 mu=0 位移暂推断"
        else:
            confidence = "high" if relative_error <= 0.35 else "medium" if relative_error <= 0.75 else "low"
            status = "auto_mu0_voltage_rank"
            note = "自动热调谐编码电压归属"
        evidence = (
            f"实际 out{entry.get('out')}={float(entry.get('applied_voltage_v') or 0.0):.3f} V；"
            f"{item['family']} mu=0 匹配到加压后 {item.get('loaded_identity')}，"
            f"Δf={item['delta_freq_ghz']:+.3f} GHz，|Δf|={shift:.3f} GHz；"
            f"按 |Δf| 与 V^2 排名匹配到 {entry.get('cavity')}"
        )
        assignment = {
            "family": item["family"],
            "cavity": entry.get("cavity") or "",
            "note": note,
            "evidence": evidence,
            "confidence": confidence,
            "status": status,
        }
        assignments.append(assignment)
        detailed_pairs.append(
            {
                **assignment,
                "electrode": entry.get("electrode"),
                "probe": entry.get("probe"),
                "out": entry.get("out"),
                "voltage_v": entry.get("applied_voltage_v"),
                "voltage_code_v2": code,
                "measured_delta_freq_ghz": item["delta_freq_ghz"],
                "measured_abs_shift_ghz": shift,
                "predicted_abs_shift_ghz": predicted,
                "residual_ghz": residual,
                "relative_error": relative_error,
                "comparison": item,
            }
        )
    return {
        "ok": bool(assignments),
        "method": "baseline mu=0 modes matched to nearest loaded resonances in the mu=-1/0/+1 window, then rank(|Δf|) matched to quadratic-coded SGM V^2",
        "mode_number": 0,
        "baseline_count": len(baseline_modes),
        "loaded_count": len(loaded_modes),
        "loaded_candidate_window": "mu=-1,0,+1",
        "matched_count": len(comparisons),
        "match_shift_limit_ghz": shift_limit_ghz,
        "missing_in_loaded": [
            str(row.get("family") or "")
            for row in baseline_rows
            if str(row.get("family") or "") not in {str(item.get("family") or "") for item in comparisons}
        ],
        "unused_loaded_candidates": [q_mode_identity(row) for idx, row in enumerate(loaded_rows) if idx not in used_loaded_indices],
        "scale_ghz_per_v2": scale_ghz_per_v2,
        "comparisons": comparisons,
        "assigned_pairs": detailed_pairs,
        "inferred_unpowered": [pair for pair in detailed_pairs if pair.get("status") == "inferred_unpowered_or_open"],
        "assignments": assignments,
    }


def compare_thermal_loaded_modes(
    baseline_modes: list[dict[str, Any]],
    loaded_modes: list[dict[str, Any]],
    plan: dict[str, Any],
) -> dict[str, Any]:
    baseline_by_family = {str(row["family"]): row for row in baseline_modes}
    loaded_by_family = {str(row["family"]): row for row in loaded_modes}
    common_families = sorted(set(baseline_by_family) & set(loaded_by_family), key=natural_key)
    comparisons: list[dict[str, Any]] = []
    for family in common_families:
        base = baseline_by_family[family]
        loaded = loaded_by_family[family]
        delta_freq_ghz = float(loaded["frequency_ghz"]) - float(base["frequency_ghz"])
        rel_base = base.get("relative_freq_ghz")
        rel_loaded = loaded.get("relative_freq_ghz")
        if rel_base is not None and rel_loaded is not None:
            delta_relative_freq_ghz = float(rel_loaded) - float(rel_base)
        else:
            delta_relative_freq_ghz = None
        delta_wavelength_nm = float(loaded["wavelength_nm"]) - float(base["wavelength_nm"])
        comparisons.append(
            {
                "family": family,
                "baseline_wavelength_nm": base["wavelength_nm"],
                "loaded_wavelength_nm": loaded["wavelength_nm"],
                "delta_wavelength_nm": delta_wavelength_nm,
                "delta_freq_ghz": delta_freq_ghz,
                "delta_relative_freq_ghz": delta_relative_freq_ghz,
                "abs_shift_ghz": abs(delta_freq_ghz),
                "baseline": base,
                "loaded": loaded,
            }
        )
    active_entries = sorted(plan.get("active_entries") or [], key=lambda item: float(item.get("voltage_code_v2") or 0.0))
    skipped_entries = sorted(plan.get("skipped_entries") or [], key=lambda item: electrode_sort_key(str(item.get("electrode") or "")))
    sorted_comparisons = sorted(comparisons, key=lambda item: float(item["abs_shift_ghz"]))
    assignable_count = min(len(active_entries), len(sorted_comparisons))
    unassigned_count = max(0, len(sorted_comparisons) - assignable_count)
    low_shift_candidates = sorted_comparisons[:unassigned_count]
    shifted_candidates = sorted_comparisons[unassigned_count : unassigned_count + assignable_count]
    codes = [float(entry.get("voltage_code_v2") or 0.0) for entry in active_entries[:assignable_count]]
    shifts = [float(item.get("abs_shift_ghz") or 0.0) for item in shifted_candidates]
    denominator = sum(code * code for code in codes)
    scale_ghz_per_v2 = (sum(code * shift for code, shift in zip(codes, shifts)) / denominator) if denominator > 0 else 0.0
    signs = [1 if float(item["delta_freq_ghz"]) >= 0 else -1 for item in shifted_candidates if float(item["abs_shift_ghz"]) > 1e-9]
    sign = 1 if signs.count(1) >= signs.count(-1) else -1
    assignments: list[dict[str, Any]] = []
    detailed_pairs: list[dict[str, Any]] = []
    for entry, item, code, shift in zip(active_entries, shifted_candidates, codes, shifts):
        predicted = scale_ghz_per_v2 * code
        residual = shift - predicted
        relative_error = abs(residual) / max(abs(predicted), 1e-9)
        confidence = "high" if shift >= 0.3 and relative_error <= 0.30 else "medium" if shift >= 0.1 and relative_error <= 0.65 else "low"
        evidence = (
            f"编码电压 out{entry.get('out')}={float(entry.get('voltage_v')):.3f} V；"
            f"{item['family']} 位移 {item['delta_wavelength_nm']:+.6f} nm / {item['delta_freq_ghz']:+.3f} GHz；"
            f"按 |Δf| 排名匹配到 {entry.get('cavity')}"
        )
        assignment = {
            "family": item["family"],
            "cavity": entry.get("cavity") or "",
            "note": "自动热调谐编码电压归属",
            "evidence": evidence,
            "confidence": confidence,
            "status": "auto_voltage_rank",
        }
        assignments.append(assignment)
        detailed_pairs.append(
            {
                **assignment,
                "electrode": entry.get("electrode"),
                "probe": entry.get("probe"),
                "out": entry.get("out"),
                "voltage_v": entry.get("voltage_v"),
                "voltage_code_v2": code,
                "measured_abs_shift_ghz": shift,
                "predicted_abs_shift_ghz": predicted,
                "residual_ghz": residual,
                "relative_error": relative_error,
                "comparison": item,
            }
        )
    inferred_unpowered: list[dict[str, Any]] = []
    if skipped_entries and low_shift_candidates:
        for entry, item in zip(skipped_entries, low_shift_candidates):
            assignment = {
                "family": item["family"],
                "cavity": entry.get("cavity") or "",
                "note": "该腔对应电极未加压，按最小位移暂推断",
                "evidence": (
                    f"{entry.get('electrode')} / {entry.get('cavity')} 未参与编码加压（{entry.get('contact_status') or '无接触记录'}）；"
                    f"{item['family']} 位移最小：{item['delta_wavelength_nm']:+.6f} nm / {item['delta_freq_ghz']:+.3f} GHz"
                ),
                "confidence": "low",
                "status": "inferred_unpowered_or_open",
            }
            assignments.append(assignment)
            inferred_unpowered.append({**assignment, "comparison": item, "skipped_entry": entry})
    return {
        "ok": bool(assignments),
        "method": "same-family mu=0 peak shift, rank(|Δf|) matched to quadratic-coded SGM V^2",
        "mode_number": 0,
        "baseline_count": len(baseline_modes),
        "loaded_count": len(loaded_modes),
        "common_family_count": len(common_families),
        "active_voltage_count": len(active_entries),
        "skipped_voltage_count": len(skipped_entries),
        "missing_in_loaded": sorted(set(baseline_by_family) - set(loaded_by_family), key=natural_key),
        "new_in_loaded": sorted(set(loaded_by_family) - set(baseline_by_family), key=natural_key),
        "scale_ghz_per_v2": scale_ghz_per_v2,
        "dominant_delta_freq_sign": sign,
        "comparisons": comparisons,
        "assigned_pairs": detailed_pairs,
        "inferred_unpowered": inferred_unpowered,
        "assignments": assignments,
    }


def read_array_family_centers(summary_path: Path) -> list[dict[str, Any]]:
    if not summary_path.exists():
        raise FileNotFoundError(summary_path)
    data = json.loads(summary_path.read_text(encoding="utf-8-sig"))
    families = data.get("families") if isinstance(data, dict) else None
    if not isinstance(families, list):
        raise ValueError(f"array_preanalysis_summary.json lacks families list: {summary_path}")
    rows: list[dict[str, Any]] = []
    for raw in families:
        if not isinstance(raw, dict):
            continue
        family = str(raw.get("family_label") or raw.get("family") or "").strip()
        folded = finite_float(raw.get("center_folded_ghz"))
        if not family or folded is None:
            continue
        rows.append(
            {
                "family": family,
                "center_folded_ghz": folded,
                "count": finite_int(raw.get("count")),
                "median_depth": finite_float(raw.get("median_depth")),
                "max_depth": finite_float(raw.get("max_depth")),
            }
        )
    return sorted(rows, key=lambda item: natural_key(str(item.get("family") or "")))


def circular_signed_delta_ghz(start_ghz: float, stop_ghz: float, period_ghz: float) -> float:
    if period_ghz <= 0:
        return stop_ghz - start_ghz
    return ((stop_ghz - start_ghz + 0.5 * period_ghz) % period_ghz) - 0.5 * period_ghz


def compare_thermal_family_centers(
    baseline_centers: list[dict[str, Any]],
    loaded_centers: list[dict[str, Any]],
    plan: dict[str, Any],
    *,
    fsr_ghz: float,
) -> dict[str, Any]:
    baseline_by_family = {str(row["family"]): row for row in baseline_centers}
    loaded_by_family = {str(row["family"]): row for row in loaded_centers}
    common_families = sorted(set(baseline_by_family) & set(loaded_by_family), key=natural_key)
    comparisons: list[dict[str, Any]] = []
    for family in common_families:
        base = baseline_by_family[family]
        loaded = loaded_by_family[family]
        delta = circular_signed_delta_ghz(float(base["center_folded_ghz"]), float(loaded["center_folded_ghz"]), fsr_ghz)
        comparisons.append(
            {
                "family": family,
                "baseline_center_folded_ghz": base["center_folded_ghz"],
                "loaded_center_folded_ghz": loaded["center_folded_ghz"],
                "delta_folded_ghz": delta,
                "red_shift_ghz": max(0.0, -delta),
                "abs_shift_ghz": abs(delta),
                "baseline": base,
                "loaded": loaded,
            }
        )
    entries = sorted(
        plan.get("entries") or [],
        key=lambda item: (float(item.get("applied_voltage_code_v2") or 0.0), electrode_sort_key(str(item.get("electrode") or ""))),
    )
    sorted_comparisons = sorted(comparisons, key=lambda item: float(item["abs_shift_ghz"]))
    assignable_count = min(len(entries), len(sorted_comparisons))
    pairs = list(zip(entries[:assignable_count], sorted_comparisons[:assignable_count]))
    codes = [float(entry.get("applied_voltage_code_v2") or 0.0) for entry, _item in pairs]
    shifts = [float(item.get("abs_shift_ghz") or 0.0) for _entry, item in pairs]
    nonzero = [(code, shift) for code, shift in zip(codes, shifts) if code > 1e-12]
    denominator = sum(code * code for code, _shift in nonzero)
    scale_ghz_per_v2 = (sum(code * shift for code, shift in nonzero) / denominator) if denominator > 0 else 0.0
    assignments: list[dict[str, Any]] = []
    detailed_pairs: list[dict[str, Any]] = []
    for entry, item in pairs:
        code = float(entry.get("applied_voltage_code_v2") or 0.0)
        shift = float(item.get("abs_shift_ghz") or 0.0)
        predicted = scale_ghz_per_v2 * code
        residual = shift - predicted
        relative_error = abs(residual) / max(abs(predicted), 1.0)
        if not entry.get("usable"):
            confidence = "low"
            status = "inferred_unpowered_or_open"
            note = "该腔对应电极未加压，按最小折叠位移暂推断"
        else:
            confidence = "high" if relative_error <= 0.35 else "medium" if relative_error <= 0.75 else "low"
            status = "auto_folded_voltage_rank"
            note = "自动热调谐编码电压归属"
        evidence = (
            f"实际 out{entry.get('out')}={float(entry.get('applied_voltage_v') or 0.0):.3f} V；"
            f"{item['family']} 折叠中心位移 {item['delta_folded_ghz']:+.3f} GHz，|Δ|={shift:.3f} GHz；"
            f"按 |折叠位移| 排名匹配到 {entry.get('cavity')}"
        )
        assignment = {
            "family": item["family"],
            "cavity": entry.get("cavity") or "",
            "note": note,
            "evidence": evidence,
            "confidence": confidence,
            "status": status,
        }
        assignments.append(assignment)
        detailed_pairs.append(
            {
                **assignment,
                "electrode": entry.get("electrode"),
                "probe": entry.get("probe"),
                "out": entry.get("out"),
                "voltage_v": entry.get("applied_voltage_v"),
                "voltage_code_v2": code,
                "measured_abs_shift_ghz": shift,
                "predicted_abs_shift_ghz": predicted,
                "residual_ghz": residual,
                "relative_error": relative_error,
                "comparison": item,
            }
        )
    return {
        "ok": bool(assignments),
        "method": "family folded-center shift, rank(|Δfolded|) matched to quadratic-coded SGM V^2",
        "mode_number": 0,
        "fsr_ghz": fsr_ghz,
        "baseline_count": len(baseline_centers),
        "loaded_count": len(loaded_centers),
        "common_family_count": len(common_families),
        "missing_in_loaded": sorted(set(baseline_by_family) - set(loaded_by_family), key=natural_key),
        "new_in_loaded": sorted(set(loaded_by_family) - set(baseline_by_family), key=natural_key),
        "scale_ghz_per_v2": scale_ghz_per_v2,
        "comparisons": comparisons,
        "assigned_pairs": detailed_pairs,
        "inferred_unpowered": [pair for pair in detailed_pairs if pair.get("status") == "inferred_unpowered_or_open"],
        "assignments": assignments,
    }


def read_mode_review_rows(q_dir: Path) -> list[dict[str, Any]]:
    path = q_dir / Q_BY_MODE_FILE
    if not path.exists():
        raise FileNotFoundError(path)
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for raw in csv.DictReader(handle):
            family = str(raw.get("family_label") or raw.get("family") or "").strip()
            mode_number = finite_int(raw.get("mode_number"))
            folded_freq_ghz = finite_float(raw.get("folded_freq_ghz"))
            sample_index = finite_int(raw.get("sample_index"))
            if not family or mode_number is None or folded_freq_ghz is None or sample_index is None:
                continue
            rows.append(
                {
                    **raw,
                    "family": family,
                    "mode_number": mode_number,
                    "folded_freq_ghz": folded_freq_ghz,
                    "sample_index": sample_index,
                }
            )
    return sorted(rows, key=lambda item: (natural_key(str(item["family"])), int(item["mode_number"])))


def mode_review_points_payload(
    config: dict[str, Any],
    chip: str,
    die: str,
    q_slot: object = "Q",
) -> dict[str, Any]:
    normalized_q_slot = normalize_q_slot(q_slot)
    q_dir = q_slot_dir(die_dir(config, chip, die), normalized_q_slot)
    rows = read_mode_review_rows(q_dir)
    families = sorted({str(row["family"]) for row in rows}, key=natural_key)
    colors = {family: MODE_REVIEW_COLORS[index % len(MODE_REVIEW_COLORS)] for index, family in enumerate(families)}
    summary_path = q_dir / "array_preanalysis_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8-sig")) if summary_path.exists() else {}
    fsr_ghz = finite_float(summary.get("selected_fsr_ghz"))
    points: list[dict[str, Any]] = []
    for row in rows:
        if str(row.get("fit_status") or "").strip().lower() != "ok":
            continue
        family = str(row["family"])
        points.append(
            {
                "family": family,
                "mode_number": int(row["mode_number"]),
                "folded_freq_ghz": float(row["folded_freq_ghz"]),
                "wavelength_nm": finite_float(row.get("wavelength_nm")),
                "depth": finite_float(row.get("depth")),
                "linewidth_loaded_mhz": finite_float(row.get("linewidth_loaded_mhz")),
                "QL_M": (finite_float(row.get("QL")) or 0.0) / 1e6,
                "color": colors[family],
            }
        )
    if not points:
        raise ValueError(f"没有可交互显示的成功拟合模式: {q_dir / Q_BY_MODE_FILE}")
    if fsr_ghz is None or fsr_ghz <= 0:
        fsr_ghz = max(float(point["folded_freq_ghz"]) for point in points) * 1.05
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "q_slot": normalized_q_slot,
        "fsr_ghz": fsr_ghz,
        "point_count": len(points),
        "families": [{"family": family, "color": colors[family]} for family in families],
        "points": points,
        "source": str(q_dir / Q_BY_MODE_FILE),
    }


def load_mode_review_trace_cached(q_dir: Path) -> dict[str, Any]:
    raw_path = latest_raw_npz(q_dir)
    summary_path = q_dir / "array_preanalysis_summary.json"
    acquisition_path = acquisition_json_for_q_dir(q_dir, raw_path)
    signature = (
        raw_path.stat().st_mtime_ns,
        raw_path.stat().st_size,
        summary_path.stat().st_mtime_ns if summary_path.exists() else 0,
        acquisition_path.stat().st_mtime_ns if acquisition_path and acquisition_path.exists() else 0,
    )
    key = str(q_dir.resolve())
    with MODE_REVIEW_TRACE_CACHE_LOCK:
        cached = MODE_REVIEW_TRACE_CACHE.get(key)
        if cached and cached.get("signature") == signature:
            return cached["data"]
        data = load_preanalysis_trace_data(q_dir, summary_path)
        MODE_REVIEW_TRACE_CACHE.clear()
        MODE_REVIEW_TRACE_CACHE[key] = {"signature": signature, "data": data}
        return data


def one_fsr_modes_payload(
    config: dict[str, Any],
    chip: str,
    die: str,
    q_slot: object = "Q",
    mode_number: int | None = None,
) -> dict[str, Any]:
    import numpy as np  # type: ignore

    normalized_q_slot = normalize_q_slot(q_slot)
    q_dir = q_slot_dir(die_dir(config, chip, die), normalized_q_slot)
    summary_path = q_dir / "array_preanalysis_summary.json"
    modes_path = q_dir / "array_preanalysis_modes.csv"
    if not summary_path.exists():
        raise FileNotFoundError(summary_path)
    if not modes_path.exists():
        raise FileNotFoundError(modes_path)

    summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
    fsr_mhz = finite_float(summary.get("selected_fsr_mhz"))
    if fsr_mhz is None:
        fsr_ghz = finite_float(summary.get("selected_fsr_ghz"))
        fsr_mhz = fsr_ghz * 1000.0 if fsr_ghz is not None else None
    fold_origin_mhz = finite_float(summary.get("fold_origin_mhz"))
    expected_families = finite_int(summary.get("expected_families")) or 16
    if fsr_mhz is None or fsr_mhz <= 0 or fold_origin_mhz is None:
        raise ValueError(f"单 FSR 交互图缺少有效的 FSR 或折叠原点: {summary_path}")

    rows: list[dict[str, Any]] = []
    with modes_path.open(newline="", encoding="utf-8-sig") as handle:
        for raw in csv.DictReader(handle):
            row_mode = finite_int(raw.get("mode_number"))
            folded_freq_ghz = finite_float(raw.get("folded_freq_ghz"))
            norm_transmission = finite_float(raw.get("norm_transmission"))
            if row_mode is None or folded_freq_ghz is None or norm_transmission is None:
                continue
            family = str(raw.get("family_label") or "unmatched").strip() or "unmatched"
            rows.append(
                {
                    "mode_number": row_mode,
                    "folded_freq_ghz": folded_freq_ghz,
                    "norm_transmission": norm_transmission,
                    "depth": finite_float(raw.get("depth_1_minus_norm")),
                    "family": family,
                }
            )
    available_modes = sorted({int(row["mode_number"]) for row in rows})
    if not available_modes:
        raise ValueError(f"模式表中没有可显示的 mode_number: {modes_path}")

    if mode_number is None:
        selected_group = summary.get("selected_one_fsr_group")
        selected_mode = finite_int(selected_group.get("mode_number")) if isinstance(selected_group, dict) else None
        if selected_mode not in available_modes:
            selected_mode = min(available_modes, key=lambda value: (abs(value), value))
    else:
        selected_mode = int(mode_number)
        if selected_mode not in available_modes:
            raise ValueError(f"mu={selected_mode} 不在可用范围 {available_modes[0]}..{available_modes[-1]}")

    def mode_statistics(candidate: int) -> dict[str, Any]:
        selected_rows = [row for row in rows if int(row["mode_number"]) == candidate]
        families = {str(row["family"]) for row in selected_rows if str(row["family"]) != "unmatched"}
        return {
            "mode_number": candidate,
            "point_count": len(selected_rows),
            "family_count": len(families),
            "unmatched_count": sum(1 for row in selected_rows if str(row["family"]) == "unmatched"),
        }

    selected_rows = [row for row in rows if int(row["mode_number"]) == selected_mode]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in selected_rows:
        grouped.setdefault(str(row["family"]), []).append(row)
    representative_ids: set[int] = set()
    duplicate_families: list[str] = []
    for family, family_rows in grouped.items():
        if family == "unmatched":
            continue
        representative = min(family_rows, key=lambda row: float(row["norm_transmission"]))
        representative_ids.add(id(representative))
        if len(family_rows) > 1:
            duplicate_families.append(family)

    present_families = sorted(
        (family for family in grouped if family != "unmatched"),
        key=natural_key,
    )
    missing_families = [f"F{index}" for index in range(1, expected_families + 1) if f"F{index}" not in grouped]
    points: list[dict[str, Any]] = []
    for row in selected_rows:
        family = str(row["family"])
        family_index = finite_int(family[1:]) if family.startswith("F") else None
        color = (
            ONE_FSR_FAMILY_COLORS[(family_index - 1) % len(ONE_FSR_FAMILY_COLORS)]
            if family_index is not None and family_index > 0
            else "#777777"
        )
        points.append(
            {
                **row,
                "representative": family != "unmatched" and id(row) in representative_ids,
                "color": color,
            }
        )

    trace_data = load_mode_review_trace_cached(q_dir)
    start_mhz = fold_origin_mhz + selected_mode * fsr_mhz
    stop_mhz = start_mhz + fsr_mhz
    frequency = np.asarray(trace_data["freq_mhz"], dtype=float)
    transmission = np.asarray(trace_data["trans_norm"], dtype=float)
    trace_mask = np.isfinite(frequency) & np.isfinite(transmission) & (frequency >= start_mhz) & (frequency <= stop_mhz)
    trace_x = (frequency[trace_mask] - start_mhz) / 1000.0
    trace_y = transmission[trace_mask]
    order = np.argsort(trace_x)
    trace_x = trace_x[order]
    trace_y = trace_y[order]
    max_trace_points = 2400
    if len(trace_x) > max_trace_points:
        chosen: set[int] = {0, len(trace_x) - 1}
        bucket_count = max(1, max_trace_points // 2 - 1)
        edges = np.linspace(0, len(trace_x), bucket_count + 1, dtype=int)
        for left, right in zip(edges[:-1], edges[1:]):
            if right <= left:
                continue
            section = trace_y[left:right]
            chosen.add(left + int(np.argmin(section)))
            chosen.add(left + int(np.argmax(section)))
        keep = np.asarray(sorted(chosen), dtype=int)
        trace_x = trace_x[keep]
        trace_y = trace_y[keep]

    family_legend = []
    for family in present_families:
        family_index = finite_int(family[1:]) if family.startswith("F") else None
        color = (
            ONE_FSR_FAMILY_COLORS[(family_index - 1) % len(ONE_FSR_FAMILY_COLORS)]
            if family_index is not None and family_index > 0
            else "#777777"
        )
        family_legend.append({"family": family, "color": color})
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "q_slot": normalized_q_slot,
        "selected_mode_number": selected_mode,
        "fsr_ghz": fsr_mhz / 1000.0,
        "expected_families": expected_families,
        "mode_options": [mode_statistics(candidate) for candidate in available_modes],
        "trace": [[float(x), float(y)] for x, y in zip(trace_x, trace_y)],
        "points": points,
        "present_families": present_families,
        "missing_families": missing_families,
        "duplicate_families": sorted(duplicate_families, key=natural_key),
        "unmatched_count": sum(1 for row in selected_rows if str(row["family"]) == "unmatched"),
        "families": family_legend,
        "source": {
            "modes": str(modes_path),
            "raw": str(trace_data["raw_path"]),
        },
    }


def mode_review_local_payload(
    config: dict[str, Any],
    chip: str,
    die: str,
    family: str,
    mode_number: int,
    q_slot: object = "Q",
) -> dict[str, Any]:
    started = time.perf_counter()
    normalized_q_slot = normalize_q_slot(q_slot)
    q_dir = q_slot_dir(die_dir(config, chip, die), normalized_q_slot)
    row = next(
        (
            item
            for item in read_mode_review_rows(q_dir)
            if str(item["family"]) == family and int(item["mode_number"]) == mode_number
        ),
        None,
    )
    if row is None:
        raise ValueError(f"未找到模式: {family}, mu={mode_number}")
    if str(row.get("fit_status") or "").strip().lower() != "ok":
        raise ValueError(f"该模式没有成功的洛伦兹拟合: {family}, mu={mode_number}")

    import numpy as np  # type: ignore

    from a221_workbench.tasks.analysis.optical_q import lorentzian_notch

    trace = load_mode_review_trace_cached(q_dir)
    center_raw = int(row["sample_index"])
    center = center_raw - int(trace["valid_start"])
    freq_mhz = trace["freq_mhz"]
    trans_norm = trace["trans_norm"]
    if center < 0 or center >= len(freq_mhz):
        raise ValueError(f"模式采样点不在 MZI 有效区间内: {center_raw}")
    half = max(30, finite_int(row.get("half_window_samples")) or 1200)
    lo = max(0, center - half)
    hi = min(len(freq_mhz), center + half + 1)
    local_freq = np.asarray(freq_mhz[lo:hi], dtype=float)
    local_trans = np.asarray(trans_norm[lo:hi], dtype=float)
    finite = np.isfinite(local_freq) & np.isfinite(local_trans)
    local_freq = local_freq[finite]
    local_trans = local_trans[finite]
    if len(local_freq) < 20:
        raise RuntimeError("局部拟合窗口内有效数据不足")

    center_freq = float(freq_mhz[center])
    fit_x = local_freq - center_freq
    fit_center_offset = finite_float(row.get("fit_center_offset_mhz")) or 0.0
    detuning = fit_x - fit_center_offset
    order = np.argsort(detuning)
    detuning = detuning[order]
    local_trans = local_trans[order]
    max_raw_points = 1000
    if len(detuning) > max_raw_points:
        keep = np.linspace(0, len(detuning) - 1, max_raw_points, dtype=int)
        keep = np.unique(np.r_[keep, int(np.argmin(np.abs(detuning)))])
        detuning = detuning[keep]
        local_trans = local_trans[keep]

    a = finite_float(row.get("baseline_a"))
    b = finite_float(row.get("baseline_slope_per_mhz"))
    depth = finite_float(row.get("depth"))
    linewidth_mhz = finite_float(row.get("linewidth_loaded_mhz"))
    if a is None or b is None or depth is None or linewidth_mhz is None:
        raise ValueError(f"洛伦兹拟合参数不完整: {family}, mu={mode_number}")
    fit_axis = np.linspace(float(np.min(fit_x)), float(np.max(fit_x)), 700)
    fit_values = lorentzian_notch(
        fit_axis,
        a,
        b,
        depth,
        abs(linewidth_mhz) / 2.0,
        fit_center_offset,
    )
    fit_detuning = fit_axis - fit_center_offset
    ql = finite_float(row.get("QL"))
    return {
        "ok": True,
        "family": family,
        "mode_number": mode_number,
        "wavelength_nm": finite_float(row.get("wavelength_nm")),
        "folded_freq_ghz": finite_float(row.get("folded_freq_ghz")),
        "depth": depth,
        "linewidth_loaded_mhz": linewidth_mhz,
        "QL_M": ql / 1e6 if ql is not None else None,
        "rms_residual": finite_float(row.get("rms_residual")),
        "max_abs_residual": finite_float(row.get("max_abs_residual")),
        "raw": [[float(x), float(y)] for x, y in zip(detuning, local_trans, strict=False)],
        "fit": [[float(x), float(y)] for x, y in zip(fit_detuning, fit_values, strict=False)],
        "x_label": "相对拟合中心频率 (MHz)",
        "y_label": "归一化透过率",
        "source": str(q_dir / "raw.npz"),
        "elapsed_s": time.perf_counter() - started,
    }


def write_mu0_shift_table(path: Path, assigned_pairs: list[dict[str, Any]]) -> None:
    fieldnames = [
        "family",
        "assigned_cavity",
        "confidence",
        "status",
        "electrode",
        "probe",
        "sgm_out",
        "voltage_v",
        "voltage_squared_v2",
        "baseline_relative_freq_ghz",
        "loaded_relative_freq_ghz",
        "loaded_observed_family",
        "loaded_mode_number",
        "loaded_identity",
        "match_method",
        "match_status",
        "match_cost_ghz",
        "match_shift_limit_ghz",
        "delta_freq_ghz",
        "abs_delta_freq_ghz",
        "baseline_wavelength_nm",
        "loaded_wavelength_nm",
        "delta_wavelength_nm",
        "predicted_abs_shift_ghz",
        "residual_ghz",
        "relative_error",
        "evidence",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for pair in assigned_pairs:
            comparison = pair.get("comparison") if isinstance(pair.get("comparison"), dict) else {}
            writer.writerow(
                {
                    "family": pair.get("family"),
                    "assigned_cavity": pair.get("cavity"),
                    "confidence": pair.get("confidence"),
                    "status": pair.get("status"),
                    "electrode": pair.get("electrode"),
                    "probe": pair.get("probe"),
                    "sgm_out": pair.get("out"),
                    "voltage_v": pair.get("voltage_v"),
                    "voltage_squared_v2": pair.get("voltage_code_v2"),
                    "baseline_relative_freq_ghz": comparison.get("baseline_relative_freq_ghz"),
                    "loaded_relative_freq_ghz": comparison.get("loaded_relative_freq_ghz"),
                    "loaded_observed_family": comparison.get("loaded_observed_family"),
                    "loaded_mode_number": comparison.get("loaded_mode_number"),
                    "loaded_identity": comparison.get("loaded_identity"),
                    "match_method": comparison.get("match_method"),
                    "match_status": comparison.get("match_status"),
                    "match_cost_ghz": comparison.get("match_cost_ghz"),
                    "match_shift_limit_ghz": comparison.get("match_shift_limit_ghz"),
                    "delta_freq_ghz": comparison.get("delta_freq_ghz"),
                    "abs_delta_freq_ghz": comparison.get("abs_shift_ghz"),
                    "baseline_wavelength_nm": comparison.get("baseline_wavelength_nm"),
                    "loaded_wavelength_nm": comparison.get("loaded_wavelength_nm"),
                    "delta_wavelength_nm": comparison.get("delta_wavelength_nm"),
                    "predicted_abs_shift_ghz": pair.get("predicted_abs_shift_ghz"),
                    "residual_ghz": pair.get("residual_ghz"),
                    "relative_error": pair.get("relative_error"),
                    "evidence": pair.get("evidence"),
                }
            )


def generate_thermal_assignment_evidence(
    run_dir: Path,
    baseline_q_dir: Path,
    loaded_q_dir: Path,
    baseline_modes_m1_0_p1: list[dict[str, Any]],
    analysis: dict[str, Any],
) -> dict[str, Any]:
    evidence_dir = run_dir / "evidence"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    table_path = evidence_dir / "mu0_shift_table.csv"
    assigned_pairs = analysis.get("assigned_pairs") if isinstance(analysis.get("assigned_pairs"), list) else []
    write_mu0_shift_table(table_path, assigned_pairs)
    result: dict[str, Any] = {
        "ok": True,
        "evidence_dir": str(evidence_dir),
        "mu0_shift_table": str(table_path),
    }
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt  # type: ignore
        import numpy as np  # type: ignore

        plt.rcParams.update(
            {
                "font.size": 9,
                "axes.titlesize": 12,
                "axes.labelsize": 10,
                "xtick.labelsize": 9,
                "ytick.labelsize": 9,
                "legend.fontsize": 9,
                "lines.linewidth": 1.2,
            }
        )

        baseline_summary = baseline_q_dir / "array_preanalysis_summary.json"
        loaded_summary = loaded_q_dir / "array_preanalysis_summary.json"
        fsr_ghz = None
        if baseline_summary.exists():
            summary = json.loads(baseline_summary.read_text(encoding="utf-8-sig"))
            fsr_ghz = finite_float(summary.get("selected_fsr_ghz"))
        window_freqs = [
            float(row["relative_freq_ghz"])
            for row in baseline_modes_m1_0_p1
            if row.get("relative_freq_ghz") is not None
        ]
        if not window_freqs:
            window_freqs = [
                float((pair.get("comparison") or {}).get("baseline_relative_freq_ghz"))
                for pair in assigned_pairs
                if isinstance(pair.get("comparison"), dict)
                and (pair.get("comparison") or {}).get("baseline_relative_freq_ghz") is not None
            ]
        if not window_freqs:
            raise ValueError("No finite baseline relative frequencies for mu=-1/0/+1 evidence window")
        margin = max(5.0, 0.08 * float(fsr_ghz or 200.0))
        x_min = min(window_freqs) - margin
        x_max = max(window_freqs) + margin
        base_x, base_y = load_preanalysis_trace(baseline_q_dir, baseline_summary)
        load_x, load_y = load_preanalysis_trace(loaded_q_dir, loaded_summary)
        plt.rcParams.update(
            {
                "font.size": 9,
                "axes.titlesize": 12,
                "axes.labelsize": 10,
                "xtick.labelsize": 9,
                "ytick.labelsize": 9,
                "legend.fontsize": 9,
                "lines.linewidth": 1.2,
            }
        )
        base_mask = np.isfinite(base_x) & np.isfinite(base_y) & (base_x >= x_min) & (base_x <= x_max)
        load_mask = np.isfinite(load_x) & np.isfinite(load_y) & (load_x >= x_min) & (load_x <= x_max)
        bx, by = thin_xy(base_x[base_mask], base_y[base_mask])
        lx, ly = thin_xy(load_x[load_mask], load_y[load_mask])

        overlay_path = evidence_dir / "mu_minus1_0_plus1_before_after.png"
        fig, ax = plt.subplots(figsize=(13, 6))
        loaded_y_offset = 1.0
        ax.plot(bx, by, color="#2364aa", lw=1.0, alpha=0.9, label="0 V baseline")
        ax.plot(
            lx,
            ly + loaded_y_offset,
            color="#d97706",
            lw=1.0,
            alpha=0.8,
            label=f"coded voltage loaded (+{loaded_y_offset:g} offset)",
        )
        y_levels = np.linspace(0.08, 0.30, max(1, len(assigned_pairs)))
        for idx, pair in enumerate(sorted(assigned_pairs, key=lambda item: natural_key(str(item.get("family") or "")))):
            comparison = pair.get("comparison") if isinstance(pair.get("comparison"), dict) else {}
            bfreq = comparison.get("baseline_relative_freq_ghz")
            lfreq = comparison.get("loaded_relative_freq_ghz")
            delta = comparison.get("delta_freq_ghz")
            if bfreq is None or lfreq is None:
                continue
            y = float(y_levels[idx % len(y_levels)])
            loaded_y = y + loaded_y_offset
            ax.scatter([float(bfreq)], [y], color="#2364aa", s=28, zorder=5)
            ax.scatter([float(lfreq)], [loaded_y], color="#d97706", s=28, zorder=5)
            ax.annotate(
                "",
                xy=(float(lfreq), loaded_y),
                xytext=(float(bfreq), y),
                arrowprops={"arrowstyle": "->", "color": "#444", "lw": 1.0},
            )
            ax.text(
                (float(bfreq) + float(lfreq)) / 2.0,
                (y + loaded_y) / 2.0,
                f"{pair.get('family')} Δf={float(delta):+.2f} GHz",
                ha="center",
                va="center",
                fontsize=8,
                rotation=0,
            )
        ax.set_xlim(x_min, x_max)
        ax.set_ylim(-0.05, loaded_y_offset + 1.08)
        ax.set_xlabel("Relative frequency (GHz)")
        ax.set_ylabel("Normalized transmission (loaded trace +1 offset)")
        ax.set_title("Thermal assignment evidence: stacked baseline vs coded-voltage scan (mu=-1/0/+1 window)")
        ax.grid(True, alpha=0.25)
        ax.legend(loc="best")
        fig.tight_layout()
        fig.savefig(overlay_path)
        plt.close(fig)

        voltage_path = evidence_dir / "voltage_squared_vs_delta_f.png"
        fig, ax = plt.subplots(figsize=(8, 5.5))
        sorted_pairs = sorted(assigned_pairs, key=lambda item: float(item.get("voltage_code_v2") or 0.0))
        xs = [float(pair.get("voltage_code_v2") or 0.0) for pair in sorted_pairs]
        ys = [
            float((pair.get("comparison") or {}).get("delta_freq_ghz"))
            if isinstance(pair.get("comparison"), dict) and (pair.get("comparison") or {}).get("delta_freq_ghz") is not None
            else math.nan
            for pair in sorted_pairs
        ]
        colors = ["#999999" if not math.isfinite(y) else "#1f77b4" if y >= 0 else "#d62728" for y in ys]
        ax.axhline(0.0, color="#666", lw=0.8)
        ax.scatter(xs, ys, c=colors, s=58, zorder=4)
        for x, y, pair in zip(xs, ys, sorted_pairs):
            if not math.isfinite(y):
                continue
            ax.text(
                x,
                y,
                f" {pair.get('family')}→{pair.get('cavity')}",
                fontsize=8,
                va="center",
                ha="left",
            )
        ax.set_xlabel("Applied V^2 (V^2)")
        ax.set_ylabel("mu=0 Δf (GHz)")
        ax.set_title("Thermal tuning response for family-to-cavity assignment")
        ax.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(voltage_path)
        plt.close(fig)
        result.update(
            {
                "overlay_png": str(overlay_path),
                "voltage_squared_png": str(voltage_path),
                "frequency_window_ghz": [x_min, x_max],
            }
        )
    except Exception as exc:
        result["ok"] = False
        result["error"] = repr(exc)
    return result


def run_thermal_auto_assignment(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    baseline_q_dir = directory / "Q"
    q_table = baseline_q_dir / Q_BY_MODE_FILE
    baseline_summary_path = baseline_q_dir / "array_preanalysis_summary.json"
    baseline_modes = read_q_modes_csv(q_table, mode_number=0)
    if len(baseline_modes) < 2:
        raise ValueError(f"零电压基线 q_by_mode.csv 中 mu=0 模式不足：{q_table}")
    baseline_modes_m1_0_p1 = read_q_modes_csv_multi(q_table, mode_numbers={-1, 0, 1})
    plan = build_thermal_auto_assignment_plan(
        config,
        chip,
        die,
        voltage_step_v=finite_float(payload.get("voltage_step_v")),
        good_only=not bool(payload.get("include_non_good_contacts")),
    )
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = thermal_auto_assignment_dir(directory, timestamp)
    baseline_dir = run_dir / "baseline"
    baseline_dir.mkdir(parents=True, exist_ok=True)
    baseline_copy = baseline_dir / Q_BY_MODE_FILE
    shutil.copy2(q_table, baseline_copy)
    baseline_summary_copy = None
    if baseline_summary_path.exists():
        baseline_summary_copy = baseline_dir / "array_preanalysis_summary.json"
        shutil.copy2(baseline_summary_path, baseline_summary_copy)
    steps: list[dict[str, Any]] = []
    apply_result = set_sgm_voltage(
        config,
        {
            "chip": chip,
            "die": die,
            "outputs_v": plan["outputs_v"],
            "max_voltage_v": plan["configured_auto_limit_v"],
            "write_mode": "full_state",
            "state_dir": str(run_dir),
            "note": f"auto family assignment coded voltages {timestamp}",
        },
    )
    steps.append({"name": "写入 SGM 编码电压", "ok": bool(apply_result.get("ok")), "result": apply_result})
    if not apply_result.get("ok"):
        return {"ok": False, "stage": "apply_coded_sgm", "run_dir": str(run_dir), "plan": plan, "steps": steps}
    scan_result = run_assignment_large_scan(
        config,
        payload,
        run_dir=run_dir,
        source_directory=directory,
        chip=chip,
        die=die,
    )
    steps.append({"name": "加压大扫并阵列预分析", "ok": bool(scan_result.get("ok")), "result": scan_result})
    restore_zero: dict[str, Any] | None = None
    if bool(payload.get("restore_zero", True)):
        restore_zero = set_sgm_voltage(config, {"chip": chip, "die": die, "all_zero": True, "state_dir": str(run_dir)})
        steps.append({"name": "SGM 全部恢复 0 V", "ok": bool(restore_zero.get("ok")), "result": restore_zero})
    if not scan_result.get("ok"):
        return {
            "ok": False,
            "stage": "loaded_large_scan",
            "run_dir": str(run_dir),
            "plan": plan,
            "steps": steps,
            "restore_zero": restore_zero,
        }
    loaded_scan_dir, flatten_result = flatten_assignment_loaded_scan_dir(run_dir, die)
    scan_result["loaded_scan_dir"] = str(loaded_scan_dir)
    scan_result["q_dir"] = str(loaded_scan_dir / "Q")
    steps.append({"name": "整理加压大扫目录", "ok": bool(flatten_result is None or flatten_result.get("ok")), "result": flatten_result})
    loaded_q_dir = loaded_scan_dir / "Q"
    loaded_q_table = loaded_q_dir / Q_BY_MODE_FILE
    loaded_modes = read_q_modes_csv_multi(loaded_q_table, mode_numbers={-1, 0, 1})
    loaded_summary_path = loaded_q_dir / "array_preanalysis_summary.json"
    baseline_summary = None
    loaded_summary = None
    fsr_ghz = 0.0
    if baseline_summary_path.exists():
        baseline_summary = json.loads(baseline_summary_path.read_text(encoding="utf-8-sig"))
    if loaded_summary_path.exists():
        loaded_summary = json.loads(loaded_summary_path.read_text(encoding="utf-8-sig"))
    if isinstance(loaded_summary, dict) or isinstance(baseline_summary, dict):
        fsr_ghz = (
            finite_float((loaded_summary or {}).get("selected_fsr_ghz"))
            or finite_float((baseline_summary or {}).get("selected_fsr_ghz"))
            or 0.0
        )
    analysis = compare_thermal_mu0_relative_shifts(baseline_modes, loaded_modes, plan, fsr_ghz=fsr_ghz)
    folded_center_analysis = None
    if baseline_summary_path.exists() and loaded_summary_path.exists():
        folded_center_analysis = compare_thermal_family_centers(
            read_array_family_centers(baseline_summary_path),
            read_array_family_centers(loaded_summary_path),
            plan,
            fsr_ghz=fsr_ghz,
        )
    evidence = generate_thermal_assignment_evidence(
        run_dir,
        baseline_q_dir,
        loaded_q_dir,
        baseline_modes_m1_0_p1,
        analysis,
    )
    family_save = save_family_assignments(config, {"chip": chip, "die": die, "assignments": analysis["assignments"]})
    detail = {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "baseline_q_table": str(q_table),
        "baseline_copy": str(baseline_copy),
        "baseline_summary": str(baseline_summary_path) if baseline_summary_path.exists() else None,
        "baseline_summary_copy": str(baseline_summary_copy) if baseline_summary_copy else None,
        "loaded_scan_dir": str(loaded_scan_dir),
        "loaded_q_table": str(loaded_q_table),
        "loaded_summary": str(loaded_summary_path) if loaded_summary_path.exists() else None,
        "plan": plan,
        "analysis": analysis,
        "folded_center_analysis": folded_center_analysis,
        "evidence": evidence,
        "flatten_loaded_scan_dir": flatten_result,
        "family_assignment_path": family_save.get("family_assignment_path"),
        "steps": steps,
    }
    detail_path = run_dir / "auto_family_assignment.json"
    detail_path.write_text(json.dumps(detail, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {
        "ok": bool(analysis.get("ok")) and bool(evidence.get("ok")),
        "message": "模式家族自动归属完成；请检查 mu=-1/0/+1 对比图、V^2-Δf 图和置信度后再作为最终结论使用。",
        "run_dir": str(run_dir),
        "detail_path": str(detail_path),
        "family_assignment_path": family_save.get("family_assignment_path"),
        "loaded_scan_dir": str(loaded_scan_dir),
        "baseline_copy": str(baseline_copy),
        "evidence": evidence,
        "plan": plan,
        "analysis": analysis,
        "folded_center_analysis": folded_center_analysis,
        "steps": steps,
    }


def thermal_auto_assignment_dir(directory: Path, timestamp: str) -> Path:
    path = thermal_tuning_dir(directory) / f"auto_assignment_{timestamp}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def thermal_current_mode_sweep_dir(directory: Path, q_slot: object = "Q") -> Path:
    path = thermal_q_slot_dir(directory, q_slot) / "current_mode_sweep"
    path.mkdir(parents=True, exist_ok=True)
    return path


def dip_position_sweep_voltage(reading: dict[str, Any]) -> float | None:
    try:
        position = reading.get("position") if isinstance(reading, dict) else None
        dip = position.get("dip") if isinstance(position, dict) else None
        value = float(dip.get("dip_sweep_voltage_v")) if isinstance(dip, dict) else math.nan
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def dip_position_time_s(reading: dict[str, Any]) -> float | None:
    try:
        position = reading.get("position") if isinstance(reading, dict) else None
        dip = position.get("dip") if isinstance(position, dict) else None
        value = float(dip.get("dip_time_s")) if isinstance(dip, dict) else math.nan
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def threshold_crossing_time_s(reading: dict[str, Any]) -> float | None:
    try:
        crossing = reading.get("crossing") if isinstance(reading, dict) else None
        selected = crossing.get("selected") if isinstance(crossing, dict) else None
        value = float(selected.get("time_s")) if isinstance(selected, dict) else math.nan
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def threshold_crossing_threshold_v(reading: dict[str, Any]) -> float | None:
    try:
        crossing = reading.get("crossing") if isinstance(reading, dict) else None
        value = float(crossing.get("threshold_v")) if isinstance(crossing, dict) else math.nan
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def dip_cache_frame_id(reading: dict[str, Any]) -> int | None:
    try:
        value = reading.get("cache_frame_id") if isinstance(reading, dict) else None
        if value is None:
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def read_scope_dip_after_frame(
    config: dict[str, Any],
    *,
    previous_frame_id: int | None,
    timeout_s: float,
    branch: str,
    smooth_points: int,
    source: str,
    center_time_s: float | None = None,
    window_s: float | None = None,
    max_wait_s: float = 0.45,
) -> dict[str, Any]:
    started = time.perf_counter()
    attempts = 0
    last: dict[str, Any] | None = None
    while True:
        attempts += 1
        reading = bridge_scope_dip_position(
            config,
            timeout_s=timeout_s,
            branch=branch,
            smooth_points=smooth_points,
            source=source,
            center_time_s=center_time_s,
            window_s=window_s,
        )
        frame_id = dip_cache_frame_id(reading)
        fresh = (
            previous_frame_id is None
            or frame_id is None
            or frame_id > previous_frame_id
            or source.strip().lower() not in {"cache", "cached"}
        )
        reading["fresh_cache"] = bool(fresh)
        reading["previous_cache_frame_id"] = previous_frame_id
        reading["cache_wait_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
        reading["cache_poll_attempts"] = attempts
        last = reading
        if fresh or not reading.get("ok"):
            return reading
        if (time.perf_counter() - started) >= max_wait_s:
            if source.strip().lower() in {"cache", "cached"}:
                fallback = bridge_scope_dip_position(
                    config,
                    timeout_s=max(timeout_s, 0.15),
                    branch=branch,
                    smooth_points=smooth_points,
                    source="single",
                    center_time_s=center_time_s,
                    window_s=window_s,
                )
                fallback["fresh_cache"] = True
                fallback["previous_cache_frame_id"] = previous_frame_id
                fallback["cache_fallback"] = True
                fallback["cache_fallback_reason"] = (
                    f"scope cache did not advance beyond frame {previous_frame_id} "
                    f"within {max_wait_s:g} s"
                )
                fallback["cache_wait_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
                fallback["cache_poll_attempts"] = attempts
                return fallback
            last["ok"] = False
            last["error"] = (
                f"scope cache did not advance beyond frame {previous_frame_id} "
                f"within {max_wait_s:g} s"
            )
            return last
        time.sleep(0.02)


def watch_threshold_crossing_during_write(
    config: dict[str, Any],
    write_fn: Any,
    *,
    baseline_time_s: float,
    threshold_v: float,
    previous_frame_id: int | None,
    timeout_s: float,
    smooth_points: int,
    source: str,
    tracking_window_s: float,
    watch_duration_s: float,
    poll_s: float,
) -> dict[str, Any]:
    readings: list[dict[str, Any]] = []
    started = time.perf_counter()
    stop_at = started + max(0.05, watch_duration_s)
    poll_interval = max(0.005, poll_s)

    def read_once() -> dict[str, Any]:
        reading = bridge_scope_threshold_crossing(
            config,
            timeout_s=timeout_s,
            smooth_points=smooth_points,
            source="cache" if source.lower() in {"auto", "cache", "cached"} else source,
            center_time_s=baseline_time_s,
            window_s=tracking_window_s,
            reference_time_s=baseline_time_s,
            threshold_v=threshold_v,
            edge="nearest",
        )
        reading["watch_elapsed_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
        frame_id = dip_cache_frame_id(reading)
        reading["fresh_cache"] = bool(
            previous_frame_id is None
            or frame_id is None
            or frame_id > previous_frame_id
            or source.strip().lower() not in {"cache", "cached"}
        )
        return reading

    def worker() -> None:
        while time.perf_counter() < stop_at:
            readings.append(read_once())
            time.sleep(poll_interval)

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    time.sleep(min(0.015, max(0.0, watch_duration_s / 5.0)))
    write_started = time.perf_counter()
    try:
        write_result = write_fn()
    except Exception as exc:
        write_result = {"ok": False, "error": repr(exc)}
    write_elapsed_ms = round((time.perf_counter() - write_started) * 1000.0, 3)
    thread.join(timeout=max(0.05, stop_at - time.perf_counter() + 0.1))

    valid: list[dict[str, Any]] = []
    for reading in readings:
        t_cross = threshold_crossing_time_s(reading)
        if t_cross is None:
            continue
        reading["delta_time_s"] = t_cross - baseline_time_s
        reading["abs_delta_time_s"] = abs(t_cross - baseline_time_s)
        valid.append(reading)

    fallback = None
    if not valid:
        fallback = bridge_scope_threshold_crossing(
            config,
            timeout_s=max(timeout_s, 0.15),
            smooth_points=smooth_points,
            source="single",
            center_time_s=baseline_time_s,
            window_s=tracking_window_s,
            reference_time_s=baseline_time_s,
            threshold_v=threshold_v,
            edge="nearest",
        )
        t_cross = threshold_crossing_time_s(fallback)
        if t_cross is not None:
            fallback["delta_time_s"] = t_cross - baseline_time_s
            fallback["abs_delta_time_s"] = abs(t_cross - baseline_time_s)
            fallback["watch_elapsed_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
            valid.append(fallback)

    best = max(valid, key=lambda item: float(item.get("abs_delta_time_s") or 0.0)) if valid else None
    compact_samples = []
    for reading in readings[-12:]:
        compact_samples.append(
            {
                "ok": bool(reading.get("ok")),
                "frame": reading.get("cache_frame_id"),
                "elapsed_ms": reading.get("watch_elapsed_ms"),
                "crossing_time_s": threshold_crossing_time_s(reading),
                "delta_time_s": reading.get("delta_time_s"),
                "source": reading.get("source_used"),
                "error": reading.get("error") or (reading.get("crossing") or {}).get("error"),
            }
        )
    return {
        "ok": bool(write_result.get("ok") and best is not None),
        "write": write_result,
        "write_elapsed_ms": write_elapsed_ms,
        "watch_duration_s": watch_duration_s,
        "poll_s": poll_interval,
        "num_samples": len(readings),
        "num_valid_samples": len(valid),
        "best_reading": best,
        "fallback_reading": fallback,
        "samples_tail": compact_samples,
    }


def bridge_status(config: dict[str, Any]) -> dict[str, Any]:
    bridge = str(config.get("bridge_base") or "").rstrip("/")
    if not bridge:
        return {"ok": False, "message": "未配置 PyRPL bridge URL"}
    payload = BridgeClient(bridge).health(return_errors=True)
    return {
        "ok": bool(payload.get("ok")),
        "message": payload.get("message") or payload.get("error") or "bridge responded",
        "raw": payload,
    }


def bridge_get_param(config: dict[str, Any], param: str, timeout_s: float = 5.0) -> dict[str, Any]:
    bridge = str(config.get("bridge_base") or "").rstrip("/")
    if not bridge:
        return {"ok": False, "message": "未配置 PyRPL bridge URL"}
    payload = BridgeClient(bridge).get(param, timeout_s=timeout_s, return_errors=True)
    payload.setdefault("param", param)
    if "http_status" in payload:
        payload.setdefault("bridge_status", payload["http_status"])
    payload["bridge_base"] = bridge
    return payload


def bridge_set_param(config: dict[str, Any], param: str, value: Any, timeout_s: float = 5.0) -> dict[str, Any]:
    bridge = str(config.get("bridge_base") or "").rstrip("/")
    if not bridge:
        return {"ok": False, "message": "未配置 PyRPL bridge URL"}
    payload = BridgeClient(bridge).set(param, value, timeout_s=timeout_s, return_errors=True)
    payload.setdefault("param", param)
    payload["value_requested"] = value
    payload["bridge_base"] = bridge
    return payload


def bridge_scope_dip_position(
    config: dict[str, Any],
    *,
    timeout_s: float = 2.5,
    branch: str = "auto",
    smooth_points: int = 7,
    source: str = "cache",
    center_time_s: float | None = None,
    window_s: float | None = None,
) -> dict[str, Any]:
    bridge = str(config.get("bridge_base") or "").rstrip("/")
    if not bridge:
        return {"ok": False, "message": "未配置 PyRPL bridge URL"}
    params = {
        "timeout": f"{timeout_s:g}",
        "branch": branch,
        "smooth_points": str(int(max(1, smooth_points))),
        "source": source,
    }
    if center_time_s is not None:
        params["center_time_s"] = f"{float(center_time_s):.12g}"
    if window_s is not None:
        params["window_s"] = f"{float(window_s):.12g}"
    url = f"{bridge}/scope/dip-position?{urlencode(params)}"
    try:
        http_timeout = 1.2 if source.strip().lower() in {"cache", "cached"} else max(5.0, timeout_s + 5.0)
        with urlopen(url, timeout=http_timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = {"raw_body": raw}
        if not isinstance(payload, dict):
            payload = {"raw_body": raw}
        payload.setdefault("ok", False)
        payload.setdefault("error", f"bridge HTTP {exc.code}: {exc.reason}")
        payload["bridge_status"] = exc.code
        payload["bridge_base"] = bridge
        return payload
    except Exception as exc:
        return {"ok": False, "error": repr(exc), "bridge_base": bridge}
    if not isinstance(payload, dict):
        return {"ok": False, "error": "bridge returned non-object JSON", "bridge_base": bridge}
    payload["bridge_base"] = bridge
    return payload


def bridge_scope_threshold_crossing(
    config: dict[str, Any],
    *,
    timeout_s: float = 0.15,
    smooth_points: int = 5,
    source: str = "cache",
    center_time_s: float | None = None,
    window_s: float | None = None,
    reference_time_s: float | None = None,
    threshold_v: float | None = None,
    edge: str = "nearest",
) -> dict[str, Any]:
    bridge = str(config.get("bridge_base") or "").rstrip("/")
    if not bridge:
        return {"ok": False, "message": "未配置 PyRPL bridge URL"}
    params: dict[str, str] = {
        "timeout": f"{timeout_s:g}",
        "smooth_points": str(int(max(1, smooth_points))),
        "source": source,
        "edge": edge,
    }
    if center_time_s is not None:
        params["center_time_s"] = f"{float(center_time_s):.12g}"
    if window_s is not None:
        params["window_s"] = f"{float(window_s):.12g}"
    if reference_time_s is not None:
        params["reference_time_s"] = f"{float(reference_time_s):.12g}"
    if threshold_v is not None:
        params["threshold_v"] = f"{float(threshold_v):.12g}"
    url = f"{bridge}/scope/threshold-crossing?{urlencode(params)}"
    try:
        http_timeout = 1.2 if source.strip().lower() in {"cache", "cached"} else max(5.0, timeout_s + 5.0)
        with urlopen(url, timeout=http_timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = {"raw_body": raw}
        if not isinstance(payload, dict):
            payload = {"raw_body": raw}
        payload.setdefault("ok", False)
        payload.setdefault("error", f"bridge HTTP {exc.code}: {exc.reason}")
        payload["bridge_status"] = exc.code
        payload["bridge_base"] = bridge
        return payload
    except Exception as exc:
        return {"ok": False, "error": repr(exc), "bridge_base": bridge, "params": params}
    if not isinstance(payload, dict):
        return {"ok": False, "error": "bridge returned non-object JSON", "bridge_base": bridge, "params": params}
    payload["bridge_base"] = bridge
    payload["request_params"] = params
    return payload


def configure_coupling_scope_inputs(config: dict[str, Any]) -> dict[str, Any]:
    steps = []
    ok = True
    for param, value in (("scope.input1", "in1"), ("scope.input2", "out2")):
        result = bridge_set_param(config, param, value)
        steps.append({"param": param, "value": value, "result": result})
        ok = ok and bool(result.get("ok"))
    return {
        "ok": ok,
        "message": "输出光功率读数使用 scope CH1=in1；CH2=out2 只作扫频参考",
        "scope_ch1_input": "in1",
        "scope_ch2_input": "out2",
        "steps": steps,
    }


def bridge_power_readiness(config: dict[str, Any]) -> dict[str, Any]:
    input_setup = configure_coupling_scope_inputs(config)
    active_means = bridge_get_param(config, "scope.active_means_v")
    overlay_ready = bool(active_means.get("ok") and "P inst:" in str(active_means.get("value") or ""))
    return {
        "ok": True,
        "ready": overlay_ready,
        "required_readout": "scope.active_means_v with P inst line",
        "input_setup": input_setup,
        "scope_ch1_input": "in1",
        "scope_ch2_input": "out2",
        "active_means_v": active_means,
        "hint": None
        if overlay_ready
        else "自动耦合需要可解析的 scope.active_means_v 光功率文本；若没有 P inst 行，需要打开/刷新 PyRPL scope GUI。",
    }


def run_compatible_hardware_stop(
    stop_label: str,
    allowed_active_actions: set[str],
    operation: Any,
    *,
    require_active_action: bool = False,
) -> dict[str, Any]:
    if not GLOBAL_HARDWARE_STOP_RUN_LOCK.acquire(blocking=False):
        raise ValueError("另一项硬件停止/恢复操作仍在执行。")
    reserved = False
    try:
        with GLOBAL_HARDWARE_TASK_STATE_LOCK:
            active = bool(GLOBAL_HARDWARE_TASK_STATE.get("active"))
            active_action = str(GLOBAL_HARDWARE_TASK_STATE.get("action") or "")
            if require_active_action and not active:
                raise ValueError(f"当前没有可由“{stop_label}”停止的运行中任务。")
            if active and active_action not in allowed_active_actions:
                raise ValueError(
                    f"不能用“{stop_label}”中断正在运行的无关硬件任务："
                    f"{active_action or '未知任务'}"
                )
            GLOBAL_HARDWARE_TASK_STATE.update(
                {
                    "stop_active": True,
                    "stop_label": stop_label,
                    "stop_started_at": datetime.now().isoformat(timespec="seconds"),
                }
            )
            reserved = True
        return operation()
    finally:
        if reserved:
            with GLOBAL_HARDWARE_TASK_STATE_LOCK:
                GLOBAL_HARDWARE_TASK_STATE.update(
                    {
                        "stop_active": False,
                        "stop_label": "",
                        "stop_started_at": None,
                    }
                )
        GLOBAL_HARDWARE_STOP_RUN_LOCK.release()


def stop_current_mode_lock(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    # One stop action serves both a standalone lock and the batch lock/spectrum flow.
    # This keeps hardware recovery independent from browser-side state.
    with CURRENT_MODE_LOCK_STATE_LOCK:
        stop_generation = int(CURRENT_MODE_LOCK_STATE.get("generation") or 0) + 1
        CURRENT_MODE_LOCK_STATE.update(
            {
                "generation": stop_generation,
                "state": "stopping",
                "active": True,
            }
        )
    NOISE_SPECTRUM_CANCEL_EVENT.set()
    steps: list[dict[str, Any]] = []
    for name, route in (
        ("cancel_lock_process", "/api/lock/cancel"),
        ("stop_spectrum_acquisition", "/api/spectrum/stop"),
        ("safe_off", "/api/safe_off"),
        ("restore_sweep", "/api/lock/restore_sweep"),
    ):
        try:
            result = instrument_post(config, route, payload)
        except Exception as exc:
            result = {"ok": False, "error": repr(exc)}
        steps.append({"name": name, "result": result})
    critical_names = {"cancel_lock_process", "safe_off", "restore_sweep"}
    stop_ok = all(
        bool(step["result"].get("ok"))
        for step in steps
        if step["name"] in critical_names
    )
    result = {
        "ok": stop_ok,
        "message": (
            "当前模式锁定已停止；扫频已恢复，TOPTICA PC 电压已恢复到 75 V。"
            if stop_ok
            else "停止/恢复未全部成功；PID 状态保持未知，请检查步骤并重试。"
        ),
        "steps": steps,
    }
    if result["ok"]:
        with CURRENT_MODE_LOCK_STATE_LOCK:
            if CURRENT_MODE_LOCK_STATE.get("generation") == stop_generation:
                CURRENT_MODE_LOCK_STATE.update(
                    {
                        "state": "idle",
                        "active": False,
                        "optical_mode": None,
                        "last_spectrum": None,
                        "stopped_at": datetime.now().isoformat(timespec="seconds"),
                    }
                )
    else:
        with CURRENT_MODE_LOCK_STATE_LOCK:
            if CURRENT_MODE_LOCK_STATE.get("generation") == stop_generation:
                CURRENT_MODE_LOCK_STATE.update({"state": "unknown", "active": True})
    return result


def start_current_mode_lock(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    optical_mode = dict(payload.get("optical_mode")) if isinstance(payload.get("optical_mode"), dict) else None
    with CURRENT_MODE_LOCK_STATE_LOCK:
        if CURRENT_MODE_LOCK_STATE.get("active"):
            return {
                "ok": False,
                "error": "PID 已在保持、启动或停止过程中；请先使用“停止测量”恢复扫频。",
                "lock_state": dict(CURRENT_MODE_LOCK_STATE),
            }
        generation = int(CURRENT_MODE_LOCK_STATE.get("generation") or 0) + 1
        CURRENT_MODE_LOCK_STATE.update(
            {
                "generation": generation,
                "state": "starting",
                "active": True,
                "chip": str(payload.get("chip") or ""),
                "die": str(payload.get("die") or ""),
                "q_slot": str(payload.get("q_slot") or "Q"),
                "optical_mode": optical_mode,
                "last_spectrum": None,
                "started_at": datetime.now().isoformat(timespec="seconds"),
                "stopped_at": None,
            }
        )
    try:
        result = instrument_post(config, "/api/lock/current", payload)
    except Exception:
        with CURRENT_MODE_LOCK_STATE_LOCK:
            if CURRENT_MODE_LOCK_STATE.get("generation") == generation:
                CURRENT_MODE_LOCK_STATE.update({"state": "unknown", "active": True})
        raise
    with CURRENT_MODE_LOCK_STATE_LOCK:
        if CURRENT_MODE_LOCK_STATE.get("generation") == generation:
            CURRENT_MODE_LOCK_STATE.update(
                {
                    "state": "locked" if result.get("ok") else "idle",
                    "active": bool(result.get("ok")),
                    **(
                        {}
                        if result.get("ok")
                        else {
                            "chip": "",
                            "die": "",
                            "q_slot": "",
                            "optical_mode": None,
                            "last_spectrum": None,
                            "started_at": None,
                        }
                    ),
                }
            )
    return result


def pick_folder(initial_dir: str | None = None, title: str | None = None) -> dict[str, Any]:
    import tkinter as tk
    from tkinter import filedialog

    initial = expand_path(initial_dir)
    if initial is None or not initial.exists():
        initial = Path.home()
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        selected = filedialog.askdirectory(
            title=str(title or "选择本机 results 数据根目录"),
            initialdir=str(initial),
            mustexist=True,
        )
    finally:
        root.destroy()
    return {"ok": True, "cancelled": not bool(selected), "path": selected or None}


def json_bytes(payload: Any, status: int = 200) -> tuple[int, bytes, str]:
    return status, (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8"), "application/json; charset=utf-8"


def html_bytes(text: str) -> tuple[int, bytes, str]:
    return 200, text.encode("utf-8"), "text/html; charset=utf-8"


def read_request_json(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length") or 0)
    if length <= 0:
        return {}
    raw = handler.rfile.read(length).decode("utf-8")
    data = json.loads(raw) if raw else {}
    if not isinstance(data, dict):
        raise ValueError("JSON body must be an object")
    return data


PAGE_HTML = (Path(__file__).parent / "static/page_html.html").read_text(encoding="utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "ArrayCavityDashboard/0.1"

    def send_payload(self, result: tuple[int, bytes, str]) -> None:
        status, body, content_type = result
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
        self.close_connection = True

    def send_json(self, payload: Any, status: int = 200) -> None:
        self.send_payload(json_bytes(payload, status))

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query)
            config = read_config()
            if parsed.path == "/":
                self.send_payload(html_bytes(PAGE_HTML))
            elif parsed.path == "/api/state":
                self.send_json(state_payload(config))
            elif parsed.path == "/api/instrument/status":
                self.send_json({
                    "ok": True,
                    "bridge": bridge_status(config),
                    "rp": {
                        **resolve_rp(config),
                        "device_id": config.get("rp_device_id"),
                    },
                    "laser": {
                        "type": config.get("laser_type"),
                        "serial_number": config.get("laser_serial"),
                        "host": config.get("laser_host"),
                    },
                    "scope": {
                        "type": config.get("scope_type"),
                        "serial_number": config.get("scope_serial"),
                        "resource": config.get("scope_resource"),
                    },
                })
            elif parsed.path == "/api/dies":
                chip = query.get("chip", [""])[0]
                self.send_json({"ok": True, "chip": chip, "dies": list_dies(config, chip)})
            elif parsed.path == "/api/reference/chips":
                root = query.get("root", [""])[0]
                self.send_json({"ok": True, "chips": reference_chips(root)})
            elif parsed.path == "/api/reference/dies":
                root = query.get("root", [""])[0]
                chip = query.get("chip", [""])[0]
                self.send_json({"ok": True, "chip": chip, "dies": reference_dies(root, chip)})
            elif parsed.path == "/api/die":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                directory = die_dir(config, chip, die)
                self.send_json({
                    "ok": True,
                    "chip": chip,
                    "die": die,
                    "directory": str(directory),
                    "readme_path": str(directory / README_FILE),
                    "observation": load_observation(config, chip, die),
                    "card_status": array_die_card_status(config, chip, die),
                })
            elif parsed.path == "/api/electrode":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                directory = die_dir(config, chip, die)
                record = load_electrode_record(config, chip, die)
                self.send_json({
                    "ok": True,
                    "chip": chip,
                    "die": die,
                    "directory": str(directory),
                    "electrode_path": str(electrode_path(directory)),
                    "record": record,
                })
            elif parsed.path == "/api/family":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                q_slot = query.get("q_slot", ["Q"])[0]
                self.send_json({"ok": True, "record": load_family_assignments(config, chip, die, q_slot)})
            elif parsed.path == "/api/polarization":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                self.send_json({"ok": True, "record": load_polarization_manifest(config, chip, die)})
            elif parsed.path == "/api/die-card/status":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                self.send_json(array_die_card_status(config, chip, die))
            elif parsed.path == "/api/thermal/modes":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                q_slot = query.get("q_slot", ["Q"])[0]
                self.send_json(load_thermal_modes(config, chip, die, q_slot))
            elif parsed.path == "/api/thermal/auto_assign/preview":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                self.send_json(build_thermal_auto_assignment_plan(config, chip, die))
            elif parsed.path == "/api/thermal/quick_probe_shift/progress":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                q_slot = query.get("q_slot", ["Q"])[0]
                self.send_json(quick_probe_progress(config, chip, die, q_slot))
            elif parsed.path == "/api/thermal/current_fsr_assignment/progress":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                q_slot = query.get("q_slot", ["Q"])[0]
                self.send_json(load_current_fsr_progress(config, chip, die, q_slot))
            elif parsed.path == "/api/thermal/comb_reconstruction/progress":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                self.send_json(load_comb_reconstruction_progress(config, chip, die))
            elif parsed.path == "/api/thermal/noise_spectrum/progress":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                self.send_json(load_noise_spectrum_progress(config, chip, die))
            elif parsed.path == "/api/thermal/lock_current/status":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                self.send_json(current_mode_lock_status(config, chip, die))
            elif parsed.path in {"/api/instrument/health", "/api/legacy/health"}:
                params = {key: values[0] for key, values in query.items()}
                self.send_json(instrument_get(config, "/api/health", params))
            elif parsed.path in {"/api/optical/cavity", "/api/legacy/cavity"}:
                params = {key: values[0] for key, values in query.items()}
                self.send_json(instrument_get(config, "/api/cavity", params))
            elif parsed.path in {"/api/optical/large_scan/status", "/api/legacy/large_scan/status"}:
                params = {key: values[0] for key, values in query.items()}
                result = instrument_get(config, "/api/large_scan/status", params)
                chip = str(params.get("chip") or "").strip()
                die = str(params.get("die") or "").strip()
                if chip and die:
                    saved_power = load_optical_power_record(config, chip, die)
                    if saved_power is not None:
                        result["power"] = saved_power
                    result["card_status"] = array_die_card_status(config, chip, die)
                self.send_json(result)
            elif parsed.path in {"/api/instrument/bridge/power-readiness", "/api/legacy/bridge/power-readiness"}:
                self.send_json(bridge_power_readiness(config))
            elif parsed.path == "/api/optical/mode-review/points":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                q_slot = query.get("q_slot", ["Q"])[0]
                self.send_json(mode_review_points_payload(config, chip, die, q_slot))
            elif parsed.path == "/api/optical/one-fsr":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                q_slot = query.get("q_slot", ["Q"])[0]
                raw_mode_number = str(query.get("mode_number", [""])[0]).strip()
                mode_number = int(raw_mode_number) if raw_mode_number else None
                self.send_json(one_fsr_modes_payload(config, chip, die, q_slot, mode_number))
            elif parsed.path == "/api/optical/mode-review/local":
                chip = query.get("chip", [""])[0]
                die = query.get("die", [""])[0]
                family = str(query.get("family", [""])[0]).strip()
                mode_number = int(query.get("mode_number", [""])[0])
                q_slot = query.get("q_slot", ["Q"])[0]
                self.send_json(mode_review_local_payload(config, chip, die, family, mode_number, q_slot))
            elif parsed.path == "/api/image":
                self.send_image(config, query)
            else:
                self.send_json({"ok": False, "error": "not found"}, 404)
        except Exception as exc:
            self.send_json(
                {
                    "ok": False,
                    "error": repr(exc),
                    "path": parsed.path,
                    "traceback_tail": traceback.format_exc()[-4000:],
                },
                400,
            )

    def do_POST(self) -> None:
        try:
            post_started = time.perf_counter()
            parsed = urlparse(self.path)
            body_started = time.perf_counter()
            body = read_request_json(self)
            body_ms = round((time.perf_counter() - body_started) * 1000.0, 3)
            config_started = time.perf_counter()
            config = read_config()
            config_ms = round((time.perf_counter() - config_started) * 1000.0, 3)
            if parsed.path == "/api/instrument/discover":
                self.send_json(discover_instrument_bindings(config, body))
            elif parsed.path == "/api/config":
                new_config = save_config(body)
                self.send_json({"ok": True, "state": state_payload(new_config)})
            elif parsed.path == "/api/pick_folder":
                self.send_json(
                    pick_folder(
                        str(body.get("initial_dir") or ""),
                        str(body.get("title") or ""),
                    )
                )
            elif parsed.path == "/api/experiment/create":
                result = create_experiment_workspace(body)
                new_config = save_config({"data_root": result["data_root"]})
                result["state"] = state_payload(new_config)
                self.send_json(result)
            elif parsed.path == "/api/chip/create":
                chip = validate_name(str(body.get("chip") or ""), "chip")
                path = chip_dir(config, chip, create=True)
                self.send_json({"ok": True, "chip": chip, "path": str(path), "state": state_payload(config)})
            elif parsed.path == "/api/die/create":
                chip = validate_name(str(body.get("chip") or ""), "chip")
                die = validate_name(str(body.get("die") or ""), "die")
                path = die_dir(config, chip, die, create=True)
                obs = empty_observation(chip, die)
                observation_path(path).write_text(json.dumps(obs, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                update_die_readme(path, obs)
                self.send_json({"ok": True, "chip": chip, "die": die, "path": str(path), "observation": obs})
            elif parsed.path == "/api/observation/save":
                self.send_json(save_observation(config, body))
            elif parsed.path == "/api/observation/upload-image":
                self.send_json(save_uploaded_observation_image(config, body))
            elif parsed.path == "/api/observation/delete-image":
                self.send_json(delete_observation_image(config, body))
            elif parsed.path == "/api/electrode/save":
                self.send_json(save_electrode_record(config, body))
            elif parsed.path == "/api/family/save":
                self.send_json(save_family_assignments(config, body))
            elif parsed.path == "/api/polarization/manual":
                self.send_json(save_manual_polarization_assignment(config, body))
            elif parsed.path == "/api/polarization/workflow-decisions":
                self.send_json(save_polarization_workflow_decisions(config, body))
            elif parsed.path == "/api/optical/power/save":
                self.send_json(save_optical_power_record(config, body))
            elif parsed.path == "/api/die-card/save":
                self.send_json(save_array_die_card(config, body))
            elif parsed.path == "/api/sgm/set_voltage":
                before_sgm_call_ms = round((time.perf_counter() - post_started) * 1000.0, 3)
                result = run_exclusive_hardware_task(
                    "DAC 电压写入",
                    body,
                    lambda: set_sgm_voltage(config, body),
                    config=config,
                )
                after_sgm_call_ms = round((time.perf_counter() - post_started) * 1000.0, 3)
                result["handler_timing_ms"] = {
                    "read_body": body_ms,
                    "read_config": config_ms,
                    "before_sgm_call": before_sgm_call_ms,
                    "after_sgm_call": after_sgm_call_ms,
                    "before_response": round((time.perf_counter() - post_started) * 1000.0, 3),
                }
                self.send_json(result)
            elif parsed.path == "/api/thermal/auto_assign/run":
                require_primary_q_workflow(body, "自动模式家族归属")
                self.send_json(
                    run_exclusive_hardware_task(
                        "自动模式家族归属",
                        body,
                        lambda: run_thermal_auto_assignment(config, body),
                        config=config,
                    )
                )
            elif parsed.path == "/api/thermal/quick_probe_shift":
                self.send_json(
                    run_exclusive_hardware_task(
                        "当前模式归属识别",
                        body,
                        lambda: run_standalone_thermal_quick_probe_shift(config, body),
                        config=config,
                        on_reserved=lambda: reserve_thermal_quick_probe_shift(body),
                    )
                )
            elif parsed.path == "/api/thermal/quick_probe_shift/stop":
                self.send_json(stop_thermal_quick_probe_shift(config, body))
            elif parsed.path == "/api/thermal/current_mode_sweep":
                chip = validate_name(str(body.get("chip") or ""), "chip")
                die = validate_name(str(body.get("die") or ""), "die")
                q_slot = payload_q_slot(body)
                directory = die_dir(config, chip, die, create=True)
                self.send_json(
                    run_exclusive_hardware_task(
                        "当前模式调谐效率测量",
                        body,
                        lambda: run_current_mode_probe_and_sweep(
                            config,
                            body,
                            output_dir=thermal_current_mode_sweep_dir(directory, q_slot),
                            reset_output=True,
                        ),
                        config=config,
                    )
                )
            elif parsed.path == "/api/thermal/current_fsr_assignment/run":
                self.send_json(
                    run_exclusive_hardware_task(
                        "批量 FSR 模式归属",
                        body,
                        lambda: run_current_fsr_probe_assignment(config, body, cancel_event_prepared=True),
                        config=config,
                        on_reserved=CURRENT_FSR_CANCEL_EVENT.clear,
                    )
                )
            elif parsed.path == "/api/thermal/current_fsr_assignment/stop":
                self.send_json(stop_current_fsr_probe_assignment(config, body))
            elif parsed.path == "/api/thermal/current_fsr_assignment/accept":
                self.send_json(accept_current_fsr_assignments(config, body))
            elif parsed.path == "/api/thermal/comb_reconstruction/preview":
                require_primary_q_workflow(body, "光梳重构预览")
                self.send_json(plan_comb_reconstruction(config, body))
            elif parsed.path == "/api/thermal/comb_reconstruction/write_verify":
                require_primary_q_workflow(body, "光梳重构写入校验")
                self.send_json(
                    run_exclusive_hardware_task(
                        "光梳对齐写入校验",
                        body,
                        lambda: run_comb_reconstruction_write_verify(
                            config,
                            body,
                            cancel_event_prepared=True,
                        ),
                        config=config,
                        on_reserved=COMB_RECONSTRUCTION_CANCEL_EVENT.clear,
                    )
                )
            elif parsed.path == "/api/thermal/comb_reconstruction/stop":
                self.send_json(stop_comb_reconstruction_write_verify(config, body))
            elif parsed.path == "/api/thermal/noise_spectrum/settings":
                require_primary_q_workflow(body, "锁模噪声频谱设置")
                self.send_json(instrument_post(config, "/api/spectrum/settings", body))
            elif parsed.path == "/api/thermal/noise_spectrum/capture_locked":
                require_primary_q_workflow(body, "当前锁模功率谱提取")
                self.send_json(
                    run_exclusive_hardware_task(
                        "当前锁模功率谱提取",
                        body,
                        lambda: capture_current_locked_noise_spectrum(config, body),
                        config=config,
                        allow_active_pid=True,
                    )
                )
            elif parsed.path == "/api/thermal/lock_current":
                require_primary_q_workflow(body, "当前模式锁定")
                self.send_json(
                    run_exclusive_hardware_task(
                        "当前模式锁定",
                        body,
                        lambda: start_current_mode_lock(config, body),
                        config=config,
                        allow_active_pid=True,
                    )
                )
            elif parsed.path == "/api/thermal/lock_current/stop":
                self.send_json(
                    run_compatible_hardware_stop(
                        "停止测量",
                        {"当前模式锁定", "当前锁模功率谱提取", "锁模噪声功率谱测量"},
                        lambda: stop_current_mode_lock(config, body),
                    )
                )
            elif parsed.path == "/api/thermal/noise_spectrum/run":
                require_primary_q_workflow(body, "锁模噪声功率谱测量")
                self.send_json(
                    run_exclusive_hardware_task(
                        "锁模噪声功率谱测量",
                        body,
                        lambda: run_locked_noise_spectrum_measurement(config, body),
                        config=config,
                    )
                )
            elif parsed.path == "/api/thermal/noise_spectrum/stop":
                self.send_json(
                    run_compatible_hardware_stop(
                        "停止噪声功率谱测量",
                        {"锁模噪声功率谱测量"},
                        lambda: stop_locked_noise_spectrum_measurement(config, body),
                    )
                )
            elif parsed.path == "/api/thermal/mode_move":
                self.send_json(
                    run_exclusive_hardware_task(
                        "模式波长跳转",
                        body,
                        lambda: move_thermal_mode_to_wavelength(config, body),
                        config=config,
                    )
                )
            elif parsed.path in {"/api/optical/coupling/standard", "/api/legacy/coupling/standard"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "自动耦合",
                        body,
                        lambda: instrument_post(config, "/api/coupling/standard", body),
                        config=config,
                    )
                )
            elif parsed.path in {"/api/optical/coupling/initialize_midpoint", "/api/legacy/coupling/initialize_midpoint"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "六轴初始状态设置",
                        body,
                        lambda: instrument_post(config, "/api/coupling/initialize_midpoint", body),
                        config=config,
                    )
                )
            elif parsed.path in {"/api/optical/coupling/stop", "/api/legacy/coupling/stop"}:
                self.send_json(instrument_post(config, "/api/coupling/stop", body))
            elif parsed.path in {"/api/instrument/bridge/action", "/api/legacy/bridge/action"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "PyRPL bridge 操作",
                        body,
                        lambda: instrument_post(config, "/api/bridge/action", body),
                        config=config,
                        allow_active_pid=True,
                    )
                )
            elif parsed.path in {"/api/instrument/safe_off", "/api/legacy/safe_off"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "RP/PID/ASG safe-off",
                        body,
                        lambda: instrument_post(config, "/api/safe_off", body),
                        config=config,
                        allow_active_pid=True,
                    )
                )
            elif parsed.path in {"/api/optical/target/move", "/api/legacy/target/move"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "激光器波长跳转",
                        body,
                        lambda: instrument_post(config, "/api/target/move", body),
                        config=config,
                    )
                )
            elif parsed.path in {"/api/optical/lock/restore_sweep", "/api/legacy/lock/restore_sweep"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "恢复细扫",
                        body,
                        lambda: instrument_post(config, "/api/lock/restore_sweep", body),
                        config=config,
                        allow_active_pid=True,
                    )
                )
            elif parsed.path in {"/api/optical/large_scan/run", "/api/legacy/large_scan/run"}:
                self.send_json(
                    run_exclusive_hardware_task(
                        "大扫采集 / 分析",
                        body,
                        lambda: instrument_post(config, "/api/large_scan/run", body),
                        config=config,
                    )
                )
            elif parsed.path in {"/api/optical/large_scan/stop", "/api/legacy/large_scan/stop"}:
                self.send_json(
                    run_compatible_hardware_stop(
                        "停止大扫并恢复细扫",
                        {"大扫采集 / 分析"},
                        lambda: instrument_post(config, "/api/large_scan/stop", body),
                        require_active_action=True,
                    )
                )
            else:
                self.send_json({"ok": False, "error": "not found"}, 404)
        except Exception as exc:
            self.send_json(
                {
                    "ok": False,
                    "error": repr(exc),
                    "path": parsed.path if "parsed" in locals() else self.path,
                    "traceback_tail": traceback.format_exc()[-4000:],
                },
                400,
            )

    def send_image(self, config: dict[str, Any], query: dict[str, list[str]]) -> None:
        chip = query.get("chip", [""])[0]
        die = query.get("die", [""])[0]
        rel = str(query.get("rel", [""])[0]).replace("\\", "/")
        if rel.startswith("/") or ".." in Path(rel).parts:
            raise ValueError("invalid image path")
        directory = die_dir(config, chip, die)
        path = (directory / rel).resolve()
        path.relative_to(directory.resolve())
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(path)
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:
        timestamp = time.strftime("%H:%M:%S")
        sys.stderr.write(f"[{timestamp}] {fmt % args}\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--no-open", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    ensure_config_file()
    config = read_config()
    host = args.host or str(config.get("listen_host") or "127.0.0.1")
    port = int(args.port or config.get("listen_port") or 7890)
    url = f"http://{host}:{port}/"
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"Array cavity dashboard listening on {url}", flush=True)
    print(f"Config: {CONFIG_FILE}", flush=True)
    root = data_root(config)
    print(f"Data root: {root if root else '<not configured>'}", flush=True)
    if not args.no_open:
        webbrowser.open(url)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
