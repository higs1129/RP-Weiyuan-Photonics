from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.thermal_tuning'


import json
import math
import sys
from pathlib import Path

def run(request):

    import numpy as np
    from scipy.optimize import least_squares, minimize_scalar
    from scipy.signal import find_peaks, peak_widths, savgol_filter
    from a221_workbench.tasks.analysis.thermal_resonance import finite_float, expected_linewidth_ghz, odd_window_samples, fit_lorentzian_candidate
    from a221_workbench.tasks.analysis.large_scan.process_large_scan import find_mzi_index


    frame_path = Path(request["frame_path"])
    data = np.load(frame_path)
    time_s = np.asarray(data["trans_time_s"], dtype=float)
    trans_v = np.asarray(data["trans_v"], dtype=float)
    mzi_time_s = np.asarray(data["mzi_time_s"], dtype=float)
    mzi_v = np.asarray(data["mzi_v"], dtype=float)
    if "trigger_time_s" not in data or "trigger_v" not in data:
        raise RuntimeError(
            f"frame has no trigger waveform: {frame_path}; "
            "CH4 must be captured so the physical trigger edge can define frequency zero"
        )
    trigger_time_s = np.asarray(data["trigger_time_s"], dtype=float)
    trigger_v = np.asarray(data["trigger_v"], dtype=float)
    d1 = float(request["mzi_d1_mhz"])
    frequency_axis_sign = float(request.get("frequency_axis_sign", -1.0))
    tolerance_ghz = abs(float(request["tolerance_ghz"]))
    search_half_ghz = abs(float(request["search_half_ghz"]))
    trigger_level_v = float(request.get("trigger_level_v", 0.0))
    trigger_slope = str(request.get("trigger_slope", "negative")).strip().lower()

    if len(time_s) != len(trans_v) or len(mzi_time_s) != len(mzi_v):
        raise RuntimeError(f"invalid frame lengths in {frame_path}")
    if len(trigger_time_s) != len(trigger_v) or len(trigger_time_s) < 2:
        raise RuntimeError(f"invalid trigger waveform length in {frame_path}")

    trigger_finite = np.isfinite(trigger_time_s) & np.isfinite(trigger_v)
    trigger_indices = np.flatnonzero(trigger_finite)
    if len(trigger_indices) < 2:
        raise RuntimeError(f"too few finite trigger samples in {frame_path}")
    pair_start = trigger_indices[:-1]
    pair_stop = trigger_indices[1:]
    adjacent = pair_stop == pair_start + 1
    pair_start = pair_start[adjacent]
    pair_stop = pair_stop[adjacent]
    if trigger_slope in {"negative", "fall", "falling", "down"}:
        crossing_mask = (trigger_v[pair_start] > trigger_level_v) & (trigger_v[pair_stop] <= trigger_level_v)
        normalized_trigger_slope = "negative"
    elif trigger_slope in {"positive", "rise", "rising", "up"}:
        crossing_mask = (trigger_v[pair_start] < trigger_level_v) & (trigger_v[pair_stop] >= trigger_level_v)
        normalized_trigger_slope = "positive"
    else:
        raise RuntimeError(f"unsupported trigger slope {trigger_slope!r}")
    crossing_start = pair_start[crossing_mask]
    crossing_stop = pair_stop[crossing_mask]
    if len(crossing_start) == 0:
        raise RuntimeError(
            f"no {normalized_trigger_slope} CH trigger crossing at {trigger_level_v:g} V in {frame_path}"
        )

    edge_times = []
    for start, stop in zip(crossing_start, crossing_stop):
        t0 = float(trigger_time_s[start])
        t1 = float(trigger_time_s[stop])
        v0 = float(trigger_v[start])
        v1 = float(trigger_v[stop])
        fraction = (trigger_level_v - v0) / (v1 - v0) if v1 != v0 else 0.5
        fraction = min(1.0, max(0.0, fraction))
        edge_times.append(t0 + fraction * (t1 - t0))
    trigger_edge_time_s = float(min(edge_times, key=abs))

    mzi_index = find_mzi_index(mzi_v, 0.0)
    if len(mzi_index) < 4:
        raise RuntimeError(f"too few MZI extrema ({len(mzi_index)}) in {frame_path}")

    extrema_mu = np.arange(len(mzi_index), dtype=float) / 2.0
    mu_mzi = np.interp(
        np.arange(len(mzi_v), dtype=float),
        mzi_index.astype(float),
        extrema_mu,
        left=np.nan,
        right=np.nan,
    )
    mu_on_trans = np.interp(time_s, mzi_time_s, mu_mzi, left=np.nan, right=np.nan)
    mu_ref = float(np.interp(trigger_edge_time_s, mzi_time_s, mu_mzi, left=np.nan, right=np.nan))
    if not math.isfinite(mu_ref):
        raise RuntimeError(
            f"trigger edge {trigger_edge_time_s:.9g} s lies outside the finite MZI calibration axis in {frame_path}"
        )
    freq_ghz = frequency_axis_sign * (mu_on_trans - mu_ref) * d1 / 1000.0
    finite = np.isfinite(freq_ghz) & np.isfinite(trans_v)
    window = finite & (np.abs(freq_ghz) <= search_half_ghz)
    if np.count_nonzero(window) < 5:
        raise RuntimeError(f"no enough finite samples inside +/-{search_half_ghz:g} GHz window")

    window_indices = np.flatnonzero(window)
    window_freq_ghz = np.asarray(freq_ghz[window_indices], dtype=float)
    window_trans_v = np.asarray(trans_v[window_indices], dtype=float)
    window_time_s = np.asarray(time_s[window_indices], dtype=float)
    order = np.argsort(window_freq_ghz)
    window_freq_ghz = window_freq_ghz[order]
    window_trans_v = window_trans_v[order]
    window_time_s = window_time_s[order]
    frequency_step_ghz = abs(float(np.nanmedian(np.diff(window_freq_ghz))))
    if not math.isfinite(frequency_step_ghz) or frequency_step_ghz <= 0:
        raise RuntimeError(f"invalid MZI-calibrated frequency step in {frame_path}")

    row = request.get("row", {}) if isinstance(request.get("row"), dict) else {}
    expected_fwhm_ghz = expected_linewidth_ghz(row)
    if expected_fwhm_ghz is not None and not (frequency_step_ghz * 4.0 <= expected_fwhm_ghz <= 2.0 * search_half_ghz):
        expected_fwhm_ghz = None
    expected_depth = finite_float(row.get("depth"))
    if expected_depth is not None:
        expected_depth = min(0.9999, max(0.0, expected_depth))

    smooth_span_ghz = min(0.060, max(0.015, 0.12 * (expected_fwhm_ghz or 0.20)))
    smooth_window = odd_window_samples(smooth_span_ghz, frequency_step_ghz, len(window_trans_v))
    window_smooth_v = savgol_filter(window_trans_v, smooth_window, min(3, smooth_window - 2))
    first_difference_v = np.diff(window_trans_v)
    first_difference_median = float(np.nanmedian(first_difference_v))
    noise_v = float(np.nanmedian(np.abs(first_difference_v - first_difference_median)) / 0.67448975 / math.sqrt(2.0))
    if not math.isfinite(noise_v) or noise_v <= 0:
        noise_v = max(float(np.nanstd(first_difference_v)) / math.sqrt(2.0), 1e-12)
    signal_span_v = max(
        float(np.nanpercentile(window_smooth_v, 95) - np.nanpercentile(window_smooth_v, 5)),
        noise_v * 10.0,
    )
    candidate_min_prominence_v = max(6.0 * noise_v, 0.015 * signal_span_v)
    candidate_distance_ghz = max(0.025, min(0.120, 0.25 * (expected_fwhm_ghz or 0.20)))
    candidate_distance_samples = max(3, int(round(candidate_distance_ghz / frequency_step_ghz)))
    candidate_indices, candidate_properties = find_peaks(
        -window_smooth_v,
        prominence=candidate_min_prominence_v,
        distance=candidate_distance_samples,
    )

    fit_candidates = []
    if len(candidate_indices):
        candidate_width_samples = peak_widths(-window_smooth_v, candidate_indices, rel_height=0.5)[0]
        for candidate_index, prominence_v, width_samples in zip(
            candidate_indices,
            candidate_properties["prominences"],
            candidate_width_samples,
        ):
            fit_candidates.append(
                fit_lorentzian_candidate(
                    window_freq_ghz,
                    window_trans_v,
                    window_smooth_v,
                    int(candidate_index),
                    float(prominence_v),
                    max(float(width_samples) * frequency_step_ghz, 4.0 * frequency_step_ghz),
                    expected_fwhm_ghz,
                    expected_depth,
                    noise_v,
                    tolerance_ghz,
                    search_half_ghz,
                )
            )

    valid_fits = [candidate for candidate in fit_candidates if candidate.get("valid")]
    max_prominence_v = max(
        [finite_float(candidate.get("candidate_prominence_v")) or 0.0 for candidate in valid_fits],
        default=0.0,
    )
    for candidate in valid_fits:
        width_error = finite_float(candidate.get("width_prior_log_error")) or 0.0
        depth_error = finite_float(candidate.get("depth_prior_abs_error")) or 0.0
        center = abs(finite_float(candidate.get("fit_center_ghz")) or 0.0)
        prominence = finite_float(candidate.get("candidate_prominence_v")) or 0.0
        prominence_fraction = prominence / max(max_prominence_v, 1e-12)
        candidate["selection_score"] = (
            0.55 * width_error
            + 0.35 * depth_error
            + 0.20 * center / max(search_half_ghz, 1e-12)
            - 0.25 * prominence_fraction
        )

    if not valid_fits:
        print(json.dumps({
            "ok": False,
            "frame_path": str(frame_path),
            "family": row.get("family"),
            "cavity": row.get("cavity"),
            "error": "No physically significant resonance produced a reliable Lorentzian fit",
            "method": "prominent_resonance_lorentzian_fit",
            "candidate_count": int(len(candidate_indices)),
            "candidate_min_prominence_v": candidate_min_prominence_v,
            "estimated_noise_v": noise_v,
            "expected_linewidth_ghz": expected_fwhm_ghz,
            "expected_depth": expected_depth,
            "fit_candidates": fit_candidates,
        }, ensure_ascii=False))
        raise SystemExit(0)

    selected_fit = min(valid_fits, key=lambda candidate: float(candidate["selection_score"]))
    center_freq_ghz = float(selected_fit["fit_center_ghz"])
    center_time_s = float(np.interp(center_freq_ghz, window_freq_ghz, window_time_s))
    center_detector_v = float(np.interp(center_freq_ghz, window_freq_ghz, window_trans_v))
    passed = abs(center_freq_ghz) <= tolerance_ghz
    method = "target_prior_prominent_resonance_lorentzian_fit"

    print(json.dumps({
        "ok": True,
        "frame_path": str(frame_path),
        "family": request.get("row", {}).get("family"),
        "cavity": request.get("row", {}).get("cavity"),
        "comb_index": request.get("row", {}).get("comb_index"),
        "mzi_d1_mhz": d1,
        "frequency_axis_sign": frequency_axis_sign,
        "mzi_extrema_count": int(len(mzi_index)),
        "trigger_reference": "measured_channel_edge",
        "trigger_channel": request.get("trigger_channel"),
        "trigger_level_v": trigger_level_v,
        "trigger_slope": normalized_trigger_slope,
        "trigger_edge_time_s": trigger_edge_time_s,
        "trigger_crossing_count": int(len(edge_times)),
        "search_half_ghz": search_half_ghz,
        "tolerance_ghz": tolerance_ghz,
        "tolerance_mzi_periods": tolerance_ghz / (d1 / 1000.0) if d1 > 0 else None,
        "dip_offset_ghz": center_freq_ghz,
        "abs_dip_offset_ghz": abs(center_freq_ghz),
        "dip_time_s": center_time_s,
        "dip_time_from_trigger_s": center_time_s - trigger_edge_time_s,
        "dip_detector_v": center_detector_v,
        "dip_depth_v": selected_fit.get("fit_depth_v"),
        "passed": passed,
        "method": method,
        "candidate_count": int(len(candidate_indices)),
        "valid_fit_candidate_count": int(len(valid_fits)),
        "candidate_min_prominence_v": candidate_min_prominence_v,
        "estimated_noise_v": noise_v,
        "smooth_window_samples": int(smooth_window),
        "frequency_step_ghz": frequency_step_ghz,
        "expected_linewidth_ghz": expected_fwhm_ghz,
        "expected_depth": expected_depth,
        "selected_fit": selected_fit,
        "fit_candidates": fit_candidates,
        "frequency_window_ghz": [
            float(np.nanmin(freq_ghz[finite])),
            float(np.nanmax(freq_ghz[finite])),
        ],
        "points_in_search_window": int(np.count_nonzero(window)),
    }, ensure_ascii=False))


def main():
    run(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))

if __name__ == "__main__":
    main()
