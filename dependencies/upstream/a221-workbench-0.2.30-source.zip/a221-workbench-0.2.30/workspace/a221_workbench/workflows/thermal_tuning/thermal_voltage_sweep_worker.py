from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.thermal_tuning'


import csv
import json
import math
import sys
from pathlib import Path

def run(request):

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from a221_workbench.tasks.analysis.large_scan.process_large_scan import find_mzi_index
    from a221_workbench.tasks.analysis.thermal_tracking import continuous_prefix_rejection_reasons, tracking_rejection_reasons

    plt.rcParams.update({
        "font.size": 14,
        "axes.titlesize": 18,
        "axes.labelsize": 16,
        "xtick.labelsize": 13,
        "ytick.labelsize": 13,
        "legend.fontsize": 11,
        "lines.linewidth": 2.0,
        "figure.dpi": 150,
        "savefig.dpi": 220,
        "savefig.bbox": "tight",
    })

    output_dir = Path(request["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    frames = sorted(request["frames"], key=lambda item: float(item["voltage_v"]))
    d1 = float(request["mzi_d1_mhz"])
    frequency_axis_sign = float(request.get("frequency_axis_sign", -1.0))
    initial_gate_center_s = float(request.get("initial_gate_center_s") or 0.0)
    initial_gate_half_width_s = abs(float(request.get("initial_gate_half_width_s") or 0.0020))
    tracking_gate_left_s = abs(float(request.get("tracking_gate_left_s") or 0.0001))
    tracking_gate_right_s = abs(float(request.get("tracking_gate_right_s") or 0.0024))
    assignment = request.get("assignment") if isinstance(request.get("assignment"), dict) else {}
    minimum_tracked_prefix_points = 4

    def finite_float_value(value):
        try:
            parsed = float(value)
        except (TypeError, ValueError):
            return None
        return parsed if math.isfinite(parsed) else None

    def load_frame(frame):
        data = np.load(frame["frame_path"])
        time_s = np.asarray(data["trans_time_s"], dtype=float)
        trans = np.asarray(data["trans_v"], dtype=float)
        mzi_time = np.asarray(data["mzi_time_s"], dtype=float)
        mzi = np.asarray(data["mzi_v"], dtype=float)
        if len(time_s) != len(trans) or len(mzi_time) != len(mzi):
            raise RuntimeError(f"invalid frame lengths in {frame['frame_path']}")
        mzi_index = find_mzi_index(mzi, 0.0)
        if len(mzi_index) < 4:
            raise RuntimeError(f"too few MZI extrema ({len(mzi_index)}) in {frame['frame_path']}")
        extrema_mu = np.arange(len(mzi_index), dtype=float) / 2.0
        mu_mzi = np.interp(
            np.arange(len(mzi), dtype=float),
            mzi_index.astype(float),
            extrema_mu,
            left=np.nan,
            right=np.nan,
        )
        return {
            "time_s": time_s,
            "trans_signal_v": np.asarray(trans, dtype=float),
            "mzi_time_s": mzi_time,
            "mu_mzi": mu_mzi,
            "mzi_extrema_count": int(len(mzi_index)),
        }

    loaded = []
    for frame in frames:
        item = dict(frame)
        item["data"] = load_frame(frame)
        loaded.append(item)
    baseline_item = min(loaded, key=lambda item: abs(float(item["voltage_v"])))
    baseline = baseline_item["data"]

    def local_minima_indices(y, mask):
        idx = np.flatnonzero(mask)
        if len(idx) == 0:
            return np.asarray([], dtype=int)
        middle = idx[(idx > 0) & (idx < len(y) - 1)]
        if len(middle) == 0:
            return np.asarray([], dtype=int)
        finite = np.isfinite(y[middle - 1]) & np.isfinite(y[middle]) & np.isfinite(y[middle + 1])
        minima = middle[finite & (y[middle] <= y[middle - 1]) & (y[middle] <= y[middle + 1])]
        return minima.astype(int)

    def local_dip_depth_v(time_s, y, index, half_width_s=0.00035):
        try:
            center_t = float(time_s[index])
        except Exception:
            return math.nan
        local = (
            np.isfinite(time_s)
            & np.isfinite(y)
            & (time_s >= center_t - half_width_s)
            & (time_s <= center_t + half_width_s)
        )
        if np.count_nonzero(local) < 5:
            return math.nan
        local_y = y[local]
        baseline = float(np.nanpercentile(local_y, 90))
        return baseline - float(y[index])

    def choose_tracked_dip(
        data,
        center_s,
        left_s,
        right_s,
        *,
        label,
        prefer_right=False,
        freq_ghz=None,
        expected_freq_ghz=None,
    ):
        time_s = np.asarray(data["time_s"], dtype=float)
        trans_norm = np.asarray(data["trans_signal_v"], dtype=float)
        freq_arr = np.asarray(freq_ghz, dtype=float) if freq_ghz is not None else None
        expected_freq = finite_float_value(expected_freq_ghz)
        center_s = float(center_s)
        left_s = max(0.0, float(left_s))
        right_s = max(0.0, float(right_s))
        lo = center_s - left_s
        hi = center_s + right_s
        finite = np.isfinite(time_s) & np.isfinite(trans_norm)
        window = finite & (time_s >= lo) & (time_s <= hi)
        if not np.any(window):
            return {
                "ok": False,
                "label": label,
                "center_s": center_s,
                "min_s": lo,
                "max_s": hi,
                "error": "no finite samples in tracking gate",
            }
        minima = local_minima_indices(trans_norm, window)
        if len(minima):
            window_y = trans_norm[window]
            window_depth = float(np.nanpercentile(window_y, 90) - np.nanmin(window_y)) if len(window_y) else math.nan
            min_depth_v = max(0.00035, 0.18 * window_depth) if math.isfinite(window_depth) else 0.00035
            depth_by_index = {
                int(index): local_dip_depth_v(time_s, trans_norm, int(index))
                for index in minima
            }
            significant = np.asarray(
                [
                    int(index)
                    for index in minima
                    if math.isfinite(depth_by_index.get(int(index), math.nan))
                    and float(depth_by_index[int(index)]) >= min_depth_v
                ],
                dtype=int,
            )
            candidate_indices = significant if len(significant) else minima
            def score(index):
                t = float(time_s[index])
                distance = abs(t - center_s)
                if prefer_right and t < center_s:
                    distance += (center_s - t) * 4.0
                if expected_freq is not None and freq_arr is not None and np.isfinite(freq_arr[index]):
                    freq_distance = abs(float(freq_arr[index]) - expected_freq)
                    return (freq_distance, distance, -float(depth_by_index.get(int(index), 0.0)))
                return (distance, -float(depth_by_index.get(int(index), 0.0)))

            picked = int(min(candidate_indices, key=score))
            method = (
                ("significant_" if len(significant) else "all_")
                + ("local_min_expected_v2_track" if expected_freq is not None else "local_min_nearest_previous_time")
            )
        else:
            idx = np.flatnonzero(window)
            picked = int(idx[np.nanargmin(trans_norm[window])])
            method = "window_argmin_fallback"
            depth_by_index = {}
            min_depth_v = math.nan
            significant = np.asarray([], dtype=int)
        return {
            "ok": True,
            "label": label,
            "index": picked,
            "center_s": center_s,
            "min_s": lo,
            "max_s": hi,
            "method": method,
            "candidate_count": int(len(minima)),
            "significant_candidate_count": int(len(significant)),
            "candidate_min_depth_v": float(min_depth_v) if math.isfinite(min_depth_v) else None,
            "picked_dip_depth_v": float(depth_by_index.get(picked, math.nan)) if math.isfinite(depth_by_index.get(picked, math.nan)) else None,
            "time_s": float(time_s[picked]),
            "transmission": float(trans_norm[picked]),
            "expected_freq_ghz": expected_freq,
            "picked_freq_ghz": float(freq_arr[picked]) if freq_arr is not None and np.isfinite(freq_arr[picked]) else None,
        }

    quick_baseline_time_s = finite_float_value(
        assignment.get("quick_baseline_time_s")
        or assignment.get("baseline_dip_time_s")
    )
    baseline_anchor_time_s = quick_baseline_time_s if quick_baseline_time_s is not None else initial_gate_center_s
    baseline_pick = choose_tracked_dip(
        baseline,
        baseline_anchor_time_s,
        initial_gate_half_width_s,
        initial_gate_half_width_s,
        label="baseline",
    )
    if not baseline_pick.get("ok") and quick_baseline_time_s is not None:
        baseline_pick = choose_tracked_dip(
            baseline,
            initial_gate_center_s,
            initial_gate_half_width_s,
            initial_gate_half_width_s,
            label="baseline_initial_gate_fallback",
        )
    if not baseline_pick.get("ok"):
        raise RuntimeError(
            "baseline frame has no target dip inside the local gate; "
            f"gate={baseline_pick.get('min_s')}..{baseline_pick.get('max_s')} s"
        )
    baseline_idx = int(baseline_pick["index"])
    reference_time_s = float(baseline["time_s"][baseline_idx])

    def calibrated_freq_ghz(data):
        mu_on_trans = np.interp(
            data["time_s"],
            data["mzi_time_s"],
            data["mu_mzi"],
            left=np.nan,
            right=np.nan,
        )
        mu_ref = float(np.interp(reference_time_s, data["mzi_time_s"], data["mu_mzi"]))
        return frequency_axis_sign * (mu_on_trans - mu_ref) * d1 / 1000.0

    def sorted_finite_xy(x, y):
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        mask = np.isfinite(x) & np.isfinite(y)
        if np.count_nonzero(mask) < 2:
            return np.asarray([], dtype=float), np.asarray([], dtype=float)
        order = np.argsort(x[mask])
        return x[mask][order], y[mask][order]

    def interp_signal(freq_ghz, signal_v, query_ghz):
        x, y = sorted_finite_xy(freq_ghz, signal_v)
        if len(x) < 2:
            return np.full_like(np.asarray(query_ghz, dtype=float), np.nan, dtype=float)
        return np.interp(query_ghz, x, y, left=np.nan, right=np.nan)

    def template_feature(ywin):
        ywin = np.asarray(ywin, dtype=float)
        finite = np.isfinite(ywin)
        if np.count_nonzero(finite) < max(8, len(ywin) // 2):
            return None, math.nan
        nedge = max(5, len(ywin) // 8)
        finite_indices = np.flatnonzero(finite)
        left = float(np.median(ywin[finite_indices[:nedge]]))
        right = float(np.median(ywin[finite_indices[-nedge:]]))
        x = np.arange(len(ywin), dtype=float)
        denom = len(ywin) - 1 if len(ywin) > 1 else 1
        baseline = left + (right - left) * (x / denom)
        dip = baseline - ywin
        depth_v = float(np.nanmax(dip) - np.nanpercentile(dip, 10))
        feat = dip - np.nanmean(dip)
        feat = np.where(np.isfinite(feat), feat, 0.0)
        norm = float(np.sqrt(np.sum(feat * feat)))
        if not math.isfinite(norm) or norm <= 1e-15:
            return None, depth_v
        return feat / norm, depth_v

    def local_mode_minimum(freq_ghz, signal_v, center_ghz, *, search_half_ghz=0.22, fit_half_ghz=0.035):
        freq_ghz = np.asarray(freq_ghz, dtype=float)
        signal_v = np.asarray(signal_v, dtype=float)
        mask = (
            np.isfinite(freq_ghz)
            & np.isfinite(signal_v)
            & (freq_ghz >= center_ghz - search_half_ghz)
            & (freq_ghz <= center_ghz + search_half_ghz)
        )
        if np.count_nonzero(mask) < 3:
            return {
                "ok": False,
                "center_freq_ghz": center_ghz,
                "min_detector_v": math.nan,
                "method": "template_center_no_local_minimum",
            }
        f, y = sorted_finite_xy(freq_ghz[mask], signal_v[mask])
        sample_index = int(np.argmin(y))
        sample_center = float(f[sample_index])
        sample_value = float(y[sample_index])
        local = np.isfinite(f) & np.isfinite(y) & (np.abs(f - sample_center) <= fit_half_ghz)
        method = "sample_min_near_template"
        center = sample_center
        min_value = sample_value
        if np.count_nonzero(local) >= 5:
            x0 = sample_center
            xx = f[local] - x0
            yy = y[local]
            try:
                a, b, c = np.polyfit(xx, yy, 2)
                if math.isfinite(a) and a > 0:
                    refined = x0 - float(b) / (2.0 * float(a))
                    if refined >= float(np.min(f[local])) and refined <= float(np.max(f[local])):
                        center = refined
                        min_value = float(a * (refined - x0) ** 2 + b * (refined - x0) + c)
                        method = "quadratic_min_near_template"
            except Exception:
                pass
        local_width = np.isfinite(f) & np.isfinite(y) & (np.abs(f - center) <= max(search_half_ghz, fit_half_ghz))
        if np.count_nonzero(local_width) >= 5:
            dip_depth_v = float(np.nanpercentile(y[local_width], 90) - min_value)
        else:
            dip_depth_v = math.nan
        return {
            "ok": True,
            "center_freq_ghz": float(center),
            "sample_center_freq_ghz": sample_center,
            "min_detector_v": float(min_value),
            "method": method,
            "dip_depth_v": dip_depth_v,
        }

    for item in loaded:
        item["data"]["freq_ghz"] = calibrated_freq_ghz(item["data"])

    template_half_ghz = 0.65
    template_step_ghz = 0.002
    template_x = np.arange(-template_half_ghz, template_half_ghz + 0.5 * template_step_ghz, template_step_ghz)
    template_y = interp_signal(baseline["freq_ghz"], baseline["trans_signal_v"], template_x)
    template_vector, template_depth_v = template_feature(template_y)
    if template_vector is None:
        raise RuntimeError("failed to build baseline dip template for thermal tuning tracking")

    all_freq_values = []
    for item in loaded:
        freq = np.asarray(item["data"]["freq_ghz"], dtype=float)
        all_freq_values.extend(freq[np.isfinite(freq)].tolist())
    if all_freq_values:
        x_min = float(np.nanmin(all_freq_values))
        x_max = float(np.nanmax(all_freq_values))
    else:
        x_min, x_max = -0.050, 0.050
    candidate_step_ghz = 0.01
    candidate_min_ghz = min(-0.35, max(x_min + 0.10, -8.0))
    candidate_max_ghz = 0.08
    candidate_centers = np.arange(
        candidate_min_ghz,
        candidate_max_ghz + 0.5 * candidate_step_ghz,
        candidate_step_ghz,
    )

    score_rows = []
    depth_rows = []
    min_template_depth_v = max(0.0006, 0.15 * template_depth_v if math.isfinite(template_depth_v) else 0.0006)
    reliable_ncc_threshold = 0.95
    for item in loaded:
        data = item["data"]
        freq_ghz = data["freq_ghz"]
        signal_v = data["trans_signal_v"]
        voltage_v = float(item["voltage_v"])
        scores = np.full(len(candidate_centers), np.nan, dtype=float)
        depths = np.full(len(candidate_centers), np.nan, dtype=float)
        for center_index, center_ghz in enumerate(candidate_centers):
            if voltage_v > 1e-12 and center_ghz > 0.02:
                continue
            ywin = interp_signal(freq_ghz, signal_v, center_ghz + template_x)
            feature, depth_v = template_feature(ywin)
            depths[center_index] = depth_v
            if feature is None or not math.isfinite(depth_v) or depth_v < min_template_depth_v:
                continue
            scores[center_index] = float(np.sum(template_vector * feature))
        score_rows.append(scores)
        depth_rows.append(depths)

    score_matrix = np.asarray(score_rows, dtype=float)
    depth_matrix = np.asarray(depth_rows, dtype=float)
    path_indices = []
    tracked_prefix_frame_count = 0
    if len(loaded) and len(candidate_centers):
        n_frames, n_candidates = score_matrix.shape
        dp = np.full((n_frames, n_candidates), -1e12, dtype=float)
        previous = np.full((n_frames, n_candidates), -1, dtype=int)
        baseline_scores = score_matrix[0]
        anchor_penalty = (candidate_centers / 0.12) ** 2
        dp[0] = np.where(np.isfinite(baseline_scores), baseline_scores - anchor_penalty, -1e12)
        if float(np.max(dp[0])) <= -1e11:
            raise RuntimeError("joint template tracking did not find a valid baseline candidate")
        tracked_prefix_frame_count = 1
        for frame_index in range(1, n_frames):
            for center_index, center_ghz in enumerate(candidate_centers):
                score = score_matrix[frame_index, center_index]
                if not math.isfinite(float(score)):
                    continue
                delta = center_ghz - candidate_centers
                transition = dp[frame_index - 1].copy()
                transition -= np.where(delta > 0.04, 25.0 + (delta / 0.04) ** 2, 0.0)
                transition -= 0.10 * (delta / 0.75) ** 2
                prev_index = int(np.argmax(transition))
                dp[frame_index, center_index] = score + transition[prev_index]
                previous[frame_index, center_index] = prev_index
            if float(np.max(dp[frame_index])) <= -1e11:
                break
            tracked_prefix_frame_count = frame_index + 1
        if tracked_prefix_frame_count < minimum_tracked_prefix_points:
            raise RuntimeError(
                "joint template tracking found only "
                f"{tracked_prefix_frame_count} continuous frame(s); "
                f"at least {minimum_tracked_prefix_points} are required"
            )
        end_frame_index = tracked_prefix_frame_count - 1
        end_index = int(np.argmax(dp[end_frame_index]))
        path_indices = [end_index]
        for frame_index in range(end_frame_index, 0, -1):
            path_indices.append(int(previous[frame_index, path_indices[-1]]))
        path_indices = path_indices[::-1]

    tracked_loaded = loaded[:tracked_prefix_frame_count]
    excluded_loaded = loaded[tracked_prefix_frame_count:]
    rows = []
    trace_payloads = []
    for item, path_index in zip(tracked_loaded, path_indices):
        data = item["data"]
        freq_ghz = data["freq_ghz"]
        time_s = data["time_s"]
        signal_v = data["trans_signal_v"]
        voltage_v = float(item["voltage_v"])
        template_center_ghz = float(candidate_centers[path_index])
        local_min = local_mode_minimum(freq_ghz, signal_v, template_center_ghz)
        center_freq_ghz = float(local_min["center_freq_ghz"])
        min_trans = float(local_min["min_detector_v"])
        dip_depth_v = float(local_min.get("dip_depth_v") or math.nan)
        time_freq, time_values = sorted_finite_xy(freq_ghz, time_s)
        center_time_s = (
            float(np.interp(center_freq_ghz, time_freq, time_values))
            if len(time_freq) >= 2
            else math.nan
        )
        tracking_ncc = float(score_matrix[len(rows), path_index]) if math.isfinite(score_matrix[len(rows), path_index]) else math.nan
        matched_template_depth_v = float(depth_matrix[len(rows), path_index]) if math.isfinite(depth_matrix[len(rows), path_index]) else math.nan
        tracking_rejection = tracking_rejection_reasons(
            template_ncc=tracking_ncc,
            reliable_ncc_threshold=reliable_ncc_threshold,
            template_depth_v=matched_template_depth_v,
            minimum_template_depth_v=min_template_depth_v,
            local_minimum_ok=bool(local_min.get("ok")),
        )
        tracking_reliable = not tracking_rejection
        row = {
            "voltage_v": voltage_v,
            "voltage_squared_v2": voltage_v ** 2,
            "frame_path": item["frame_path"],
            "center_time_s": center_time_s,
            "center_freq_ghz": center_freq_ghz,
            "delta_freq_ghz": center_freq_ghz,
            "min_transmission": min_trans,
            "min_detector_v": min_trans,
            "dip_depth_v": dip_depth_v,
            "dip_depth_mv": dip_depth_v * 1000.0,
            "depth": dip_depth_v,
            "mzi_extrema_count": int(data["mzi_extrema_count"]),
            "tracking_reference_time_s": reference_time_s,
            "tracking_gate_min_s": None,
            "tracking_gate_max_s": None,
            "tracking_method": "joint_template_ncc_path",
            "tracking_candidate_count": int(np.count_nonzero(np.isfinite(score_matrix[len(rows)]))),
            "tracking_significant_candidate_count": int(np.count_nonzero(np.isfinite(score_matrix[len(rows)]))),
            "tracking_candidate_min_depth_v": min_template_depth_v,
            "tracking_picked_dip_depth_v": matched_template_depth_v,
            "tracking_expected_freq_ghz": template_center_ghz,
            "tracking_picked_freq_ghz": center_freq_ghz,
            "template_center_freq_ghz": template_center_ghz,
            "template_ncc": tracking_ncc,
            "template_depth_v": matched_template_depth_v,
            "template_depth_mv": matched_template_depth_v * 1000.0,
            "template_tracking_raw_reliable": tracking_reliable,
            "template_tracking_reliable": tracking_reliable,
            "template_tracking_rejection_reasons": tracking_rejection,
            "minimum_method": local_min.get("method"),
        }
        rows.append(row)
        trace_payloads.append({
            "voltage_v": voltage_v,
            "freq_ghz": freq_ghz,
            "trans_signal_v": signal_v,
            "center_freq_ghz": center_freq_ghz,
            "template_center_freq_ghz": template_center_ghz,
            "template_ncc": tracking_ncc,
            "template_tracking_reliable": tracking_reliable,
            "min_transmission": min_trans,
        })

    effective_rejections = continuous_prefix_rejection_reasons(
        [list(row["template_tracking_rejection_reasons"]) for row in rows]
    )
    for row, rejection_reasons in zip(rows, effective_rejections):
        row["template_tracking_rejection_reasons"] = rejection_reasons
        row["template_tracking_reliable"] = not rejection_reasons
    for trace, row in zip(trace_payloads, rows):
        trace["template_tracking_reliable"] = row["template_tracking_reliable"]

    baseline_row = min(rows, key=lambda row: abs(row["voltage_v"]))
    baseline_freq = float(baseline_row["center_freq_ghz"])
    for row in rows:
        row["delta_freq_ghz"] = float(row["center_freq_ghz"]) - baseline_freq
    fit_rows = [
        row for row in rows
        if math.isfinite(float(row.get("voltage_squared_v2", math.nan)))
        and math.isfinite(float(row.get("delta_freq_ghz", math.nan)))
        and (abs(float(row.get("voltage_v", 0.0))) < 1e-12 or bool(row.get("template_tracking_reliable")))
    ]
    fit_x = np.asarray([float(row["voltage_squared_v2"]) for row in fit_rows], dtype=float)
    fit_y = np.asarray([float(row["delta_freq_ghz"]) for row in fit_rows], dtype=float)
    denom = float(np.dot(fit_x, fit_x)) if len(fit_x) else 0.0
    slope_ghz_per_v2 = float(np.dot(fit_x, fit_y) / denom) if denom > 0 else math.nan
    fit_pred = slope_ghz_per_v2 * fit_x if math.isfinite(slope_ghz_per_v2) else np.full_like(fit_y, np.nan)
    ss_res = float(np.nansum((fit_y - fit_pred) ** 2)) if len(fit_y) else math.nan
    ss_tot = float(np.nansum((fit_y - np.nanmean(fit_y)) ** 2)) if len(fit_y) else math.nan
    fit_r2 = 1.0 - ss_res / ss_tot if math.isfinite(ss_res) and ss_tot > 0 else math.nan
    fit_by_voltage = {
        float(x): float(yhat)
        for x, yhat in zip(fit_x, fit_pred)
        if math.isfinite(float(x)) and math.isfinite(float(yhat))
    }
    for row in rows:
        fit_value = fit_by_voltage.get(float(row["voltage_squared_v2"]))
        row["fit_delta_freq_ghz"] = fit_value
        row["fit_residual_ghz"] = (
            float(row["delta_freq_ghz"]) - fit_value
            if fit_value is not None and math.isfinite(float(row["delta_freq_ghz"]))
            else None
        )
    thermal_tuning_fit = {
        "ok": len(fit_rows) >= minimum_tracked_prefix_points and math.isfinite(slope_ghz_per_v2),
        "model": "delta_freq_ghz = slope_ghz_per_v2 * voltage_squared_v2",
        "frequency_axis_sign": frequency_axis_sign,
        "frequency_axis_note": "fine-sweep segment is wavelength-up / optical-frequency-down; MZI fringe coordinate is multiplied by -1",
        "intercept_ghz": 0.0,
        "slope_ghz_per_v2": slope_ghz_per_v2 if math.isfinite(slope_ghz_per_v2) else None,
        "slope_mhz_per_v2": slope_ghz_per_v2 * 1000.0 if math.isfinite(slope_ghz_per_v2) else None,
        "r2": fit_r2 if math.isfinite(fit_r2) else None,
        "point_count": int(len(fit_rows)),
        "minimum_point_count": minimum_tracked_prefix_points,
    }

    tracking_coverage = {
        "requested_frame_count": int(len(loaded)),
        "tracked_prefix_frame_count": int(len(rows)),
        "excluded_frame_count": int(len(excluded_loaded)),
        "minimum_prefix_point_count": minimum_tracked_prefix_points,
        "tracked_voltage_max_v": max(float(row["voltage_v"]) for row in rows),
        "excluded_voltages_v": [float(item["voltage_v"]) for item in excluded_loaded],
        "truncated": bool(excluded_loaded),
        "truncation_reason": (
            "target mode no longer had a continuous valid template path"
            if excluded_loaded
            else None
        ),
    }

    csv_path = output_dir / "voltage_sweep_summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = [
            "voltage_v",
            "voltage_squared_v2",
            "center_time_s",
            "center_freq_ghz",
            "delta_freq_ghz",
            "fit_delta_freq_ghz",
            "fit_residual_ghz",
            "min_transmission",
            "min_detector_v",
            "dip_depth_v",
            "dip_depth_mv",
            "depth",
            "mzi_extrema_count",
            "tracking_reference_time_s",
            "tracking_gate_min_s",
            "tracking_gate_max_s",
            "tracking_method",
            "tracking_candidate_count",
            "tracking_significant_candidate_count",
            "tracking_candidate_min_depth_v",
            "tracking_picked_dip_depth_v",
            "tracking_expected_freq_ghz",
            "tracking_picked_freq_ghz",
            "template_center_freq_ghz",
            "template_ncc",
            "template_depth_v",
            "template_depth_mv",
            "template_tracking_raw_reliable",
            "template_tracking_reliable",
            "template_tracking_rejection_reasons",
            "minimum_method",
            "frame_path",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    summary_path = output_dir / "voltage_sweep_summary.json"
    selected_mode = request.get("selected_mode") or {}
    summary = {
        "ok": True,
        "selected_mode": selected_mode,
        "assignment": assignment,
        "mzi_d1_mhz": d1,
        "reference_time_s": reference_time_s,
        "baseline_frame": baseline_item["frame_path"],
        "baseline_tracking": {
            "quick_baseline_time_s": quick_baseline_time_s,
            "baseline_anchor_time_s": baseline_anchor_time_s,
            "baseline_pick": baseline_pick,
        },
        "search_window_s": [
            min(float(np.nanmin(item["data"]["time_s"])) for item in loaded),
            max(float(np.nanmax(item["data"]["time_s"])) for item in loaded),
        ],
        "analysis_window": "full_frame_display_tracked_local_dip",
        "vertical_processing": "raw_detector_voltage_v_no_baseline_normalization",
        "tracking_algorithm": "joint_baseline_template_ncc_longest_continuous_prefix_then_local_minimum",
        "template_tracking": {
            "template_half_ghz": template_half_ghz,
            "template_step_ghz": template_step_ghz,
            "candidate_step_ghz": candidate_step_ghz,
            "candidate_min_ghz": candidate_min_ghz,
            "candidate_max_ghz": candidate_max_ghz,
            "baseline_template_depth_v": template_depth_v if math.isfinite(template_depth_v) else None,
            "minimum_template_depth_v": min_template_depth_v,
            "reliable_ncc_threshold": reliable_ncc_threshold,
            "reliability_depth_metric": "template_window_depth_v",
            "expected_shift_direction": "right",
        },
        "fit_quality_coverage": {
            "reliable_prefix_frame_count": int(sum(bool(row.get("template_tracking_reliable")) for row in rows)),
            "excluded_from_fit_frame_count": int(
                len(loaded) - sum(bool(row.get("template_tracking_reliable")) for row in rows)
            ),
            "excluded_from_fit_voltages_v": [
                float(row["voltage_v"])
                for row in rows
                if not bool(row.get("template_tracking_reliable"))
            ] + [float(item["voltage_v"]) for item in excluded_loaded],
            "continuous_prefix_required": True,
        },
        "tracking_coverage": tracking_coverage,
        "tracking_gate_s": {
            "initial_center": initial_gate_center_s,
            "initial_half_width": initial_gate_half_width_s,
            "tracking_left": tracking_gate_left_s,
            "tracking_right": tracking_gate_right_s,
            "expected_shift_direction": "right",
        },
        "thermal_tuning_fit": thermal_tuning_fit,
        "rows": rows,
        "csv_path": str(csv_path),
    }

    all_freq_values = []
    for trace in trace_payloads:
        freq = np.asarray(trace["freq_ghz"], dtype=float)
        all_freq_values.extend(freq[np.isfinite(freq)].tolist())
    if all_freq_values:
        x_min = float(np.nanmin(all_freq_values))
        x_max = float(np.nanmax(all_freq_values))
    else:
        x_min, x_max = -0.050, 0.050
    overlay_path = output_dir / "calibrated_spectra_overlay.png"
    fig, ax = plt.subplots(figsize=(11, 6), constrained_layout=True)
    all_signal_mv = []
    for trace in trace_payloads:
        values = np.asarray(trace["trans_signal_v"], dtype=float) * 1000.0
        all_signal_mv.extend(values[np.isfinite(values)].tolist())
    if all_signal_mv:
        low_mv = float(np.nanpercentile(all_signal_mv, 2))
        high_mv = float(np.nanpercentile(all_signal_mv, 98))
        offset_step_mv = max((high_mv - low_mv) * 1.35, 1.0)
    else:
        offset_step_mv = 1.0
    for index, trace in enumerate(trace_payloads):
        x = np.asarray(trace["freq_ghz"], dtype=float)
        y = np.asarray(trace["trans_signal_v"], dtype=float) * 1000.0 + index * offset_step_mv
        mask = np.isfinite(x) & np.isfinite(y)
        if np.count_nonzero(mask) > 50000:
            idx = np.flatnonzero(mask)
            stride = int(math.ceil(len(idx) / 50000))
            idx = idx[::stride]
        else:
            idx = np.flatnonzero(mask)
        label = f"{trace['voltage_v']:.2f} V"
        ax.plot(x[idx], y[idx], label=label)
        if trace.get("template_tracking_reliable", True):
            ax.scatter([trace["center_freq_ghz"]], [trace["min_transmission"] * 1000.0 + index * offset_step_mv], s=34, zorder=5)
        else:
            ax.scatter(
                [trace["center_freq_ghz"]],
                [trace["min_transmission"] * 1000.0 + index * offset_step_mv],
                s=52,
                marker="x",
                color="#d62728",
                zorder=6,
            )
    ax.axvline(0.0, color="#444", lw=1.0, alpha=0.45)
    ax.set_xlabel("MZI-calibrated relative frequency (GHz)")
    ax.set_ylabel("Detector voltage (mV) + vertical offset")
    family = selected_mode.get("family") or ""
    mu = selected_mode.get("mode_number")
    ax.set_title(f"Thermal tuning spectra, {family}, mu={mu}")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)
    fig.savefig(overlay_path)
    plt.close(fig)

    score_map_path = output_dir / "template_tracking_score_map.png"
    fig, ax = plt.subplots(figsize=(9.5, 5.2), constrained_layout=True)
    score_for_plot = np.ma.masked_invalid(np.asarray(score_matrix[:len(rows)], dtype=float))
    if score_for_plot.size and len(candidate_centers) and len(rows):
        cmap = plt.get_cmap("viridis").copy()
        cmap.set_bad("white")
        image = ax.imshow(
            score_for_plot,
            aspect="auto",
            origin="lower",
            extent=[float(candidate_centers[0]), float(candidate_centers[-1]), 0, len(rows) - 1],
            vmin=0.0,
            vmax=1.0,
            cmap=cmap,
        )
        ax.plot(
            [float(row["template_center_freq_ghz"]) for row in rows],
            np.arange(len(rows), dtype=float),
            "r.-",
            label="chosen template path",
        )
        ax.set_yticks(np.arange(len(rows), dtype=float))
        ax.set_yticklabels([f"{float(row['voltage_v']):.2f}V" for row in rows])
        fig.colorbar(image, ax=ax, label="normalized cross-correlation")
        ax.legend(loc="lower right")
    else:
        ax.text(0.5, 0.5, "No template score map", transform=ax.transAxes, ha="center", va="center")
    ax.set_xlabel("Template center candidate (GHz)")
    ax.set_ylabel("Voltage")
    ax.set_title(f"Template tracking score map, {family}, mu={mu}")
    fig.savefig(score_map_path)
    plt.close(fig)

    response_path = output_dir / "thermal_tuning_response.png"
    fig, ax = plt.subplots(figsize=(8.5, 5.5), constrained_layout=True)
    reliable_rows = [
        row for row in rows
        if abs(float(row.get("voltage_v", 0.0))) < 1e-12 or bool(row.get("template_tracking_reliable"))
    ]
    unreliable_rows = [row for row in rows if row not in reliable_rows]
    xs = [row["voltage_squared_v2"] for row in reliable_rows]
    ys = [row["delta_freq_ghz"] for row in reliable_rows]
    ax.axhline(0.0, color="#555", lw=1.0)
    ax.plot(xs, ys, marker="o", label="reliable template-tracked centers")
    if unreliable_rows:
        ax.scatter(
            [row["voltage_squared_v2"] for row in unreliable_rows],
            [row["delta_freq_ghz"] for row in unreliable_rows],
            marker="x",
            color="#d62728",
            s=54,
            label="excluded by tracking quality gate",
        )
    if thermal_tuning_fit["ok"]:
        x_fit = np.linspace(0.0, max([row["voltage_squared_v2"] for row in rows]) if rows else 0.0, 100)
        y_fit = float(thermal_tuning_fit["slope_ghz_per_v2"]) * x_fit
        label = (
            f"fit: {float(thermal_tuning_fit['slope_mhz_per_v2']):.1f} MHz/V²"
            + (f", R²={float(thermal_tuning_fit['r2']):.4f}" if thermal_tuning_fit.get("r2") is not None else "")
        )
        ax.plot(x_fit, y_fit, "--", color="#333333", label=label)
    for row in rows:
        ax.text(row["voltage_squared_v2"], row["delta_freq_ghz"], f" {row['voltage_v']:.2f}V", fontsize=10, va="center")
    ax.set_xlabel("Applied V^2 (V^2)")
    ax.set_ylabel("Mode shift Δf (GHz)")
    ax.set_title(f"Thermal tuning response, {family}, mu={mu}")
    ax.grid(True, alpha=0.25)
    if thermal_tuning_fit["ok"] or unreliable_rows:
        ax.legend(loc="best")
    fig.savefig(response_path)
    plt.close(fig)

    summary.update({
        "overlay_png": str(overlay_path),
        "score_map_png": str(score_map_path),
        "response_png": str(response_path),
        "frequency_window_ghz": [x_min, x_max],
        "frequency_axis_sign": frequency_axis_sign,
        "thermal_tuning_fit": thermal_tuning_fit,
    })
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "ok": True,
        "summary_path": str(summary_path),
        "csv_path": str(csv_path),
        "overlay_png": str(overlay_path),
        "score_map_png": str(score_map_path),
        "response_png": str(response_path),
        "rows": rows,
        "reference_time_s": reference_time_s,
        "frequency_window_ghz": [x_min, x_max],
        "frequency_axis_sign": frequency_axis_sign,
        "thermal_tuning_fit": thermal_tuning_fit,
        "tracking_coverage": tracking_coverage,
        "template_tracking": summary["template_tracking"],
        "fit_quality_coverage": summary["fit_quality_coverage"],
    }, ensure_ascii=False))


def main():
    run(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))

if __name__ == "__main__":
    main()
