from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.thermal_tuning'


import json
import sys
import time
import traceback
from pathlib import Path

def run(request):
    import numpy as np
    from a221_workbench.tasks.large_scan.acquire_large_scan import create_scope


    def emit(payload):
        print(json.dumps(payload, ensure_ascii=False), flush=True)


    def capture_frame(scope, capture_request):
        started = time.perf_counter()
        scope.single()
        single = scope.wait_for_single_complete(timeout_s=float(capture_request.get("single_timeout_s") or 5.0))
        t_trans, trans_v, trans_header = scope.read_channel(int(capture_request["trans_channel"]))
        t_mzi, mzi_v, mzi_header = scope.read_channel(int(capture_request["mzi_channel"]))
        t_trigger, trigger_v, trigger_header = scope.read_channel(int(capture_request["trigger_channel"]))
        output_path = Path(capture_request["output_path"])
        output_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            output_path,
            trans_time_s=np.asarray(t_trans, dtype=float),
            trans_v=np.asarray(trans_v, dtype=float),
            mzi_time_s=np.asarray(t_mzi, dtype=float),
            mzi_v=np.asarray(mzi_v, dtype=float),
            trigger_time_s=np.asarray(t_trigger, dtype=float),
            trigger_v=np.asarray(trigger_v, dtype=float),
        )
        return {
            "ok": True,
            "output_path": str(output_path),
            "trans_points": len(trans_v),
            "mzi_points": len(mzi_v),
            "trigger_points": len(trigger_v),
            "trans_header": trans_header,
            "mzi_header": mzi_header,
            "trigger_header": trigger_header,
            "trigger_channel": int(capture_request["trigger_channel"]),
            "scope_idn": scope.idn(),
            "single_acquisition": single,
            "elapsed_s": time.perf_counter() - started,
        }


    scope = create_scope(request["scope_type"], request["scope_resource"], timeout_ms=120000)
    try:
        if request.get("stream_commands"):
            emit({"ok": True, "ready": True, "scope_idn": scope.idn()})
            for raw_line in sys.stdin:
                try:
                    command = json.loads(raw_line)
                    operation = str(command.get("op") or "").strip().lower()
                    if operation == "close":
                        result = {"ok": True, "closed": True}
                        if command.get("restore_continuous"):
                            try:
                                scope.instrument.timeout = 2500
                                scope.run()
                                result["restore_scope_run_continuous"] = {"ok": True, "reused_connection": True}
                            except Exception as exc:
                                result["ok"] = False
                                result["restore_scope_run_continuous"] = {"ok": False, "error": repr(exc)}
                        emit(result)
                        break
                    if operation != "capture":
                        raise ValueError(f"unsupported thermal scope command: {operation!r}")
                    emit(capture_frame(scope, {**request, **command}))
                except Exception as exc:
                    emit({
                        "ok": False,
                        "error": repr(exc),
                        "traceback_tail": traceback.format_exc()[-3000:],
                    })
        else:
            emit(capture_frame(scope, request))
    finally:
        scope.close()


def main():
    run(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))

if __name__ == "__main__":
    main()
