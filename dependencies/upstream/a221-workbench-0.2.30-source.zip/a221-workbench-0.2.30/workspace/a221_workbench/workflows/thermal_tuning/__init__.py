"""Thermal tuning workers; execute only with an explicit request."""
