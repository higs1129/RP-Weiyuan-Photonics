"""Run the onsite large-scan flow and standardize the Q folder."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.large_scan'

from a221_workbench._shared.paths import module_file, project_root


import argparse
import csv
import json
import math
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

from a221_workbench._shared.campaign_paths import CAMPAIGN_ENV, CHIP_ENV, DATA_ROOT_ENV, default_campaign, default_chip, default_results_dir


from a221_workbench.tasks.large_scan.acquire_large_scan import AcquisitionOptions
from a221_workbench.workflows.large_scan._step_process import start_step, run_step, run_optional_step, acquisition_cli_preview
from a221_workbench.tasks.analysis.large_scan.process_large_scan import ProcessOptions
from a221_workbench.tasks.analysis.large_scan.fit_large_scan_dispersion import DispersionOptions
from a221_workbench.tasks.analysis.large_scan.fit_large_scan_q import QFitOptions
from a221_workbench.tasks.analysis.large_scan.analyze_array_large_scan import ArrayOptions
from a221_workbench.tasks.analysis.large_scan import validate_array_min_depth
from a221_workbench.tasks.large_scan.write_interactive_q_review import ReviewOptions, write_q_only_review
from a221_workbench.tasks.large_scan.write_cavity_card import CardOptions, latest_evidence_dir

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = project_root()
VALID_Q_SUBDIRS = {"Q", "Q'"}


def normalize_q_subdir(value: object) -> str:
    q_subdir = str(value or "Q").strip()
    if q_subdir not in VALID_Q_SUBDIRS:
        raise ValueError(f"q_subdir must be one of {sorted(VALID_Q_SUBDIRS)!r}, got {q_subdir!r}")
    return q_subdir


def latest_new_scan(q_dir: Path, started_at: float) -> tuple[Path, Path, str]:
    candidates = sorted(
        q_dir.glob("large_scan_*_1530-1570nm.npz"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    for npz_path in candidates:
        if npz_path.stat().st_mtime + 1 < started_at:
            continue
        meta_path = npz_path.with_suffix(".json")
        if meta_path.exists():
            return npz_path, meta_path, npz_path.stem
    raise RuntimeError(f"No new timestamped large-scan npz/json found in {q_dir}")


def latest_existing_scan(q_dir: Path) -> tuple[Path, Path, str]:
    candidates = sorted(
        q_dir.glob("large_scan_*_1530-1570nm.npz"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    for npz_path in candidates:
        meta_path = npz_path.with_suffix(".json")
        if meta_path.exists():
            return npz_path, meta_path, npz_path.stem

    stable_npz = q_dir / "raw.npz"
    stable_meta = q_dir / "acquisition.json"
    if stable_npz.exists() and stable_meta.exists():
        return stable_npz, stable_meta, stable_npz.stem
    raise RuntimeError(f"No existing large-scan raw npz/json found in {q_dir}")


def wait_for_new_scan_ready(
    q_dir: Path,
    started_at: float,
    acquire_proc: subprocess.Popen,
    *,
    timeout_s: float = 140.0,
) -> tuple[Path, Path, str, float]:
    wait_started_at = time.perf_counter()
    deadline = time.monotonic() + timeout_s
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            npz_path, meta_path, stem = latest_new_scan(q_dir, started_at)
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if int(meta.get("rows", 0)) > 0 and npz_path.exists():
                raw_ready_seconds = time.perf_counter() - wait_started_at
                print(f"RAW_READY {npz_path} after {raw_ready_seconds:.3f} s", flush=True)
                return npz_path, meta_path, stem, raw_ready_seconds
        except (RuntimeError, json.JSONDecodeError, OSError) as exc:
            last_error = exc

        return_code = acquire_proc.poll()
        if return_code is not None:
            if return_code != 0:
                raise subprocess.CalledProcessError(return_code, acquire_proc.args)
            if last_error is not None:
                raise RuntimeError(f"Acquisition ended before raw data became ready: {last_error}") from last_error
            raise RuntimeError("Acquisition ended before raw data became ready.")
        time.sleep(0.25)

    raise TimeoutError(f"Timed out waiting for new raw npz/json in {q_dir}")


def assert_acquisition_gates(npz_path: Path, meta_path: Path) -> dict[str, object]:
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if not npz_path.exists():
        raise RuntimeError(f"Missing new raw npz: {npz_path}")
    if int(meta.get("rows", 0)) <= 0:
        raise RuntimeError("Acquisition metadata reports zero rows.")
    if not meta.get("trigger_window_ok"):
        raise RuntimeError("Trigger window gate failed.")
    if not meta.get("pc_voltage_ok", False):
        raise RuntimeError("PC piezo gate failed.")
    if meta.get("smile_cycle_before_scan") is not True or meta.get("smile_post_cycle") is not True:
        raise RuntimeError("Motor Control SMILE cycle gate failed.")
    if meta.get("smile_cycle_kind") not in (None, "motor_control_smile_enable"):
        raise RuntimeError("Pre-scan SMILE cycle used the wrong TOPTICA control path.")
    if meta.get("smile_post_cycle_kind") not in (None, "motor_control_smile_enable"):
        raise RuntimeError("Post-scan SMILE cycle used the wrong TOPTICA control path.")
    if meta.get("smile_post_cycle_order") != "after_fine_scan_restore":
        raise RuntimeError("Post-scan SMILE cycle did not run after fine-scan state restoration.")
    if not meta.get("fine_scan_arc_factor_restored") or not meta.get("scope_idle_restored"):
        raise RuntimeError("Fine-scan restore gate failed before post-scan emission cycle.")

    target = meta.get("laser_restore_target_nm")
    if target is None or meta.get("laser_restore_commanded") is False:
        raise RuntimeError(f"Laser restore command gate failed: target={target}")

    with np.load(npz_path) as arrays:
        for name in arrays.files:
            if not (name.endswith("_trans_v") or name.endswith("_mzi_v")):
                continue
            values = np.asarray(arrays[name], dtype=float)
            mn = float(np.nanmin(values))
            mx = float(np.nanmax(values))
            tol = max(1e-9, (mx - mn) * 1e-4)
            low_frac = float(np.mean(values <= mn + tol))
            high_frac = float(np.mean(values >= mx - tol))
            if low_frac > 0.01 or high_frac > 0.01:
                raise RuntimeError(
                    f"Saturation gate failed for {name}: low_frac={low_frac:.4g}, high_frac={high_frac:.4g}"
                )
    return meta


def move_file(src: Path, dst: Path) -> None:
    if not src.exists():
        raise RuntimeError(f"Missing expected file: {src}")
    if src.resolve() == dst.resolve():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    shutil.move(str(src), str(dst))


def move_file_if_exists(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    if src.resolve() == dst.resolve():
        return True
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    shutil.move(str(src), str(dst))
    return True


def update_summary_paths(q_dir: Path, evidence_dir: Path) -> None:
    replacements = {
        "process_summary.json": {
            "dip_table": str(evidence_dir / "dip_table.csv"),
            "raw_ch2_ch3_figure": str(evidence_dir / "raw_time_trace.png")
            if (evidence_dir / "raw_time_trace.png").exists()
            else None,
            "flattened_ch2_figure": str(evidence_dir / "normalized_dip_detection.png")
            if (evidence_dir / "normalized_dip_detection.png").exists()
            else None,
            "transmission_spectrum_figure": str(q_dir / "transmission_spectrum.png")
            if (q_dir / "transmission_spectrum.png").exists()
            else None,
            "fsr_periodicity_figure": str(q_dir / "fsr_periodicity.png") if (q_dir / "fsr_periodicity.png").exists() else None,
            "folded_dispersion_figure": str(q_dir / "folded_dispersion.png")
            if (q_dir / "folded_dispersion.png").exists()
            else None,
        },
        "dispersion_summary.json": {
            "family_points_csv": str(q_dir / "family_points.csv"),
            "auto_centered_family_points_csv": str(q_dir / "family_points.csv"),
            "common_coordinate_fit_figure": None,
            "auto_centered_fit_figure": None,
            "interactive_q_review": str(q_dir / "interactive_q.html"),
        },
        "q_summary.json": {
            "q_table": str(q_dir / "q_by_mode.csv"),
            "best_lock_candidate_json": str(q_dir / "best_lock_candidate.json")
            if (q_dir / "best_lock_candidate.json").exists()
            else None,
            "trend_figure": str(q_dir / "q_trend.png"),
            "fit_examples_figure": None,
            "local_dip_mosaic_figure": None,
            "interactive_q_review": str(q_dir / "interactive_q.html"),
        },
    }
    for name, patch in replacements.items():
        path = evidence_dir / name
        if not path.exists():
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        data.update(patch)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def finite_float(value: object) -> float | None:
    try:
        parsed = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def family_labels(q_dir: Path) -> dict[str, str]:
    path = q_dir / "family_points.csv"
    if not path.exists():
        return {}
    labels: dict[str, str] = {}
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            family = row.get("family", "")
            label = row.get("family_label", "")
            if family and label:
                labels[family] = label
    return labels


def build_onsite_verdict(
    q_dir: Path,
    evidence_dir: Path,
    *,
    phase_seconds: dict[str, float],
) -> dict[str, object]:
    process_summary = read_json(evidence_dir / "process_summary.json")
    dispersion_summary = read_json(evidence_dir / "dispersion_summary.json")
    q_summary = read_json(evidence_dir / "q_summary.json")
    labels = family_labels(q_dir)

    family_rows: list[dict[str, object]] = []
    for fit in dispersion_summary.get("auto_centered_fits", []):
        if not isinstance(fit, dict) or "quadratic" not in fit:
            continue
        family = str(fit["name"])
        quadratic = fit["quadratic"]
        if not isinstance(quadratic, dict):
            continue
        spacing = fit.get("spacing_quality", {})
        if not isinstance(spacing, dict):
            spacing = {}
        q_family = {}
        family_summary = q_summary.get("family_summary", {})
        if isinstance(family_summary, dict):
            q_family = family_summary.get(family, {}) or {}
        family_rows.append(
            {
                "family": family,
                "label": labels.get(family, family),
                "count": int(fit.get("count", 0)),
                "fsr_ghz": round(float(quadratic["effective_d1_mhz"]) / 1000.0, 6),
                "d2_mhz": round(float(quadratic["d2_mhz_per_mode2"]), 3),
                "rms_mhz": round(float(quadratic["rms_residual_mhz"]), 3),
                "spacing_ok": bool(spacing.get("spacing_ok", False)),
                "spacing_rms_mhz": round(float(spacing.get("rms_spacing_error_mhz", float("nan"))), 3),
                "spacing_max_error_mhz": round(float(spacing.get("max_abs_spacing_error_mhz", float("nan"))), 3),
                "max_mode_gap": int(spacing.get("max_mode_gap", 0)),
                "q0_median_M": round(float(q_family.get("Q0_median_M", float("nan"))), 3),
                "q1_median_M": round(float(q_family.get("Q1_median_M", float("nan"))), 3),
            }
        )

    prune_log = dispersion_summary.get("outlier_prune_log", {})
    prune_count = 0
    if isinstance(prune_log, dict):
        prune_count = sum(len(items) for items in prune_log.values() if isinstance(items, list))
    mode_count = int(q_summary.get("mode_count", 0))
    ok_count = int(q_summary.get("ok_count", 0))
    fit_ratio = ok_count / mode_count if mode_count else 0.0
    depth_filtered = int(dispersion_summary.get("depth_filtered_dip_count", 0))
    family_counts = [int(row["count"]) for row in family_rows]
    rms_values = [float(row["rms_mhz"]) for row in family_rows]
    spacing_bad = [row for row in family_rows if not bool(row["spacing_ok"])]
    spacing_error_values = [
        float(row["spacing_max_error_mhz"]) for row in family_rows if np.isfinite(float(row["spacing_max_error_mhz"]))
    ]
    q0_values = [float(row["q0_median_M"]) for row in family_rows if np.isfinite(float(row["q0_median_M"]))]

    flags: list[str] = []
    if spacing_bad:
        labels = ",".join(str(row["label"]) for row in spacing_bad)
        flags.append(f"family_spacing_bad:{labels}")
    config = dispersion_summary.get("config", {})
    reference_fsr_mhz = float(config.get("reference_fsr_mhz", 0.0)) if isinstance(config, dict) else 0.0
    if reference_fsr_mhz > 0 and spacing_error_values and max(spacing_error_values) > 0.08 * reference_fsr_mhz:
        flags.append(f"family_spacing_error_high:max={max(spacing_error_values):.1f}MHz")
    if fit_ratio < 0.9:
        flags.append(f"q_fit_ratio_low:{ok_count}/{mode_count}")
    if len(family_rows) < 3:
        flags.append(f"family_count_low:{len(family_rows)}")
    if depth_filtered < 60:
        flags.append(f"depth_filtered_sparse:{depth_filtered}")
    if family_counts and min(family_counts) < 12:
        flags.append(f"family_points_sparse:min={min(family_counts)}")
    if rms_values and max(rms_values) > 80.0:
        flags.append(f"d2_rms_high:max={max(rms_values):.1f}MHz")
    if prune_count:
        flags.append(f"residual_pruned:{prune_count}")
    if q0_values and max(q0_values) < 0.8:
        flags.append(f"q0_low:max={max(q0_values):.3f}M")

    if any(
        flag.startswith(("family_spacing_bad", "family_spacing_error_high", "d2_rms_high", "family_count_low"))
        for flag in flags
    ):
        verdict = "escalate"
    elif flags:
        verdict = "limited"
    else:
        verdict = "accepted"

    analysis_seconds = sum(float(phase_seconds.get(key, 0.0)) for key in ("process", "dispersion", "q_fit"))
    raw_ready_seconds = float(phase_seconds.get("acquire_to_raw_ready", phase_seconds.get("acquire", 0.0)))
    return {
        "verdict": verdict,
        "flags": flags,
        "dip_count": process_summary.get("dip_count"),
        "depth_filtered_dip_count": depth_filtered,
        "q_fit": {"ok": ok_count, "total": mode_count, "ratio": round(fit_ratio, 3)},
        "families": sorted(family_rows, key=lambda row: str(row["label"])),
        "phase_seconds": {key: round(value, 3) for key, value in phase_seconds.items()},
        "analysis_seconds": round(analysis_seconds, 3),
        "time_to_analysis_ready_seconds": round(raw_ready_seconds + analysis_seconds, 3),
    }


def threshold_suffix(value: float) -> str:
    return f"{value:g}".replace(".", "p")


def required_stable_outputs(q_dir: Path) -> list[Path]:
    return [
        q_dir / "raw.npz",
        q_dir / "acquisition.json",
        q_dir / "family_points.csv",
        q_dir / "q_by_mode.csv",
        q_dir / "q_trend.png",
    ]


def required_evidence_outputs(evidence_dir: Path) -> list[Path]:
    return [
        evidence_dir / "dip_table.csv",
        evidence_dir / "process_summary.json",
        evidence_dir / "dispersion_summary.json",
        evidence_dir / "q_summary.json",
    ]


def standardized_outputs_ready(q_dir: Path, evidence_dir: Path | None) -> bool:
    return (
        evidence_dir is not None
        and all(path.exists() for path in required_stable_outputs(q_dir))
        and all(path.exists() for path in required_evidence_outputs(evidence_dir))
    )


def evidence_dir_for_stem(q_dir: Path, stem: str) -> Path:
    parts = stem.split("_")
    if len(parts) >= 4 and parts[0] == "large" and parts[1] == "scan":
        return q_dir / "evidence" / f"processing_{parts[2]}_{parts[3]}"
    return q_dir / "evidence" / f"processing_resume_{time.strftime('%Y%m%d_%H%M%S')}"


def move_first_existing(q_dir: Path, src_names: list[str], dst_name: str) -> None:
    dst = q_dir / dst_name
    for src_name in src_names:
        src = q_dir / src_name
        if src.exists():
            move_file(src, dst)
            return
    if dst.exists():
        return
    sources = ", ".join(str(q_dir / name) for name in src_names)
    raise RuntimeError(f"Missing expected file: one of {sources}")


def standardize_outputs(q_dir: Path, stem: str, *, depth_threshold: float) -> Path:
    existing_evidence = latest_evidence_dir(q_dir)
    unstandardized_outputs_exist = any(path.is_file() for path in q_dir.glob(f"{stem}_*"))
    if (q_dir / f"{stem}.npz").exists() and stem != "raw":
        unstandardized_outputs_exist = True
    if standardized_outputs_ready(q_dir, existing_evidence) and not unstandardized_outputs_exist:
        update_summary_paths(q_dir, existing_evidence)
        return existing_evidence

    evidence_dir = evidence_dir_for_stem(q_dir, stem)
    evidence_dir.mkdir(parents=True, exist_ok=True)

    depth_suffix = threshold_suffix(depth_threshold)
    stable = {
        "raw.npz": [f"{stem}.npz"],
        "acquisition.json": [f"{stem}.json"],
        "family_points.csv": [
            f"{stem}_dispersion_auto_centered_family_points.csv",
            f"{stem}_q_peak_points.csv",
        ],
        "q_by_mode.csv": [f"{stem}_large_scan_q_by_family.csv"],
        "q_trend.png": [f"{stem}_large_scan_q_trends.png"],
    }
    optional_stable = {
        f"{stem}_best_lock_candidate.json": "best_lock_candidate.json",
        f"{stem}_interactive_q.html": "interactive_q.html",
        f"{stem}_transmission_spectrum.png": "transmission_spectrum.png",
        f"{stem}_fsr_periodicity.png": "fsr_periodicity.png",
        f"{stem}_folded_dispersion.png": "folded_dispersion.png",
    }
    evidence = {
        f"{stem}_dip_table.csv": "dip_table.csv",
        f"{stem}_process_summary.json": "process_summary.json",
        f"{stem}_dispersion_fit_summary.json": "dispersion_summary.json",
        f"{stem}_large_scan_q_summary.json": "q_summary.json",
    }
    optional_evidence: dict[str, str] = {
        f"{stem}_ch2_ch3_raw.png": "raw_time_trace.png",
        f"{stem}_ch2_flattened_for_dips.png": "normalized_dip_detection.png",
    }
    for dst_name, src_names in stable.items():
        move_first_existing(q_dir, src_names, dst_name)
    for src_name, dst_name in optional_stable.items():
        move_file_if_exists(q_dir / src_name, q_dir / dst_name)
    for src_name, dst_name in evidence.items():
        src = q_dir / src_name
        dst = evidence_dir / dst_name
        if src.exists():
            move_file(src, dst)
        elif not dst.exists():
            raise RuntimeError(f"Missing expected file: {src}")
    for src_name, dst_name in optional_evidence.items():
        move_file_if_exists(q_dir / src_name, evidence_dir / dst_name)

    protected_stable = {q_dir / name for name in stable}
    protected_stable.update(q_dir / name for name in optional_stable.values())
    protected_resolved = {path.resolve() for path in protected_stable if path.exists()}
    for path in q_dir.glob(f"{stem}*"):
        if path.is_file():
            if path.resolve() in protected_resolved:
                continue
            path.unlink()
    update_summary_paths(q_dir, evidence_dir)
    return evidence_dir


def nominal_width_samples_for_raw(npz_path: Path, meta_path: Path, override: int | None) -> int:
    if override is not None:
        return override
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    sample_rate = float(meta.get("actual_sample_rate_hz", meta.get("sample_rate_hz", 200_000.0)))
    return max(20, round(500 * sample_rate / 500_000.0))


def read_process_reference_fsr(q_dir: Path, stem: str) -> tuple[float | None, str]:
    for path in (q_dir / f"{stem}_process_summary.json", q_dir / "evidence" / "process_summary.json"):
        if not path.exists():
            continue
        try:
            config = read_json(path).get("config", {})
        except (json.JSONDecodeError, OSError):
            continue
        if not isinstance(config, dict):
            continue
        fsr_mhz = finite_float(config.get("disk_fsr_mhz"))
        if fsr_mhz is not None and fsr_mhz > 0:
            return fsr_mhz, str(config.get("disk_fsr_source", "process_summary"))
    return None, "unavailable"


def write_q_peak_points_from_dip_table(
    dip_table: Path,
    q_dir: Path,
    stem: str,
) -> tuple[Path, int]:
    out_path = q_dir / f"{stem}_q_peak_points.csv"
    fields = [
        "family",
        "family_label",
        "mode_number_ref",
        "mode_number_centered",
        "mode_number",
        "sample_index",
        "time_s",
        "wavelength_nm_linear",
        "norm_transmission",
        "depth_1_minus_norm",
        "mzi_mu",
        "relative_freq_mhz",
        "folded_freq_mhz",
    ]
    with dip_table.open(newline="", encoding="utf-8") as src, out_path.open("w", newline="", encoding="utf-8") as dst:
        reader = csv.DictReader(src)
        writer = csv.DictWriter(dst, fieldnames=fields)
        writer.writeheader()
        count = 0
        for count, row in enumerate(reader, start=1):
            mode = row.get("mode_number") or row.get("dip_id") or str(count)
            writer.writerow(
                {
                    "family": "unassigned",
                    "family_label": "未归属",
                    "mode_number_ref": mode,
                    "mode_number_centered": mode,
                    "mode_number": mode,
                    "sample_index": row.get("sample_index", ""),
                    "time_s": row.get("time_s", ""),
                    "wavelength_nm_linear": row.get("wavelength_nm_linear", ""),
                    "norm_transmission": row.get("norm_transmission", ""),
                    "depth_1_minus_norm": row.get("depth_1_minus_norm", ""),
                    "mzi_mu": row.get("mzi_mu", ""),
                    "relative_freq_mhz": row.get("relative_freq_mhz", ""),
                    "folded_freq_mhz": row.get("folded_freq_mhz", ""),
                }
            )
    return out_path, count if "count" in locals() else 0


def write_dispersion_unavailable_summary(
    q_dir: Path,
    stem: str,
    *,
    family_points: Path,
    depth_threshold: float,
    reason: str,
    error: dict[str, object] | None = None,
) -> Path:
    reference_fsr_mhz, reference_fsr_source = read_process_reference_fsr(q_dir, stem)
    depth_filtered_count = 0
    with family_points.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            depth = finite_float(row.get("depth_1_minus_norm"))
            if depth is not None and depth >= depth_threshold:
                depth_filtered_count += 1
    summary = {
        "ok": False,
        "status": "q_fit_without_family_assignment",
        "reason": reason,
        "error": error,
        "config": {
            "reference_fsr_mhz": reference_fsr_mhz or 0.0,
            "reference_fsr_source": reference_fsr_source,
            "depth_threshold": depth_threshold,
        },
        "depth_filtered_dip_count": depth_filtered_count,
        "auto_centered_fits": [],
        "fits": [],
        "family_points_csv": str(family_points),
        "auto_centered_family_points_csv": str(family_points),
    }
    path = q_dir / f"{stem}_dispersion_fit_summary.json"
    path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def dispersion_has_family_fits(q_dir: Path) -> bool:
    evidence_dir = latest_evidence_dir(q_dir)
    if evidence_dir is None:
        return False
    summary_path = evidence_dir / "dispersion_summary.json"
    if not summary_path.exists():
        return False
    try:
        summary = read_json(summary_path)
    except (json.JSONDecodeError, OSError):
        return False
    fits = summary.get("auto_centered_fits", [])
    return any(isinstance(fit, dict) and isinstance(fit.get("quadratic"), dict) for fit in fits)


def run_analysis_chain(args, q_dir, npz_path, meta_path, stem, *, process_extra_args=None, dispersion_extra_args=None):
    nominal_width = nominal_width_samples_for_raw(npz_path, meta_path, args.nominal_width_samples)
    # Retain historical CLI :g rounding at this compatibility boundary.
    phase_seconds = {}
    phase_seconds["process"] = run_step("process", ProcessOptions(
        data_path=str(npz_path), campaign=args.campaign, chip=args.chip, die=args.die,
        cavity=args.cavity, nominal_width_samples=nominal_width,
        mzi_d1_mhz=float(f"{args.mzi_d1_mhz:g}"),
        disk_fsr_mhz=float(f"{args.disk_fsr_mhz:g}") if args.disk_fsr_mhz is not None else None,
    ))
    dip_table = q_dir / f"{stem}_dip_table.csv"
    family_points = q_dir / f"{stem}_dispersion_auto_centered_family_points.csv"
    phase_seconds["dispersion"], dispersion_error = run_optional_step("dispersion", DispersionOptions(
        dip_table=str(dip_table), campaign=args.campaign, chip=args.chip, die=args.die,
        cavity=args.cavity, depth_threshold=float(f"{args.depth_threshold:g}"),
        reference_fsr_mhz=float(f"{args.disk_fsr_mhz:g}") if args.disk_fsr_mhz is not None else None,
    ), timeout_s=args.dispersion_timeout_s)
    if dispersion_error is not None or not family_points.exists():
        reason = ("dispersion command failed; Q fitting continues from unassigned dip table"
                  if dispersion_error is not None else
                  "dispersion command did not write family points; Q fitting continues from unassigned dip table")
        family_points, _point_count = write_q_peak_points_from_dip_table(dip_table, q_dir, stem)
        write_dispersion_unavailable_summary(q_dir, stem, family_points=family_points,
                                             depth_threshold=args.depth_threshold, reason=reason, error=dispersion_error)
    phase_seconds["q_fit"] = run_step("q", QFitOptions(
        data_path=str(npz_path), family_points_csv=str(family_points), campaign=args.campaign,
        chip=args.chip, die=args.die, cavity=args.cavity, depth_threshold=float(f"{args.depth_threshold:g}"),
    ))
    return phase_seconds


def refresh_cavity_card(args, results_root, *, card_extra_args=None):
    return run_step("card", CardOptions(chip=args.chip, die=args.die, cavity=args.cavity,
                    results_root=results_root,
                    radius_um=float(f"{args.radius_um:g}") if args.radius_um is not None else None,
                    gap_um=float(f"{args.gap_um:g}") if args.gap_um is not None else None))


def refresh_interactive_q_review(q_dir: Path) -> float:
    started_at = time.perf_counter()
    if not dispersion_has_family_fits(q_dir):
        write_q_only_review(q_dir)
        return time.perf_counter() - started_at
    return run_step("review", ReviewOptions(cavity_dir=q_dir.parent))


def standardize_raw_only(q_dir: Path, npz_path: Path, meta_path: Path) -> tuple[Path, Path]:
    raw_path = q_dir / "raw.npz"
    acquisition_path = q_dir / "acquisition.json"
    move_file(npz_path, raw_path)
    move_file(meta_path, acquisition_path)
    return raw_path, acquisition_path


def run_array_preanalysis(args, q_dir, npz_path, meta_path):
    min_depth = validate_array_min_depth(getattr(args, "array_min_depth", ArrayOptions.min_depth))
    raw_path, acquisition_path = standardize_raw_only(q_dir, npz_path, meta_path)
    nominal_width = nominal_width_samples_for_raw(raw_path, acquisition_path, args.nominal_width_samples)
    elapsed = run_step("array", ArrayOptions(
        data_path=raw_path, chip=args.chip, die=args.die, cavity=args.cavity, output_dir=q_dir,
        nominal_width_samples=nominal_width, mzi_d1_mhz=float(f"{args.mzi_d1_mhz:g}"),
        min_depth=min_depth,
        disk_fsr_mhz=float(f"{args.disk_fsr_mhz:.12g}") if args.disk_fsr_mhz is not None else None,
        reference_family_points=args.reference_family_points, reference_family_plan=args.reference_family_plan,
        reference_family_match_tolerance_mhz=float(f"{args.reference_family_match_tolerance_mhz:g}"),
    ))
    summary = read_json(q_dir / "array_preanalysis_summary.json")
    return {"array_preanalysis": elapsed}, summary, raw_path, acquisition_path


def run_array_preanalysis_flow(
    args: argparse.Namespace,
    q_dir: Path,
    acquire_options: AcquisitionOptions,
    started_at: float,
) -> int:
    if args.standardize_only or args.resume_existing_raw:
        npz_path, meta_path, stem = latest_existing_scan(q_dir)
        meta = assert_acquisition_gates(npz_path, meta_path)
        phase_seconds, summary, raw_path, acquisition_path = run_array_preanalysis(args, q_dir, npz_path, meta_path)
        print(
            json.dumps(
                {
                    "ok": True,
                    "mode": "array-preanalysis-existing-raw",
                    "q_dir": str(q_dir),
                    "raw_npz": str(raw_path),
                    "acquisition_json": str(acquisition_path),
                    "stem": raw_path.stem,
                    "source_stem": stem,
                    "rows": meta.get("rows"),
                    "sample_rate_hz": meta.get("actual_sample_rate_hz"),
                    "phase_seconds": {key: round(value, 3) for key, value in phase_seconds.items()},
                    "array_preanalysis": summary,
                },
                indent=2,
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0

    acquire_started_at = time.perf_counter()
    acquire_proc = start_step("acquire", acquire_options)
    npz_path: Path | None = None
    meta_path: Path | None = None
    stem: str | None = None
    phase_seconds: dict[str, float] = {}
    try:
        npz_path, meta_path, stem, phase_seconds["acquire_to_raw_ready"] = wait_for_new_scan_ready(
            q_dir,
            started_at,
            acquire_proc,
        )
    finally:
        return_code = acquire_proc.wait()
        phase_seconds["acquire_total"] = time.perf_counter() - acquire_started_at
        phase_seconds["post_raw_restore_overlap"] = max(
            0.0,
            phase_seconds["acquire_total"] - phase_seconds.get("acquire_to_raw_ready", 0.0),
        )
        if return_code != 0:
            raise subprocess.CalledProcessError(return_code, acquire_proc.args)

    if npz_path is None or meta_path is None or stem is None:
        raise RuntimeError("Acquisition did not produce a scan for array preanalysis.")
    meta = assert_acquisition_gates(npz_path, meta_path)
    analysis_phase, summary, raw_path, acquisition_path = run_array_preanalysis(args, q_dir, npz_path, meta_path)
    phase_seconds.update(analysis_phase)
    print(
        json.dumps(
            {
                "ok": True,
                "mode": "array-preanalysis",
                "q_dir": str(q_dir),
                "raw_npz": str(raw_path),
                "acquisition_json": str(acquisition_path),
                "stem": raw_path.stem,
                "source_stem": stem,
                "rows": meta.get("rows"),
                "sample_rate_hz": meta.get("actual_sample_rate_hz"),
                "phase_seconds": {key: round(value, 3) for key, value in phase_seconds.items()},
                "array_preanalysis": summary,
            },
            indent=2,
            ensure_ascii=False,
        ),
        flush=True,
    )
    return 0


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run acquisition, analysis, Q fitting, and card generation for one cavity.")
    parser.add_argument("--chip", default=default_chip(), help=f"Chip/sample id. Defaults to ${CHIP_ENV} or chip7.")
    parser.add_argument(
        "--campaign",
        default=default_campaign(),
        help=f"Campaign path under ${DATA_ROOT_ENV}/experiments. Defaults to ${CAMPAIGN_ENV} or wafer_measuement/Batch_260515.",
    )
    parser.add_argument("--die", required=True)
    parser.add_argument("--cavity", required=True)
    parser.add_argument(
        "--q-subdir",
        default="Q",
        choices=sorted(VALID_Q_SUBDIRS),
        help="Neutral polarization data slot under the cavity/die directory.",
    )
    parser.add_argument(
        "--results-root",
        type=Path,
        default=None,
        help=f"Root containing <die>/<cavity>/<q-subdir>. Defaults to ${DATA_ROOT_ENV}/experiments/<campaign>/results/<chip>.",
    )
    parser.add_argument(
        "--disk-fsr-mhz",
        type=float,
        default=None,
        help="Optional manual FSR override. If omitted, process_large_scan.py infers chip7/array-design FSR and auto-selects from measured candidates.",
    )
    parser.add_argument("--reference-family-points", type=Path, default=None)
    parser.add_argument("--reference-family-plan", type=Path, default=None)
    parser.add_argument("--reference-family-match-tolerance-mhz", type=float, default=2000.0)
    parser.add_argument("--radius-um", type=float, default=None, help="Optional cavity radius for non-chip7 cards.")
    parser.add_argument("--gap-um", type=float, default=None, help="Optional coupling gap for non-chip7 cards.")
    parser.add_argument("--laser-connection", choices=["serial", "tcp"], default="serial")
    parser.add_argument("--laser-port", default="COM3", help="TOPTICA serial port forwarded to acquire_large_scan.py.")
    parser.add_argument("--laser-host", default="192.168.1.13", help="TOPTICA TCP host forwarded to acquire_large_scan.py.")
    parser.add_argument(
        "--toptica-python",
        default="",
        help="Python executable containing the TOPTICA SDK, used only for --laser-connection tcp.",
    )
    parser.add_argument(
        "--scope-type",
        choices=["rs_rte", "tektronix_mso66b"],
        default="rs_rte",
        help="Oscilloscope driver forwarded to acquire_large_scan.py.",
    )
    parser.add_argument(
        "--scope-resource",
        default="TCPIP::192.168.1.8::INSTR",
        help="Oscilloscope VISA resource forwarded to acquire_large_scan.py.",
    )
    parser.add_argument("--trigger-channel", type=int, default=1, help="Oscilloscope channel carrying the large-scan trigger.")
    parser.add_argument("--trans-channel", type=int, default=2, help="Oscilloscope channel carrying chip transmission.")
    parser.add_argument("--mzi-channel", type=int, default=3, help="Oscilloscope channel carrying the MZI signal.")
    parser.add_argument("--mzi-d1-mhz", type=float, default=40.44357, help="MZI free spectral range used for frequency calibration.")
    parser.add_argument("--aux-mzi-channel", type=int, default=None, help="Optional second MZI channel saved with the same raw scan.")
    parser.add_argument("--no-save-transmission", action="store_true", help="Skip enabling/reading the transmission channel.")
    parser.add_argument("--fine-trigger-channel", type=int, default=4, help="Oscilloscope channel carrying the restored fine-scan trigger.")
    parser.add_argument("--fine-trigger-level-v", type=float, default=0.0, help="Fine-scan trigger level after large-scan restore.")
    parser.add_argument(
        "--fine-trigger-slope",
        choices=["positive", "negative"],
        default="negative",
        help="Fine-scan trigger edge after large-scan restore.",
    )
    parser.add_argument(
        "--fine-horizontal-delay-s",
        type=float,
        default=None,
        help="Optional oscilloscope horizontal delay after large-scan fine-scan restore.",
    )
    parser.add_argument("--sample-rate-hz", type=float, default=200_000.0)
    parser.add_argument(
        "--laser-readback-samples",
        type=int,
        default=1200,
        help="During new large-scan acquisition, sample TOPTICA actual wavelength this many times for MZI comparison.",
    )
    parser.add_argument(
        "--laser-readback-interval-s",
        type=float,
        default=0.02,
        help="Interval between TOPTICA actual-wavelength samples during large-scan acquisition.",
    )
    parser.add_argument(
        "--laser-settle-tolerance-nm",
        type=float,
        default=0.01,
        help="Required actual-wavelength error before SMILE cycling and post-scan fine-state restore.",
    )
    parser.add_argument("--depth-threshold", type=float, default=0.2)
    parser.add_argument(
        "--array-min-depth", type=validate_array_min_depth, default=ArrayOptions.min_depth,
        help="Minimum relative dip depth used for array FSR/family analysis (default: 0.2).",
    )
    parser.add_argument(
        "--dispersion-timeout-s",
        type=float,
        default=30.0,
        help="Maximum time to spend on mode-family/FSR analysis before falling back to unassigned Q fitting.",
    )
    parser.add_argument("--storage-format", choices=["npz", "npz-compressed"], default="npz")
    parser.add_argument("--nominal-width-samples", type=int, default=None)
    parser.add_argument(
        "--resume-existing-raw",
        action="store_true",
        help="Skip acquisition and rerun process/dispersion/Q fit from the latest raw npz/json in this cavity's Q folder.",
    )
    parser.add_argument(
        "--standardize-only",
        action="store_true",
        help="Skip acquisition and analysis; only standardize existing outputs, update summary paths, and refresh the card.",
    )
    parser.add_argument(
        "--array-preanalysis-only",
        action="store_true",
        help="For array cavities, run the array MZI/FSR/family analysis including its Q fits; skip the full cavity card and interactive HTML chain.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print planned paths and commands without connecting to instruments.")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if not math.isfinite(args.mzi_d1_mhz) or args.mzi_d1_mhz <= 0:
        raise SystemExit(f"--mzi-d1-mhz must be positive, got {args.mzi_d1_mhz!r}")
    if args.resume_existing_raw and args.standardize_only and not args.array_preanalysis_only:
        raise SystemExit("Use only one of --resume-existing-raw or --standardize-only.")
    if (args.reference_family_points is None) != (args.reference_family_plan is None):
        raise SystemExit("--reference-family-points and --reference-family-plan must be provided together.")
    if args.reference_family_points is not None and args.disk_fsr_mhz is None:
        raise SystemExit("Reference-family assignment requires --disk-fsr-mhz from the pre-tuning scan.")
    for label, channel in (
        ("trigger", args.trigger_channel),
        ("transmission", args.trans_channel),
        ("MZI", args.mzi_channel),
        ("auxiliary MZI", args.aux_mzi_channel),
        ("fine trigger", args.fine_trigger_channel),
    ):
        if channel is None:
            continue
        if channel < 1 or channel > 6:
            raise SystemExit(f"{label} channel must be CH1-CH6, got CH{channel}.")
    large_scan_channels = [args.trigger_channel, args.trans_channel, args.mzi_channel]
    if args.aux_mzi_channel is not None:
        large_scan_channels.append(args.aux_mzi_channel)
    if len(set(large_scan_channels)) != len(large_scan_channels):
        raise SystemExit("Large-scan trigger, transmission, MZI, and auxiliary MZI channels must be different channels.")
    try:
        results_root = args.results_root if args.results_root is not None else default_results_dir(args.chip, campaign=args.campaign)
    except RuntimeError as exc:
        if not args.dry_run:
            raise SystemExit(f"{exc} For this wrapper, pass --results-root to override.") from exc
        results_root = Path(f"<set {DATA_ROOT_ENV} or pass --results-root>") / "experiments" / args.campaign / "results" / args.chip
    q_dir = results_root / args.die / args.cavity / normalize_q_subdir(args.q_subdir)

    phase_seconds: dict[str, float] = {}
    started_at = time.time()
    acquire_options = AcquisitionOptions(
        campaign=args.campaign, chip=args.chip, die=args.die, cavity=args.cavity,
        start_nm=1530.0, stop_nm=1570.0, speed_nm_s=2.0,
        laser_connection=args.laser_connection, laser_port=args.laser_port,
        laser_host=args.laser_host, toptica_python=args.toptica_python,
        scope_type=args.scope_type, scope_resource=args.scope_resource,
        sample_rate_hz=float(f"{args.sample_rate_hz:g}"), record_seconds=20.0,
        trigger_channel=args.trigger_channel, trans_channel=args.trans_channel, mzi_channel=args.mzi_channel,
        aux_mzi_channel=args.aux_mzi_channel, no_save_transmission=args.no_save_transmission,
        fine_trigger_channel=args.fine_trigger_channel, fine_trigger_level_v=float(f"{args.fine_trigger_level_v:g}"),
        fine_trigger_slope=args.fine_trigger_slope, fine_horizontal_delay_s=float(f"{args.fine_horizontal_delay_s:g}") if args.fine_horizontal_delay_s is not None else None,
        laser_readback_samples=max(0, int(args.laser_readback_samples)),
        laser_readback_interval_s=float(f"{args.laser_readback_interval_s:g}"),
        laser_settle_tolerance_nm=float(f"{args.laser_settle_tolerance_nm:g}"),
        storage_format=args.storage_format, restore_wavelength_mode="initial",
        cycle_smile_before_scan=True, cycle_smile_after_scan=True, output_dir=str(q_dir),
    )
    acquire_args = acquisition_cli_preview(acquire_options)
    process_extra_args = ["--mzi-d1-mhz", f"{args.mzi_d1_mhz:g}"]
    if args.disk_fsr_mhz is not None:
        process_extra_args.extend(["--disk-fsr-mhz", f"{args.disk_fsr_mhz:g}"])
    dispersion_extra_args = (
        ["--reference-fsr-mhz", f"{args.disk_fsr_mhz:g}"] if args.disk_fsr_mhz is not None else []
    )
    card_extra_args = []
    if args.radius_um is not None:
        card_extra_args.extend(["--radius-um", f"{args.radius_um:g}"])
    if args.gap_um is not None:
        card_extra_args.extend(["--gap-um", f"{args.gap_um:g}"])

    if args.dry_run:
        if args.array_preanalysis_only:
            planned_commands = {
                "array_preanalysis": "run array analysis from raw.npz, including its Q fits; skip cavity card and interactive HTML",
                "disk_fsr_mhz": args.disk_fsr_mhz,
                "mzi_d1_mhz": args.mzi_d1_mhz,
                "array_min_depth": args.array_min_depth,
            }
        elif args.standardize_only:
            planned_commands = {
                "standardize": "standardize existing outputs and refresh cavity card only",
                "card_extra_args": card_extra_args,
            }
        elif args.resume_existing_raw:
            planned_commands = {
                "resume": "reuse latest existing raw npz/json; run process, dispersion, Q fit, standardization, and card refresh",
                "process_extra_args": process_extra_args,
                "dispersion_extra_args": dispersion_extra_args,
                "card_extra_args": card_extra_args,
            }
        else:
            planned_commands = {
                "acquire": acquire_args,
                "process_extra_args": process_extra_args,
                "dispersion_extra_args": dispersion_extra_args,
                "card_extra_args": card_extra_args,
            }
        plan = {
            "dry_run": True,
            "mode": "array-preanalysis"
            if args.array_preanalysis_only
            else "standardize-only"
            if args.standardize_only
            else "resume-existing-raw"
            if args.resume_existing_raw
            else "acquire-and-analyze",
            "campaign": args.campaign,
            "chip": args.chip,
            "die": args.die,
            "cavity": args.cavity,
            "results_root": str(results_root),
            "q_dir": str(q_dir),
            "requires_instrument_connection": False,
            "disk_fsr_mhz": args.disk_fsr_mhz,
            "channel_map": {
                "trigger": f"CH{args.trigger_channel}",
                "transmission": f"CH{args.trans_channel}",
                "mzi": f"CH{args.mzi_channel}",
                "aux_mzi": f"CH{args.aux_mzi_channel}" if args.aux_mzi_channel is not None else None,
                "fine_trigger": {
                    "channel": f"CH{args.fine_trigger_channel}",
                    "level_v": args.fine_trigger_level_v,
                    "slope": args.fine_trigger_slope,
                    "horizontal_delay_s": args.fine_horizontal_delay_s,
                    "expected_source": "RP OUT1 via pid1(asg0)",
                },
            },
            "laser": {
                "connection": args.laser_connection,
                "host": args.laser_host,
                "port": args.laser_port,
                "toptica_python": args.toptica_python,
            },
            "commands": planned_commands,
        }
        print(json.dumps(plan, indent=2, ensure_ascii=False), flush=True)
        return 0

    q_dir.mkdir(parents=True, exist_ok=True)

    if args.array_preanalysis_only:
        return run_array_preanalysis_flow(args, q_dir, acquire_options, started_at)

    if args.standardize_only:
        npz_path, meta_path, stem = latest_existing_scan(q_dir)
        meta = assert_acquisition_gates(npz_path, meta_path)
        evidence_dir = standardize_outputs(q_dir, stem, depth_threshold=args.depth_threshold)
        verdict = build_onsite_verdict(q_dir, evidence_dir, phase_seconds={"standardize_only": 0.0})
        phase_seconds = {"standardize_only": 0.0}
        phase_seconds["interactive_q_review"] = refresh_interactive_q_review(q_dir)
        phase_seconds["cavity_card"] = refresh_cavity_card(args, results_root, card_extra_args=card_extra_args)
        print(
            json.dumps(
                {
                    "ok": True,
                    "mode": "standardize-only",
                    "onsite_verdict": verdict,
                    "q_dir": str(q_dir),
                    "evidence_dir": str(evidence_dir),
                    "stem": stem,
                    "rows": meta.get("rows"),
                    "sample_rate_hz": meta.get("actual_sample_rate_hz"),
                },
                indent=2,
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0

    if args.resume_existing_raw:
        npz_path, meta_path, stem = latest_existing_scan(q_dir)
        meta = assert_acquisition_gates(npz_path, meta_path)
        phase_seconds = run_analysis_chain(
            args,
            q_dir,
            npz_path,
            meta_path,
            stem,
            process_extra_args=process_extra_args,
            dispersion_extra_args=dispersion_extra_args,
        )
        evidence_dir = standardize_outputs(q_dir, stem, depth_threshold=args.depth_threshold)
        verdict = build_onsite_verdict(q_dir, evidence_dir, phase_seconds=phase_seconds)
        phase_seconds["interactive_q_review"] = refresh_interactive_q_review(q_dir)
        phase_seconds["cavity_card"] = refresh_cavity_card(args, results_root, card_extra_args=card_extra_args)
        print(
            json.dumps(
                {
                    "ok": True,
                    "mode": "resume-existing-raw",
                    "onsite_verdict": verdict,
                    "q_dir": str(q_dir),
                    "evidence_dir": str(evidence_dir),
                    "stem": stem,
                    "rows": meta.get("rows"),
                    "sample_rate_hz": meta.get("actual_sample_rate_hz"),
                },
                indent=2,
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0

    acquire_started_at = time.perf_counter()
    acquire_proc = start_step("acquire", acquire_options)
    npz_path: Path | None = None
    meta_path: Path | None = None
    stem: str | None = None
    try:
        npz_path, meta_path, stem, phase_seconds["acquire_to_raw_ready"] = wait_for_new_scan_ready(
            q_dir,
            started_at,
            acquire_proc,
        )
        phase_seconds.update(
            run_analysis_chain(
                args,
                q_dir,
                npz_path,
                meta_path,
                stem,
                process_extra_args=process_extra_args,
                dispersion_extra_args=dispersion_extra_args,
            )
        )
    finally:
        return_code = acquire_proc.wait()
        phase_seconds["acquire_total"] = time.perf_counter() - acquire_started_at
        phase_seconds["post_raw_restore_overlap"] = max(
            0.0,
            phase_seconds["acquire_total"] - phase_seconds.get("acquire_to_raw_ready", 0.0),
        )
        if return_code != 0:
            raise subprocess.CalledProcessError(return_code, acquire_proc.args)

    if npz_path is None or meta_path is None or stem is None:
        raise RuntimeError("Acquisition did not produce a scan for analysis.")

    meta = assert_acquisition_gates(npz_path, meta_path)
    evidence_dir = standardize_outputs(q_dir, stem, depth_threshold=args.depth_threshold)
    verdict = build_onsite_verdict(q_dir, evidence_dir, phase_seconds=phase_seconds)
    phase_seconds["interactive_q_review"] = refresh_interactive_q_review(q_dir)
    phase_seconds["cavity_card"] = refresh_cavity_card(args, results_root, card_extra_args=card_extra_args)
    print(
        json.dumps(
            {
                "ok": True,
                "onsite_verdict": verdict,
                "q_dir": str(q_dir),
                "evidence_dir": str(evidence_dir),
                "stem": stem,
                "rows": meta.get("rows"),
                "sample_rate_hz": meta.get("actual_sample_rate_hz"),
            },
            indent=2,
            ensure_ascii=False,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
