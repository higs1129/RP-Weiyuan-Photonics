"""Process isolation for typed scan steps (acquisition overlap and dispersion timeout)."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.workflows.large_scan'

from a221_workbench._shared.paths import module_file, project_root
import sys
from pathlib import Path
_workspace = Path(__file__).resolve().parents[2]

import importlib
import json
import subprocess
import time
from dataclasses import asdict

REPO_ROOT = project_root()
STEPS = {
    "acquire": ("a221_workbench.tasks.large_scan.acquire_large_scan", "AcquisitionOptions", "acquire_scan"),
    "process": ("a221_workbench.tasks.analysis.large_scan.process_large_scan", "ProcessOptions", "process_scan"),
    "dispersion": ("a221_workbench.tasks.analysis.large_scan.fit_large_scan_dispersion", "DispersionOptions", "fit_dispersion"),
    "q": ("a221_workbench.tasks.analysis.large_scan.fit_large_scan_q", "QFitOptions", "fit_scan_q"),
    "array": ("a221_workbench.tasks.analysis.large_scan.analyze_array_large_scan", "ArrayOptions", "analyze_array_scan"),
    "review": ("a221_workbench.tasks.large_scan.write_interactive_q_review", "ReviewOptions", "write_review"),
    "card": ("a221_workbench.tasks.large_scan.write_cavity_card", "CardOptions", "write_card"),
}


def invoke_step(name, values):
    """Dispatch typed values to the same function used by the standalone CLI."""
    from dataclasses import fields
    module_name, options_name, function_name = STEPS[name]
    module = importlib.import_module(module_name)
    options_type = getattr(module, options_name)
    values = dict(values)
    for field in fields(options_type):
        if "Path" in str(field.type) and values.get(field.name) is not None:
            values[field.name] = Path(values[field.name])
    return getattr(module, function_name)(options_type(**values))


def step_command(name, options):
    if name not in STEPS:
        raise ValueError(f"Unknown scan step: {name}")
    return [sys.executable, str(Path(__file__).resolve()), name, json.dumps(asdict(options), default=str)]


def run_command(args: list[str]) -> float:
    print("RUN", " ".join(args), flush=True)
    started_at = time.perf_counter()
    subprocess.run(args, cwd=REPO_ROOT, check=True)
    return time.perf_counter() - started_at


def kill_process_tree(pid: int) -> dict[str, object]:
    if not sys.platform.startswith("win"):
        return {"ok": False, "message": "process-tree kill is only implemented for Windows"}
    completed = subprocess.run(
        ["taskkill", "/PID", str(pid), "/T", "/F"],
        text=True,
        capture_output=True,
    )
    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout_tail": completed.stdout[-2000:],
        "stderr_tail": completed.stderr[-2000:],
    }


def run_optional_command(args: list[str], *, timeout_s: float | None = None) -> tuple[float, dict[str, object] | None]:
    print("RUN", " ".join(args), flush=True)
    started_at = time.perf_counter()
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform.startswith("win") else 0
    proc = subprocess.Popen(
        args,
        cwd=REPO_ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=creationflags,
    )
    timed_out = False
    stop_result = None
    try:
        stdout, stderr = proc.communicate(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        timed_out = True
        stop_result = kill_process_tree(proc.pid)
        stdout, stderr = proc.communicate(timeout=10.0)
    elapsed = time.perf_counter() - started_at
    if stdout:
        print(stdout, end="", flush=True)
    if stderr:
        print(stderr, end="", file=sys.stderr, flush=True)
    if proc.returncode == 0 and not timed_out:
        return elapsed, None
    return elapsed, {
        "returncode": proc.returncode,
        "timed_out": timed_out,
        "timeout_s": timeout_s,
        "command": args,
        "stop_result": stop_result,
        "stdout_tail": stdout[-4000:],
        "stderr_tail": stderr[-4000:],
    }


def start_command(args: list[str]) -> subprocess.Popen:
    print("RUN", " ".join(args), flush=True)
    return subprocess.Popen(args, cwd=REPO_ROOT)


def start_step(name, options):
    return start_command(step_command(name, options))


def run_step(name, options):
    return run_command(step_command(name, options))


def run_optional_step(name, options, *, timeout_s=None):
    return run_optional_command(step_command(name, options), timeout_s=timeout_s)


def acquisition_cli_preview(options):
    """Retain the public dry-run command preview; execution uses typed steps."""
    values = asdict(options)
    args = []
    for name, value in values.items():
        if value is False and name in {"cycle_smile_before_scan", "cycle_smile_after_scan"}:
            args.append("--no-" + name.replace("_", "-"))
            continue
        if value is None or value is False:
            continue
        args.append("--" + name.replace("_", "-"))
        if value is not True:
            args.append(str(value))
    return [sys.executable, str(module_file('a221_workbench.tasks.large_scan.acquire_large_scan')), *args]


if __name__ == "__main__":
    invoke_step(sys.argv[1], json.loads(sys.argv[2]))
