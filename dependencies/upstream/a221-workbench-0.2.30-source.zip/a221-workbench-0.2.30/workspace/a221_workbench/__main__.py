"""Installed package command-line adapter."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench'

import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench'

import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench'

import argparse
from .workflows import WORKFLOWS, run_workflow


def main():
    parser = argparse.ArgumentParser(description='A221 package workflow entry points')
    parser.add_argument('workflow', choices=sorted(WORKFLOWS))
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    return run_workflow(args.workflow, args.arguments, check=False).returncode


if __name__ == '__main__':
    raise SystemExit(main())
