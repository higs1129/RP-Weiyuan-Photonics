"""Offline mechanical susceptibility fit matching the existing report fitter.

Frequency is MHz; the vertical input is a power-like dB quantity. The model
is a susceptibility-squared peak plus a constant *linear* background, scored
in dB. Gamma is reported as approximate FWHM, with Q = f0 / Gamma.
"""

from __future__ import annotations

from pathlib import Path
import math
import numpy as np


def mechanical_fit_javascript():
    """Self-contained report implementation, embedded by both report writers."""
    return Path(__file__).with_suffix('.js').read_text(encoding='utf-8')


def susceptibility_linear(frequency_mhz, f0_mhz, gamma_mhz, amplitude, background):
    x = np.asarray(frequency_mhz, dtype=float)
    f0, gamma, amp = max(f0_mhz, 1e-12), max(gamma_mhz, 1e-12), max(amplitude, 1e-300)
    den = (f0*f0 - x*x)**2 + (x*gamma)**2
    return max(background, 1e-300) + amp * (f0*gamma)**2 / np.maximum(den, 1e-300)


def fit_mechanical_q(frequency_mhz, power_db, *, window_mhz=None):
    """Fit one selected peak; return parameters, dB residual and fit interval.

    Retains the report's 1600-point stride and 75-iteration coordinate search.
    The result describes this local model, without claiming uncertainty bounds.
    """
    x, db = np.asarray(frequency_mhz, dtype=float), np.asarray(power_db, dtype=float)
    if x.ndim != 1 or x.shape != db.shape:
        raise ValueError('Frequency and power must be matched one-dimensional arrays')
    mask = np.isfinite(x) & np.isfinite(db)
    if window_mhz is not None:
        lo, hi = window_mhz
        if not np.isfinite(lo) or not np.isfinite(hi) or lo >= hi:
            raise ValueError('window_mhz must be an increasing finite interval')
        mask &= (x >= lo) & (x <= hi)
    x, db = x[mask], db[mask]
    if len(x) < 12 or np.any(x <= 0) or np.any(np.diff(x) <= 0):
        raise ValueError('Require at least 12 positive, increasing frequency samples')
    stride = max(1, math.ceil(len(x) / 1600))
    x, db = x[::stride], db[::stride]
    y = 10.0 ** (db / 10.0)
    if not np.all(np.isfinite(y)) or np.max(y) <= 0:
        raise ValueError('Power cannot be represented in linear units')
    xmin, xmax = float(x.min()), float(x.max())
    span = max(xmax - xmin, 1e-9)
    edge = max(3, math.floor(len(x) * .16))
    bg = max(1e-300, float(np.median(np.r_[y[:edge], y[-edge:]])))
    imax = int(np.argmax(y))
    percentile = np.sort(y)[math.floor((len(y)-1)*.9 + .5)]
    amp = max(float(y[imax] - bg), float(percentile - bg), bg*.1, 1e-300)
    half = bg + amp/2
    left, right = xmin, xmax
    for i in range(imax, 0, -1):
        if y[i] <= half:
            left = float(x[i]); break
    for i in range(imax, len(y)):
        if y[i] <= half:
            right = float(x[i]); break
    gamma = max(min(right-left, span), span/200)
    q = [float(x[imax]), math.log(gamma), math.log(amp), math.log(bg)]

    def parameters(values):
        return [min(xmax, max(xmin, values[0])), *[math.exp(v) for v in values[1:]]]

    def score(values):
        p = parameters(values)
        model_db = 10 * np.log10(np.maximum(susceptibility_linear(x, *p), 1e-300))
        penalty = 1e4 if p[1] < span/3000 or p[1] > span*2 else 0
        return float((np.sum((model_db-db)**2) + penalty) / len(x))

    best = score(q)
    steps = [span/12, math.log(1.8), math.log(1.8), math.log(1.25)]
    for _ in range(75):
        improved = False
        for k in range(4):
            local_best, local_q = best, q
            for direction in (-1, 1):
                candidate = q.copy(); candidate[k] += direction * steps[k]
                candidate[0] = min(xmax, max(xmin, candidate[0]))
                value = score(candidate)
                if value < local_best:
                    local_best, local_q = value, candidate
            if local_best < best:
                q, best, improved = local_q, local_best, True
        if not improved:
            steps = [v*.72 for v in steps]
        if max(steps) < 1e-6:
            break
    f0, gamma, amplitude, background = parameters(q)
    return {'f0_mhz': f0, 'fwhm_mhz': gamma, 'Qm': f0/gamma,
            'amplitude_linear': amplitude, 'background_linear': background,
            'rms_residual_db': math.sqrt(best), 'window_mhz': [xmin, xmax],
            'fit_points': len(x), 'fit_status': 'ok',
            'linewidth_convention': 'Gamma; approximate FWHM'}
