"""Offline scientific analysis. Import individual modules to select dependencies."""
