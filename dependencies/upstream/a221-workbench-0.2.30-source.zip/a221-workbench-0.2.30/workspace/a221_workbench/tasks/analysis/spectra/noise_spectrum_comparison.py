from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.analysis.spectra'


import argparse
import html
import json
import math
from pathlib import Path
from typing import Any

import numpy as np


COLORS = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#7A5195", "#2F4B7C"]


def finite_float(value: Any) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def minmax_downsample(x: np.ndarray, y: np.ndarray, max_points: int) -> tuple[np.ndarray, np.ndarray]:
    count = min(len(x), len(y))
    if count <= max_points:
        return np.asarray(x[:count], dtype=float), np.asarray(y[:count], dtype=float)
    bins = max(1, max_points // 2)
    edges = np.linspace(0, count, bins + 1, dtype=int)
    selected: list[int] = []
    for start, stop in zip(edges[:-1], edges[1:]):
        if stop <= start:
            continue
        segment = np.asarray(y[start:stop], dtype=float)
        finite = np.flatnonzero(np.isfinite(segment))
        if not finite.size:
            continue
        local = segment[finite]
        extrema = [start + int(finite[int(np.argmin(local))]), start + int(finite[int(np.argmax(local))])]
        selected.extend(sorted(set(extrema)))
    indices = np.asarray(sorted(set(selected)), dtype=int)
    return np.asarray(x[indices], dtype=float), np.asarray(y[indices], dtype=float)


def peak_bin_downsample(x: np.ndarray, y: np.ndarray, bins: int) -> tuple[np.ndarray, np.ndarray]:
    count = min(len(x), len(y))
    if count <= bins:
        return np.asarray(x[:count], dtype=float), np.asarray(y[:count], dtype=float)
    edges = np.linspace(0, count, bins + 1, dtype=int)
    out_x: list[float] = []
    out_y: list[float] = []
    for start, stop in zip(edges[:-1], edges[1:]):
        if stop <= start:
            continue
        x_segment = np.asarray(x[start:stop], dtype=float)
        y_segment = np.asarray(y[start:stop], dtype=float)
        finite = np.isfinite(x_segment) & np.isfinite(y_segment)
        if not finite.any():
            continue
        out_x.append(float(np.nanmean(x_segment[finite])))
        out_y.append(float(np.nanmax(y_segment[finite])))
    return np.asarray(out_x), np.asarray(out_y)


def measurement_sort_key(row: dict[str, Any]) -> tuple[float, str]:
    comb_index = finite_float(row.get("comb_index"))
    return (comb_index if comb_index is not None else float("inf"), str(row.get("family") or ""))


def write_noise_spectrum_comparison(
    run_dir: Path,
    measurements: list[dict[str, Any]],
    *,
    offset_db: float = 10.0,
    line_max_points: int = 7000,
    heatmap_bins: int = 1800,
) -> dict[str, Any]:
    run_dir = Path(run_dir).resolve()
    traces: list[dict[str, Any]] = []
    full_psd: list[np.ndarray] = []
    for row in sorted((dict(item) for item in measurements if isinstance(item, dict)), key=measurement_sort_key):
        if str(row.get("status") or "") != "completed":
            continue
        raw_path = Path(str(row.get("raw_npz") or ""))
        if not raw_path.exists():
            continue
        with np.load(raw_path) as data:
            frequency_hz = np.asarray(data["frequency_hz"], dtype=float)
            psd = np.asarray(data["input1_dbm_per_hz"], dtype=float)
        count = min(len(frequency_hz), len(psd))
        mask = np.isfinite(frequency_hz[:count]) & np.isfinite(psd[:count])
        frequency_mhz = frequency_hz[:count][mask] / 1e6
        psd = psd[:count][mask]
        if frequency_mhz.size < 2:
            continue
        line_x, line_y = minmax_downsample(frequency_mhz, psd, line_max_points)
        heat_x, heat_y = peak_bin_downsample(frequency_mhz, psd, heatmap_bins)
        family = str(row.get("family") or "?")
        cavity = str(row.get("cavity") or "?")
        label = f"{family} / {cavity}"
        traces.append(
            {
                "label": label,
                "family": family,
                "cavity": cavity,
                "mu": row.get("mu"),
                "combIndex": row.get("comb_index"),
                "color": COLORS[len(traces) % len(COLORS)],
                "lineX": line_x.tolist(),
                "lineY": line_y.tolist(),
                "heatX": heat_x.tolist(),
                "heatY": heat_y.tolist(),
                "median": float(np.nanmedian(psd)),
                "rawPath": str(raw_path),
            }
        )
        full_psd.append(psd)
    if not traces:
        return {"ok": False, "error": "没有可用的 completed noise.npz"}

    finite_values = np.concatenate(full_psd)
    color_min = float(np.nanpercentile(finite_values, 2.0))
    color_max = float(np.nanpercentile(finite_values, 99.8))
    if color_max <= color_min:
        color_min = float(np.nanmin(finite_values))
        color_max = float(np.nanmax(finite_values))
    frequency_min = min(min(trace["lineX"]) for trace in traces)
    frequency_max = max(max(trace["lineX"]) for trace in traces)
    payload = {
        "title": "Locked-mode noise PSD comparison",
        "subtitle": (
            f"{run_dir.name}; {len(traces)} modes; stack display offset {offset_db:g} dB/trace; "
            "heatmap uses absolute PSD with a shared robust color scale"
        ),
        "offsetDb": float(offset_db),
        "colorMin": color_min,
        "colorMax": color_max,
        "frequencyMin": frequency_min,
        "frequencyMax": frequency_max,
        "traces": traces,
    }
    payload_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    output = run_dir / "noise_psd_comparison.html"
    document = _comparison_html().replace("__TITLE__", html.escape(payload["title"])).replace("__PAYLOAD__", payload_json)
    output.write_text(document, encoding="utf-8")
    return {
        "ok": True,
        "path": str(output),
        "trace_count": len(traces),
        "frequency_min_mhz": frequency_min,
        "frequency_max_mhz": frequency_max,
        "offset_db_per_trace": float(offset_db),
        "heatmap_color_min_dbm_per_hz": color_min,
        "heatmap_color_max_dbm_per_hz": color_max,
        "line_downsampling": "per-bin min/max, original order retained",
        "heatmap_downsampling": "per-bin maximum PSD",
    }


def _comparison_html() -> str:
    return r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
:root{color-scheme:light;--line:#d0d7de;--ink:#111;--muted:#57606a}
*{box-sizing:border-box}body{margin:0;background:#fff;color:var(--ink);font-family:Arial,"Microsoft YaHei",sans-serif}
#wrap{max-width:1560px;margin:auto;padding:18px 22px 30px}h1{font-size:30px;margin:0 0 5px;letter-spacing:0}#subtitle{font-size:16px;color:var(--muted);margin-bottom:13px}
#controls{display:flex;flex-wrap:wrap;gap:8px 17px;align-items:center;padding:9px 0 13px}.trace-toggle{display:inline-flex;gap:6px;align-items:center;font-size:15px}.trace-toggle input{margin:0}
.panel{border-top:1px solid var(--line);padding-top:15px;margin-top:8px}.panel h2{font-size:23px;margin:0 0 5px;letter-spacing:0}.note{font-size:15px;color:var(--muted);margin-bottom:9px}
.canvas-box{position:relative;width:100%;height:560px}.canvas-box.heat{height:390px}canvas{width:100%;height:100%;display:block;background:#fff}
#tip{position:fixed;display:none;z-index:10;pointer-events:none;background:#fff;border:1px solid #111;border-radius:4px;padding:8px 10px;font-size:14px;box-shadow:0 3px 12px rgba(0,0,0,.2);white-space:nowrap}
.hint{font-size:14px;color:var(--muted);margin-top:10px}@media(max-width:800px){#wrap{padding:12px 10px 24px}.canvas-box{height:460px}.canvas-box.heat{height:350px}}
</style>
</head>
<body>
<div id="wrap">
  <h1 id="title"></h1><div id="subtitle"></div><div id="controls"></div>
  <section class="panel"><h2>Offset stacked noise PSD</h2><div class="note">原始 PSD 仅增加固定显示偏移，不做逐条归一化；悬停显示未加偏移的绝对值。</div><div class="canvas-box"><canvas id="stack"></canvas></div></section>
  <section class="panel"><h2>Absolute PSD waterfall</h2><div class="note" id="heatNote"></div><div class="canvas-box heat"><canvas id="heat"></canvas></div></section>
  <div class="hint">滚轮缩放频率轴，Shift + 拖动平移，双击恢复；两个面板共享同一频率范围。</div>
</div>
<div id="tip"></div>
<script>
const P=__PAYLOAD__, tip=document.getElementById('tip'), enabled=P.traces.map(()=>true), view={x0:P.frequencyMin,x1:P.frequencyMax}, FONT='Arial,"Microsoft YaHei",sans-serif';
document.getElementById('title').textContent=P.title;document.getElementById('subtitle').textContent=P.subtitle;
document.getElementById('heatNote').textContent=`统一绝对色标 ${P.colorMin.toFixed(1)} 到 ${P.colorMax.toFixed(1)} dBm/Hz；色域外数据仅显示裁剪，原始数值不变。`;
const controls=document.getElementById('controls');P.traces.forEach((t,i)=>{const label=document.createElement('label');label.className='trace-toggle';label.innerHTML=`<input type="checkbox" checked><span style="color:${t.color};font-weight:700">${t.label}</span>`;label.querySelector('input').onchange=e=>{enabled[i]=e.target.checked;drawAll()};controls.appendChild(label)});
const stack=document.getElementById('stack'),heat=document.getElementById('heat'),ctxS=stack.getContext('2d'),ctxH=heat.getContext('2d');
const padS={l:150,r:58,t:22,b:60},padH={l:105,r:170,t:18,b:60};let drag=null;
function size(canvas,ctx){const box=canvas.parentElement,dpr=window.devicePixelRatio||1;canvas.width=Math.round(box.clientWidth*dpr);canvas.height=Math.round(box.clientHeight*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);return{w:box.clientWidth,h:box.clientHeight}}
function sx(x,p,w){return p.l+(x-view.x0)/(view.x1-view.x0)*(w-p.l-p.r)}
function ix(px,p,w){return view.x0+(px-p.l)/(w-p.l-p.r)*(view.x1-view.x0)}
function ticks(a,b,n=7){const span=Math.max(Math.abs(b-a),1e-12),raw=span/n,pow=10**Math.floor(Math.log10(raw)),m=raw/pow,step=(m<1.5?1:m<3?2:m<7?5:10)*pow,out=[];for(let v=Math.ceil(a/step)*step;v<=b+step*1e-6;v+=step)out.push(v);return out}
function axis(ctx,p,w,h,yLabel){ctx.strokeStyle='#111';ctx.lineWidth=1.2;ctx.strokeRect(p.l,p.t,w-p.l-p.r,h-p.t-p.b);ctx.font=`16px ${FONT}`;ctx.textAlign='center';ctx.textBaseline='top';for(const v of ticks(view.x0,view.x1)){const x=sx(v,p,w);ctx.strokeStyle='#d8dee4';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(x,p.t);ctx.lineTo(x,h-p.b);ctx.stroke();ctx.strokeStyle='#111';ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(x,h-p.b);ctx.lineTo(x,h-p.b+7);ctx.stroke();ctx.fillStyle='#111';ctx.fillText(v.toFixed(view.x1-view.x0<1?3:2),x,h-p.b+12)}ctx.font=`19px ${FONT}`;ctx.fillText('Frequency (MHz)',(p.l+w-p.r)/2,h-27);ctx.save();ctx.translate(25,(p.t+h-p.b)/2);ctx.rotate(-Math.PI/2);ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(yLabel,0,0);ctx.restore()}
function stackRange(){const values=[];P.traces.forEach((t,i)=>{if(!enabled[i])return;const off=(P.traces.length-1-i)*P.offsetDb;for(const y of t.lineY)if(Number.isFinite(y))values.push(y+off)});if(!values.length)return[-140,-80];let mn=Math.min(...values),mx=Math.max(...values),q=(mx-mn)*.04;return[mn-q,mx+q]}
function drawStack(){const {w,h}=size(stack,ctxS),yr=stackRange(),sy=y=>h-padS.b-(y-yr[0])/(yr[1]-yr[0])*(h-padS.t-padS.b);ctxS.clearRect(0,0,w,h);axis(ctxS,padS,w,h,`PSD + ${P.offsetDb} dB/trace display offset`);ctxS.font=`16px ${FONT}`;ctxS.textAlign='right';ctxS.textBaseline='middle';for(const v of ticks(yr[0],yr[1],7)){const y=sy(v);ctxS.strokeStyle='#d8dee4';ctxS.lineWidth=.7;ctxS.beginPath();ctxS.moveTo(padS.l,y);ctxS.lineTo(w-padS.r,y);ctxS.stroke();ctxS.strokeStyle='#111';ctxS.lineWidth=1.1;ctxS.beginPath();ctxS.moveTo(padS.l,y);ctxS.lineTo(padS.l-7,y);ctxS.stroke();ctxS.fillStyle='#111';ctxS.fillText(v.toFixed(0),padS.l-12,y)}P.traces.forEach((t,i)=>{if(!enabled[i])return;const off=(P.traces.length-1-i)*P.offsetDb;ctxS.strokeStyle=t.color;ctxS.lineWidth=1.8;ctxS.beginPath();let started=false;for(let k=0;k<t.lineX.length;k++){const x=t.lineX[k],y=t.lineY[k]+off;if(x<view.x0||x>view.x1)continue;const px=sx(x,padS,w),py=sy(y);if(!started){ctxS.moveTo(px,py);started=true}else ctxS.lineTo(px,py)}if(started)ctxS.stroke();const baseline=sy(t.median+off);ctxS.fillStyle=t.color;ctxS.font=`bold 15px ${FONT}`;ctxS.textAlign='right';ctxS.textBaseline='middle';ctxS.fillText(t.label,padS.l-60,baseline)})}
const viridis=['#440154','#3b528b','#21918c','#5ec962','#fde725'];function color(v){let q=Math.max(0,Math.min(1,(v-P.colorMin)/(P.colorMax-P.colorMin||1))),x=q*(viridis.length-1),i=Math.min(viridis.length-2,Math.floor(x)),f=x-i,a=viridis[i].match(/\w\w/g).map(h=>parseInt(h,16)),b=viridis[i+1].match(/\w\w/g).map(h=>parseInt(h,16));return`rgb(${a.map((v,j)=>Math.round(v+(b[j]-v)*f)).join(',')})`}
function drawHeat(){const {w,h}=size(heat,ctxH);ctxH.clearRect(0,0,w,h);axis(ctxH,padH,w,h,'Mode / cavity');const active=P.traces.map((t,i)=>[t,i]).filter(([,i])=>enabled[i]),rowH=(h-padH.t-padH.b)/Math.max(active.length,1);active.forEach(([t,i],row)=>{const top=padH.t+row*rowH,center=top+rowH/2;for(let k=0;k<t.heatX.length;k++){const x=t.heatX[k];if(x<view.x0||x>view.x1)continue;const x0=sx(x,padH,w),x1=k+1<t.heatX.length?sx(t.heatX[k+1],padH,w):x0+2;ctxH.fillStyle=color(t.heatY[k]);ctxH.fillRect(x0,top,Math.max(1.2,x1-x0+1),rowH+0.5)}ctxH.strokeStyle='#111';ctxH.lineWidth=1.1;ctxH.beginPath();ctxH.moveTo(padH.l,center);ctxH.lineTo(padH.l-7,center);ctxH.stroke();ctxH.fillStyle='#111';ctxH.font=`bold 15px ${FONT}`;ctxH.textAlign='right';ctxH.textBaseline='middle';ctxH.fillText(t.label,padH.l-12,center)});const bx=w-padH.r+34,by=padH.t,bh=h-padH.t-padH.b;for(let j=0;j<180;j++){ctxH.fillStyle=color(P.colorMax-(P.colorMax-P.colorMin)*j/179);ctxH.fillRect(bx,by+j*bh/180,18,bh/180+1)}ctxH.strokeStyle='#111';ctxH.lineWidth=1.1;ctxH.strokeRect(bx,by,18,bh);for(const y of [by,by+bh]){ctxH.beginPath();ctxH.moveTo(bx+18,y);ctxH.lineTo(bx+25,y);ctxH.stroke()}ctxH.fillStyle='#111';ctxH.font=`15px ${FONT}`;ctxH.textAlign='left';ctxH.textBaseline='top';ctxH.fillText(P.colorMax.toFixed(1),bx+29,by);ctxH.textBaseline='bottom';ctxH.fillText(P.colorMin.toFixed(1),bx+29,by+bh);ctxH.save();ctxH.translate(bx+90,by+bh/2);ctxH.rotate(-Math.PI/2);ctxH.font=`17px ${FONT}`;ctxH.textAlign='center';ctxH.textBaseline='middle';ctxH.fillText('PSD (dBm/Hz)',0,0);ctxH.restore()}
function drawAll(){drawStack();drawHeat()}
function nearest(t,x){let a=t.lineX,lo=0,hi=a.length-1;while(lo<hi){let m=(lo+hi)>>1;if(a[m]<x)lo=m+1;else hi=m}let i=lo>0&&Math.abs(a[lo-1]-x)<Math.abs(a[lo]-x)?lo-1:lo;return[t.lineX[i],t.lineY[i]]}
function bind(canvas,p,isHeat){canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect(),x=ix(e.clientX-r.left,p,r.width),f=e.deltaY<0?.82:1.22;view.x0=x-(x-view.x0)*f;view.x1=x+(view.x1-x)*f;drawAll()},{passive:false});canvas.addEventListener('dblclick',()=>{view.x0=P.frequencyMin;view.x1=P.frequencyMax;drawAll()});canvas.addEventListener('mousedown',e=>{if(!e.shiftKey)return;drag={x:e.clientX,x0:view.x0,x1:view.x1,w:canvas.getBoundingClientRect().width,p}});window.addEventListener('mouseup',()=>drag=null);canvas.addEventListener('mousemove',e=>{if(drag){const dx=e.clientX-drag.x,span=drag.x1-drag.x0,plotW=drag.w-drag.p.l-drag.p.r;view.x0=drag.x0-dx/plotW*span;view.x1=drag.x1-dx/plotW*span;drawAll();return}const r=canvas.getBoundingClientRect(),px=e.clientX-r.left;if(px<p.l||px>r.width-p.r){tip.style.display='none';return}const x=ix(px,p,r.width);let body=`<b>${x.toFixed(4)} MHz</b>`;if(isHeat){const active=P.traces.map((t,i)=>[t,i]).filter(([,i])=>enabled[i]),row=Math.max(0,Math.min(active.length-1,Math.floor((e.clientY-r.top-p.t)/((r.height-p.t-p.b)/Math.max(active.length,1))))),t=active[row]?.[0];if(t){const q=nearest(t,x);body+=`<br><b>${t.label}</b>: ${q[1].toFixed(2)} dBm/Hz`}}else{P.traces.forEach((t,i)=>{if(!enabled[i])return;const q=nearest(t,x);body+=`<br><span style="color:${t.color};font-weight:700">${t.label}</span>: ${q[1].toFixed(2)} dBm/Hz`})}tip.innerHTML=body;tip.style.display='block';tip.style.left=e.clientX+14+'px';tip.style.top=e.clientY+12+'px'});canvas.addEventListener('mouseleave',()=>tip.style.display='none')}
bind(stack,padS,false);bind(heat,padH,true);window.addEventListener('resize',drawAll);drawAll();
</script>
</body>
</html>'''


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate stacked and waterfall noise PSD comparison HTML")
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--offset-db", type=float, default=10.0)
    args = parser.parse_args()
    summary_path = args.run_dir / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
    result = write_noise_spectrum_comparison(
        args.run_dir,
        summary.get("measurements") or [],
        offset_db=args.offset_db,
    )
    summary["comparison"] = result
    summary["comparison_html"] = result.get("path") if result.get("ok") else None
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for state_path in (args.run_dir.parent / "latest.json", args.run_dir.parent / "progress.json"):
        if not state_path.exists():
            continue
        try:
            state = json.loads(state_path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        if not isinstance(state, dict):
            continue
        recorded_run = Path(str(state.get("run_dir") or ""))
        try:
            is_current_run = recorded_run.resolve() == args.run_dir.resolve()
        except OSError:
            is_current_run = False
        if not is_current_run:
            continue
        state["comparison"] = result
        state["comparison_html"] = summary["comparison_html"]
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
