from __future__ import annotations


import math


def tracking_rejection_reasons(
    *,
    template_ncc: float,
    reliable_ncc_threshold: float,
    template_depth_v: float,
    minimum_template_depth_v: float,
    local_minimum_ok: bool,
) -> list[str]:
    """Return explicit reasons why a template-tracked center is not fit-worthy."""
    reasons: list[str] = []
    if not math.isfinite(template_ncc) or template_ncc < reliable_ncc_threshold:
        reasons.append("template_ncc_below_threshold")
    if not math.isfinite(template_depth_v) or template_depth_v < minimum_template_depth_v:
        reasons.append("template_depth_below_threshold")
    if not local_minimum_ok:
        reasons.append("local_minimum_not_found")
    return reasons


def continuous_prefix_rejection_reasons(
    reasons_by_frame: list[list[str]],
) -> list[list[str]]:
    """Prevent a lost trajectory from reappearing on an unrelated later feature."""
    prefix_open = True
    effective: list[list[str]] = []
    for frame_reasons in reasons_by_frame:
        reasons = list(frame_reasons)
        if prefix_open and reasons:
            prefix_open = False
        elif not prefix_open and not reasons:
            reasons.append("after_unreliable_tracking_point")
        effective.append(reasons)
    return effective
