from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.analysis.spectra'


import argparse
import html
import json
import math
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np


def finite_float(value: Any) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def cavity_number(value: Any) -> int:
    text = str(value or "")
    digits = "".join(character for character in text if character.isdigit())
    return int(digits) if digits else 10**9


def load_summary(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"summary must contain a JSON object: {path}")
    return payload


def completed_by_cavity(summary: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for item in summary.get("measurements") or []:
        if not isinstance(item, dict) or str(item.get("status") or "") != "completed":
            continue
        cavity = str(item.get("cavity") or "").strip()
        raw_path = Path(str(item.get("raw_npz") or ""))
        if cavity and raw_path.exists():
            result[cavity] = dict(item)
    return result


def load_psd(path: Path) -> tuple[np.ndarray, np.ndarray]:
    with np.load(path) as data:
        frequency_hz = np.asarray(data["frequency_hz"], dtype=float)
        psd_dbm_per_hz = np.asarray(data["input1_dbm_per_hz"], dtype=float)
    count = min(frequency_hz.size, psd_dbm_per_hz.size)
    mask = np.isfinite(frequency_hz[:count]) & np.isfinite(psd_dbm_per_hz[:count])
    frequency_hz = frequency_hz[:count][mask]
    psd_dbm_per_hz = psd_dbm_per_hz[:count][mask]
    if frequency_hz.size < 3 or np.any(np.diff(frequency_hz) <= 0):
        raise ValueError(f"invalid frequency axis: {path}")
    return frequency_hz, psd_dbm_per_hz


def interpolate_to(reference_hz: np.ndarray, frequency_hz: np.ndarray, values: np.ndarray) -> np.ndarray:
    if reference_hz.size == frequency_hz.size and np.allclose(reference_hz, frequency_hz, rtol=0, atol=1e-6):
        return values
    return np.interp(reference_hz, frequency_hz, values, left=np.nan, right=np.nan)


def detect_common_tone(
    frequency_hz: np.ndarray,
    before_psd: list[np.ndarray],
    after_psd: list[np.ndarray],
    *,
    search_min_hz: float,
    search_max_hz: float | None,
) -> dict[str, Any]:
    difference = np.vstack(after_psd) - np.vstack(before_psd)
    median_difference = np.nanmedian(difference, axis=0)
    upper_hz = float(search_max_hz) if search_max_hz is not None else float(frequency_hz[-1] * 0.98)
    search_mask = (
        np.isfinite(median_difference)
        & (frequency_hz >= float(search_min_hz))
        & (frequency_hz <= upper_hz)
    )
    if not search_mask.any():
        raise ValueError("tone-search interval contains no finite PSD bins")
    search_indices = np.flatnonzero(search_mask)
    peak_index = int(search_indices[int(np.nanargmax(median_difference[search_mask]))])
    peak_difference = difference[:, peak_index]
    return {
        "frequency_hz": float(frequency_hz[peak_index]),
        "bin_index": peak_index,
        "median_after_minus_before_db": float(np.nanmedian(peak_difference)),
        "mean_after_minus_before_db": float(np.nanmean(peak_difference)),
        "support_count_above_6_db": int(np.sum(peak_difference > 6.0)),
        "trace_count": int(difference.shape[0]),
        "search_min_hz": float(search_min_hz),
        "search_max_hz": upper_hz,
    }


def same_frequency_on_off_snr(
    frequency_hz: np.ndarray,
    before_psd_dbm_per_hz: np.ndarray,
    after_psd_dbm_per_hz: np.ndarray,
    target_hz: float,
    *,
    rbw_hz: float,
    signal_half_width_rbw: float,
) -> dict[str, float | None]:
    offset_hz = np.abs(frequency_hz - float(target_hz))
    signal_mask = offset_hz <= float(signal_half_width_rbw) * rbw_hz
    if not signal_mask.any():
        raise ValueError("signal-search window contains no frequency bins")
    signal_indices = np.flatnonzero(signal_mask)
    local_peak = int(signal_indices[int(np.nanargmax(after_psd_dbm_per_hz[signal_mask]))])
    off_psd = float(before_psd_dbm_per_hz[local_peak])
    on_psd = float(after_psd_dbm_per_hz[local_peak])
    contrast_db = on_psd - off_psd
    power_subtracted_snr_db = None
    if contrast_db > 0:
        power_subtracted_snr_db = 10.0 * math.log10(math.expm1(contrast_db * math.log(10.0) / 10.0))
    return {
        "peak_frequency_hz": float(frequency_hz[local_peak]),
        "off_psd_dbm_per_hz": off_psd,
        "on_psd_dbm_per_hz": on_psd,
        "snr_db": contrast_db,
        "power_subtracted_snr_db": power_subtracted_snr_db,
    }


def rounded(value: Any, digits: int = 6) -> Any:
    if isinstance(value, float):
        return round(value, digits) if math.isfinite(value) else None
    if isinstance(value, dict):
        return {key: rounded(item, digits) for key, item in value.items()}
    if isinstance(value, list):
        return [rounded(item, digits) for item in value]
    return value


def summary_stats(rows: list[dict[str, Any]]) -> dict[str, Any]:
    snr = np.asarray([row["same_frequency"]["snr_db"] for row in rows], dtype=float)
    off_psd = np.asarray([row["same_frequency"]["off_psd_dbm_per_hz"] for row in rows], dtype=float)
    on_psd = np.asarray([row["same_frequency"]["on_psd_dbm_per_hz"] for row in rows], dtype=float)

    def stats(values: np.ndarray) -> dict[str, float]:
        return {
            "median": float(np.median(values)),
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
            "min": float(np.min(values)),
            "max": float(np.max(values)),
        }

    return {
        "cavity_count": len(rows),
        "snr_db": stats(snr),
        "off_psd_dbm_per_hz": stats(off_psd),
        "on_psd_dbm_per_hz": stats(on_psd),
    }


def build_html(payload: dict[str, Any]) -> str:
    chart_payload = {
        "toneKhz": payload["tone_detection"]["frequency_hz"] / 1e3,
        "summary": payload["summary"],
        "rows": [
            {
                "cavity": row["cavity"],
                "family": row["family"],
                "mu": row["mu"],
                "snr": row["same_frequency"]["snr_db"],
                "strictSnr": row["same_frequency"]["power_subtracted_snr_db"],
                "peakKhz": row["same_frequency"]["peak_frequency_hz"] / 1e3,
                "onPsd": row["same_frequency"]["on_psd_dbm_per_hz"],
                "offPsd": row["same_frequency"]["off_psd_dbm_per_hz"],
            }
            for row in payload["cavities"]
        ],
    }
    data = json.dumps(chart_payload, ensure_ascii=False, separators=(",", ":"))
    title = f"各腔 {chart_payload['toneKhz']:.2f} kHz 超声频点信噪比"
    return _html_template().replace("__TITLE__", html.escape(title)).replace("__DATA__", data)


def _html_template() -> str:
    return r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--ink:#111827;--muted:#53606d;--line:#cbd5df;--grid:#e6ebf0;--series:#0072b2;--median:#009e73}
*{box-sizing:border-box}body{margin:0;background:#fff;color:var(--ink);font-family:Arial,"Microsoft YaHei",sans-serif}
main{max-width:1480px;margin:0 auto;padding:22px 26px 30px}h1{font-size:28px;line-height:1.25;margin:0 0 5px;letter-spacing:0}.sub{font-size:16px;color:var(--muted);margin-bottom:15px}
.metrics{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));border:1px solid var(--line);margin-bottom:18px}.metric{padding:11px 14px;border-right:1px solid var(--line)}.metric:last-child{border-right:0}.metric span{display:block;color:var(--muted);font-size:14px}.metric strong{display:block;font-size:22px;margin-top:3px}
.chart{height:650px;border-top:1px solid var(--line);position:relative}svg{width:100%;height:100%;display:block;overflow:visible}.tip{position:fixed;z-index:5;display:none;pointer-events:none;background:#fff;border:1px solid var(--ink);border-radius:4px;padding:9px 11px;font-size:14px;line-height:1.45;box-shadow:0 3px 14px rgba(0,0,0,.18)}
.foot{font-size:14px;color:var(--muted);margin-top:10px}.axis-label{font-size:19px}.tick{font-size:16px}.point{cursor:crosshair}.point:focus{outline:2px solid #111;outline-offset:2px}
@media(max-width:800px){main{padding:14px 10px 24px}.metrics{grid-template-columns:repeat(2,1fr)}.metric:nth-child(2){border-right:0}.metric:nth-child(-n+2){border-bottom:1px solid var(--line)}.chart{height:520px}h1{font-size:24px}}
</style>
</head>
<body><main>
<h1>__TITLE__</h1>
<div class="sub">每个腔均取加超声后的实际峰位，并减去加超声前相同频率 bin 的 PSD。</div>
<div class="metrics" id="metrics"></div>
<div class="chart"><svg id="chart" role="img" aria-label="各腔超声频点信噪比对比图"></svg></div>
<div class="foot">横轴按物理腔编号排序；悬停或聚焦数据点可查看模式族、峰位及同频 ON/OFF PSD。</div>
</main><div class="tip" id="tip"></div>
<script>
const D=__DATA__,svg=document.getElementById('chart'),tip=document.getElementById('tip'),NS='http://www.w3.org/2000/svg';
const colors={series:'#0072b2',median:'#009e73'},font='Arial, Microsoft YaHei, sans-serif';
function el(tag,attrs={},text=''){const n=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,v);if(text)n.textContent=text;return n}
function fmt(v,n=1){return Number(v).toFixed(n)}
function metrics(){const s=D.summary.snr_db;document.getElementById('metrics').innerHTML=`<div class="metric"><span>共同超声频率</span><strong>${fmt(D.toneKhz,2)} kHz</strong></div><div class="metric"><span>同频 SNR 中位数</span><strong>${fmt(s.median)} dB</strong></div><div class="metric"><span>腔间标准差</span><strong>${fmt(s.std)} dB</strong></div><div class="metric"><span>SNR 范围</span><strong>${fmt(s.min)}–${fmt(s.max)} dB</strong></div>`}
function draw(){while(svg.firstChild)svg.removeChild(svg.firstChild);const box=svg.getBoundingClientRect(),w=Math.max(box.width,680),h=Math.max(box.height,420),p={l:92,r:34,t:26,b:78};svg.setAttribute('viewBox',`0 0 ${w} ${h}`);const vals=D.rows.map(r=>r.snr);let ymin=Math.min(0,...vals),ymax=Math.max(10,...vals),span=Math.max(10,ymax-ymin);ymin=Math.floor((ymin-span*.08)/5)*5;ymax=Math.ceil((ymax+span*.12)/5)*5;const x=i=>p.l+i*(w-p.l-p.r)/(D.rows.length-1),y=v=>h-p.b-(v-ymin)/(ymax-ymin)*(h-p.t-p.b);svg.appendChild(el('rect',{x:p.l,y:p.t,width:w-p.l-p.r,height:h-p.t-p.b,fill:'#fff',stroke:'#111827','stroke-width':'1.2'}));for(let v=Math.ceil(ymin/10)*10;v<=ymax;v+=10){const yy=y(v);svg.appendChild(el('line',{x1:p.l,y1:yy,x2:w-p.r,y2:yy,stroke:'#e6ebf0','stroke-width':'1'}));svg.appendChild(el('line',{x1:p.l-7,y1:yy,x2:p.l,y2:yy,stroke:'#111827','stroke-width':'1.2'}));svg.appendChild(el('text',{x:p.l-13,y:yy+5,'text-anchor':'end',class:'tick','font-family':font},String(v)))}const medianY=y(D.summary.snr_db.median);svg.appendChild(el('line',{x1:p.l,y1:medianY,x2:w-p.r,y2:medianY,stroke:colors.median,'stroke-width':'2','stroke-dasharray':'8 6'}));D.rows.forEach((r,i)=>{const xx=x(i),yy=y(r.snr);svg.appendChild(el('line',{x1:xx,y1:y(0),x2:xx,y2:yy,stroke:'#b9c4ce','stroke-width':'2'}));svg.appendChild(el('line',{x1:xx,y1:h-p.b,x2:xx,y2:h-p.b+7,stroke:'#111827','stroke-width':'1.1'}));svg.appendChild(el('text',{x:xx,y:h-p.b+29,'text-anchor':'middle',class:'tick','font-family':font},r.cavity));point(r,xx,yy)});svg.appendChild(el('text',{x:(p.l+w-p.r)/2,y:h-18,'text-anchor':'middle',class:'axis-label','font-family':font},'物理腔编号'));svg.appendChild(el('text',{x:24,y:(p.t+h-p.b)/2,'text-anchor':'middle',class:'axis-label','font-family':font,transform:`rotate(-90 24 ${(p.t+h-p.b)/2})`},'同频 ON/OFF SNR (dB)'))}
function point(r,xx,yy){const node=el('circle',{cx:xx,cy:yy,r:7,fill:colors.series,stroke:'#fff','stroke-width':'1.8',class:'point',tabindex:'0'});const body=()=>`<b>${r.cavity} · ${r.family}, μ=${r.mu}</b><br>同频 SNR: ${fmt(r.snr,2)} dB<br>峰位: ${fmt(r.peakKhz,3)} kHz<br>加超声后 PSD: ${fmt(r.onPsd,2)} dBm/Hz<br>加超声前同频 PSD: ${fmt(r.offPsd,2)} dBm/Hz`;node.addEventListener('mouseenter',e=>showTip(e,body()));node.addEventListener('mousemove',e=>showTip(e,body()));node.addEventListener('mouseleave',hideTip);node.addEventListener('focus',e=>{const b=node.getBoundingClientRect();showTip({clientX:b.left,clientY:b.top},body())});node.addEventListener('blur',hideTip);svg.appendChild(node)}
function showTip(e,body){tip.innerHTML=body;tip.style.display='block';let left=e.clientX+14,top=e.clientY+12;if(left+tip.offsetWidth>innerWidth-8)left=e.clientX-tip.offsetWidth-14;if(top+tip.offsetHeight>innerHeight-8)top=e.clientY-tip.offsetHeight-12;tip.style.left=left+'px';tip.style.top=top+'px'}function hideTip(){tip.style.display='none'}
window.addEventListener('resize',draw);metrics();draw();
</script></body></html>'''


def analyze(
    before_summary_path: Path,
    after_summary_path: Path,
    output_dir: Path,
    *,
    target_frequency_hz: float | None = None,
    search_min_hz: float = 10_000.0,
    search_max_hz: float | None = None,
    signal_half_width_rbw: float = 2.0,
) -> dict[str, Any]:
    before_summary_path = before_summary_path.resolve()
    after_summary_path = after_summary_path.resolve()
    output_dir = output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"refusing to overwrite non-empty output directory: {output_dir}")

    before_summary = load_summary(before_summary_path)
    after_summary = load_summary(after_summary_path)
    before_rows = completed_by_cavity(before_summary)
    after_rows = completed_by_cavity(after_summary)
    cavities = sorted(set(before_rows) & set(after_rows), key=cavity_number)
    if not cavities:
        raise ValueError("the two runs have no completed cavity in common")

    rbw_hz = finite_float((load_summary(before_summary_path.parent / "run_config.json")).get("spectrum_rbw_hz"))
    if rbw_hz is None or rbw_hz <= 0:
        raise ValueError("before run_config.json does not contain a positive spectrum_rbw_hz")
    after_rbw = finite_float((load_summary(after_summary_path.parent / "run_config.json")).get("spectrum_rbw_hz"))
    if after_rbw is None or not math.isclose(rbw_hz, after_rbw, rel_tol=1e-6, abs_tol=1e-6):
        raise ValueError(f"RBW mismatch: before={rbw_hz}, after={after_rbw}")

    reference_hz: np.ndarray | None = None
    before_psd: list[np.ndarray] = []
    after_psd: list[np.ndarray] = []
    for cavity in cavities:
        before_frequency, before_values = load_psd(Path(str(before_rows[cavity]["raw_npz"])))
        after_frequency, after_values = load_psd(Path(str(after_rows[cavity]["raw_npz"])))
        if reference_hz is None:
            reference_hz = before_frequency
        before_psd.append(interpolate_to(reference_hz, before_frequency, before_values))
        after_psd.append(interpolate_to(reference_hz, after_frequency, after_values))
    assert reference_hz is not None

    detection = detect_common_tone(
        reference_hz,
        before_psd,
        after_psd,
        search_min_hz=search_min_hz,
        search_max_hz=search_max_hz,
    )
    if target_frequency_hz is not None:
        detection["auto_detected_frequency_hz"] = detection["frequency_hz"]
        detection["frequency_hz"] = float(target_frequency_hz)
        detection["source"] = "explicit"
    else:
        detection["source"] = "median after-minus-before maximum across matched cavities"

    rows: list[dict[str, Any]] = []
    for index, cavity in enumerate(cavities):
        same_frequency_result = same_frequency_on_off_snr(
            reference_hz,
            before_psd[index],
            after_psd[index],
            detection["frequency_hz"],
            rbw_hz=rbw_hz,
            signal_half_width_rbw=signal_half_width_rbw,
        )
        metadata = after_rows[cavity]
        rows.append(
            {
                "cavity": cavity,
                "cavity_index": cavity_number(cavity),
                "family": metadata.get("family"),
                "mu": metadata.get("mu"),
                "comb_index": metadata.get("comb_index"),
                "wavelength_nm": metadata.get("wavelength_nm"),
                "before_raw_npz": str(Path(str(before_rows[cavity]["raw_npz"])).resolve()),
                "after_raw_npz": str(Path(str(after_rows[cavity]["raw_npz"])).resolve()),
                "same_frequency": same_frequency_result,
            }
        )

    payload = {
        "schema_version": 2,
        "analysis_kind": "ultrasound_tone_same_frequency_on_off_snr_by_cavity",
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "chip": after_summary.get("chip"),
        "die": after_summary.get("die"),
        "before_run": {
            "label": "加超声前",
            "summary_json": str(before_summary_path),
            "run_dir": str(before_summary_path.parent),
            "started_at": before_summary.get("started_at"),
        },
        "after_run": {
            "label": "加超声后",
            "summary_json": str(after_summary_path),
            "run_dir": str(after_summary_path.parent),
            "started_at": after_summary.get("started_at"),
        },
        "tone_detection": detection,
        "snr_definition": {
            "name": "paired same-frequency ON/OFF PSD contrast",
            "formula": "SNR_dB = P_on(f0) - P_off(f0)",
            "f0_selection": "For each cavity, maximize the after-run PSD within the signal-search window around the common detected tone, then use that exact frequency bin in both runs.",
            "unit": "dB",
            "psd_unit": "dBm/Hz",
            "rbw_hz": rbw_hz,
            "signal_half_width_rbw": signal_half_width_rbw,
            "signal_half_width_hz": signal_half_width_rbw * rbw_hz,
            "strict_power_subtraction_formula": "10*log10(10^(SNR_dB/10)-1)",
            "note": "The reported snr_db follows the laboratory's established same-frequency subtraction convention. power_subtracted_snr_db is also stored; at these high contrasts the numerical correction is negligible.",
        },
        "summary": summary_stats(rows),
        "cavities": rows,
    }
    payload = rounded(payload)
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "ultrasound_snr_by_cavity.json"
    html_path = output_dir / "ultrasound_snr_comparison.html"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    html_path.write_text(build_html(payload), encoding="utf-8")
    return {
        "ok": True,
        "json_path": str(json_path),
        "html_path": str(html_path),
        "tone_frequency_hz": payload["tone_detection"]["frequency_hz"],
        "summary": payload["summary"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare before/after noise PSD runs at a common ultrasound tone")
    parser.add_argument("before_summary", type=Path)
    parser.add_argument("after_summary", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--target-frequency-hz", type=float)
    parser.add_argument("--search-min-hz", type=float, default=10_000.0)
    parser.add_argument("--search-max-hz", type=float)
    args = parser.parse_args()
    result = analyze(
        args.before_summary,
        args.after_summary,
        args.output_dir,
        target_frequency_hz=args.target_frequency_hz,
        search_min_hz=args.search_min_hz,
        search_max_hz=args.search_max_hz,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
