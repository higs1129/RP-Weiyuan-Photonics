"""Pre-analyze array-cavity large-scan spectra before thermal tuning.

This script intentionally stops before cavity identity assignment and final Q
fitting.  It calibrates the broad scan with the MZI trace, estimates the
dominant array FSR from pairwise resonance spacings, then folds resonances into
one FSR and clusters them into array-mode families.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.analysis.large_scan'

#!/usr/bin/env python3


from dataclasses import dataclass, field

import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import curve_fit, linear_sum_assignment
from scipy.signal import find_peaks


from a221_workbench.tasks.analysis.optical_q import fit_notch_window, notch_quality_factors
from a221_workbench.tasks.analysis.optical_q import choose_half_window, estimate_initial_gamma, lorentzian_notch

from a221_workbench._shared.chip7_design import C_M_PER_S, DEFAULT_NG_ESTIMATE
from a221_workbench.tasks.analysis.large_scan.process_large_scan import (
    die_design_info,
    expected_array_fsr_mhz,
    finite_float,
    find_array_design_path,
    find_mzi_index,
    find_transmission_dips,
    normalize_transmission_with_baseline,
    plot_envelope_xy,
    read_large_scan_data,
    relative_frequency_mhz,
)


plt.rcParams.update(
    {
        "font.size": 14,
        "axes.titlesize": 20,
        "axes.labelsize": 17,
        "xtick.labelsize": 14,
        "ytick.labelsize": 14,
        "legend.fontsize": 13,
        "lines.linewidth": 2.2,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
    }
)


def infer_chip_die_cavity(data_path: Path) -> tuple[str, str, str]:
    parts = list(data_path.resolve().parts)
    chip = ""
    die = ""
    cavity = ""
    for i, part in enumerate(parts):
        lower = part.lower()
        if re.fullmatch(r"chip\d+", lower):
            chip = part
            if i + 1 < len(parts):
                die = parts[i + 1]
            if i + 2 < len(parts) and parts[i + 2].lower() != "q":
                cavity = parts[i + 2]
            break
    if not cavity and data_path.parent.name.lower() != "q":
        cavity = data_path.parent.name
    return chip or "unknown_chip", die or "unknown_die", cavity or ""


def infer_expected_families(chip: str) -> int | None:
    lower = chip.lower()
    if lower == "chip8":
        return 9
    if lower == "chip9":
        return 16
    return None


def design_radius_um_for_target(
    *,
    data_path: Path,
    output_dir: Path,
    chip: str,
    die: str,
    cavity: str,
) -> tuple[float, str] | None:
    design_path = find_array_design_path(output_dir, data_path)
    if design_path is None:
        return None
    design = json.loads(design_path.read_text(encoding="utf-8-sig"))
    if not isinstance(design, dict):
        return None
    radius_um = finite_float(design.get("baseline_radius_um"))
    if radius_um is None or radius_um <= 0:
        return None
    target_cavity = cavity if cavity not in {"", "."} else str(design.get("baseline_cavity") or "")
    offsets = design.get("cavity_radius_offset_steps")
    info = die_design_info(design, die)
    radius_step_nm = finite_float(info.get("radius_step_nm"))
    if target_cavity and isinstance(offsets, dict) and radius_step_nm is not None:
        offset_steps = finite_float(offsets.get(target_cavity))
        if offset_steps is not None:
            radius_um += offset_steps * radius_step_nm / 1000.0
    if radius_um <= 0:
        return None
    source = f"{design_path} baseline/ng-reference radius for {chip}/{die}/{target_cavity or 'baseline'}"
    return radius_um, source


def group_index_for_frequency(freq_mhz: np.ndarray, fold_origin_mhz: float, fsr_mhz: float) -> np.ndarray:
    return np.floor((freq_mhz - fold_origin_mhz) / fsr_mhz).astype(int)


def choose_mode_zero_reference(mode_number_ref: np.ndarray, wavelength_nm: np.ndarray, *, center_nm: float) -> dict[str, Any]:
    candidates: list[dict[str, Any]] = []
    for mode in sorted(set(int(item) for item in mode_number_ref)):
        mask = mode_number_ref == mode
        wavelengths = wavelength_nm[mask]
        wavelengths = wavelengths[np.isfinite(wavelengths)]
        if len(wavelengths) == 0:
            continue
        nearest_i = int(np.argmin(np.abs(wavelengths - center_nm)))
        candidates.append(
            {
                "mode_number_ref": int(mode),
                "center_nm": float(center_nm),
                "mean_wavelength_nm": float(np.mean(wavelengths)),
                "median_wavelength_nm": float(np.median(wavelengths)),
                "nearest_wavelength_nm": float(wavelengths[nearest_i]),
                "nearest_abs_error_nm": float(abs(wavelengths[nearest_i] - center_nm)),
                "point_count": int(len(wavelengths)),
            }
        )
    if not candidates:
        return {
            "mode_number_ref": 0,
            "center_nm": float(center_nm),
            "source": "fallback_no_wavelength_candidates",
        }
    best = sorted(candidates, key=lambda item: (item["nearest_abs_error_nm"], -item["point_count"], abs(item["mode_number_ref"])))[0]
    best["source"] = "nearest_resonance_to_center_nm"
    return best


def sample_mzi_mu(n: int, mzi_index: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if len(mzi_index) < 2:
        return np.array([], dtype=int), np.array([], dtype=float)
    start = int(mzi_index[0])
    stop = int(mzi_index[-1])
    sample_idx = np.arange(start, stop + 1, dtype=int)
    extrema_mu = np.arange(len(mzi_index), dtype=float) / 2.0
    mu = np.interp(sample_idx.astype(float), mzi_index.astype(float), extrema_mu)
    return sample_idx, mu


def time_to_wavelength_nm(time_s: np.ndarray, *, start_nm: float, center_nm: float, stop_nm: float) -> np.ndarray:
    return center_nm + (stop_nm - start_nm) / 20.0 * time_s


def wavelength_nm_to_freq_mhz(wavelength_nm: np.ndarray | float) -> np.ndarray | float:
    return C_M_PER_S / (np.asarray(wavelength_nm) * 1e-9) / 1e6


def freq_mhz_to_wavelength_nm(freq_mhz: np.ndarray | float) -> np.ndarray | float:
    return C_M_PER_S / (np.asarray(freq_mhz) * 1e6) * 1e9


def read_acquisition_metadata(data_path: Path, output_dir: Path) -> tuple[dict[str, Any], Path | None]:
    candidates = [
        output_dir / "acquisition.json",
        data_path.parent / "acquisition.json",
        data_path.with_suffix(".json"),
        data_path.parent / f"{data_path.stem}.json",
    ]
    seen: set[Path] = set()
    for path in candidates:
        path = path.resolve()
        if path in seen:
            continue
        seen.add(path)
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        if isinstance(payload, dict):
            return payload, path
    return {}, None


def laser_start_anchor_from_metadata(
    metadata: dict[str, Any],
    *,
    nominal_start_nm: float,
    max_delta_nm: float = 2.0,
) -> dict[str, Any]:
    preferred_fields = [
        "laser_start_readback_after_emission_cycle_nm",
        "laser_start_readback_after_smile_cycle_nm",
        "laser_start_readback_nm",
    ]
    checked: list[dict[str, Any]] = []
    for field in preferred_fields:
        value = finite_float(metadata.get(field))
        checked.append({"field": field, "value_nm": value})
        if value is None:
            continue
        delta_nm = float(value) - float(nominal_start_nm)
        if abs(delta_nm) > max_delta_nm:
            checked[-1]["rejected"] = f"|delta_nm| > {max_delta_nm:g}"
            continue
        nominal_start_freq_mhz = float(wavelength_nm_to_freq_mhz(nominal_start_nm))
        actual_start_freq_mhz = float(wavelength_nm_to_freq_mhz(value))
        return {
            "ok": True,
            "source": field,
            "anchor_nm": float(value),
            "nominal_start_nm": float(nominal_start_nm),
            "delta_nm": delta_nm,
            "anchor_freq_mhz": actual_start_freq_mhz,
            "nominal_start_freq_mhz": nominal_start_freq_mhz,
            "freq_offset_mhz": actual_start_freq_mhz - nominal_start_freq_mhz,
            "checked": checked,
        }
    return {
        "ok": False,
        "source": "linear_time_axis_fallback",
        "nominal_start_nm": float(nominal_start_nm),
        "checked": checked,
        "message": "No usable TOPTICA start readback found near the configured start wavelength.",
    }


def trigger_level_and_slope(metadata: dict[str, Any]) -> tuple[float, str]:
    config = metadata.get("config") if isinstance(metadata.get("config"), dict) else {}
    level = finite_float(config.get("trigger_level_v"))
    if level is None:
        level = finite_float(metadata.get("trigger_level_v"))
    if level is None:
        level = 1.0
    slope = str(config.get("trigger_slope") or metadata.get("trigger_slope") or "positive").strip().lower()
    if slope not in {"positive", "negative"}:
        slope = "positive"
    return float(level), slope


def trigger_anchor_from_trace(
    *,
    time_s: np.ndarray,
    trigger: np.ndarray,
    valid_idx: np.ndarray,
    rel_freq_trace_mhz: np.ndarray,
    metadata: dict[str, Any],
    center_nm: float,
) -> dict[str, Any]:
    if len(trigger) == 0 or not np.any(np.isfinite(trigger)):
        return {"ok": False, "source": "trigger_unavailable", "message": "No finite trigger channel samples."}
    if len(valid_idx) == 0 or len(rel_freq_trace_mhz) == 0:
        return {"ok": False, "source": "trigger_unavailable", "message": "No finite MZI frequency axis for trigger anchoring."}

    level, slope = trigger_level_and_slope(metadata)
    y = np.asarray(trigger, dtype=float)
    t = np.asarray(time_s, dtype=float)
    finite = np.isfinite(y[:-1]) & np.isfinite(y[1:]) & np.isfinite(t[:-1]) & np.isfinite(t[1:])
    if slope == "negative":
        crossing_mask = finite & (y[:-1] >= level) & (y[1:] < level)
    else:
        crossing_mask = finite & (y[:-1] <= level) & (y[1:] > level)
    crossing_indices = np.where(crossing_mask)[0]
    if len(crossing_indices) == 0:
        return {
            "ok": False,
            "source": "trigger_edge_not_found",
            "trigger_level_v": level,
            "trigger_slope": slope,
            "trigger_min_v": float(np.nanmin(y)),
            "trigger_max_v": float(np.nanmax(y)),
        }

    candidates: list[dict[str, float]] = []
    for idx in crossing_indices:
        y0 = float(y[idx])
        y1 = float(y[idx + 1])
        frac = 0.0 if y1 == y0 else (level - y0) / (y1 - y0)
        frac = min(1.0, max(0.0, frac))
        sample_index = float(idx) + frac
        time_cross = float(t[idx] + frac * (t[idx + 1] - t[idx]))
        candidates.append({"sample_index": sample_index, "time_s": time_cross})
    selected = min(candidates, key=lambda item: abs(item["time_s"]))
    sample_index = float(selected["sample_index"])
    if sample_index < float(valid_idx[0]) or sample_index > float(valid_idx[-1]):
        return {
            "ok": False,
            "source": "trigger_edge_outside_mzi_range",
            "trigger_sample_index": sample_index,
            "trigger_time_s": float(selected["time_s"]),
            "mzi_valid_sample_min": int(valid_idx[0]),
            "mzi_valid_sample_max": int(valid_idx[-1]),
        }

    rel_at_trigger_mhz = float(np.interp(sample_index, valid_idx.astype(float), rel_freq_trace_mhz))
    center_freq_mhz = float(wavelength_nm_to_freq_mhz(center_nm))
    return {
        "ok": True,
        "source": "scope_trigger_edge_center_nm",
        "anchor_nm": float(center_nm),
        "anchor_freq_mhz": center_freq_mhz,
        "trigger_level_v": level,
        "trigger_slope": slope,
        "trigger_time_s": float(selected["time_s"]),
        "trigger_sample_index": sample_index,
        "relative_freq_at_trigger_mhz": rel_at_trigger_mhz,
        "freq_offset_mhz": -rel_at_trigger_mhz,
        "candidate_count": int(len(candidates)),
        "note": "MZI relative frequency is shifted so CH1 large-scan trigger edge is the absolute center wavelength.",
    }


def absolute_wavelength_anchor(
    *,
    metadata: dict[str, Any],
    time_s: np.ndarray,
    trigger: np.ndarray,
    valid_idx: np.ndarray,
    rel_freq_trace_mhz: np.ndarray,
    start_nm: float,
    center_nm: float,
) -> dict[str, Any]:
    trigger_anchor = trigger_anchor_from_trace(
        time_s=time_s,
        trigger=trigger,
        valid_idx=valid_idx,
        rel_freq_trace_mhz=rel_freq_trace_mhz,
        metadata=metadata,
        center_nm=center_nm,
    )
    if trigger_anchor.get("ok"):
        trigger_anchor["fallback"] = laser_start_anchor_from_metadata(metadata, nominal_start_nm=start_nm)
        return trigger_anchor
    laser_anchor = laser_start_anchor_from_metadata(metadata, nominal_start_nm=start_nm)
    laser_anchor["trigger_anchor_attempt"] = trigger_anchor
    return laser_anchor


def write_laser_readback_comparison_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "index",
        "ok",
        "scope_time_estimate_s",
        "scope_time_command_estimate_s",
        "read_started_elapsed_s",
        "read_finished_elapsed_s",
        "read_duration_s",
        "laser_readback_nm",
        "mzi_calibrated_nm",
        "laser_minus_mzi_nm",
        "laser_minus_mzi_ghz",
        "in_scope_range",
        "error",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fieldnames})


def compare_laser_readbacks_to_mzi(
    metadata: dict[str, Any],
    *,
    time_s: np.ndarray,
    wavelength_axis_nm: np.ndarray,
    absolute_wavelength_calibration: dict[str, Any],
    mzi_d1_mhz: float,
    output_path: Path,
) -> dict[str, Any]:
    raw_samples = metadata.get("laser_scan_readback_samples")
    if not isinstance(raw_samples, list) or not raw_samples:
        return {"ok": False, "reason": "no_laser_scan_readback_samples"}

    config = metadata.get("config") if isinstance(metadata.get("config"), dict) else {}
    pre_trigger_seconds = finite_float(config.get("pre_trigger_seconds"))
    finite_axis = np.isfinite(time_s) & np.isfinite(wavelength_axis_nm)
    if np.sum(finite_axis) < 2:
        return {"ok": False, "reason": "no_finite_mzi_wavelength_axis"}

    time_valid = np.asarray(time_s[finite_axis], dtype=float)
    wavelength_valid = np.asarray(wavelength_axis_nm[finite_axis], dtype=float)
    order = np.argsort(time_valid)
    time_valid = time_valid[order]
    wavelength_valid = wavelength_valid[order]
    t_min = float(time_valid[0])
    t_max = float(time_valid[-1])

    center_nm = finite_float(absolute_wavelength_calibration.get("anchor_nm"))
    if center_nm is None:
        start_nm = finite_float(config.get("start_nm"))
        stop_nm = finite_float(config.get("stop_nm"))
        if start_nm is not None and stop_nm is not None:
            center_nm = 0.5 * (start_nm + stop_nm)
    trigger_time_s = finite_float(absolute_wavelength_calibration.get("trigger_time_s"))
    if trigger_time_s is None:
        trigger_time_s = 0.0
    elapsed_pairs: list[tuple[float, float]] = []
    for sample in raw_samples:
        if not isinstance(sample, dict):
            continue
        elapsed = finite_float(sample.get("elapsed_since_scan_command_s"))
        laser_nm = finite_float(sample.get("wavelength_nm"))
        if elapsed is not None and laser_nm is not None:
            elapsed_pairs.append((elapsed, laser_nm))
    laser_center_elapsed_s = None
    if center_nm is not None and len(elapsed_pairs) >= 2:
        elapsed_pairs = sorted(elapsed_pairs)
        for (t0, wl0), (t1, wl1) in zip(elapsed_pairs[:-1], elapsed_pairs[1:]):
            if wl1 == wl0:
                continue
            lo = min(wl0, wl1)
            hi = max(wl0, wl1)
            if lo <= center_nm <= hi:
                frac = (center_nm - wl0) / (wl1 - wl0)
                laser_center_elapsed_s = float(t0 + frac * (t1 - t0))
                break

    rows: list[dict[str, Any]] = []
    for sample in raw_samples:
        if not isinstance(sample, dict):
            continue
        laser_nm = finite_float(sample.get("wavelength_nm"))
        elapsed = finite_float(sample.get("elapsed_since_scan_command_s"))
        command_scope_time_s = None
        if elapsed is not None and pre_trigger_seconds is not None:
            command_scope_time_s = elapsed - pre_trigger_seconds
        if elapsed is not None and laser_center_elapsed_s is not None:
            scope_time_s = elapsed - laser_center_elapsed_s + trigger_time_s
        else:
            scope_time_s = finite_float(sample.get("scope_time_estimate_s"))
            if scope_time_s is None:
                scope_time_s = command_scope_time_s
        read_started = finite_float(sample.get("read_started_elapsed_s"))
        read_finished = finite_float(sample.get("read_finished_elapsed_s"))
        read_duration = finite_float(sample.get("read_duration_s"))
        in_scope_range = scope_time_s is not None and t_min <= scope_time_s <= t_max
        row: dict[str, Any] = {
            "index": sample.get("index", ""),
            "ok": bool(sample.get("ok")) and laser_nm is not None and in_scope_range,
            "scope_time_estimate_s": scope_time_s,
            "scope_time_command_estimate_s": command_scope_time_s,
            "read_started_elapsed_s": read_started,
            "read_finished_elapsed_s": read_finished,
            "read_duration_s": read_duration,
            "laser_readback_nm": laser_nm,
            "in_scope_range": bool(in_scope_range),
            "error": sample.get("error") or "",
        }
        if laser_nm is not None and scope_time_s is not None and in_scope_range:
            mzi_nm = float(np.interp(scope_time_s, time_valid, wavelength_valid))
            laser_freq_mhz = float(wavelength_nm_to_freq_mhz(laser_nm))
            mzi_freq_mhz = float(wavelength_nm_to_freq_mhz(mzi_nm))
            row.update(
                {
                    "mzi_calibrated_nm": mzi_nm,
                    "laser_minus_mzi_nm": float(laser_nm - mzi_nm),
                    "laser_minus_mzi_ghz": float((laser_freq_mhz - mzi_freq_mhz) / 1000.0),
                }
            )
        rows.append(row)

    write_laser_readback_comparison_csv(output_path, rows)
    finite_delta_nm = np.array([finite_float(row.get("laser_minus_mzi_nm")) for row in rows], dtype=object)
    finite_delta_nm = np.array([float(item) for item in finite_delta_nm if item is not None and math.isfinite(float(item))])
    finite_delta_ghz = np.array([finite_float(row.get("laser_minus_mzi_ghz")) for row in rows], dtype=object)
    finite_delta_ghz = np.array([float(item) for item in finite_delta_ghz if item is not None and math.isfinite(float(item))])
    read_durations = np.array([finite_float(row.get("read_duration_s")) for row in rows], dtype=object)
    read_durations = np.array([float(item) for item in read_durations if item is not None and math.isfinite(float(item))])
    stats: dict[str, Any] = {
        "ok": len(finite_delta_nm) > 0,
        "path": str(output_path),
        "sample_count": len(rows),
        "compared_count": int(len(finite_delta_nm)),
        "time_basis": (
            "TOPTICA readback midpoint is aligned to scope time by matching the laser readback center wavelength "
            "to the CH1 trigger edge when that crossing is available; otherwise it falls back to command-start time."
        ),
        "alignment": {
            "method": "laser_readback_center_crossing"
            if laser_center_elapsed_s is not None
            else "command_start_minus_pre_trigger_fallback",
            "center_nm": center_nm,
            "laser_center_elapsed_s": laser_center_elapsed_s,
            "scope_trigger_time_s": trigger_time_s,
            "command_start_trigger_offset_s": (
                float(laser_center_elapsed_s - pre_trigger_seconds)
                if laser_center_elapsed_s is not None and pre_trigger_seconds is not None
                else None
            ),
        },
    }
    if len(finite_delta_nm):
        stats.update(
            {
                "mean_delta_nm": float(np.mean(finite_delta_nm)),
                "std_delta_nm": float(np.std(finite_delta_nm)),
                "max_abs_delta_nm": float(np.max(np.abs(finite_delta_nm))),
                "mean_delta_ghz": float(np.mean(finite_delta_ghz)),
                "std_delta_ghz": float(np.std(finite_delta_ghz)),
                "max_abs_delta_ghz": float(np.max(np.abs(finite_delta_ghz))),
            }
        )
    if len(read_durations):
        stats.update(
            {
                "mean_read_duration_s": float(np.mean(read_durations)),
                "max_read_duration_s": float(np.max(read_durations)),
            }
        )
    region_stats: dict[str, Any] = {}
    linear_fit: dict[str, Any] = {}
    for name, max_abs_time_s in (("all", None), ("center_pm8s", 8.0), ("center_pm5s", 5.0)):
        region_delta_nm: list[float] = []
        region_delta_ghz: list[float] = []
        fit_time_s: list[float] = []
        fit_readback_ghz: list[float] = []
        fit_mzi_ghz: list[float] = []
        for row in rows:
            scope_time_s = finite_float(row.get("scope_time_estimate_s"))
            delta_nm = finite_float(row.get("laser_minus_mzi_nm"))
            delta_ghz = finite_float(row.get("laser_minus_mzi_ghz"))
            laser_nm = finite_float(row.get("laser_readback_nm"))
            mzi_nm = finite_float(row.get("mzi_calibrated_nm"))
            if delta_nm is None or delta_ghz is None:
                continue
            if max_abs_time_s is not None and (scope_time_s is None or abs(scope_time_s) > max_abs_time_s):
                continue
            region_delta_nm.append(float(delta_nm))
            region_delta_ghz.append(float(delta_ghz))
            if scope_time_s is not None and laser_nm is not None and mzi_nm is not None:
                fit_time_s.append(float(scope_time_s))
                fit_readback_ghz.append(float(wavelength_nm_to_freq_mhz(laser_nm)) / 1000.0)
                fit_mzi_ghz.append(float(wavelength_nm_to_freq_mhz(mzi_nm)) / 1000.0)
        if not region_delta_nm:
            region_stats[name] = {"count": 0}
            linear_fit[name] = {"count": 0}
            continue
        arr_nm = np.asarray(region_delta_nm, dtype=float)
        arr_ghz = np.asarray(region_delta_ghz, dtype=float)
        region_stats[name] = {
            "count": int(len(arr_nm)),
            "mean_delta_nm": float(np.mean(arr_nm)),
            "std_delta_nm": float(np.std(arr_nm)),
            "max_abs_delta_nm": float(np.max(np.abs(arr_nm))),
            "mean_delta_ghz": float(np.mean(arr_ghz)),
            "std_delta_ghz": float(np.std(arr_ghz)),
            "max_abs_delta_ghz": float(np.max(np.abs(arr_ghz))),
        }
        if len(fit_time_s) >= 2:
            fit_t = np.asarray(fit_time_s, dtype=float)
            fit_readback = np.asarray(fit_readback_ghz, dtype=float)
            fit_mzi = np.asarray(fit_mzi_ghz, dtype=float)
            readback_slope, readback_intercept = [float(v) for v in np.polyfit(fit_t, fit_readback, 1)]
            mzi_slope, mzi_intercept = [float(v) for v in np.polyfit(fit_t, fit_mzi, 1)]
            slope_ratio = readback_slope / mzi_slope if mzi_slope != 0 else math.nan
            linear_fit[name] = {
                "count": int(len(fit_t)),
                "readback_slope_ghz_per_s": readback_slope,
                "readback_intercept_ghz": readback_intercept,
                "mzi_slope_ghz_per_s": mzi_slope,
                "mzi_intercept_ghz": mzi_intercept,
                "slope_ratio_readback_over_mzi": float(slope_ratio),
                "mzi_d1_mhz": float(mzi_d1_mhz),
                "corrected_mzi_d1_mhz": float(mzi_d1_mhz * slope_ratio) if math.isfinite(slope_ratio) else math.nan,
            }
        else:
            linear_fit[name] = {"count": int(len(fit_time_s))}
    stats["region_stats"] = region_stats
    stats["linear_fit"] = linear_fit
    recommended = linear_fit.get("center_pm8s") or linear_fit.get("all") or {}
    recommended_ratio = finite_float(recommended.get("slope_ratio_readback_over_mzi"))
    stats["recommended_slope_correction"] = {
        "source_region": "center_pm8s" if finite_float((linear_fit.get("center_pm8s") or {}).get("slope_ratio_readback_over_mzi")) is not None else "all",
        "slope_ratio_readback_over_mzi": recommended_ratio,
        "mzi_d1_mhz": float(mzi_d1_mhz),
        "corrected_mzi_d1_mhz": float(mzi_d1_mhz * recommended_ratio)
        if recommended_ratio is not None
        else None,
        "note": "Assuming TOPTICA readback is globally accurate, scale the MZI relative-frequency axis by this ratio around the 1550 nm trigger anchor.",
    }
    return stats


def add_slope_corrected_wavelengths(
    q_rows: list[dict[str, Any]],
    *,
    laser_readback_comparison: dict[str, Any],
    anchor_freq_mhz: float | None,
) -> None:
    correction = laser_readback_comparison.get("recommended_slope_correction")
    if not isinstance(correction, dict):
        return
    ratio = finite_float(correction.get("slope_ratio_readback_over_mzi"))
    if ratio is None or anchor_freq_mhz is None:
        return
    for row in q_rows:
        freq_mhz = finite_float(row.get("absolute_freq_mhz"))
        if freq_mhz is None:
            continue
        corrected_freq_mhz = float(anchor_freq_mhz) + ratio * (freq_mhz - float(anchor_freq_mhz))
        row["absolute_freq_mhz_slope_corrected"] = corrected_freq_mhz
        row["wavelength_nm_slope_corrected"] = float(freq_mhz_to_wavelength_nm(corrected_freq_mhz))
        row["mzi_readback_slope_ratio"] = ratio
        row["mzi_readback_slope_region"] = correction.get("source_region") or ""


def robust_depth_weights(depth: np.ndarray) -> np.ndarray:
    finite = depth[np.isfinite(depth)]
    if len(finite) == 0:
        return np.ones_like(depth)
    lo = float(np.quantile(finite, 0.20))
    hi = float(np.quantile(finite, 0.95))
    if hi <= lo:
        hi = float(np.max(finite))
    if hi <= lo:
        return np.ones_like(depth)
    weights = (depth - lo) / (hi - lo)
    return np.clip(weights, 0.05, 1.0)


def auto_pair_spacing_range_ghz(
    freq_ghz: np.ndarray,
    *,
    expected_families: int | None,
    bin_ghz: float,
    min_ghz: float | None,
    max_ghz: float | None,
) -> tuple[float, float]:
    finite = np.sort(freq_ghz[np.isfinite(freq_ghz)])
    if len(finite) < 2:
        lo = min_ghz if min_ghz is not None else bin_ghz * 2.0
        hi = max_ghz if max_ghz is not None else lo + bin_ghz * 10.0
        return float(lo), float(max(hi, lo + bin_ghz))

    span = float(finite[-1] - finite[0])
    adjacent = np.diff(finite)
    adjacent = adjacent[adjacent > max(bin_ghz, 1e-9)]
    if min_ghz is None:
        if len(adjacent) and expected_families and expected_families > 1:
            # Array FSR is one full repeated pattern, not the nearest-neighbor
            # spacing between cavities inside that pattern.
            inferred_min = float(np.median(adjacent)) * max(2.0, 0.45 * expected_families)
        elif len(adjacent):
            inferred_min = float(np.quantile(adjacent, 0.75)) * 2.0
        else:
            inferred_min = bin_ghz * 5.0
        min_ghz = max(bin_ghz * 2.0, inferred_min)
    if max_ghz is None:
        max_ghz = max(span, float(min_ghz) + bin_ghz * 10.0)
    if max_ghz <= min_ghz:
        max_ghz = min_ghz + bin_ghz * 10.0
    return float(min_ghz), float(max_ghz)


def pair_spacing_spectrum(
    freq_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    min_ghz: float | None,
    max_ghz: float | None,
    bin_ghz: float,
    min_depth: float,
    max_resonances: int,
    expected_families: int | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[dict[str, float]]]:
    mask = np.isfinite(freq_mhz) & np.isfinite(depth) & (depth >= min_depth)
    freq = np.asarray(freq_mhz[mask], dtype=float) / 1000.0
    dep = np.asarray(depth[mask], dtype=float)
    if len(freq) > max_resonances:
        keep = np.argsort(dep)[-max_resonances:]
        freq = freq[keep]
        dep = dep[keep]
    order = np.argsort(freq)
    freq = freq[order]
    dep = dep[order]
    min_ghz, max_ghz = auto_pair_spacing_range_ghz(
        freq,
        expected_families=expected_families,
        bin_ghz=bin_ghz,
        min_ghz=min_ghz,
        max_ghz=max_ghz,
    )
    edges = np.arange(min_ghz, max_ghz + bin_ghz, bin_ghz)
    if len(freq) < 3 or len(edges) < 3:
        centers = 0.5 * (edges[:-1] + edges[1:])
        return centers, np.zeros_like(centers), np.zeros_like(centers), []
    weights = robust_depth_weights(dep)
    hist = np.zeros(len(edges) - 1, dtype=float)
    for i in range(len(freq) - 1):
        diff = freq[i + 1 :] - freq[i]
        good = (diff >= min_ghz) & (diff <= max_ghz)
        if not np.any(good):
            continue
        pair_weights = np.sqrt(weights[i] * weights[i + 1 :][good])
        partial, _ = np.histogram(diff[good], bins=edges, weights=pair_weights)
        hist += partial
    smooth_sigma_bins = max(1.0, 0.20 / bin_ghz)
    smooth = gaussian_filter1d(hist, sigma=smooth_sigma_bins)
    centers = 0.5 * (edges[:-1] + edges[1:])
    candidates: list[dict[str, float]] = []
    if len(smooth) and np.max(smooth) > 0:
        min_distance = max(1, int(round(2.0 / bin_ghz)))
        peaks, props = find_peaks(smooth, distance=min_distance, prominence=0.02 * float(np.max(smooth)))
        if len(peaks) == 0:
            peaks = np.array([int(np.argmax(smooth))])
            props = {"prominences": np.array([float(np.max(smooth))])}
        rank_score = smooth[peaks] / np.sqrt(np.maximum(centers[peaks], bin_ghz))
        order = np.argsort(rank_score)[::-1]
        prominences = props.get("prominences", np.zeros(len(peaks)))
        for rank, peak_i in enumerate(peaks[order][:10], start=1):
            candidates.append(
                {
                    "rank": float(rank),
                    "fsr_ghz": float(centers[peak_i]),
                    "fsr_mhz": float(centers[peak_i] * 1000.0),
                    "score": float(smooth[peak_i]),
                    "rank_score": float(rank_score[order[rank - 1]]),
                    "raw_count": float(hist[peak_i]),
                    "prominence": float(prominences[order[rank - 1]]) if len(prominences) else 0.0,
                    "search_min_ghz": float(min_ghz),
                    "search_max_ghz": float(max_ghz),
                }
            )
    return centers, hist, smooth, candidates


def circular_fold(freq_mhz: np.ndarray, fsr_mhz: float) -> tuple[np.ndarray, float]:
    folded = np.mod(freq_mhz, fsr_mhz)
    if len(folded) < 2:
        return folded, 0.0
    sorted_folded = np.sort(folded)
    gaps = np.diff(np.concatenate([sorted_folded, sorted_folded[:1] + fsr_mhz]))
    largest_gap_i = int(np.argmax(gaps))
    origin = float(np.mod(sorted_folded[(largest_gap_i + 1) % len(sorted_folded)], fsr_mhz))
    return np.mod(folded - origin, fsr_mhz), origin


def weighted_quantiles(values: np.ndarray, weights: np.ndarray, probs: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    values = values[order]
    weights = weights[order]
    cumulative = np.cumsum(weights)
    if cumulative[-1] <= 0:
        return np.quantile(values, probs)
    cumulative = cumulative / cumulative[-1]
    return np.interp(probs, cumulative, values)


def cluster_folded_families(
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    expected_families: int,
    max_iter: int = 80,
) -> tuple[np.ndarray, np.ndarray]:
    if expected_families <= 0 or len(folded_mhz) == 0:
        return np.zeros(len(folded_mhz), dtype=int), np.array([], dtype=float)
    k = min(expected_families, len(folded_mhz))
    weights = robust_depth_weights(depth)
    probs = (np.arange(k, dtype=float) + 0.5) / k
    centers = weighted_quantiles(folded_mhz, weights, probs)
    labels = np.zeros(len(folded_mhz), dtype=int)
    for _ in range(max_iter):
        distance = np.abs(folded_mhz[:, None] - centers[None, :])
        new_labels = np.argmin(distance, axis=1)
        new_centers = centers.copy()
        for i in range(k):
            mask = new_labels == i
            if np.any(mask):
                new_centers[i] = float(np.average(folded_mhz[mask], weights=weights[mask]))
        if np.array_equal(new_labels, labels) and np.allclose(new_centers, centers):
            break
        labels = new_labels
        centers = new_centers
    order = np.argsort(centers)
    remap = np.empty(k, dtype=int)
    for new_i, old_i in enumerate(order):
        remap[old_i] = new_i
    return remap[labels], centers[order]


def fit_track_model(
    mode: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    previous: np.ndarray | None = None,
    point_weights: np.ndarray | None = None,
    fsr_mhz: float | None = None,
) -> np.ndarray:
    if len(mode) == 0:
        return previous if previous is not None else np.array([0.0], dtype=float)
    fit_values = folded_mhz.astype(float)
    if fsr_mhz is not None and fsr_mhz > 0 and previous is not None:
        predicted = np.polyval(previous, mode.astype(float))
        fit_values = fit_values + np.round((predicted - fit_values) / fsr_mhz) * fsr_mhz
    if point_weights is None:
        point_weights = robust_depth_weights(depth)
    point_weights = np.asarray(point_weights, dtype=float)
    degree = min(2, len(mode) - 1)
    if degree <= 0:
        return np.array([float(np.average(fit_values, weights=np.maximum(point_weights, 0.05)))], dtype=float)
    weights = np.sqrt(np.maximum(point_weights, 0.05))
    try:
        return np.polyfit(mode.astype(float), fit_values, deg=degree, w=weights)
    except (np.linalg.LinAlgError, ValueError):
        return previous if previous is not None else np.array([float(np.median(fit_values))], dtype=float)


def predict_track_center(model: np.ndarray, mode: int | float, fsr_mhz: float) -> float:
    return float(np.mod(np.polyval(model, float(mode)), fsr_mhz))


def circular_residual_mhz(value: float, predicted: float, fsr_mhz: float) -> float:
    return float((value - predicted + fsr_mhz / 2.0) % fsr_mhz - fsr_mhz / 2.0)


def assign_rows_to_array_tracks(
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    models: list[np.ndarray],
    *,
    fsr_mhz: float,
    tolerance_mhz: float,
    point_weights: np.ndarray | None = None,
) -> np.ndarray:
    labels = np.full(len(folded_mhz), -1, dtype=int)
    if len(folded_mhz) == 0 or not models:
        return labels

    if point_weights is None:
        point_weights = robust_depth_weights(depth)
    point_weights = np.asarray(point_weights, dtype=float)

    for mode in sorted(set(int(item) for item in mode_number)):
        row_indices = np.where(mode_number == mode)[0]
        if len(row_indices) == 0:
            continue
        track_count = len(models)
        cost = np.full((len(row_indices), track_count + len(row_indices)), np.inf, dtype=float)
        residuals = np.zeros((len(row_indices), track_count), dtype=float)
        for r_i, row_i in enumerate(row_indices):
            for track_i, model in enumerate(models):
                predicted = predict_track_center(model, mode, fsr_mhz)
                residual = circular_residual_mhz(float(folded_mhz[row_i]), predicted, fsr_mhz)
                residuals[r_i, track_i] = residual
                cost[r_i, track_i] = max(float(point_weights[row_i]), 0.05) * residual**2
            cost[r_i, track_count + r_i] = max(float(point_weights[row_i]), 0.05) * tolerance_mhz**2
        assigned_rows, assigned_tracks = linear_sum_assignment(cost)
        for r_i, track_i in zip(assigned_rows, assigned_tracks):
            if track_i < track_count and abs(residuals[r_i, track_i]) <= tolerance_mhz:
                labels[row_indices[r_i]] = int(track_i)
    return labels


def seed_track_centers_from_bins(
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    expected_families: int,
) -> np.ndarray:
    if len(folded_mhz) == 0:
        return np.linspace(0, 1, expected_families, endpoint=False)
    by_mode: dict[int, np.ndarray] = {
        int(mode): np.where(mode_number == int(mode))[0]
        for mode in sorted(set(int(item) for item in mode_number))
    }
    seed_mode = sorted(
        by_mode,
        key=lambda mode: (
            0 if len(by_mode[mode]) >= expected_families else 1,
            abs(len(by_mode[mode]) - expected_families),
            abs(mode),
            -len(by_mode[mode]),
        ),
    )[0]
    seed_indices = by_mode[seed_mode]
    if len(seed_indices) >= expected_families:
        keep = seed_indices[np.argsort(depth[seed_indices])[-expected_families:]]
        return np.sort(folded_mhz[keep])

    weights = robust_depth_weights(depth)
    probs = (np.arange(expected_families, dtype=float) + 0.5) / expected_families
    return weighted_quantiles(folded_mhz, weights, probs)


def candidate_track_center_seeds(
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    expected_families: int,
) -> list[tuple[int | None, np.ndarray]]:
    if expected_families <= 0 or len(folded_mhz) == 0:
        return []
    seeds: list[tuple[int | None, np.ndarray]] = []
    seen: set[tuple[float, ...]] = set()

    by_mode = {
        int(mode): np.where(mode_number == int(mode))[0]
        for mode in sorted(set(int(item) for item in mode_number))
    }
    ordered_modes = sorted(
        by_mode,
        key=lambda mode: (
            0 if len(by_mode[mode]) >= expected_families else 1,
            abs(len(by_mode[mode]) - expected_families),
            abs(mode),
            -len(by_mode[mode]),
        ),
    )
    for mode in ordered_modes:
        indices = by_mode[mode]
        if len(indices) < expected_families:
            continue
        keep = indices[np.argsort(depth[indices])[-expected_families:]]
        centers = np.sort(folded_mhz[keep].astype(float))
        key = tuple(float(item) for item in np.round(centers, decimals=6))
        if key not in seen:
            seen.add(key)
            seeds.append((int(mode), centers))

    fallback = seed_track_centers_from_bins(
        mode_number,
        folded_mhz,
        depth,
        expected_families=expected_families,
    )
    fallback_key = tuple(float(item) for item in np.round(fallback, decimals=6))
    if fallback_key not in seen:
        seeds.append((None, fallback))
    return seeds


def fit_models_for_track_labels(
    labels: np.ndarray,
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    point_weights: np.ndarray,
    previous_models: list[np.ndarray],
    *,
    fsr_mhz: float,
) -> list[np.ndarray]:
    models: list[np.ndarray] = []
    for track_i, previous in enumerate(previous_models):
        mask = labels == track_i
        models.append(
            fit_track_model(
                mode_number[mask],
                folded_mhz[mask],
                depth[mask],
                previous=previous,
                point_weights=point_weights[mask],
                fsr_mhz=fsr_mhz,
            )
        )
    return models


def track_assignment_metrics(
    labels: np.ndarray,
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    point_weights: np.ndarray,
    models: list[np.ndarray],
    *,
    fsr_mhz: float,
    unmatched_penalty_mhz: float,
) -> dict[str, float | int]:
    assigned = labels >= 0
    residuals = np.zeros(len(labels), dtype=float)
    for row_i in np.where(assigned)[0]:
        track_i = int(labels[row_i])
        predicted = predict_track_center(models[track_i], int(mode_number[row_i]), fsr_mhz)
        residuals[row_i] = circular_residual_mhz(float(folded_mhz[row_i]), predicted, fsr_mhz)

    assigned_weight = float(np.sum(point_weights[assigned]))
    assigned_sse = float(np.sum(point_weights[assigned] * residuals[assigned] ** 2))
    unmatched = ~assigned
    penalty_sse = float(np.sum(point_weights[unmatched]) * unmatched_penalty_mhz**2)
    total_weight = max(float(np.sum(point_weights)), 1e-12)
    return {
        "objective_mhz2": assigned_sse + penalty_sse,
        "weighted_rms_mhz": math.sqrt((assigned_sse + penalty_sse) / total_weight),
        "assigned_weighted_rms_mhz": math.sqrt(assigned_sse / assigned_weight) if assigned_weight > 0 else math.inf,
        "assigned_count": int(np.sum(assigned)),
        "unmatched_count": int(np.sum(unmatched)),
    }


def refine_track_assignment(
    initial_models: list[np.ndarray],
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    point_weights: np.ndarray,
    *,
    fsr_mhz: float,
    tolerance_mhz: float,
    max_iterations: int,
) -> tuple[np.ndarray, list[np.ndarray], int]:
    models = [np.asarray(model, dtype=float) for model in initial_models]
    previous_labels: np.ndarray | None = None
    labels = np.full(len(folded_mhz), -1, dtype=int)
    iterations_used = 0
    for iteration in range(max(1, max_iterations)):
        iterations_used = iteration + 1
        labels = assign_rows_to_array_tracks(
            mode_number,
            folded_mhz,
            depth,
            models,
            fsr_mhz=fsr_mhz,
            tolerance_mhz=tolerance_mhz,
            point_weights=point_weights,
        )
        new_models = fit_models_for_track_labels(
            labels,
            mode_number,
            folded_mhz,
            depth,
            point_weights,
            models,
            fsr_mhz=fsr_mhz,
        )
        labels_stable = previous_labels is not None and np.array_equal(labels, previous_labels)
        models_stable = all(
            old.shape == new.shape and np.allclose(old, new, rtol=0, atol=1e-6)
            for old, new in zip(models, new_models)
        )
        models = new_models
        if labels_stable and models_stable:
            break
        previous_labels = labels.copy()
    return labels, models, iterations_used


def improve_assignment_with_segment_swaps(
    labels: np.ndarray,
    models: list[np.ndarray],
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    point_weights: np.ndarray,
    *,
    fsr_mhz: float,
    tolerance_mhz: float,
    max_passes: int = 2,
) -> tuple[np.ndarray, list[np.ndarray], list[dict[str, Any]]]:
    current_labels = labels.copy()
    current_models = [model.copy() for model in models]
    current_metrics = track_assignment_metrics(
        current_labels,
        mode_number,
        folded_mhz,
        point_weights,
        current_models,
        fsr_mhz=fsr_mhz,
        unmatched_penalty_mhz=tolerance_mhz,
    )
    mode_values = sorted(set(int(item) for item in mode_number))
    accepted: list[dict[str, Any]] = []

    for _pass in range(max(0, max_passes)):
        best: tuple[float, np.ndarray, list[np.ndarray], dict[str, Any]] | None = None
        track_count = len(current_models)
        for first_track in range(track_count - 1):
            for second_track in range(first_track + 1, track_count):
                pair_mask = np.isin(current_labels, [first_track, second_track])
                if not np.any(pair_mask):
                    continue
                interval_candidates = {
                    (mode_values[0], boundary) for boundary in mode_values[:-1]
                } | {
                    (boundary, mode_values[-1]) for boundary in mode_values[1:]
                }
                for start_mode, stop_mode in sorted(interval_candidates):
                    interval = pair_mask & (mode_number >= start_mode) & (mode_number <= stop_mode)
                    if not np.any(interval):
                        continue
                    candidate_labels = current_labels.copy()
                    first_mask = interval & (current_labels == first_track)
                    second_mask = interval & (current_labels == second_track)
                    if not np.any(first_mask) or not np.any(second_mask):
                        continue
                    candidate_labels[first_mask] = second_track
                    candidate_labels[second_mask] = first_track
                    candidate_models = [model.copy() for model in current_models]
                    for track_i in (first_track, second_track):
                        track_mask = candidate_labels == track_i
                        candidate_models[track_i] = fit_track_model(
                            mode_number[track_mask],
                            folded_mhz[track_mask],
                            depth[track_mask],
                            previous=current_models[track_i],
                            point_weights=point_weights[track_mask],
                            fsr_mhz=fsr_mhz,
                        )
                    candidate_metrics = track_assignment_metrics(
                        candidate_labels,
                        mode_number,
                        folded_mhz,
                        point_weights,
                        candidate_models,
                        fsr_mhz=fsr_mhz,
                        unmatched_penalty_mhz=tolerance_mhz,
                    )
                    objective = float(candidate_metrics["objective_mhz2"])
                    if best is None or objective < best[0]:
                        best = (
                            objective,
                            candidate_labels,
                            candidate_models,
                            {
                                "track_a": int(first_track),
                                "track_b": int(second_track),
                                "mode_start": int(start_mode),
                                "mode_stop": int(stop_mode),
                                "before_weighted_rms_mhz": float(current_metrics["weighted_rms_mhz"]),
                                "after_weighted_rms_mhz": float(candidate_metrics["weighted_rms_mhz"]),
                            },
                        )

        if best is None:
            break
        improvement = float(current_metrics["objective_mhz2"]) - best[0]
        minimum_improvement = max(1e-6, 1e-9 * float(current_metrics["objective_mhz2"]))
        if improvement <= minimum_improvement:
            break
        current_labels = best[1]
        current_models = best[2]
        accepted.append(best[3])
        current_metrics = track_assignment_metrics(
            current_labels,
            mode_number,
            folded_mhz,
            point_weights,
            current_models,
            fsr_mhz=fsr_mhz,
            unmatched_penalty_mhz=tolerance_mhz,
        )

    return current_labels, current_models, accepted


def track_array_mode_families(
    folded_mhz: np.ndarray,
    mode_number: np.ndarray,
    depth: np.ndarray,
    *,
    expected_families: int,
    fsr_mhz: float,
    iterations: int = 12,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    if expected_families <= 0 or len(folded_mhz) == 0:
        return np.full(len(folded_mhz), -1, dtype=int), np.array([], dtype=float), {
            "method": "array_parallel_track_assignment",
            "status": "no_points",
        }

    track_count = min(expected_families, len(folded_mhz))
    seeds = candidate_track_center_seeds(
        mode_number,
        folded_mhz,
        depth,
        expected_families=track_count,
    )
    median_family_spacing = fsr_mhz / max(track_count, 1)
    tolerance_mhz = max(2_000.0, 0.70 * median_family_spacing, 0.035 * fsr_mhz)
    point_weights = robust_depth_weights(depth)

    candidates: list[dict[str, Any]] = []
    seen_labels: set[bytes] = set()
    for seed_mode, seed_centers in seeds:
        initial_models = [np.array([float(center)], dtype=float) for center in seed_centers]
        labels, models, iterations_used = refine_track_assignment(
            initial_models,
            mode_number,
            folded_mhz,
            depth,
            point_weights,
            fsr_mhz=fsr_mhz,
            tolerance_mhz=tolerance_mhz,
            max_iterations=iterations,
        )
        label_key = labels.tobytes()
        if label_key in seen_labels:
            continue
        seen_labels.add(label_key)
        metrics = track_assignment_metrics(
            labels,
            mode_number,
            folded_mhz,
            point_weights,
            models,
            fsr_mhz=fsr_mhz,
            unmatched_penalty_mhz=tolerance_mhz,
        )
        candidates.append(
            {
                "seed_mode": seed_mode,
                "labels": labels,
                "models": models,
                "iterations_used": int(iterations_used),
                "metrics": metrics,
            }
        )

    if not candidates:
        return np.full(len(folded_mhz), -1, dtype=int), np.array([], dtype=float), {
            "method": "array_parallel_track_assignment_global_search",
            "status": "no_seed_candidates",
        }

    candidates.sort(
        key=lambda item: (
            float(item["metrics"]["objective_mhz2"]),
            int(item["metrics"]["unmatched_count"]),
        )
    )
    candidate = candidates[0]
    segment_search_threshold_mhz = max(100.0, 0.005 * median_family_spacing)
    segment_search_needed = float(candidate["metrics"]["assigned_weighted_rms_mhz"]) > segment_search_threshold_mhz
    if segment_search_needed:
        labels, models, swaps = improve_assignment_with_segment_swaps(
            candidate["labels"],
            candidate["models"],
            mode_number,
            folded_mhz,
            depth,
            point_weights,
            fsr_mhz=fsr_mhz,
            tolerance_mhz=tolerance_mhz,
        )
    else:
        labels = candidate["labels"]
        models = candidate["models"]
        swaps = []
    refinement_reverted = False
    if swaps:
        swapped_labels = labels.copy()
        swapped_models = [model.copy() for model in models]
        swapped_metrics = track_assignment_metrics(
            swapped_labels,
            mode_number,
            folded_mhz,
            point_weights,
            swapped_models,
            fsr_mhz=fsr_mhz,
            unmatched_penalty_mhz=tolerance_mhz,
        )
        refined_labels, refined_models, refinement_iterations = refine_track_assignment(
            models,
            mode_number,
            folded_mhz,
            depth,
            point_weights,
            fsr_mhz=fsr_mhz,
            tolerance_mhz=tolerance_mhz,
            max_iterations=iterations,
        )
        refined_metrics = track_assignment_metrics(
            refined_labels,
            mode_number,
            folded_mhz,
            point_weights,
            refined_models,
            fsr_mhz=fsr_mhz,
            unmatched_penalty_mhz=tolerance_mhz,
        )
        if float(refined_metrics["objective_mhz2"]) <= float(swapped_metrics["objective_mhz2"]):
            labels = refined_labels
            models = refined_models
        else:
            labels = swapped_labels
            models = swapped_models
            refinement_reverted = True
    else:
        refinement_iterations = 0
    metrics = track_assignment_metrics(
        labels,
        mode_number,
        folded_mhz,
        point_weights,
        models,
        fsr_mhz=fsr_mhz,
        unmatched_penalty_mhz=tolerance_mhz,
    )
    chosen = {
        **candidate,
        "labels": labels,
        "models": models,
        "metrics": metrics,
        "segment_swaps": swaps,
        "refinement_iterations": int(refinement_iterations),
    }
    labels = chosen["labels"]
    models = chosen["models"]

    center_mode = 0
    if len(mode_number):
        center_mode = int(sorted(set(int(item) for item in mode_number), key=abs)[0])
    centers = np.array([predict_track_center(model, center_mode, fsr_mhz) for model in models], dtype=float)
    order = np.argsort(centers)
    remap = {int(old): int(new) for new, old in enumerate(order)}
    remapped = np.full_like(labels, -1)
    for old, new in remap.items():
        remapped[labels == old] = new
    sorted_centers = centers[order]

    by_mode_counts: dict[str, dict[str, int]] = {}
    for mode in sorted(set(int(item) for item in mode_number)):
        mask = mode_number == mode
        assigned = remapped[mask]
        by_mode_counts[str(mode)] = {
            "dip_count": int(np.sum(mask)),
            "assigned_count": int(np.sum(assigned >= 0)),
            "unique_families": int(len(set(int(item) for item in assigned if item >= 0))),
            "unmatched_count": int(np.sum(assigned < 0)),
        }
    diagnostics = {
        "method": "array_parallel_track_assignment_global_search",
        "track_count": int(track_count),
        "max_iterations": int(iterations),
        "assignment_tolerance_mhz": float(tolerance_mhz),
        "center_mode": int(center_mode),
        "unmatched_count": int(np.sum(remapped < 0)),
        "seed_candidate_count": int(len(seeds)),
        "unique_solution_count": int(len(candidates)),
        "chosen_seed_mode": chosen["seed_mode"],
        "chosen_iterations": int(chosen["iterations_used"]),
        "chosen_refinement_iterations": int(chosen["refinement_iterations"]),
        "chosen_refinement_reverted": bool(refinement_reverted),
        "segment_swap_search_threshold_mhz": float(segment_search_threshold_mhz),
        "segment_swap_search_ran": bool(segment_search_needed),
        "segment_swaps": chosen["segment_swaps"],
        "objective": chosen["metrics"],
        "model_coefficients_mhz": [models[int(old)].tolist() for old in order],
        "candidate_summaries": [
            {
                "seed_mode": item["seed_mode"],
                "iterations_used": int(item["iterations_used"]),
                "objective_mhz2": float(item["metrics"]["objective_mhz2"]),
                "weighted_rms_mhz": float(item["metrics"]["weighted_rms_mhz"]),
                "assigned_weighted_rms_mhz": float(item["metrics"]["assigned_weighted_rms_mhz"]),
                "unmatched_count": int(item["metrics"]["unmatched_count"]),
            }
            for item in candidates
        ],
        "by_mode_counts": by_mode_counts,
    }
    return remapped, sorted_centers, diagnostics


def family_index(value: Any) -> int | None:
    match = re.fullmatch(r"F([1-9]\d*)", str(value or "").strip(), flags=re.IGNORECASE)
    if match is None:
        return None
    return int(match.group(1)) - 1


def assign_reference_family_trajectories(
    reference_rows: list[dict[str, Any]],
    plan_rows: list[dict[str, Any]],
    observed_absolute_freq_mhz: np.ndarray,
    observed_folded_mhz: np.ndarray,
    *,
    expected_families: int,
    match_tolerance_mhz: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Transfer pre-tuning family identities onto a post-tuning large scan."""
    observed_absolute_freq_mhz = np.asarray(observed_absolute_freq_mhz, dtype=float)
    observed_folded_mhz = np.asarray(observed_folded_mhz, dtype=float)
    labels = np.full(len(observed_absolute_freq_mhz), -1, dtype=int)
    mode_number_ref = np.zeros(len(observed_absolute_freq_mhz), dtype=int)
    mode_number = np.zeros(len(observed_absolute_freq_mhz), dtype=int)
    family_centers = np.full(expected_families, np.nan, dtype=float)

    shifts_by_family: dict[int, float] = {}
    target_frequencies_mhz: list[float] = []
    for row in plan_rows:
        label_i = family_index(row.get("family"))
        current_ghz = finite_float(row.get("current_frequency_ghz"))
        target_ghz = finite_float(row.get("target_frequency_ghz"))
        if label_i is None or current_ghz is None or target_ghz is None:
            continue
        shifts_by_family[label_i] = (target_ghz - current_ghz) * 1000.0
        target_frequencies_mhz.append(target_ghz * 1000.0)

    finite_observed = np.where(np.isfinite(observed_absolute_freq_mhz))[0]
    if not shifts_by_family or not len(finite_observed):
        return labels, mode_number_ref, mode_number, family_centers, {
            "method": "reference_family_trajectory_assignment",
            "status": "missing_plan_or_observed_frequencies",
            "matched_count": 0,
        }

    observed_finite_values = observed_absolute_freq_mhz[finite_observed]
    anchor_offsets: list[float] = []
    for target_mhz in target_frequencies_mhz:
        nearest = int(np.argmin(np.abs(observed_finite_values - target_mhz)))
        delta = float(observed_finite_values[nearest] - target_mhz)
        if abs(delta) <= match_tolerance_mhz:
            anchor_offsets.append(delta)
    global_offset_mhz = float(np.median(anchor_offsets)) if anchor_offsets else 0.0

    references: list[dict[str, Any]] = []
    for row in reference_rows:
        label_i = family_index(row.get("family") or row.get("family_label"))
        absolute_freq_mhz = finite_float(row.get("absolute_freq_mhz"))
        centered_mode = finite_float(row.get("mode_number_centered"))
        if centered_mode is None:
            centered_mode = finite_float(row.get("mode_number"))
        reference_mode = finite_float(row.get("mode_number_ref"))
        if reference_mode is None:
            reference_mode = centered_mode
        if (
            label_i is None
            or label_i not in shifts_by_family
            or label_i < 0
            or label_i >= expected_families
            or absolute_freq_mhz is None
            or centered_mode is None
            or reference_mode is None
        ):
            continue
        references.append(
            {
                "label": label_i,
                "mode_number": int(round(centered_mode)),
                "mode_number_ref": int(round(reference_mode)),
                "predicted_absolute_freq_mhz": absolute_freq_mhz + shifts_by_family[label_i] + global_offset_mhz,
            }
        )

    if not references:
        return labels, mode_number_ref, mode_number, family_centers, {
            "method": "reference_family_trajectory_assignment",
            "status": "no_usable_reference_points",
            "matched_count": 0,
            "global_frequency_offset_mhz": global_offset_mhz,
        }

    predicted = np.asarray([row["predicted_absolute_freq_mhz"] for row in references], dtype=float)
    real_cost = np.abs(predicted[:, None] - observed_finite_values[None, :])
    dummy_cost = np.full((len(references), len(references)), float(match_tolerance_mhz), dtype=float)
    assigned_rows, assigned_cols = linear_sum_assignment(np.hstack([real_cost, dummy_cost]))

    residuals_mhz: list[float] = []
    matched_by_family: dict[str, int] = {f"F{i + 1}": 0 for i in range(expected_families)}
    ambiguous_count = 0
    for ref_i, assignment_i in zip(assigned_rows, assigned_cols):
        if assignment_i >= len(finite_observed):
            continue
        residual = float(real_cost[ref_i, assignment_i])
        if residual > match_tolerance_mhz:
            continue
        observed_i = int(finite_observed[assignment_i])
        reference = references[int(ref_i)]
        labels[observed_i] = int(reference["label"])
        mode_number_ref[observed_i] = int(reference["mode_number_ref"])
        mode_number[observed_i] = int(reference["mode_number"])
        residuals_mhz.append(residual)
        matched_by_family[f"F{int(reference['label']) + 1}"] += 1
        if real_cost.shape[1] > 1:
            two_nearest = np.partition(real_cost[ref_i], 1)[:2]
            if float(two_nearest[1] - two_nearest[0]) < 100.0:
                ambiguous_count += 1

    for label_i in range(expected_families):
        mask = labels == label_i
        if np.any(mask):
            family_centers[label_i] = float(np.median(observed_folded_mhz[mask]))

    diagnostics = {
        "method": "reference_family_trajectory_assignment",
        "status": "ok",
        "match_tolerance_mhz": float(match_tolerance_mhz),
        "global_frequency_offset_mhz": global_offset_mhz,
        "anchor_count": len(anchor_offsets),
        "reference_point_count": len(references),
        "matched_count": int(np.sum(labels >= 0)),
        "unmatched_detected_count": int(np.sum(labels < 0)),
        "unmatched_reference_count": int(len(references) - np.sum(labels >= 0)),
        "ambiguous_reference_count": int(ambiguous_count),
        "median_absolute_residual_mhz": float(np.median(residuals_mhz)) if residuals_mhz else None,
        "max_absolute_residual_mhz": float(np.max(residuals_mhz)) if residuals_mhz else None,
        "matched_by_family": matched_by_family,
    }
    return labels, mode_number_ref, mode_number, family_centers, diagnostics


def load_reference_family_inputs(
    family_points_path: Path,
    plan_path: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    with family_points_path.open(newline="", encoding="utf-8-sig") as handle:
        reference_rows = [dict(row) for row in csv.DictReader(handle)]
    plan = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    plan_rows = plan.get("plan_rows") if isinstance(plan, dict) else None
    if not isinstance(plan_rows, list):
        raise ValueError(f"Reference plan has no plan_rows list: {plan_path}")
    return reference_rows, [dict(row) for row in plan_rows if isinstance(row, dict)]


def select_one_fsr_group(
    mode_number: np.ndarray,
    labels: np.ndarray,
    expected_families: int,
) -> dict[str, int]:
    if len(mode_number) == 0:
        return {"mode_number": 0, "unique_families": 0, "point_count": 0, "unmatched_count": 0}
    candidates: list[dict[str, int]] = []
    for mode in sorted(set(int(item) for item in mode_number)):
        mask = mode_number == mode
        assigned = labels[mask]
        unique = len(set(int(item) for item in assigned if item >= 0))
        candidates.append(
            {
                "mode_number": int(mode),
                "unique_families": int(unique),
                "point_count": int(np.sum(mask)),
                "unmatched_count": int(np.sum(assigned < 0)),
            }
        )
    good_enough = max(1, min(expected_families, math.ceil(expected_families * 0.65)))
    near_zero = [item for item in candidates if item["unique_families"] >= good_enough]
    if near_zero:
        return sorted(
            near_zero,
            key=lambda item: (abs(item["mode_number"]), -item["unique_families"], item["unmatched_count"], -item["point_count"]),
        )[0]
    return sorted(candidates, key=lambda item: (-item["unique_families"], item["unmatched_count"], abs(item["mode_number"]), -item["point_count"]))[0]


def one_fsr_group_diagnostics(
    mode_number: np.ndarray,
    labels: np.ndarray,
    *,
    selected_group: int,
    expected_families: int,
) -> dict[str, Any]:
    mask = mode_number == selected_group
    group_labels = [int(item) for item in labels[mask] if int(item) >= 0]
    unmatched = int(np.sum(labels[mask] < 0))
    counts = {f"F{i + 1}": group_labels.count(i) for i in range(expected_families)}
    return {
        "mode_number": int(selected_group),
        "unique_families": int(sum(1 for value in counts.values() if value > 0)),
        "point_count": int(np.sum(mask)),
        "unmatched_count": unmatched,
        "missing_families": [name for name, value in counts.items() if value == 0],
        "duplicate_families": [name for name, value in counts.items() if value > 1],
        "family_point_counts": counts,
    }


def write_modes_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "dip_id",
        "sample_index",
        "time_s",
        "wavelength_nm",
        "norm_transmission",
        "depth_1_minus_norm",
        "relative_freq_ghz",
        "absolute_freq_mhz",
        "wavelength_source",
        "mode_number",
        "mode_number_ref",
        "mode_number_centered",
        "folded_freq_ghz",
        "family_label",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fieldnames})


def write_array_family_points_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "family",
        "family_label",
        "mode_number",
        "mode_number_ref",
        "mode_number_centered",
        "sample_index",
        "time_s",
        "wavelength_nm",
        "wavelength_nm_linear",
        "absolute_freq_mhz",
        "wavelength_source",
        "relative_freq_mhz",
        "folded_freq_ref_mhz",
        "folded_freq_centered_mhz",
        "norm_transmission",
        "depth_1_minus_norm",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            if str(row.get("family", "")) == "unmatched":
                continue
            writer.writerow({field: row.get(field, "") for field in fieldnames})


def fit_array_q_mode(
    row: dict[str, Any],
    *,
    time_s: np.ndarray,
    trans_norm_full: np.ndarray,
    mzi_freq_axis_mhz: np.ndarray,
    wavelength_axis_nm: np.ndarray,
    all_indices: np.ndarray,
    min_half_window_samples: int,
    max_half_window_samples: int,
    neighbor_window_fraction: float,
) -> dict[str, Any]:
    center_idx = int(round(float(row["sample_index"])))
    half = choose_half_window(
        center_idx,
        all_indices,
        min_samples=min_half_window_samples,
        max_samples=max_half_window_samples,
        fraction=neighbor_window_fraction,
    )
    start = max(0, center_idx - half)
    end = min(len(time_s), center_idx + half + 1)
    local_indices = np.arange(start, end, dtype=int)
    finite = np.isfinite(mzi_freq_axis_mhz[local_indices]) & np.isfinite(trans_norm_full[local_indices])
    local_indices = local_indices[finite]
    if len(local_indices) < 30:
        raise RuntimeError("too few finite MZI-calibrated samples")

    x_abs = mzi_freq_axis_mhz[local_indices]
    y = trans_norm_full[local_indices]
    x0_abs = float(mzi_freq_axis_mhz[center_idx])
    x = x_abs - x0_abs
    local_center = int(np.argmin(np.abs(local_indices - center_idx)))
    popt, fit = fit_notch_window(x, y, local_center, slope_limit=0.02, min_edge_samples=5, min_span_mhz=1.0)
    residual = y - fit
    a, b, eta, gamma_mhz, x0_fit_mhz = [float(v) for v in popt]
    wavelength_center_sample_nm = float(np.interp(center_idx, np.arange(len(wavelength_axis_nm)), wavelength_axis_nm))
    center_freq_abs_mhz = float(wavelength_nm_to_freq_mhz(wavelength_center_sample_nm))
    f0_abs_mhz = center_freq_abs_mhz + x0_fit_mhz
    wavelength_fit_nm = float(freq_mhz_to_wavelength_nm(f0_abs_mhz))
    quality = notch_quality_factors(f0_abs_mhz, eta, gamma_mhz)
    transmission = quality['transmission']
    kappa_total_mhz = quality['linewidth_loaded_mhz']
    kappa0_mhz, kappa1_mhz = quality['kappa0_mhz'], quality['kappa1_mhz']
    q0, q1, ql = quality['Q0'], quality['Q1'], quality['QL']
    coupling_note = quality['coupling_note']
    return {
        "family": row["family"],
        "family_label": row.get("family_label", row["family"]),
        "mode_number": int(row["mode_number"]),
        "mode_number_ref": int(row.get("mode_number_ref", row["mode_number"])),
        "mode_number_centered": int(row.get("mode_number_centered", row["mode_number"])),
        "sample_index": center_idx,
        "time_s": float(time_s[center_idx]),
        "wavelength_nm": wavelength_fit_nm,
        "wavelength_nm_center_sample": wavelength_center_sample_nm,
        "absolute_freq_mhz": f0_abs_mhz,
        "wavelength_source": str(row.get("wavelength_source") or "unknown") + "+lorentzian_fit_center",
        "relative_freq_ghz": float(row["relative_freq_mhz"]) / 1000.0,
        "folded_freq_ghz": float(row["folded_freq_centered_mhz"]) / 1000.0,
        "fit_center_offset_mhz": x0_fit_mhz,
        "half_window_samples": half,
        "fit_points": int(len(y)),
        "transmission": transmission,
        "depth": 1.0 - transmission,
        "linewidth_loaded_mhz": kappa_total_mhz,
        "kappa0_mhz": kappa0_mhz,
        "kappa1_mhz": kappa1_mhz,
        "Q0": q0,
        "Q1": q1,
        "QL": ql,
        "baseline_a": a,
        "baseline_slope_per_mhz": b,
        "rms_residual": float(np.sqrt(np.mean(residual**2))),
        "max_abs_residual": float(np.max(np.abs(residual))),
        "fit_status": "ok",
        "coupling_note": coupling_note,
    }


def failed_array_q_row(row: dict[str, Any], time_s: np.ndarray, wavelength_axis_nm: np.ndarray, exc: Exception) -> dict[str, Any]:
    center_idx = int(round(float(row["sample_index"])))
    return {
        "family": row["family"],
        "family_label": row.get("family_label", row["family"]),
        "mode_number": int(row["mode_number"]),
        "mode_number_ref": int(row.get("mode_number_ref", row["mode_number"])),
        "mode_number_centered": int(row.get("mode_number_centered", row["mode_number"])),
        "sample_index": center_idx,
        "time_s": float(time_s[center_idx]),
        "wavelength_nm": float(wavelength_axis_nm[center_idx]),
        "wavelength_nm_center_sample": float(wavelength_axis_nm[center_idx]),
        "absolute_freq_mhz": float(wavelength_nm_to_freq_mhz(wavelength_axis_nm[center_idx])),
        "wavelength_source": "fallback_center_sample",
        "relative_freq_ghz": float(row["relative_freq_mhz"]) / 1000.0,
        "folded_freq_ghz": float(row["folded_freq_centered_mhz"]) / 1000.0,
        "fit_center_offset_mhz": math.nan,
        "half_window_samples": math.nan,
        "fit_points": 0,
        "transmission": math.nan,
        "depth": math.nan,
        "linewidth_loaded_mhz": math.nan,
        "kappa0_mhz": math.nan,
        "kappa1_mhz": math.nan,
        "Q0": math.nan,
        "Q1": math.nan,
        "QL": math.nan,
        "baseline_a": math.nan,
        "baseline_slope_per_mhz": math.nan,
        "rms_residual": math.nan,
        "max_abs_residual": math.nan,
        "fit_status": f"failed: {exc}",
        "coupling_note": "",
    }


def write_array_q_table(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "family",
        "family_label",
        "mode_number",
        "mode_number_ref",
        "mode_number_centered",
        "sample_index",
        "time_s",
        "wavelength_nm",
        "wavelength_nm_center_sample",
        "absolute_freq_mhz",
        "wavelength_nm_slope_corrected",
        "absolute_freq_mhz_slope_corrected",
        "mzi_readback_slope_ratio",
        "mzi_readback_slope_region",
        "wavelength_source",
        "relative_freq_ghz",
        "folded_freq_ghz",
        "fit_center_offset_mhz",
        "half_window_samples",
        "fit_points",
        "transmission",
        "depth",
        "linewidth_loaded_mhz",
        "kappa0_mhz",
        "kappa1_mhz",
        "Q0",
        "Q1",
        "QL",
        "baseline_a",
        "baseline_slope_per_mhz",
        "rms_residual",
        "max_abs_residual",
        "fit_status",
        "coupling_note",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fit_array_q_rows(
    family_points: list[dict[str, Any]],
    *,
    time_s: np.ndarray,
    trans_norm_full: np.ndarray,
    mzi_freq_axis_mhz: np.ndarray,
    wavelength_axis_nm: np.ndarray,
    min_half_window_samples: int,
    max_half_window_samples: int,
    neighbor_window_fraction: float,
) -> list[dict[str, Any]]:
    points = [row for row in family_points if row.get("family") != "unmatched"]
    all_indices = np.array([int(round(float(row["sample_index"]))) for row in points], dtype=int)
    rows: list[dict[str, Any]] = []
    for row in points:
        try:
            rows.append(
                fit_array_q_mode(
                    row,
                    time_s=time_s,
                    trans_norm_full=trans_norm_full,
                    mzi_freq_axis_mhz=mzi_freq_axis_mhz,
                    wavelength_axis_nm=wavelength_axis_nm,
                    all_indices=all_indices,
                    min_half_window_samples=min_half_window_samples,
                    max_half_window_samples=max_half_window_samples,
                    neighbor_window_fraction=neighbor_window_fraction,
                )
            )
        except Exception as exc:
            rows.append(failed_array_q_row(row, time_s, wavelength_axis_nm, exc))
    return rows


def summarize_array_q(q_rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "mode_count": len(q_rows),
        "ok_count": sum(1 for row in q_rows if row.get("fit_status") == "ok"),
        "family_summary": {},
    }
    for family in sorted({str(row["family"]) for row in q_rows}):
        fam_all = [row for row in q_rows if row["family"] == family]
        fam = [row for row in fam_all if row.get("fit_status") == "ok"]
        if not fam_all:
            continue
        item: dict[str, Any] = {
            "family_label": str(fam_all[0].get("family_label", family)),
            "row_count": len(fam_all),
            "ok_count": len(fam),
            "failed_count": len(fam_all) - len(fam),
        }
        if fam:
            item.update(
                {
                    "mode_min": int(min(int(row["mode_number"]) for row in fam)),
                    "mode_max": int(max(int(row["mode_number"]) for row in fam)),
                    "wavelength_min_nm": float(np.nanmin([float(row["wavelength_nm"]) for row in fam])),
                    "wavelength_max_nm": float(np.nanmax([float(row["wavelength_nm"]) for row in fam])),
                    "Q0_median_M": float(np.nanmedian([float(row["Q0"]) for row in fam]) / 1e6),
                    "Q1_median_M": float(np.nanmedian([float(row["Q1"]) for row in fam]) / 1e6),
                    "QL_median_M": float(np.nanmedian([float(row["QL"]) for row in fam]) / 1e6),
                    "linewidth_median_mhz": float(np.nanmedian([float(row["linewidth_loaded_mhz"]) for row in fam])),
                    "depth_median": float(np.nanmedian([float(row["depth"]) for row in fam])),
                }
            )
        summary["family_summary"][family] = item
    return summary


def plot_frequency_spectrum(
    path: Path,
    *,
    rel_freq_trace_mhz: np.ndarray,
    trans_norm: np.ndarray,
    dip_freq_mhz: np.ndarray,
    dip_norm: np.ndarray,
    dip_depth: np.ndarray,
    min_depth: float,
    mzi_d1_mhz: float,
) -> None:
    order = np.argsort(rel_freq_trace_mhz)
    fig, ax = plt.subplots(figsize=(14, 6), constrained_layout=True)
    plot_envelope_xy(
        ax,
        rel_freq_trace_mhz[order] / 1000.0,
        trans_norm[order],
        target_bins=30000,
        color="#2364aa",
        label="normalized transmission",
        lw=0.75,
        alpha=0.16,
    )
    if len(dip_freq_mhz):
        pick = slice(None, None, max(1, len(dip_freq_mhz) // 1500))
        ax.scatter(
            dip_freq_mhz[pick] / 1000.0,
            dip_norm[pick],
            s=10,
            color="#777777",
            alpha=0.35,
            label="all detected dips",
            zorder=3,
        )
        used = dip_depth >= min_depth
        if np.any(used):
            ax.scatter(
                dip_freq_mhz[used] / 1000.0,
                dip_norm[used],
                s=14,
                color="#c43b3b",
                alpha=0.88,
                label=f"used dips, depth >= {min_depth:g}",
                zorder=4,
            )
    ax.set_xlabel("Relative frequency (GHz)")
    ax.set_ylabel("Normalized transmission")
    ax.set_title(f"MZI-calibrated broad transmission spectrum, MZI D1={mzi_d1_mhz:.5f} MHz")
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)
    fig.savefig(path)
    plt.close(fig)


def plot_pair_fsr(
    path: Path,
    *,
    centers_ghz: np.ndarray,
    hist: np.ndarray,
    smooth: np.ndarray,
    candidates: list[dict[str, float]],
    design_fsr_mhz: float | None,
) -> None:
    fig, ax = plt.subplots(figsize=(13, 6), constrained_layout=True)
    if len(centers_ghz):
        ax.bar(centers_ghz, hist, width=np.median(np.diff(centers_ghz)) if len(centers_ghz) > 1 else 0.1, color="#9fb7d5", alpha=0.45, label="pair-spacing histogram")
        ax.plot(centers_ghz, smooth, color="#2364aa", label="smoothed weighted count")
    if candidates:
        x = np.array([item["fsr_ghz"] for item in candidates], dtype=float)
        y = np.array([item["score"] for item in candidates], dtype=float)
        ax.scatter(x, y, s=48, color="#c43b3b", zorder=3, label="candidate FSR peaks")
        best = candidates[0]
        ax.axvline(best["fsr_ghz"], color="#2b8c5a", lw=2.0, label=f"selected {best['fsr_ghz']:.4g} GHz")
    if design_fsr_mhz is not None and math.isfinite(design_fsr_mhz):
        ax.axvline(design_fsr_mhz / 1000.0, color="#666666", lw=1.4, ls="--", label="array-design estimate")
    ax.set_xlabel("Pairwise resonance spacing (GHz)")
    ax.set_ylabel("Weighted pair count")
    ax.set_title("Dominant FSR from resonance frequency-difference spectrum")
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)
    fig.savefig(path)
    plt.close(fig)


def plot_one_fsr_modes(
    path: Path,
    *,
    rel_freq_trace_mhz: np.ndarray,
    trans_norm: np.ndarray,
    dip_freq_mhz: np.ndarray,
    dip_norm: np.ndarray,
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    labels: np.ndarray,
    selected_group: int,
    expected_families: int,
    fsr_mhz: float,
    fold_origin_mhz: float,
) -> None:
    start_mhz = fold_origin_mhz + selected_group * fsr_mhz
    stop_mhz = start_mhz + fsr_mhz
    trace_mask = (rel_freq_trace_mhz >= start_mhz) & (rel_freq_trace_mhz <= stop_mhz)
    dip_mask = mode_number == selected_group
    fig, ax = plt.subplots(figsize=(12.8, 6.2), constrained_layout=True)
    if np.any(trace_mask):
        x = (rel_freq_trace_mhz[trace_mask] - start_mhz) / 1000.0
        y = trans_norm[trace_mask]
        order = np.argsort(x)
        ax.plot(x[order], y[order], color="#2364aa", lw=1.4, label="normalized transmission")
    cmap = plt.get_cmap("tab20")
    present: set[int] = set()
    duplicate_labels: list[str] = []
    if np.any(dip_mask):
        unmatched_mask = dip_mask & (labels < 0)
        if np.any(unmatched_mask):
            ax.scatter(
                folded_mhz[unmatched_mask] / 1000.0,
                dip_norm[unmatched_mask],
                s=34,
                color="#777777",
                alpha=0.45,
                marker="x",
                zorder=2,
                label="unmatched",
            )
        for label in [item for item in np.unique(labels[dip_mask]) if item >= 0]:
            mask = dip_mask & (labels == label)
            present.add(int(label))
            x = folded_mhz[mask] / 1000.0
            y = dip_norm[mask]
            color = cmap(int(label) % 20)
            representative = int(np.argmin(y))
            if len(x) > 1:
                duplicate_labels.append(f"F{int(label) + 1}")
                other = np.ones(len(x), dtype=bool)
                other[representative] = False
                ax.scatter(
                    x[other],
                    y[other],
                    s=30,
                    color=color,
                    alpha=0.32,
                    edgecolors="none",
                    zorder=2,
                    label="_nolegend_",
                )
            xx = float(x[representative])
            yy = float(y[representative])
            name = f"F{int(label) + 1}"
            ax.scatter(
                [xx],
                [yy],
                s=64,
                color=color,
                edgecolors="black",
                linewidths=0.6,
                zorder=3,
                label=name,
            )
            if yy < 0.12:
                ax.text(xx, yy + 0.04, name, color=color, fontsize=11, ha="center", va="bottom")
            else:
                ax.text(xx, yy - 0.035, name, color=color, fontsize=11, ha="center", va="top")
    missing = [f"F{i + 1}" for i in range(expected_families) if i not in present]
    note_parts = [
        f"shown families: {len(present)}/{expected_families}",
    ]
    if missing:
        note_parts.append("missing " + ", ".join(missing))
    if duplicate_labels:
        note_parts.append("duplicates collapsed " + ", ".join(duplicate_labels))
    unmatched_count = int(np.sum(dip_mask & (labels < 0)))
    if unmatched_count:
        note_parts.append(f"unmatched {unmatched_count}")
    ax.text(
        0.01,
        0.99,
        "; ".join(note_parts),
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=12,
        bbox={"boxstyle": "round,pad=0.3", "facecolor": "white", "edgecolor": "#ccd3df", "alpha": 0.92},
    )
    ax.set_xlim(0, fsr_mhz / 1000.0)
    ax.set_ylim(-0.06, 1.06)
    ax.set_xlabel("Offset inside selected FSR (GHz)")
    ax.set_ylabel("Normalized transmission")
    ax.set_title(f"Selected one-FSR panel near mode index {selected_group:+d} ({len(present)}/{expected_families} families)")
    ax.grid(True, alpha=0.22)
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)
    fig.savefig(path)
    plt.close(fig)


def plot_folded_families(
    path: Path,
    *,
    rel_freq_mhz: np.ndarray,
    mode_number: np.ndarray,
    folded_mhz: np.ndarray,
    depth: np.ndarray,
    labels: np.ndarray,
    centers_mhz: np.ndarray,
    fsr_mhz: float,
) -> None:
    fig, (ax, side) = plt.subplots(
        1,
        2,
        figsize=(15, 6.5),
        gridspec_kw={"width_ratios": [4.5, 1.3]},
        constrained_layout=True,
    )
    cmap = plt.get_cmap("tab20")
    sizes = 22 + 80 * robust_depth_weights(depth)
    unmatched = labels < 0
    if np.any(unmatched):
        ax.scatter(
            mode_number[unmatched],
            folded_mhz[unmatched] / 1000.0,
            s=24,
            color="#777777",
            alpha=0.35,
            marker="x",
            label="unmatched",
            linewidths=0.8,
        )
    for label in [item for item in np.unique(labels) if item >= 0]:
        mask = labels == label
        color = cmap(int(label) % 20)
        ax.scatter(
            mode_number[mask],
            folded_mhz[mask] / 1000.0,
            s=sizes[mask],
            color=color,
            alpha=0.82,
            label=f"F{int(label) + 1}",
            edgecolors="none",
        )
        side.scatter(
            np.full(np.sum(mask), int(label) + 1),
            folded_mhz[mask] / 1000.0,
            s=10,
            color=color,
            alpha=0.25,
            edgecolors="none",
        )
    for i, center in enumerate(centers_mhz):
        side.scatter(i + 1, center / 1000.0, s=54, color=cmap(i % 20), edgecolors="black", linewidths=0.7)
    ax.set_xlabel("FSR index")
    ax.set_ylabel("Folded frequency within one FSR (GHz)")
    ax.set_title(f"Folded array-mode families, selected FSR={fsr_mhz / 1000.0:.6g} GHz")
    ax.grid(True, alpha=0.22)
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0, ncol=1)
    side.set_xlabel("Family")
    side.set_ylabel("Folded frequency (GHz)")
    side.set_title("One-FSR centers")
    side.grid(True, alpha=0.22)
    fig.savefig(path)
    plt.close(fig)


@dataclass
class ArrayOptions:
    """Typed inputs shared by the CLI and callable step; no device I/O on construction."""
    data_path: Path
    output_dir: Path | None = None
    chip: str | None = None
    die: str | None = None
    cavity: str | None = None
    start_nm: float = 1530.0
    center_nm: float = 1550.0
    stop_nm: float = 1570.0
    mzi_d1_mhz: float = 40.44357
    mzi_d2_mhz: float = 4e-08
    mzi_d3_mhz: float = -3e-14
    disk_fsr_mhz: float | None = None
    reference_family_points: Path | None = None
    reference_family_plan: Path | None = None
    reference_family_match_tolerance_mhz: float = 2000.0
    offset_mhz: float = 0.0
    peak_sensitivity_db: float = 0.0
    mzi_sensitivity_db: float = 0.0
    nominal_width_samples: int = 50
    fsr_min_ghz: float | None = None
    fsr_max_ghz: float | None = None
    fsr_bin_ghz: float = 0.1
    min_depth: float = 0.2
    max_fsr_resonances: int = 1200
    expected_families: int | None = None
    q_min_half_window_samples: int = 120
    q_max_half_window_samples: int = 2500
    q_neighbor_window_fraction: float = 0.4


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_path", type=Path, help="Large-scan raw CSV/NPZ path.")
    parser.add_argument("--output-dir", type=Path, default=None, help="Directory for preanalysis outputs. Defaults to data file directory.")
    parser.add_argument("--chip", default=None)
    parser.add_argument("--die", default=None)
    parser.add_argument("--cavity", default=None)
    parser.add_argument("--start-nm", type=float, default=1530.0)
    parser.add_argument("--center-nm", type=float, default=1550.0)
    parser.add_argument("--stop-nm", type=float, default=1570.0)
    parser.add_argument("--mzi-d1-mhz", type=float, default=40.44357)
    parser.add_argument("--mzi-d2-mhz", type=float, default=4e-8)
    parser.add_argument("--mzi-d3-mhz", type=float, default=-3e-14)
    parser.add_argument("--disk-fsr-mhz", type=float, default=None, help="Optional manual FSR override for folding.")
    parser.add_argument(
        "--reference-family-points",
        type=Path,
        default=None,
        help="Optional pre-tuning family_points.csv used to retain physical F labels after tuning.",
    )
    parser.add_argument(
        "--reference-family-plan",
        type=Path,
        default=None,
        help="Comb-reconstruction plan.json containing each family's expected frequency shift.",
    )
    parser.add_argument(
        "--reference-family-match-tolerance-mhz",
        type=float,
        default=2000.0,
        help="Maximum absolute frequency error for reference-trajectory assignment.",
    )
    parser.add_argument("--offset-mhz", type=float, default=0.0)
    parser.add_argument("--peak-sensitivity-db", type=float, default=0.0)
    parser.add_argument("--mzi-sensitivity-db", type=float, default=0.0)
    parser.add_argument("--nominal-width-samples", type=int, default=50)
    parser.add_argument("--fsr-min-ghz", type=float, default=None, help="Optional lower bound for pair-spacing FSR search. Defaults to data-driven auto range.")
    parser.add_argument("--fsr-max-ghz", type=float, default=None, help="Optional upper bound for pair-spacing FSR search. Defaults to the measured scan span.")
    parser.add_argument("--fsr-bin-ghz", type=float, default=0.10)
    parser.add_argument("--min-depth", type=float, default=0.2)
    parser.add_argument("--max-fsr-resonances", type=int, default=1200)
    parser.add_argument("--expected-families", type=int, default=None)
    parser.add_argument("--q-min-half-window-samples", type=int, default=120)
    parser.add_argument("--q-max-half-window-samples", type=int, default=2500)
    parser.add_argument("--q-neighbor-window-fraction", type=float, default=0.40)
    return parser.parse_args(argv)


def analyze_array_scan(args: ArrayOptions) -> dict[str, object]:
    data_path = args.data_path.resolve()
    output_dir = args.output_dir.resolve() if args.output_dir is not None else data_path.parent.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    chip0, die0, cavity0 = infer_chip_die_cavity(data_path)
    chip = args.chip or chip0
    die = args.die or die0
    cavity = args.cavity or cavity0
    expected_families = args.expected_families or infer_expected_families(chip)
    acquisition_metadata, acquisition_metadata_path = read_acquisition_metadata(data_path, output_dir)

    time_s, trigger_raw, trans_raw, mzi_raw = read_large_scan_data(data_path)
    mzi_index = find_mzi_index(mzi_raw, args.mzi_sensitivity_db)
    if len(mzi_index) < 4:
        raise SystemExit(f"Too few MZI extrema detected: {len(mzi_index)}")

    valid_idx, valid_mu = sample_mzi_mu(len(trans_raw), mzi_index)
    rel_freq_trace_mhz, mu_center = relative_frequency_mhz(
        valid_mu,
        start_nm=args.start_nm,
        center_nm=args.center_nm,
        stop_nm=args.stop_nm,
        d1=args.mzi_d1_mhz,
        d2=args.mzi_d2_mhz,
        d3=args.mzi_d3_mhz,
        offset_mhz=args.offset_mhz,
    )
    trans_norm_full, _baseline = normalize_transmission_with_baseline(trans_raw)
    trans_norm = trans_norm_full[valid_idx]
    wavelength_axis_linear_nm = time_to_wavelength_nm(
        time_s,
        start_nm=args.start_nm,
        center_nm=args.center_nm,
        stop_nm=args.stop_nm,
    )
    absolute_wavelength_calibration = absolute_wavelength_anchor(
        metadata=acquisition_metadata,
        time_s=time_s,
        trigger=trigger_raw,
        valid_idx=valid_idx,
        rel_freq_trace_mhz=rel_freq_trace_mhz,
        start_nm=args.start_nm,
        center_nm=args.center_nm,
    )
    wavelength_axis_nm = np.asarray(wavelength_axis_linear_nm, dtype=float).copy()
    absolute_freq_axis_mhz = np.asarray(wavelength_nm_to_freq_mhz(wavelength_axis_linear_nm), dtype=float)
    wavelength_source = "linear_time_axis"
    if absolute_wavelength_calibration.get("ok"):
        absolute_freq_trace_mhz = (
            float(wavelength_nm_to_freq_mhz(args.center_nm))
            + rel_freq_trace_mhz
            + float(absolute_wavelength_calibration["freq_offset_mhz"])
        )
        absolute_freq_axis_mhz = np.full(len(time_s), np.nan, dtype=float)
        absolute_freq_axis_mhz[valid_idx] = absolute_freq_trace_mhz
        wavelength_axis_nm[valid_idx] = freq_mhz_to_wavelength_nm(absolute_freq_trace_mhz)
        wavelength_source = f"mzi_relative_frequency+{absolute_wavelength_calibration.get('source', 'absolute_anchor')}"
    absolute_wavelength_calibration["metadata_path"] = str(acquisition_metadata_path) if acquisition_metadata_path else None
    mzi_freq_axis_mhz = np.full(len(time_s), np.nan, dtype=float)
    mzi_freq_axis_mhz[valid_idx] = rel_freq_trace_mhz

    dip_idx, dip_norm, _trans_norm_for_dips, _baseline_for_dips = find_transmission_dips(
        trans_raw,
        peak_sensitivity_db=args.peak_sensitivity_db,
        nominal_width_samples=args.nominal_width_samples,
        mzi_index=mzi_index,
    )
    in_range = (dip_idx >= valid_idx[0]) & (dip_idx <= valid_idx[-1])
    dip_idx = dip_idx[in_range]
    dip_norm = dip_norm[in_range]
    dip_freq_mhz = np.interp(dip_idx.astype(float), valid_idx.astype(float), rel_freq_trace_mhz)
    depth = 1.0 - dip_norm

    design_fsr = expected_array_fsr_mhz(data_path=data_path, output_dir=output_dir, chip=chip, die=die, cavity=cavity)
    design_fsr_mhz = design_fsr[0] if design_fsr is not None else None
    design_radius = design_radius_um_for_target(data_path=data_path, output_dir=output_dir, chip=chip, die=die, cavity=cavity)
    design_radius_um = design_radius[0] if design_radius is not None else None

    fsr_search_min_ghz = args.fsr_min_ghz
    fsr_search_max_ghz = args.fsr_max_ghz
    fsr_search_reference: dict[str, Any] = {"source": "data_driven_auto_range"}
    if design_fsr_mhz is not None and math.isfinite(design_fsr_mhz) and design_fsr_mhz > 0:
        design_fsr_ghz = design_fsr_mhz / 1000.0
        if fsr_search_min_ghz is None:
            fsr_search_min_ghz = 0.5 * design_fsr_ghz
        if fsr_search_max_ghz is None:
            fsr_search_max_ghz = 1.5 * design_fsr_ghz
        fsr_search_reference = {
            "source": "array_design_pm50pct",
            "design_fsr_mhz": float(design_fsr_mhz),
            "design_fsr_source": design_fsr[1],
        }

    centers_ghz, spacing_hist, spacing_smooth, fsr_candidates = pair_spacing_spectrum(
        dip_freq_mhz,
        depth,
        min_ghz=fsr_search_min_ghz,
        max_ghz=fsr_search_max_ghz,
        bin_ghz=args.fsr_bin_ghz,
        min_depth=args.min_depth,
        max_resonances=args.max_fsr_resonances,
        expected_families=expected_families,
    )
    if not fsr_candidates and args.disk_fsr_mhz is None:
        raise SystemExit("Could not find a dominant FSR candidate from the pair-spacing spectrum.")
    selected_fsr_mhz = float(args.disk_fsr_mhz) if args.disk_fsr_mhz is not None else float(fsr_candidates[0]["fsr_mhz"])
    selected_fsr_source = "manual_override" if args.disk_fsr_mhz is not None else "pair_spacing_spectrum"
    if args.reference_family_points is not None:
        selected_fsr_source = "pre_tuning_reference"

    inferred_ng = None
    if design_radius_um is not None and selected_fsr_mhz > 0:
        inferred_ng = C_M_PER_S / (selected_fsr_mhz * 1e6 * 2.0 * math.pi * design_radius_um * 1e-6)

    if expected_families is None:
        expected_families = max(1, min(20, len(dip_freq_mhz) // 5))

    cluster_mask = np.isfinite(dip_freq_mhz) & np.isfinite(depth) & (depth >= args.min_depth)
    cluster_freq = dip_freq_mhz[cluster_mask]
    cluster_depth = depth[cluster_mask]
    cluster_indices = np.where(cluster_mask)[0]
    cluster_wavelength_nm = wavelength_axis_nm[dip_idx[cluster_indices]]
    folded_mhz, fold_origin_ref_mhz = circular_fold(cluster_freq, selected_fsr_mhz)
    mode_number_ref = group_index_for_frequency(cluster_freq, fold_origin_ref_mhz, selected_fsr_mhz)
    detected_mode_number_ref = mode_number_ref.copy()
    use_reference_families = args.reference_family_points is not None or args.reference_family_plan is not None
    if use_reference_families:
        if args.reference_family_points is None or args.reference_family_plan is None:
            raise SystemExit("--reference-family-points and --reference-family-plan must be provided together.")
        if args.disk_fsr_mhz is None:
            raise SystemExit("Reference-family assignment requires --disk-fsr-mhz from the pre-tuning scan.")
        reference_rows, reference_plan_rows = load_reference_family_inputs(
            args.reference_family_points.resolve(),
            args.reference_family_plan.resolve(),
        )
        cluster_absolute_freq_mhz = absolute_freq_axis_mhz[dip_idx[cluster_indices]]
        (
            family_labels,
            mode_number_ref,
            mode_number,
            family_centers_mhz,
            family_assignment,
        ) = assign_reference_family_trajectories(
            reference_rows,
            reference_plan_rows,
            cluster_absolute_freq_mhz,
            folded_mhz,
            expected_families=int(expected_families),
            match_tolerance_mhz=float(args.reference_family_match_tolerance_mhz),
        )
        family_assignment.update(
            {
                "reference_family_points": str(args.reference_family_points.resolve()),
                "reference_family_plan": str(args.reference_family_plan.resolve()),
            }
        )
        matched_reference = family_labels >= 0
        if np.any(matched_reference):
            mode_zero_ref = int(
                round(float(np.median(detected_mode_number_ref[matched_reference] - mode_number[matched_reference])))
            )
        else:
            mode_zero_ref = 0
        unmatched_reference = ~matched_reference
        mode_number[unmatched_reference] = detected_mode_number_ref[unmatched_reference] - mode_zero_ref
        mode_number_ref[unmatched_reference] = detected_mode_number_ref[unmatched_reference]
        mode_zero = {
            "mode_number_ref": mode_zero_ref,
            "source": "reference_family_points",
            "reference_family_points": str(args.reference_family_points.resolve()),
        }
    else:
        family_labels, family_centers_mhz, family_assignment = track_array_mode_families(
            folded_mhz,
            mode_number_ref,
            cluster_depth,
            expected_families=int(expected_families),
            fsr_mhz=selected_fsr_mhz,
        )
        mode_zero = choose_mode_zero_reference(mode_number_ref, cluster_wavelength_nm, center_nm=args.center_nm)
        mode_zero_ref = int(mode_zero.get("mode_number_ref", 0))
        mode_number = mode_number_ref - mode_zero_ref
    fold_origin_centered_mhz = fold_origin_ref_mhz + mode_zero_ref * selected_fsr_mhz
    selected_group = select_one_fsr_group(mode_number, family_labels, int(expected_families))
    selected_group_number = int(selected_group["mode_number"])
    selected_group_info = one_fsr_group_diagnostics(
        mode_number,
        family_labels,
        selected_group=selected_group_number,
        expected_families=int(expected_families),
    )

    family_rows = []
    for i, center in enumerate(family_centers_mhz):
        mask = family_labels == i
        family_rows.append(
            {
                "family_label": f"F{i + 1}",
                "center_folded_ghz": float(center / 1000.0),
                "count": int(np.sum(mask)),
                "median_depth": float(np.median(cluster_depth[mask])) if np.any(mask) else float("nan"),
                "max_depth": float(np.max(cluster_depth[mask])) if np.any(mask) else float("nan"),
            }
        )

    rows: list[dict[str, Any]] = []
    for j, original_i in enumerate(cluster_indices):
        label_i = int(family_labels[j])
        family = f"F{label_i + 1}" if label_i >= 0 else "unmatched"
        sample_index = int(dip_idx[original_i])
        ref_mode = int(mode_number_ref[j])
        centered_mode = int(mode_number[j])
        rows.append(
            {
                "dip_id": int(original_i + 1),
                "family": family,
                "family_label": family,
                "sample_index": sample_index,
                "time_s": float(time_s[sample_index]),
                "wavelength_nm": float(wavelength_axis_nm[sample_index]),
                "wavelength_nm_linear": float(wavelength_axis_linear_nm[sample_index]),
                "absolute_freq_mhz": float(absolute_freq_axis_mhz[sample_index]),
                "wavelength_source": wavelength_source,
                "norm_transmission": float(dip_norm[original_i]),
                "depth_1_minus_norm": float(depth[original_i]),
                "relative_freq_mhz": float(cluster_freq[j]),
                "relative_freq_ghz": float(cluster_freq[j] / 1000.0),
                "mode_number": centered_mode,
                "mode_number_ref": ref_mode,
                "mode_number_centered": centered_mode,
                "folded_freq_ref_mhz": float(folded_mhz[j]),
                "folded_freq_centered_mhz": float(folded_mhz[j]),
                "folded_freq_ghz": float(folded_mhz[j] / 1000.0),
            }
        )

    spectrum_path = output_dir / "array_preanalysis_spectrum.png"
    one_fsr_path = output_dir / "array_preanalysis_one_fsr_modes.png"
    fsr_path = output_dir / "array_preanalysis_pair_fsr.png"
    folded_path = output_dir / "array_preanalysis_folded_families.png"
    modes_path = output_dir / "array_preanalysis_modes.csv"
    family_points_path = output_dir / "family_points.csv"
    q_table_path = output_dir / "q_by_mode.csv"
    q_summary_path = output_dir / "array_q_summary.json"
    summary_path = output_dir / "array_preanalysis_summary.json"
    laser_readback_comparison_path = output_dir / "laser_readback_vs_mzi.csv"

    plot_frequency_spectrum(
        spectrum_path,
        rel_freq_trace_mhz=rel_freq_trace_mhz,
        trans_norm=trans_norm,
        dip_freq_mhz=dip_freq_mhz,
        dip_norm=dip_norm,
        dip_depth=depth,
        min_depth=args.min_depth,
        mzi_d1_mhz=args.mzi_d1_mhz,
    )
    plot_pair_fsr(
        fsr_path,
        centers_ghz=centers_ghz,
        hist=spacing_hist,
        smooth=spacing_smooth,
        candidates=fsr_candidates,
        design_fsr_mhz=design_fsr_mhz,
    )
    plot_one_fsr_modes(
        one_fsr_path,
        rel_freq_trace_mhz=rel_freq_trace_mhz,
        trans_norm=trans_norm,
        dip_freq_mhz=cluster_freq,
        dip_norm=dip_norm[cluster_mask],
        mode_number=mode_number,
        folded_mhz=folded_mhz,
        labels=family_labels,
        selected_group=selected_group_number,
        expected_families=int(expected_families),
        fsr_mhz=selected_fsr_mhz,
        fold_origin_mhz=fold_origin_centered_mhz,
    )
    plot_folded_families(
        folded_path,
        rel_freq_mhz=cluster_freq,
        mode_number=mode_number,
        folded_mhz=folded_mhz,
        depth=cluster_depth,
        labels=family_labels,
        centers_mhz=family_centers_mhz,
        fsr_mhz=selected_fsr_mhz,
    )
    write_modes_csv(modes_path, rows)
    write_array_family_points_csv(family_points_path, rows)
    laser_readback_comparison = compare_laser_readbacks_to_mzi(
        acquisition_metadata,
        time_s=time_s,
        wavelength_axis_nm=wavelength_axis_nm,
        absolute_wavelength_calibration=absolute_wavelength_calibration,
        mzi_d1_mhz=args.mzi_d1_mhz,
        output_path=laser_readback_comparison_path,
    )
    q_rows = fit_array_q_rows(
        rows,
        time_s=time_s,
        trans_norm_full=trans_norm_full,
        mzi_freq_axis_mhz=mzi_freq_axis_mhz,
        wavelength_axis_nm=wavelength_axis_nm,
        min_half_window_samples=args.q_min_half_window_samples,
        max_half_window_samples=args.q_max_half_window_samples,
        neighbor_window_fraction=args.q_neighbor_window_fraction,
    )
    add_slope_corrected_wavelengths(
        q_rows,
        laser_readback_comparison=laser_readback_comparison,
        anchor_freq_mhz=finite_float(absolute_wavelength_calibration.get("anchor_freq_mhz")),
    )
    write_array_q_table(q_table_path, q_rows)
    q_summary = summarize_array_q(q_rows)
    q_summary.update(
        {
            "ok": True,
            "family_points_csv": str(family_points_path),
            "q_table": str(q_table_path),
            "frequency_axis": (
                "MZI-calibrated relative frequency for linewidth; "
                f"absolute wavelength/Q center from {wavelength_source}"
            ),
            "absolute_wavelength_calibration": absolute_wavelength_calibration,
            "q_fit_config": {
                "min_half_window_samples": int(args.q_min_half_window_samples),
                "max_half_window_samples": int(args.q_max_half_window_samples),
                "neighbor_window_fraction": float(args.q_neighbor_window_fraction),
            },
            "laser_readback_vs_mzi": laser_readback_comparison,
        }
    )
    q_summary_path.write_text(json.dumps(q_summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    summary = {
        "ok": True,
        "data_path": str(data_path),
        "output_dir": str(output_dir),
        "chip": chip,
        "die": die,
        "cavity": cavity,
        "mzi": {
            "d1_mhz": args.mzi_d1_mhz,
            "d2_mhz": args.mzi_d2_mhz,
            "d3_mhz": args.mzi_d3_mhz,
            "extrema_count": int(len(mzi_index)),
            "mu_center": float(mu_center),
        },
        "absolute_wavelength_calibration": absolute_wavelength_calibration,
        "laser_readback_vs_mzi": laser_readback_comparison,
        "resonance_count": int(len(dip_idx)),
        "resonance_count_used_for_fsr": int(min(np.sum(np.isfinite(dip_freq_mhz) & np.isfinite(depth) & (depth >= args.min_depth)), args.max_fsr_resonances)),
        "min_depth": args.min_depth,
        "expected_families": int(expected_families),
        "selected_fsr_ghz": float(selected_fsr_mhz / 1000.0),
        "selected_fsr_mhz": selected_fsr_mhz,
        "selected_fsr_source": selected_fsr_source,
        "fsr_search_range_ghz": {
            "min": float(fsr_search_min_ghz) if fsr_search_min_ghz is not None else None,
            "max": float(fsr_search_max_ghz) if fsr_search_max_ghz is not None else None,
        },
        "fsr_search_reference": fsr_search_reference,
        "design_fsr_mhz": design_fsr_mhz,
        "design_fsr_source": design_fsr[1] if design_fsr is not None else None,
        "design_radius_um": design_radius_um,
        "design_radius_source": design_radius[1] if design_radius is not None else None,
        "ng_from_selected_fsr": float(inferred_ng) if inferred_ng is not None else None,
        "ng_reference_note": f"ng = c / (2*pi*R*FSR), R from array design, comparison ng={DEFAULT_NG_ESTIMATE:g}",
        "fold_origin_mhz": float(fold_origin_centered_mhz),
        "fold_origin_ref_mhz": float(fold_origin_ref_mhz),
        "mu_zero_reference": mode_zero,
        "mu_numbering_note": "mode_number is centered so the FSR group nearest center_nm is mu=0; original FSR index is mode_number_ref.",
        "selected_one_fsr_group": selected_group_info,
        "family_assignment": family_assignment,
        "array_q": {
            "summary_json": str(q_summary_path),
            "family_points_csv": str(family_points_path),
            "q_table": str(q_table_path),
            "mode_count": q_summary["mode_count"],
            "ok_count": q_summary["ok_count"],
        },
        "fsr_candidates": fsr_candidates,
        "families": family_rows,
        "outputs": {
            "spectrum_png": str(spectrum_path),
            "one_fsr_png": str(one_fsr_path),
            "pair_fsr_png": str(fsr_path),
            "folded_families_png": str(folded_path),
            "modes_csv": str(modes_path),
            "family_points_csv": str(family_points_path),
            "q_table": str(q_table_path),
            "laser_readback_vs_mzi_csv": str(laser_readback_comparison_path)
            if laser_readback_comparison.get("path")
            else None,
            "array_q_summary_json": str(q_summary_path),
            "summary_json": str(summary_path),
        },
    }
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)
    return summary

def main(argv: list[str] | None = None) -> int:
    analyze_array_scan(ArrayOptions(**vars(parse_args(argv))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
