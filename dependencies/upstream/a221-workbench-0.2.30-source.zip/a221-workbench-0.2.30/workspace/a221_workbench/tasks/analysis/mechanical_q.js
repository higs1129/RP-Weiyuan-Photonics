function dbmToLinear(v){return Math.pow(10,v/10)}
function linearToDbm(v){return 10*Math.log10(Math.max(v,1e-300))}
function median(arr){if(!arr.length)return NaN;const a=[...arr].sort((x,y)=>x-y),m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2}
function percentile(arr,p){if(!arr.length)return NaN;const a=[...arr].sort((x,y)=>x-y),i=Math.min(a.length-1,Math.max(0,Math.round((a.length-1)*p)));return a[i]}
function mechComponentLinear(x,p){const f0=Math.max(p[0],1e-12),gamma=Math.max(p[1],1e-12),amp=Math.max(p[2],1e-300),den=(f0*f0-x*x)*(f0*f0-x*x)+(x*gamma)*(x*gamma),peak=(f0*gamma)*(f0*gamma);return amp*peak/Math.max(den,1e-300)}
function mechSusceptibilityLinear(x,p){const bg=Math.max(p[3],1e-300);return bg+mechComponentLinear(x,p)}
function fitMechanicalSusceptibilityVisible(chart){
  const source=(chart.opt.series[0]&&chart.opt.series[0].data)||[];
  let pts=source.filter(p=>finite(p[0])&&finite(p[1])&&p[0]>=chart.view.x0&&p[0]<=chart.view.x1).map(p=>[p[0],dbmToLinear(p[1]),p[1]]);
  if(pts.length<12)throw new Error('visible range has too few points');
  const stride=Math.max(1,Math.ceil(pts.length/1600));
  pts=pts.filter((_,i)=>i%stride===0);
  const xs=pts.map(p=>p[0]), ys=pts.map(p=>p[1]), ydb=pts.map(p=>p[2]);
  const xMin=Math.min(...xs), xMax=Math.max(...xs), span=Math.max(xMax-xMin,1e-9);
  const edgeN=Math.max(3,Math.floor(pts.length*0.16));
  const bg0=Math.max(1e-300,median([...ys.slice(0,edgeN),...ys.slice(-edgeN)]));
  let imax=0; for(let i=1;i<ys.length;i++) if(ys[i]>ys[imax]) imax=i;
  const f00=xs[imax], amp0=Math.max(ys[imax]-bg0, percentile(ys,.9)-bg0, bg0*0.1, 1e-300);
  const half=bg0+amp0/2;
  let left=xMin,right=xMax;
  for(let i=imax;i>0;i--){if(ys[i]<=half){left=xs[i];break}}
  for(let i=imax;i<ys.length;i++){if(ys[i]<=half){right=xs[i];break}}
  const g0=Math.max(Math.min(right-left,span),span/200);
  let q=[f00,Math.log(g0),Math.log(amp0),Math.log(bg0)];
  const score=(qq)=>{
    const p=[Math.min(xMax,Math.max(xMin,qq[0])),Math.exp(qq[1]),Math.exp(qq[2]),Math.exp(qq[3])];
    let s=0,n=0;
    for(let i=0;i<pts.length;i++){const m=linearToDbm(mechSusceptibilityLinear(xs[i],p)); if(!finite(m))continue; const r=m-ydb[i]; s+=r*r; n++}
    const g=p[1];
    if(g<span/3000||g>span*2)s+=1e4;
    return s/Math.max(n,1);
  };
  let best=score(q), steps=[span/12,Math.log(1.8),Math.log(1.8),Math.log(1.25)];
  for(let iter=0;iter<75;iter++){
    let improved=false;
    for(let k=0;k<4;k++){
      let localBest=best, localQ=q;
      for(const dir of [-1,1]){const cand=q.slice();cand[k]+=dir*steps[k];cand[0]=Math.min(xMax,Math.max(xMin,cand[0]));const sc=score(cand);if(sc<localBest){localBest=sc;localQ=cand}}
      if(localBest<best){q=localQ;best=localBest;improved=true}
    }
    if(!improved)steps=steps.map(v=>v*0.72);
    if(Math.max(...steps)<1e-6)break;
  }
  const p=[Math.min(xMax,Math.max(xMin,q[0])),Math.exp(q[1]),Math.exp(q[2]),Math.exp(q[3])];
  const fitData=[], mechData=[]; const nfit=360;
  for(let i=0;i<nfit;i++){const x=xMin+span*i/(nfit-1),mech=mechComponentLinear(x,p);fitData.push([x,linearToDbm(p[3]+mech)]);mechData.push([x,linearToDbm(mech)])}
  const bgDb=linearToDbm(p[3]), f0=p[0], fwhm=p[1], qm=f0/fwhm;
  return {data:fitData,mechData,bgDb,f0,fwhm,qm,rmseDb:Math.sqrt(best),x0:xMin,x1:xMax};
}
