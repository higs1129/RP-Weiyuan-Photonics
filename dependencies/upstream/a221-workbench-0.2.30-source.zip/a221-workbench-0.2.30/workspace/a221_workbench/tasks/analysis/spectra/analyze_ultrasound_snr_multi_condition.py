from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.analysis.spectra'


import argparse
import html
import json
import math
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from a221_workbench.tasks.analysis.spectra.analyze_ultrasound_snr import (
    cavity_number,
    completed_by_cavity,
    detect_common_tone,
    finite_float,
    interpolate_to,
    load_psd,
    load_summary,
    rounded,
    same_frequency_on_off_snr,
    summary_stats,
)


COLORS = ["#0072B2", "#D55E00", "#009E73", "#CC79A7"]


def condition_id(label: str, index: int) -> str:
    compact = "".join(character.lower() if character.isalnum() else "_" for character in label).strip("_")
    return compact or f"condition_{index + 1}"


def load_rbw(summary_path: Path) -> float:
    config = load_summary(summary_path.parent / "run_config.json")
    rbw_hz = finite_float(config.get("spectrum_rbw_hz"))
    if rbw_hz is None or rbw_hz <= 0:
        raise ValueError(f"run_config.json does not contain a positive spectrum_rbw_hz: {summary_path.parent}")
    return rbw_hz


def analyze_condition(
    *,
    label: str,
    index: int,
    summary_path: Path,
    baseline_rows: dict[str, dict[str, Any]],
    baseline_psd: dict[str, np.ndarray],
    reference_hz: np.ndarray,
    baseline_rbw_hz: float,
    cavities: list[str],
    search_min_hz: float,
    search_max_hz: float | None,
    signal_half_width_rbw: float,
) -> dict[str, Any]:
    summary_path = summary_path.resolve()
    summary = load_summary(summary_path)
    rows_by_cavity = completed_by_cavity(summary)
    missing = sorted(set(cavities) - set(rows_by_cavity), key=cavity_number)
    if missing:
        raise ValueError(f"condition {label!r} is missing completed cavities: {', '.join(missing)}")
    rbw_hz = load_rbw(summary_path)
    if not math.isclose(rbw_hz, baseline_rbw_hz, rel_tol=1e-6, abs_tol=1e-6):
        raise ValueError(f"RBW mismatch for {label!r}: baseline={baseline_rbw_hz}, condition={rbw_hz}")

    condition_psd: dict[str, np.ndarray] = {}
    for cavity in cavities:
        frequency_hz, values = load_psd(Path(str(rows_by_cavity[cavity]["raw_npz"])))
        condition_psd[cavity] = interpolate_to(reference_hz, frequency_hz, values)

    detection = detect_common_tone(
        reference_hz,
        [baseline_psd[cavity] for cavity in cavities],
        [condition_psd[cavity] for cavity in cavities],
        search_min_hz=search_min_hz,
        search_max_hz=search_max_hz,
    )
    detection["source"] = "median condition-minus-baseline maximum across matched cavities"

    rows: list[dict[str, Any]] = []
    for cavity in cavities:
        metadata = rows_by_cavity[cavity]
        result = same_frequency_on_off_snr(
            reference_hz,
            baseline_psd[cavity],
            condition_psd[cavity],
            detection["frequency_hz"],
            rbw_hz=baseline_rbw_hz,
            signal_half_width_rbw=signal_half_width_rbw,
        )
        rows.append(
            {
                "cavity": cavity,
                "cavity_index": cavity_number(cavity),
                "family": metadata.get("family"),
                "mu": metadata.get("mu"),
                "comb_index": metadata.get("comb_index"),
                "wavelength_nm": metadata.get("wavelength_nm"),
                "baseline_raw_npz": str(Path(str(baseline_rows[cavity]["raw_npz"])).resolve()),
                "condition_raw_npz": str(Path(str(metadata["raw_npz"])).resolve()),
                "same_frequency": result,
            }
        )

    return {
        "id": condition_id(label, index),
        "label": label,
        "color": COLORS[index % len(COLORS)],
        "summary_json": str(summary_path),
        "run_dir": str(summary_path.parent),
        "started_at": summary.get("started_at"),
        "tone_detection": detection,
        "summary": summary_stats(rows),
        "cavities": rows,
    }


def build_html(payload: dict[str, Any]) -> str:
    chart_payload = {
        "baseline": payload["baseline_run"],
        "conditions": [
            {
                "id": condition["id"],
                "label": condition["label"],
                "color": condition["color"],
                "toneKhz": condition["tone_detection"]["frequency_hz"] / 1e3,
                "summary": condition["summary"],
                "rows": [
                    {
                        "cavity": row["cavity"],
                        "family": row["family"],
                        "mu": row["mu"],
                        "snr": row["same_frequency"]["snr_db"],
                        "strictSnr": row["same_frequency"]["power_subtracted_snr_db"],
                        "peakKhz": row["same_frequency"]["peak_frequency_hz"] / 1e3,
                        "onPsd": row["same_frequency"]["on_psd_dbm_per_hz"],
                        "offPsd": row["same_frequency"]["off_psd_dbm_per_hz"],
                    }
                    for row in condition["cavities"]
                ],
            }
            for condition in payload["conditions"]
        ],
    }
    data = json.dumps(chart_payload, ensure_ascii=False, separators=(",", ":"))
    title = "共振与非共振超声频点 SNR 对比"
    return _html_template().replace("__TITLE__", html.escape(title)).replace("__DATA__", data)


def _html_template() -> str:
    return r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--ink:#111827;--muted:#53606d;--line:#cbd5df;--grid:#e6ebf0}
*{box-sizing:border-box}body{margin:0;background:#fff;color:var(--ink);font-family:Arial,"Microsoft YaHei",sans-serif}
main{max-width:1480px;margin:0 auto;padding:22px 26px 30px}h1{font-size:28px;line-height:1.25;margin:0 0 5px;letter-spacing:0}.sub{font-size:16px;color:var(--muted);margin-bottom:15px}
.metrics{display:grid;grid-template-columns:repeat(3,minmax(190px,1fr));border:1px solid var(--line);margin-bottom:13px}.metric{padding:11px 14px;border-right:1px solid var(--line)}.metric:last-child{border-right:0}.metric span{display:block;color:var(--muted);font-size:14px}.metric strong{display:block;font-size:20px;margin-top:3px}.metric small{display:block;color:var(--muted);font-size:14px;margin-top:3px}
.toolbar{display:flex;gap:20px;align-items:center;flex-wrap:wrap;margin:5px 0 10px}.toggle{display:flex;align-items:center;gap:7px;font-size:15px}.swatch{width:18px;height:4px;display:inline-block}.chart{height:650px;border-top:1px solid var(--line);position:relative}svg{width:100%;height:100%;display:block;overflow:visible}.tip{position:fixed;z-index:5;display:none;pointer-events:none;background:#fff;border:1px solid var(--ink);border-radius:4px;padding:9px 11px;font-size:14px;line-height:1.45;box-shadow:0 3px 14px rgba(0,0,0,.18)}
.foot{font-size:14px;color:var(--muted);margin-top:10px}.axis-label{font-size:19px}.tick{font-size:16px}.point{cursor:crosshair}.point:focus{outline:2px solid #111;outline-offset:2px}
@media(max-width:800px){main{padding:14px 10px 24px}.metrics{grid-template-columns:1fr}.metric{border-right:0;border-bottom:1px solid var(--line)}.metric:last-child{border-bottom:0}.chart{height:520px}h1{font-size:24px}}
</style>
</head>
<body><main>
<h1>__TITLE__</h1>
<div class="sub">两组超声数据分别减去同一批不加超声数据在相同频率 bin 的 PSD。</div>
<div class="metrics" id="metrics"></div>
<div class="toolbar" id="controls"></div>
<div class="chart"><svg id="chart" role="img" aria-label="共振与非共振超声频点信噪比对比图"></svg></div>
<div class="foot">不加超声组作为共同 OFF 基准；悬停或聚焦数据点可查看模式族、峰位以及该腔的 ON/OFF 同频 PSD。</div>
</main><div class="tip" id="tip"></div>
<script>
const D=__DATA__,svg=document.getElementById('chart'),tip=document.getElementById('tip'),NS='http://www.w3.org/2000/svg',font='Arial, Microsoft YaHei, sans-serif';
const enabled=Object.fromEntries(D.conditions.map(c=>[c.id,true]));
function el(tag,attrs={},text=''){const n=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,v);if(text)n.textContent=text;return n}
function fmt(v,n=1){return Number(v).toFixed(n)}
function setup(){const cards=[`<div class="metric"><span>不加超声基准</span><strong>${D.baseline.run_name}</strong><small>${D.baseline.started_at}</small></div>`];D.conditions.forEach(c=>cards.push(`<div class="metric"><span>${c.label}</span><strong>${fmt(c.toneKhz,2)} kHz · ${fmt(c.summary.snr_db.median)} dB</strong><small>腔间标准差 ${fmt(c.summary.snr_db.std)} dB；范围 ${fmt(c.summary.snr_db.min)}–${fmt(c.summary.snr_db.max)} dB</small></div>`));document.getElementById('metrics').innerHTML=cards.join('');const controls=document.getElementById('controls');D.conditions.forEach(c=>{const label=document.createElement('label');label.className='toggle';label.innerHTML=`<input type="checkbox" checked aria-label="${c.label}"><i class="swatch" style="background:${c.color}"></i>${c.label}`;label.querySelector('input').addEventListener('change',e=>{enabled[c.id]=e.target.checked;draw()});controls.appendChild(label)})}
function draw(){while(svg.firstChild)svg.removeChild(svg.firstChild);const active=D.conditions.filter(c=>enabled[c.id]),box=svg.getBoundingClientRect(),w=Math.max(box.width,680),h=Math.max(box.height,420),p={l:92,r:34,t:26,b:78};svg.setAttribute('viewBox',`0 0 ${w} ${h}`);const vals=active.flatMap(c=>c.rows.map(r=>r.snr));let ymin=Math.min(0,...vals),ymax=Math.max(10,...vals),span=Math.max(10,ymax-ymin);ymin=Math.floor((ymin-span*.08)/5)*5;ymax=Math.ceil((ymax+span*.12)/5)*5;const count=D.conditions[0]?.rows.length||0,x=i=>p.l+i*(w-p.l-p.r)/Math.max(count-1,1),y=v=>h-p.b-(v-ymin)/(ymax-ymin)*(h-p.t-p.b);svg.appendChild(el('rect',{x:p.l,y:p.t,width:w-p.l-p.r,height:h-p.t-p.b,fill:'#fff',stroke:'#111827','stroke-width':'1.2'}));for(let v=Math.ceil(ymin/10)*10;v<=ymax;v+=10){const yy=y(v);svg.appendChild(el('line',{x1:p.l,y1:yy,x2:w-p.r,y2:yy,stroke:'#e6ebf0','stroke-width':'1'}));svg.appendChild(el('line',{x1:p.l-7,y1:yy,x2:p.l,y2:yy,stroke:'#111827','stroke-width':'1.2'}));svg.appendChild(el('text',{x:p.l-13,y:yy+5,'text-anchor':'end',class:'tick','font-family':font},String(v)))}if(count)D.conditions[0].rows.forEach((r,i)=>{const xx=x(i);svg.appendChild(el('line',{x1:xx,y1:h-p.b,x2:xx,y2:h-p.b+7,stroke:'#111827','stroke-width':'1.1'}));svg.appendChild(el('text',{x:xx,y:h-p.b+29,'text-anchor':'middle',class:'tick','font-family':font},r.cavity))});active.forEach((condition,activeIndex)=>{const shift=(activeIndex-(active.length-1)/2)*8;let path='';condition.rows.forEach((r,i)=>{const xx=x(i)+shift,yy=y(r.snr);path+=`${i?'L':'M'}${xx},${yy}`;point(condition,r,xx,yy)});if(path)svg.insertBefore(el('path',{d:path,fill:'none',stroke:condition.color,'stroke-width':'2.2','stroke-linejoin':'round','stroke-linecap':'round'}),svg.querySelector('.point'))});svg.appendChild(el('text',{x:(p.l+w-p.r)/2,y:h-18,'text-anchor':'middle',class:'axis-label','font-family':font},'物理腔编号'));svg.appendChild(el('text',{x:24,y:(p.t+h-p.b)/2,'text-anchor':'middle',class:'axis-label','font-family':font,transform:`rotate(-90 24 ${(p.t+h-p.b)/2})`},'同频 ON/OFF SNR (dB)'))}
function point(condition,r,xx,yy){const node=el('circle',{cx:xx,cy:yy,r:7,fill:condition.color,stroke:'#fff','stroke-width':'1.8',class:'point',tabindex:'0'});const body=()=>`<b>${condition.label}</b><br>${r.cavity} · ${r.family}, μ=${r.mu}<br>同频 SNR: ${fmt(r.snr,2)} dB<br>峰位: ${fmt(r.peakKhz,3)} kHz<br>加超声后 PSD: ${fmt(r.onPsd,2)} dBm/Hz<br>不加超声同频 PSD: ${fmt(r.offPsd,2)} dBm/Hz`;node.addEventListener('mouseenter',e=>showTip(e,body()));node.addEventListener('mousemove',e=>showTip(e,body()));node.addEventListener('mouseleave',hideTip);node.addEventListener('focus',e=>{const b=node.getBoundingClientRect();showTip({clientX:b.left,clientY:b.top},body())});node.addEventListener('blur',hideTip);svg.appendChild(node)}
function showTip(e,body){tip.innerHTML=body;tip.style.display='block';let left=e.clientX+14,top=e.clientY+12;if(left+tip.offsetWidth>innerWidth-8)left=e.clientX-tip.offsetWidth-14;if(top+tip.offsetHeight>innerHeight-8)top=e.clientY-tip.offsetHeight-12;tip.style.left=left+'px';tip.style.top=top+'px'}function hideTip(){tip.style.display='none'}
window.addEventListener('resize',draw);setup();draw();
</script></body></html>'''


def analyze(
    baseline_summary_path: Path,
    conditions: list[tuple[str, Path]],
    output_dir: Path,
    *,
    search_min_hz: float = 10_000.0,
    search_max_hz: float | None = None,
    signal_half_width_rbw: float = 2.0,
) -> dict[str, Any]:
    baseline_summary_path = baseline_summary_path.resolve()
    output_dir = output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"refusing to overwrite non-empty output directory: {output_dir}")
    if not conditions:
        raise ValueError("at least one ultrasound condition is required")

    baseline_summary = load_summary(baseline_summary_path)
    baseline_rows = completed_by_cavity(baseline_summary)
    cavities = sorted(baseline_rows, key=cavity_number)
    if not cavities:
        raise ValueError("baseline run has no completed cavity")
    baseline_rbw_hz = load_rbw(baseline_summary_path)

    reference_hz: np.ndarray | None = None
    baseline_psd: dict[str, np.ndarray] = {}
    for cavity in cavities:
        frequency_hz, values = load_psd(Path(str(baseline_rows[cavity]["raw_npz"])))
        if reference_hz is None:
            reference_hz = frequency_hz
        baseline_psd[cavity] = interpolate_to(reference_hz, frequency_hz, values)
    assert reference_hz is not None

    condition_payloads = [
        analyze_condition(
            label=label,
            index=index,
            summary_path=summary_path,
            baseline_rows=baseline_rows,
            baseline_psd=baseline_psd,
            reference_hz=reference_hz,
            baseline_rbw_hz=baseline_rbw_hz,
            cavities=cavities,
            search_min_hz=search_min_hz,
            search_max_hz=search_max_hz,
            signal_half_width_rbw=signal_half_width_rbw,
        )
        for index, (label, summary_path) in enumerate(conditions)
    ]

    payload = {
        "schema_version": 1,
        "analysis_kind": "ultrasound_same_frequency_on_off_snr_multi_condition",
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "chip": baseline_summary.get("chip"),
        "die": baseline_summary.get("die"),
        "baseline_run": {
            "label": "不加超声",
            "run_name": baseline_summary_path.parent.name,
            "summary_json": str(baseline_summary_path),
            "run_dir": str(baseline_summary_path.parent),
            "started_at": baseline_summary.get("started_at"),
        },
        "snr_definition": {
            "name": "paired same-frequency ON/OFF PSD contrast",
            "formula": "SNR_dB = P_condition(f0) - P_baseline(f0)",
            "f0_selection": "For each condition, detect the common tone from the median condition-minus-baseline spectrum; for each cavity, maximize condition PSD within +/-2 RBW and use that exact bin in both runs.",
            "unit": "dB",
            "psd_unit": "dBm/Hz",
            "rbw_hz": baseline_rbw_hz,
            "signal_half_width_rbw": signal_half_width_rbw,
            "signal_half_width_hz": signal_half_width_rbw * baseline_rbw_hz,
            "strict_power_subtraction_formula": "10*log10(10^(SNR_dB/10)-1)",
        },
        "conditions": condition_payloads,
    }
    payload = rounded(payload)
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "ultrasound_snr_multi_condition.json"
    html_path = output_dir / "ultrasound_snr_multi_condition.html"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    html_path.write_text(build_html(payload), encoding="utf-8")
    return {
        "ok": True,
        "json_path": str(json_path),
        "html_path": str(html_path),
        "baseline_run": payload["baseline_run"],
        "conditions": [
            {
                "label": condition["label"],
                "tone_frequency_hz": condition["tone_detection"]["frequency_hz"],
                "summary": condition["summary"],
            }
            for condition in payload["conditions"]
        ],
    }


def parse_condition(value: str) -> tuple[str, Path]:
    label, separator, path = value.partition("=")
    if not separator or not label.strip() or not path.strip():
        raise argparse.ArgumentTypeError("condition must use LABEL=SUMMARY_JSON")
    return label.strip(), Path(path.strip())


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare multiple ultrasound PSD runs against one shared OFF baseline")
    parser.add_argument("baseline_summary", type=Path)
    parser.add_argument("--condition", action="append", type=parse_condition, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--search-min-hz", type=float, default=10_000.0)
    parser.add_argument("--search-max-hz", type=float)
    args = parser.parse_args()
    result = analyze(
        args.baseline_summary,
        args.condition,
        args.output_dir,
        search_min_hz=args.search_min_hz,
        search_max_hz=args.search_max_hz,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
