"""Pure transmission-trace analysis; no device connection or experiment paths."""

from __future__ import annotations
import numpy as np

def crossing_x(y0: float, y1: float, x0: float, x1: float, y_cross: float) -> float | None:
    denom = y1 - y0
    if abs(denom) < 1e-15:
        return None
    frac = (y_cross - y0) / denom
    if frac < -1e-9 or frac > 1 + 1e-9:
        return None
    return float(x0 + frac * (x1 - x0))


def contiguous_regions(mask: np.ndarray) -> list[tuple[int, int]]:
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return []
    breaks = np.flatnonzero(np.diff(idx) > 1)
    starts = np.r_[idx[0], idx[breaks + 1]]
    ends = np.r_[idx[breaks], idx[-1]]
    return [(int(start), int(end)) for start, end in zip(starts, ends)]


def downsweep_segment(t: np.ndarray, sweep: np.ndarray) -> dict[str, object]:
    x = np.asarray(sweep, dtype=float)
    if x.size < 16:
        return {"ok": False, "error": "too few samples for downsweep selection"}
    full_ptp = float(np.nanmax(x) - np.nanmin(x))
    if not np.isfinite(full_ptp) or full_ptp <= 0:
        return {"ok": False, "error": "invalid sweep range"}

    dx = np.diff(x)
    neg = dx < -max(full_ptp * 1e-5, 1e-7)
    candidates = []
    for start_diff, end_diff in contiguous_regions(neg):
        start = start_diff
        end = end_diff + 1
        if end - start < 16:
            continue
        drop = float(x[start] - x[end])
        if drop <= 0:
            continue
        candidates.append(
            {
                "start_index": int(start),
                "end_index": int(end),
                "start_time": float(t[start]),
                "end_time": float(t[end]),
                "start_sweep_voltage": float(x[start]),
                "end_sweep_voltage": float(x[end]),
                "drop_out2_v": drop,
                "samples": int(end - start + 1),
            }
        )
    if not candidates:
        return {"ok": False, "error": "no decreasing sweep segment found"}

    best = max(candidates, key=lambda item: (item["drop_out2_v"], item["samples"]))
    best["ok"] = True
    best["num_candidates"] = len(candidates)
    return best


def analyze_apparent_width(
    t: np.ndarray,
    transmission: np.ndarray,
    sweep: np.ndarray,
    depth_fraction: float,
    use_downsweep: bool = True,
) -> dict[str, object]:
    y = np.asarray(transmission, dtype=float)
    x = np.asarray(sweep, dtype=float)
    tt = np.asarray(t, dtype=float)
    finite = np.isfinite(y) & np.isfinite(x) & np.isfinite(tt)
    y = y[finite]
    x = x[finite]
    tt = tt[finite]
    if y.size < 16:
        return {"ok": False, "error": "too few finite samples"}

    segment: dict[str, object] | None = None
    if use_downsweep:
        segment = downsweep_segment(tt, x)
        if not segment.get("ok"):
            return segment
        start = int(segment["start_index"])
        end = int(segment["end_index"])
        y = y[start : end + 1]
        x = x[start : end + 1]
        tt = tt[start : end + 1]

    t_min = float(np.nanmin(y))
    min_index = int(np.nanargmin(y))
    min_sweep_voltage = float(x[min_index])
    min_time = float(tt[min_index])
    t_max = float(np.nanpercentile(y, 95))
    if t_max <= t_min:
        return {"ok": False, "error": "invalid transmission range"}
    t_lock = float(t_min + depth_fraction * (t_max - t_min))
    platform_drop_fraction = 1.0 - depth_fraction

    candidates = []
    for start, end in contiguous_regions(y <= t_lock):
        if start == 0 or end >= y.size - 1:
            continue
        left_x = crossing_x(y[start - 1], y[start], x[start - 1], x[start], t_lock)
        right_x = crossing_x(y[end], y[end + 1], x[end], x[end + 1], t_lock)
        if left_x is None or right_x is None:
            continue
        width = abs(right_x - left_x)
        if not np.isfinite(width) or width <= 0:
            continue
        local_min_index = int(start + np.argmin(y[start : end + 1]))
        dip_x = float(x[local_min_index])
        candidates.append(
            {
                "start_index": start,
                "end_index": end,
                "min_index": local_min_index,
                "min_transmission": float(y[local_min_index]),
                "min_sweep_voltage": dip_x,
                "min_time": float(tt[local_min_index]),
                "left_sweep_voltage": float(left_x),
                "right_sweep_voltage": float(right_x),
                "quarter_full_width_out2_v": float(width),
                "platform_drop_fraction": float(platform_drop_fraction),
                "capture_side_sweep_voltage": float(max(left_x, right_x)),
                "capture_direction": "from_higher_out2_to_dip",
                "capture_width_out2_v": float(abs(max(left_x, right_x) - dip_x)),
                "lower_side_sweep_voltage": float(min(left_x, right_x)),
                "higher_side_sweep_voltage": float(max(left_x, right_x)),
                "samples_below": int(end - start + 1),
            }
        )

    if not candidates:
        return {
            "ok": False,
            "error": "no complete crossings at chosen depth",
            "transmission_min": t_min,
            "min_sweep_voltage": min_sweep_voltage,
            "min_time": min_time,
            "transmission_max_p95": t_max,
            "transmission_lock": t_lock,
            "sweep_window": "downsweep" if use_downsweep else "full_trace",
            "downsweep_segment": segment,
        }

    best = min(candidates, key=lambda item: item["min_transmission"])
    return {
        "ok": True,
        "depth_fraction": depth_fraction,
        "platform_drop_fraction": platform_drop_fraction,
        "transmission_min": t_min,
        "transmission_max_p95": t_max,
        "transmission_lock": t_lock,
        "sweep_window": "downsweep" if use_downsweep else "full_trace",
        "downsweep_segment": segment,
        "num_complete_dips": len(candidates),
        "chosen": best,
        "candidates": candidates,
    }


def assess_raw_lock_presence(
    lock_analysis: dict[str, object],
    *,
    noise_sigma_v: float,
    min_snr: float,
    min_samples: int,
) -> dict[str, object]:
    """Validate a complete raw dip using only SNR and sample support."""
    chosen = lock_analysis.get("chosen")
    chosen = chosen if isinstance(chosen, dict) else {}
    baseline_v = float(lock_analysis.get("transmission_max_p95", float("nan")))
    dip_min_v = float(chosen.get("min_transmission", float("nan")))
    depth_v = baseline_v - dip_min_v
    depth_snr = (
        float(depth_v / max(float(noise_sigma_v), 1e-12))
        if np.isfinite(depth_v) and np.isfinite(noise_sigma_v)
        else float("nan")
    )
    samples_below = int(chosen.get("samples_below") or 0)
    checks = {
        "complete_dip": bool(lock_analysis.get("ok")),
        "noise_snr": bool(np.isfinite(depth_snr) and depth_snr >= float(min_snr)),
        "minimum_samples": bool(samples_below >= int(min_samples)),
    }
    return {
        "present": bool(all(checks.values())),
        "checks": checks,
        "depth_v": float(depth_v) if np.isfinite(depth_v) else None,
        "noise_sigma_v": float(noise_sigma_v) if np.isfinite(noise_sigma_v) else None,
        "depth_snr": float(depth_snr) if np.isfinite(depth_snr) else None,
        "samples_below_lock_level": samples_below,
        "min_snr": float(min_snr),
        "min_samples": int(min_samples),
    }
