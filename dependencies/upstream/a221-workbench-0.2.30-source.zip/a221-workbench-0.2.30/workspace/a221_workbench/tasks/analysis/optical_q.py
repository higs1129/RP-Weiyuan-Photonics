"""Shared Lorentzian-notch fitting primitives."""

from __future__ import annotations


import numpy as np


def fit_notch_window(x_mhz, y, center_index, *, slope_limit=0.01,
                     min_edge_samples=1, min_span_mhz=0.0):
    """Fit one already-calibrated window, preserving the legacy fit policies.

    ``gamma_mhz`` is HWHM. Callers retain responsibility for calibration,
    neighbor/window selection and missing-data handling.
    """
    from scipy.optimize import curve_fit

    x_mhz, y = np.asarray(x_mhz, dtype=float), np.asarray(y, dtype=float)
    if x_mhz.ndim != 1 or x_mhz.shape != y.shape or len(y) < 30:
        raise ValueError('A matched one-dimensional window of at least 30 samples is required')
    if not np.all(np.isfinite(x_mhz)) or not np.all(np.isfinite(y)) or np.ptp(x_mhz) <= 0:
        raise ValueError('Fit samples must be finite and span a nonzero frequency interval')
    if not 0 <= center_index < len(y):
        raise ValueError('center_index is outside the fit window')
    edge_count = max(5, len(y) // 5)
    baseline_guess = float(np.nanmedian(np.r_[y[:edge_count], y[-edge_count:]]))
    ymin = float(np.nanmin(y[max(0, center_index - 10):min(len(y), center_index + 11)]))
    eta0 = min(0.98, max(0.02, 1.0 - ymin / max(baseline_guess, 1e-9)))
    gamma0 = estimate_initial_gamma(x_mhz, y, center_index, eta0, min_edge_samples=min_edge_samples)
    span = max(float(np.ptp(x_mhz)), min_span_mhz)
    lower = [0.2, -slope_limit, 0.0, 1.0, -0.25 * span]
    upper = [1.8, slope_limit, 0.999, max(5.0, span), 0.25 * span]
    p0 = [max(0.2, min(1.8, baseline_guess)), 0.0, eta0,
          min(gamma0, max(5.0, span / 2.0)), 0.0]
    popt, _ = curve_fit(lorentzian_notch, x_mhz, y, p0=p0,
                        bounds=(lower, upper), maxfev=30_000)
    return popt, lorentzian_notch(x_mhz, *popt)


def notch_quality_factors(absolute_frequency_mhz, eta, gamma_mhz):
    """Q conversion with the existing undercoupled/critical branch assumption."""
    import math

    if not np.isfinite(absolute_frequency_mhz) or absolute_frequency_mhz <= 0:
        raise ValueError('Absolute optical frequency must be positive and finite')
    if not np.isfinite(gamma_mhz) or gamma_mhz == 0 or not np.isfinite(eta) or not 0 <= eta <= 1:
        raise ValueError('Require finite nonzero HWHM and notch depth in [0, 1]')
    transmission = max(0.0, min(1.0, 1.0 - eta))
    gamma = abs(float(gamma_mhz))
    total = 2.0 * gamma
    if transmission <= 1e-6:
        intrinsic = coupling = gamma
        note = 'critical_assumed'
    else:
        intrinsic = gamma * (1.0 + math.sqrt(transmission))
        coupling = gamma * (1.0 - math.sqrt(transmission))
        note = 'undercoupled_branch'
    return {'transmission': transmission, 'linewidth_loaded_mhz': total,
            'kappa0_mhz': intrinsic, 'kappa1_mhz': coupling,
            'Q0': absolute_frequency_mhz / intrinsic,
            'Q1': absolute_frequency_mhz / coupling if coupling > 0 else math.nan,
            'QL': absolute_frequency_mhz / total, 'coupling_note': note}


def fit_optical_q(detuning_mhz, transmission, *, absolute_frequency_mhz,
                  center_index=None, slope_limit=0.01):
    """Public offline fit: calibrated MHz detuning, normalized transmission.

    Absolute frequency is the frequency at zero detuning, in MHz. Q0/Q1
    retain an explicit coupling-branch assumption; the trace alone does not
    determine that branch. The linewidth returned is loaded FWHM in MHz.
    """
    y = np.asarray(transmission, dtype=float)
    center_index = int(np.argmin(y)) if center_index is None else int(center_index)
    popt, fitted = fit_notch_window(detuning_mhz, y, center_index, slope_limit=slope_limit)
    a, b, eta, gamma, offset = map(float, popt)
    result = notch_quality_factors(absolute_frequency_mhz + offset, eta, gamma)
    result.update(fit_center_offset_mhz=offset, baseline_a=a,
                  baseline_slope_per_mhz=b, depth=eta,
                  rms_residual=float(np.sqrt(np.mean((y - fitted)**2))),
                  fit_points=len(y), fit_status='ok')
    return result


def lorentzian_notch(
    x_mhz: np.ndarray,
    a: float,
    b: float,
    eta: float,
    gamma_mhz: float,
    x0_mhz: float,
) -> np.ndarray:
    dx = x_mhz - x0_mhz
    baseline = a + b * dx
    return baseline * (1.0 - eta * gamma_mhz**2 / (gamma_mhz**2 + dx**2))


def choose_half_window(
    center_idx: int,
    all_indices: np.ndarray,
    *,
    min_samples: int,
    max_samples: int,
    fraction: float,
) -> int:
    distances = np.abs(all_indices - center_idx)
    distances = distances[distances > 0]
    nearest = int(np.min(distances)) if len(distances) else max_samples * 2
    half = int(fraction * nearest)
    return max(min_samples, min(max_samples, half))


def estimate_initial_gamma(
    x_mhz: np.ndarray,
    y: np.ndarray,
    center_i: int,
    eta0: float,
    *,
    min_edge_samples: int = 1,
) -> float:
    if eta0 <= 0:
        return max(50.0, 0.02 * float(np.ptp(x_mhz)))
    ymin = float(y[center_i])
    edge_count = max(int(min_edge_samples), len(y) // 5)
    ybase = float(np.nanmedian(np.r_[y[:edge_count], y[-edge_count:]]))
    half_level = ymin + 0.5 * (ybase - ymin)
    left = center_i
    while left > 0 and y[left] < half_level:
        left -= 1
    right = center_i
    while right < len(y) - 1 and y[right] < half_level:
        right += 1
    if right > left:
        return max(10.0, abs(float(x_mhz[right] - x_mhz[left])) / 2.0)
    return max(50.0, 0.02 * float(np.ptp(x_mhz)))
