from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.analysis.large_scan'


import argparse
import json
import math
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from a221_workbench.tasks.analysis.large_scan.analyze_array_large_scan import sample_mzi_mu
from a221_workbench.tasks.analysis.large_scan.process_large_scan import find_mzi_index, relative_frequency_mhz


def finite_float(value: object) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def load_npz_time_and_channel(path: Path, channel: int, role: str) -> tuple[np.ndarray, np.ndarray, str]:
    data = np.load(path)
    keys = list(data.files)
    channel_prefix = f"ch{channel}_"
    preferred = [
        f"ch{channel}_{role}_v",
        f"ch{channel}_mzi_v",
        f"ch{channel}_auxmzi_v",
    ]
    selected = next((key for key in preferred if key in keys), None)
    if selected is None:
        candidates = [
            key
            for key in keys
            if key.lower().startswith(channel_prefix)
            and key.lower().endswith("_v")
            and ("mzi" in key.lower() or role in key.lower())
        ]
        if not candidates:
            raise KeyError(f"Cannot find CH{channel} {role} channel in {path}. Available keys: {keys}")
        selected = sorted(candidates)[0]
    trace = np.asarray(data[selected], dtype=float)
    if "time_s" in keys:
        time_s = np.asarray(data["time_s"], dtype=float)
    else:
        t0 = float(np.asarray(data["time_start_s"]))
        t1 = float(np.asarray(data["time_stop_s"]))
        time_s = np.linspace(t0, t1, len(trace))
    n = min(len(time_s), len(trace))
    return time_s[:n], trace[:n], selected


def relative_axis_for_mzi(
    *,
    time_s: np.ndarray,
    trace: np.ndarray,
    d1_mhz: float,
    start_nm: float,
    center_nm: float,
    stop_nm: float,
    sensitivity_db: float,
) -> dict[str, Any]:
    extrema = find_mzi_index(trace, sensitivity_db)
    sample_idx, mu = sample_mzi_mu(len(trace), extrema)
    if len(sample_idx) < 2:
        return {"ok": False, "error": "too_few_mzi_extrema", "extrema_count": int(len(extrema))}
    freq_mhz, mu_center = relative_frequency_mhz(
        mu,
        start_nm=start_nm,
        center_nm=center_nm,
        stop_nm=stop_nm,
        d1=d1_mhz,
        d2=0.0,
        d3=0.0,
        offset_mhz=0.0,
    )
    return {
        "ok": True,
        "extrema_count": int(len(extrema)),
        "sample_idx": sample_idx,
        "time_s": time_s[sample_idx],
        "freq_mhz": freq_mhz,
        "mu_center": float(mu_center),
        "time_min_s": float(time_s[sample_idx[0]]),
        "time_max_s": float(time_s[sample_idx[-1]]),
        "freq_span_ghz": float((np.nanmax(freq_mhz) - np.nanmin(freq_mhz)) / 1000.0),
    }


def linear_slope(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    slope, intercept = np.polyfit(x.astype(float), y.astype(float), 1)
    return float(slope), float(intercept)


def compare_axes(primary: dict[str, Any], secondary: dict[str, Any], *, samples: int) -> dict[str, Any]:
    t0 = max(float(primary["time_min_s"]), float(secondary["time_min_s"]))
    t1 = min(float(primary["time_max_s"]), float(secondary["time_max_s"]))
    if t1 <= t0:
        raise RuntimeError("Primary and secondary MZI axes do not overlap in time.")
    common_t = np.linspace(t0, t1, max(10, int(samples)))
    f1 = np.interp(common_t, np.asarray(primary["time_s"]), np.asarray(primary["freq_mhz"]))
    f2 = np.interp(common_t, np.asarray(secondary["time_s"]), np.asarray(secondary["freq_mhz"]))
    slope1, intercept1 = linear_slope(common_t, f1)
    slope2, intercept2 = linear_slope(common_t, f2)
    ratio = slope2 / slope1 if slope1 != 0 else math.nan
    residual_mhz = f2 - f1
    return {
        "common_time_min_s": float(t0),
        "common_time_max_s": float(t1),
        "sample_count": int(len(common_t)),
        "primary_slope_mhz_per_s": slope1,
        "primary_intercept_mhz": intercept1,
        "secondary_slope_mhz_per_s": slope2,
        "secondary_intercept_mhz": intercept2,
        "slope_ratio_secondary_over_primary": float(ratio),
        "mean_residual_mhz": float(np.mean(residual_mhz)),
        "std_residual_mhz": float(np.std(residual_mhz)),
        "max_abs_residual_mhz": float(np.max(np.abs(residual_mhz))),
        "common_t": common_t,
        "primary_freq_mhz": f1,
        "secondary_freq_mhz": f2,
        "residual_mhz": residual_mhz,
    }


def decimate(x: np.ndarray, y: np.ndarray, max_points: int = 20000) -> tuple[np.ndarray, np.ndarray]:
    if len(x) <= max_points:
        return x, y
    step = max(1, int(math.ceil(len(x) / max_points)))
    return x[::step], y[::step]


def signal_quality(trace: np.ndarray) -> dict[str, Any]:
    y = np.asarray(trace, dtype=float)
    finite = y[np.isfinite(y)]
    if len(finite) == 0:
        return {"ok": False, "reason": "no_finite_samples"}
    ymin = float(np.min(finite))
    ymax = float(np.max(finite))
    p1, p50, p99 = [float(v) for v in np.percentile(finite, [1, 50, 99])]
    near_top_fraction = float(np.mean(finite >= ymax - 1e-3))
    near_bottom_fraction = float(np.mean(finite <= ymin + 1e-3))
    reasons: list[str] = []
    if near_top_fraction > 0.10:
        reasons.append(f"{near_top_fraction:.1%} samples within 1 mV of channel maximum")
    if near_bottom_fraction > 0.10:
        reasons.append(f"{near_bottom_fraction:.1%} samples within 1 mV of channel minimum")
    if p99 - p1 < 0.05:
        reasons.append("p99-p1 amplitude below 50 mV")
    return {
        "ok": not reasons,
        "min_v": ymin,
        "max_v": ymax,
        "mean_v": float(np.mean(finite)),
        "std_v": float(np.std(finite)),
        "p1_v": p1,
        "p50_v": p50,
        "p99_v": p99,
        "near_top_fraction_1mv": near_top_fraction,
        "near_bottom_fraction_1mv": near_bottom_fraction,
        "reason": "; ".join(reasons) if reasons else None,
    }


def plot_comparison(
    path: Path,
    *,
    primary_trace: tuple[np.ndarray, np.ndarray, str],
    secondary_trace: tuple[np.ndarray, np.ndarray, str],
    comparison: dict[str, Any],
    primary_label: str,
    secondary_label: str,
) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=False)
    t1, y1, key1 = primary_trace
    t2, y2, key2 = secondary_trace
    dt, dy = decimate(t1, y1)
    axes[0].plot(dt, dy, lw=0.7, label=f"{primary_label} ({key1})")
    dt, dy = decimate(t2, y2)
    axes[0].plot(dt, dy, lw=0.7, label=f"{secondary_label} ({key2})", alpha=0.8)
    axes[0].set_ylabel("MZI voltage (V)")
    axes[0].legend(loc="best")
    axes[0].grid(True, alpha=0.25)

    t = np.asarray(comparison["common_t"])
    f1 = np.asarray(comparison["primary_freq_mhz"]) / 1000.0
    f2 = np.asarray(comparison["secondary_freq_mhz"]) / 1000.0
    dt, df = decimate(t, f1)
    axes[1].plot(dt, df, lw=1.0, label=primary_label)
    dt, df = decimate(t, f2)
    axes[1].plot(dt, df, lw=1.0, label=secondary_label, alpha=0.8)
    axes[1].set_ylabel("Relative freq. (GHz)")
    axes[1].legend(loc="best")
    axes[1].grid(True, alpha=0.25)

    residual_ghz = np.asarray(comparison["residual_mhz"]) / 1000.0
    dt, dr = decimate(t, residual_ghz)
    axes[2].plot(dt, dr, lw=1.0)
    axes[2].axhline(0, color="k", lw=0.8, alpha=0.5)
    axes[2].set_xlabel("Scope time (s)")
    axes[2].set_ylabel("Secondary - primary (GHz)")
    axes[2].grid(True, alpha=0.25)
    fig.suptitle(
        "MZI FSR consistency check, "
        f"slope ratio={comparison['slope_ratio_secondary_over_primary']:.8f}"
    )
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare two MZI calibration FSRs saved in one large-scan raw npz.")
    parser.add_argument("raw_npz", type=Path)
    parser.add_argument("--primary-channel", type=int, default=3)
    parser.add_argument("--primary-d1-mhz", type=float, default=40.46318)
    parser.add_argument("--secondary-channel", type=int, default=5)
    parser.add_argument("--secondary-d1-mhz", type=float, required=True)
    parser.add_argument("--start-nm", type=float, default=1530.0)
    parser.add_argument("--center-nm", type=float, default=1550.0)
    parser.add_argument("--stop-nm", type=float, default=1570.0)
    parser.add_argument("--mzi-sensitivity-db", type=float, default=0.0)
    parser.add_argument("--samples", type=int, default=100000)
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    raw_npz = args.raw_npz.resolve()
    output_dir = args.output_dir.resolve() if args.output_dir else raw_npz.parent
    output_dir.mkdir(parents=True, exist_ok=True)

    primary_time, primary_trace, primary_key = load_npz_time_and_channel(raw_npz, args.primary_channel, "mzi")
    secondary_time, secondary_trace, secondary_key = load_npz_time_and_channel(raw_npz, args.secondary_channel, "auxmzi")
    primary_quality = signal_quality(primary_trace)
    secondary_quality = signal_quality(secondary_trace)
    primary_axis = relative_axis_for_mzi(
        time_s=primary_time,
        trace=primary_trace,
        d1_mhz=args.primary_d1_mhz,
        start_nm=args.start_nm,
        center_nm=args.center_nm,
        stop_nm=args.stop_nm,
        sensitivity_db=args.mzi_sensitivity_db,
    )
    secondary_axis = relative_axis_for_mzi(
        time_s=secondary_time,
        trace=secondary_trace,
        d1_mhz=args.secondary_d1_mhz,
        start_nm=args.start_nm,
        center_nm=args.center_nm,
        stop_nm=args.stop_nm,
        sensitivity_db=args.mzi_sensitivity_db,
    )
    if not primary_axis.get("ok") or not secondary_axis.get("ok"):
        summary = {"ok": False, "primary": primary_axis, "secondary": secondary_axis}
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 1

    comparison = compare_axes(primary_axis, secondary_axis, samples=args.samples)
    ratio = finite_float(comparison.get("slope_ratio_secondary_over_primary"))
    extrema_ratio = float(secondary_axis["extrema_count"] / primary_axis["extrema_count"]) if primary_axis["extrema_count"] else math.nan
    comparison_valid = bool(primary_quality.get("ok")) and bool(secondary_quality.get("ok"))
    if math.isfinite(extrema_ratio) and not (0.75 <= extrema_ratio <= 1.35):
        comparison_valid = False
    secondary_d1_if_primary_truth = args.secondary_d1_mhz / ratio if ratio and ratio != 0 else None
    primary_d1_if_secondary_truth = args.primary_d1_mhz * ratio if ratio is not None else None
    summary: dict[str, Any] = {
        "ok": comparison_valid,
        "analysis_completed": True,
        "raw_npz": str(raw_npz),
        "primary": {
            "channel": args.primary_channel,
            "key": primary_key,
            "d1_mhz": args.primary_d1_mhz,
            "extrema_count": primary_axis["extrema_count"],
            "freq_span_ghz": primary_axis["freq_span_ghz"],
            "signal_quality": primary_quality,
        },
        "secondary": {
            "channel": args.secondary_channel,
            "key": secondary_key,
            "d1_mhz": args.secondary_d1_mhz,
            "extrema_count": secondary_axis["extrema_count"],
            "freq_span_ghz": secondary_axis["freq_span_ghz"],
            "signal_quality": secondary_quality,
        },
        "comparison": {
            key: value
            for key, value in comparison.items()
            if key not in {"common_t", "primary_freq_mhz", "secondary_freq_mhz", "residual_mhz"}
        },
        "interpretation": {
            "consistent_if_slope_ratio_close_to_1": ratio,
            "valid_for_fsr_comparison": comparison_valid,
            "extrema_count_ratio_secondary_over_primary": extrema_ratio,
            "secondary_d1_mhz_if_primary_is_reference": secondary_d1_if_primary_truth,
            "primary_d1_mhz_if_secondary_is_reference": primary_d1_if_secondary_truth,
            "relative_slope_mismatch": (ratio - 1.0) if ratio is not None else None,
            "invalid_reason": None
            if comparison_valid
            else (
                "One MZI waveform is rail-clipped/flat or the detected fringe count is inconsistent; "
                "do not interpret the slope ratio as an FSR calibration result."
            ),
        },
    }
    summary_path = output_dir / "mzi_fsr_compare_summary.json"
    plot_path = output_dir / "mzi_fsr_compare.png"
    summary["outputs"] = {"summary_json": str(summary_path), "plot_png": str(plot_path)}
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    plot_comparison(
        plot_path,
        primary_trace=(primary_time, primary_trace, primary_key),
        secondary_trace=(secondary_time, secondary_trace, secondary_key),
        comparison=comparison,
        primary_label=f"CH{args.primary_channel}, D1={args.primary_d1_mhz:g} MHz",
        secondary_label=f"CH{args.secondary_channel}, D1={args.secondary_d1_mhz:g} MHz",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
