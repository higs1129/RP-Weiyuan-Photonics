"""Offline RP trace features and lockpoint plot; no connection or control."""
from __future__ import annotations
from typing import Any
from pathlib import Path
import math

import numpy as np


def channel_stats(y: np.ndarray) -> dict[str, Any]:
    finite = y[np.isfinite(y)]
    if finite.size == 0:
        return {"ok": False}
    dy = np.diff(finite)
    yrange = float(np.max(finite) - np.min(finite))
    rms_diff = float(np.sqrt(np.mean(dy * dy))) if dy.size else 0.0
    return {
        "mean": float(np.mean(finite)),
        "min": float(np.min(finite)),
        "max": float(np.max(finite)),
        "ptp": yrange,
        "std": float(np.std(finite)),
        "rms_diff": rms_diff,
        "smoothness": float(yrange / (rms_diff + 1e-12)),
    }


def extrema_features(y: np.ndarray) -> dict[str, Any]:
    finite = np.asarray(y, dtype=float)
    if finite.size < 16 or not np.all(np.isfinite(finite)):
        return {"prominence_pos": 0.0, "prominence_neg": 0.0, "width_frac": None}
    baseline = float(np.median(finite))
    p5, p95 = np.percentile(finite, [5, 95])
    y_max = float(np.max(finite))
    y_min = float(np.min(finite))
    prom_pos = float((y_max - p95) / (np.ptp(finite) + 1e-12))
    prom_neg = float((p5 - y_min) / (np.ptp(finite) + 1e-12))
    if (y_max - baseline) >= (baseline - y_min):
        half = baseline + 0.5 * (y_max - baseline)
        width = int(np.count_nonzero(finite > half))
        polarity = "peak"
    else:
        half = baseline - 0.5 * (baseline - y_min)
        width = int(np.count_nonzero(finite < half))
        polarity = "dip"
    return {
        "polarity": polarity,
        "prominence_pos": prom_pos,
        "prominence_neg": prom_neg,
        "width_frac": float(width / finite.size),
    }


def quarter_lockpoint_features(t: np.ndarray, transmission: np.ndarray, sweep: np.ndarray) -> dict[str, Any]:
    y = np.asarray(transmission, dtype=float)
    x = np.asarray(sweep, dtype=float)
    tt = np.asarray(t, dtype=float)
    if y.size < 4 or y.size != x.size:
        return {"ok": False, "error": "invalid arrays"}
    idx_min = int(np.nanargmin(y))
    t_min = float(y[idx_min])
    t_max = float(np.nanmax(y))
    t_lock = float(t_min + (t_max - t_min) / 4.0)

    crossings = []
    shifted = y - t_lock
    for i in range(y.size - 1):
        if not np.isfinite(shifted[i]) or not np.isfinite(shifted[i + 1]):
            continue
        if shifted[i] == 0 or shifted[i] * shifted[i + 1] < 0:
            denom = abs(shifted[i]) + abs(shifted[i + 1])
            frac = abs(shifted[i]) / denom if denom else 0.0
            crossings.append(
                {
                    "index": int(i),
                    "time": float(tt[i] * (1 - frac) + tt[i + 1] * frac),
                    "sweep_voltage": float(x[i] * (1 - frac) + x[i + 1] * frac),
                    "transmission": t_lock,
                }
            )
    left = [c for c in crossings if c["index"] < idx_min]
    right = [c for c in crossings if c["index"] > idx_min]
    left_pick = left[-1] if left else None
    right_pick = right[0] if right else None
    return {
        "ok": True,
        "transmission_min": t_min,
        "transmission_max": t_max,
        "transmission_lock_quarter": t_lock,
        "dip_index": idx_min,
        "dip_time": float(tt[idx_min]),
        "dip_sweep_voltage": float(x[idx_min]),
        "left_lockpoint": left_pick,
        "right_lockpoint": right_pick,
        "num_crossings": len(crossings),
    }


def smoothed_trace(y: np.ndarray, window: int) -> np.ndarray:
    if window <= 1 or y.size < 3:
        return np.asarray(y, dtype=float)
    size = max(1, int(window))
    if size % 2 == 0:
        size += 1
    size = min(size, y.size if y.size % 2 == 1 else y.size - 1)
    if size <= 1:
        return np.asarray(y, dtype=float)
    kernel = np.ones(size, dtype=float) / float(size)
    return np.convolve(np.asarray(y, dtype=float), kernel, mode="same")


def dip_position_features(
    t: np.ndarray,
    transmission: np.ndarray,
    sweep: np.ndarray,
    *,
    branch: str = "auto",
    smooth_points: int = 7,
    center_time_s: float | None = None,
    window_s: float | None = None,
) -> dict[str, Any]:
    y = np.asarray(transmission, dtype=float)
    x = np.asarray(sweep, dtype=float)
    tt = np.asarray(t, dtype=float)
    if y.size < 8 or y.size != x.size or y.size != tt.size:
        return {"ok": False, "error": "invalid arrays"}
    finite = np.isfinite(y) & np.isfinite(x) & np.isfinite(tt)
    if int(np.count_nonzero(finite)) < 8:
        return {"ok": False, "error": "not enough finite samples"}

    dx_trace = smoothed_trace(x, min(31, max(3, y.size // 50)))
    dx = np.gradient(dx_trace)
    abs_dx = np.abs(dx[finite])
    dx_scale = float(np.nanpercentile(abs_dx, 60)) if abs_dx.size else 0.0
    dx_threshold = max(dx_scale * 0.15, 1e-12)
    center_time = None
    window = None
    try:
        center_time = float(center_time_s) if center_time_s is not None else None
        if center_time is not None and not math.isfinite(center_time):
            center_time = None
    except (TypeError, ValueError):
        center_time = None
    try:
        window = abs(float(window_s)) if window_s is not None else None
        if window is not None and (not math.isfinite(window) or window <= 0):
            window = None
    except (TypeError, ValueError):
        window = None

    local = finite
    if center_time is not None and window is not None:
        local = local & (np.abs(tt - center_time) <= window)

    masks = {
        "all": finite,
        "positive": finite & (dx > dx_threshold),
        "negative": finite & (dx < -dx_threshold),
    }
    if center_time is not None and window is not None:
        masks = {name: mask & local for name, mask in masks.items()}

    def candidate(name: str, mask: np.ndarray) -> dict[str, Any]:
        idx = np.flatnonzero(mask)
        if idx.size < 8:
            return {"ok": False, "branch": name, "error": "not enough branch samples", "n": int(idx.size)}
        yy_raw = y[idx]
        yy = smoothed_trace(yy_raw, smooth_points)
        try:
            local_min = int(np.nanargmin(yy))
        except ValueError:
            return {"ok": False, "branch": name, "error": "no finite branch minimum", "n": int(idx.size)}
        global_index = int(idx[local_min])
        baseline = float(np.nanpercentile(yy_raw, 90))
        dip_y = float(y[global_index])
        depth = float(baseline - dip_y)
        return {
            "ok": True,
            "branch": name,
            "n": int(idx.size),
            "dip_index": global_index,
            "dip_time_s": float(tt[global_index]),
            "dip_sweep_voltage_v": float(x[global_index]),
            "dip_transmission_v": dip_y,
            "baseline_transmission_v": baseline,
            "depth_v": depth,
            "sweep_min_v": float(np.nanmin(x[idx])),
            "sweep_max_v": float(np.nanmax(x[idx])),
            "transmission_min_v": float(np.nanmin(yy_raw)),
            "transmission_max_v": float(np.nanmax(yy_raw)),
        }

    aliases = {
        "up": "positive",
        "rising": "positive",
        "positive": "positive",
        "down": "negative",
        "falling": "negative",
        "negative": "negative",
        "all": "all",
        "auto": "auto",
    }
    requested = aliases.get(str(branch or "auto").strip().lower(), "auto")
    candidate_names = ["all", "positive", "negative"] if requested == "auto" else [requested]
    candidates = {name: candidate(name, masks[name]) for name in candidate_names}
    if requested != "auto" and candidates.get(requested, {}).get("ok"):
        selected = candidates[requested]
    else:
        valid = [item for item in candidates.values() if item.get("ok")]
        if not valid:
            return {"ok": False, "error": "no valid dip candidate", "candidates": candidates}
        # Prefer a branch-local dip when it is available; it avoids jumping
        # between two sweep directions in the same scope frame.
        branch_valid = [item for item in valid if item.get("branch") in {"positive", "negative"}]
        selected = max(branch_valid or valid, key=lambda item: float(item.get("depth_v") or 0.0))
    return {
        "ok": True,
        "requested_branch": branch,
        "selected_branch": selected.get("branch"),
        "smooth_points": int(max(1, smooth_points)),
        "tracking_center_time_s": center_time,
        "tracking_window_s": window,
        "dip": selected,
        "candidates": candidates,
    }


def threshold_crossing_features(
    t: np.ndarray,
    transmission: np.ndarray,
    sweep: np.ndarray,
    *,
    center_time_s: float | None = None,
    window_s: float | None = None,
    reference_time_s: float | None = None,
    threshold_v: float | None = None,
    edge: str = "nearest",
    smooth_points: int = 5,
) -> dict[str, Any]:
    y_raw = np.asarray(transmission, dtype=float)
    x = np.asarray(sweep, dtype=float)
    tt = np.asarray(t, dtype=float)
    if y_raw.size < 8 or y_raw.size != x.size or y_raw.size != tt.size:
        return {"ok": False, "error": "invalid arrays"}
    finite = np.isfinite(y_raw) & np.isfinite(x) & np.isfinite(tt)
    if int(np.count_nonzero(finite)) < 8:
        return {"ok": False, "error": "not enough finite samples"}

    center_time = None
    window = None
    ref_time = None
    try:
        center_time = float(center_time_s) if center_time_s is not None else None
        if center_time is not None and not math.isfinite(center_time):
            center_time = None
    except (TypeError, ValueError):
        center_time = None
    try:
        window = abs(float(window_s)) if window_s is not None else None
        if window is not None and (not math.isfinite(window) or window <= 0):
            window = None
    except (TypeError, ValueError):
        window = None
    try:
        ref_time = float(reference_time_s) if reference_time_s is not None else None
        if ref_time is not None and not math.isfinite(ref_time):
            ref_time = None
    except (TypeError, ValueError):
        ref_time = None

    mask = finite
    if center_time is not None and window is not None:
        mask = mask & (np.abs(tt - center_time) <= window)
    idx = np.flatnonzero(mask)
    if idx.size < 8:
        return {
            "ok": False,
            "error": "not enough samples in tracking window",
            "n": int(idx.size),
            "tracking_center_time_s": center_time,
            "tracking_window_s": window,
        }

    yy_raw = y_raw[idx]
    yy = smoothed_trace(yy_raw, smooth_points)
    try:
        local_min = int(np.nanargmin(yy))
    except ValueError:
        return {"ok": False, "error": "no finite local minimum", "n": int(idx.size)}
    global_min_index = int(idx[local_min])
    baseline = float(np.nanpercentile(yy_raw, 90))
    dip_y = float(y_raw[global_min_index])
    depth = float(baseline - dip_y)
    threshold_source = "provided"
    if threshold_v is None:
        if not math.isfinite(depth) or depth <= 0:
            return {
                "ok": False,
                "error": "cannot derive threshold from non-dip trace",
                "baseline_transmission_v": baseline,
                "dip_transmission_v": dip_y,
                "depth_v": depth,
            }
        threshold = float(dip_y + 0.5 * depth)
        threshold_source = "half_depth"
    else:
        threshold = float(threshold_v)
        if not math.isfinite(threshold):
            return {"ok": False, "error": "invalid threshold_v"}

    edge_name = str(edge or "nearest").strip().lower()
    crossings: list[dict[str, Any]] = []
    local_t = tt[idx]
    local_x = x[idx]
    for i in range(idx.size - 1):
        y0 = float(yy[i])
        y1 = float(yy[i + 1])
        if not (math.isfinite(y0) and math.isfinite(y1)):
            continue
        d0 = y0 - threshold
        d1 = y1 - threshold
        if d0 == 0:
            frac = 0.0
        elif d0 * d1 > 0 or y1 == y0:
            continue
        else:
            frac = (threshold - y0) / (y1 - y0)
        if frac < -1e-9 or frac > 1 + 1e-9:
            continue
        slope = y1 - y0
        direction = "rising" if slope > 0 else "falling"
        if edge_name in {"rising", "up"} and direction != "rising":
            continue
        if edge_name in {"falling", "down"} and direction != "falling":
            continue
        t_cross = float(local_t[i] + frac * (local_t[i + 1] - local_t[i]))
        x_cross = float(local_x[i] + frac * (local_x[i + 1] - local_x[i]))
        crossings.append(
            {
                "time_s": t_cross,
                "sweep_voltage_v": x_cross,
                "direction": direction,
                "slope_v_per_sample": float(slope),
                "left_index": int(idx[i]),
                "right_index": int(idx[i + 1]),
            }
        )

    if not crossings:
        return {
            "ok": False,
            "error": "no threshold crossing in tracking window",
            "threshold_v": threshold,
            "threshold_source": threshold_source,
            "baseline_transmission_v": baseline,
            "dip_transmission_v": dip_y,
            "depth_v": depth,
            "n": int(idx.size),
        }

    target_time = ref_time if ref_time is not None else (center_time if center_time is not None else float(tt[global_min_index]))
    selected = min(crossings, key=lambda item: abs(float(item["time_s"]) - target_time))
    return {
        "ok": True,
        "threshold_v": threshold,
        "threshold_source": threshold_source,
        "edge_requested": edge_name,
        "reference_time_s": ref_time,
        "tracking_center_time_s": center_time,
        "tracking_window_s": window,
        "selected": selected,
        "num_crossings": len(crossings),
        "crossings_preview": crossings[:12],
        "n": int(idx.size),
        "baseline_transmission_v": baseline,
        "dip_transmission_v": dip_y,
        "depth_v": depth,
        "dip_time_s": float(tt[global_min_index]),
        "dip_sweep_voltage_v": float(x[global_min_index]),
    }


def triangle_similarity(t: np.ndarray, y: np.ndarray, frequency: float = 50.0) -> float:
    if t.size != y.size or t.size < 16:
        return 0.0
    yy = y - np.mean(y)
    if float(np.std(yy)) <= 1e-12:
        return 0.0
    phase = ((t - t[0]) * frequency) % 1.0
    tri = 1.0 - 4.0 * np.abs(phase - 0.5)
    tri -= np.mean(tri)
    return float(abs(np.corrcoef(yy, tri)[0, 1]))


def analyze_scope_trace(
    t: np.ndarray, ch1: np.ndarray, ch2: np.ndarray, input1: str, input2: str
) -> dict[str, Any]:
    stats = {"ch1": channel_stats(ch1), "ch2": channel_stats(ch2)}
    extrema = {"ch1": extrema_features(ch1), "ch2": extrema_features(ch2)}
    tri = {
        "ch1": triangle_similarity(t, ch1),
        "ch2": triangle_similarity(t, ch2),
    }
    sweep_ch = "ch1" if tri["ch1"] >= tri["ch2"] else "ch2"
    other_ch = "ch2" if sweep_ch == "ch1" else "ch1"
    # A Lorentzian transmission channel should usually be less triangular than
    # the control signal and have a localized peak/dip or otherwise meaningful
    # non-triangular variation.
    lorentz_ch = other_ch
    if input1 in {"out1", "out2", "asg0", "asg1"} and input2 not in {"out1", "out2", "asg0", "asg1"}:
        sweep_ch, lorentz_ch = "ch1", "ch2"
    if input2 in {"out1", "out2", "asg0", "asg1"} and input1 not in {"out1", "out2", "asg0", "asg1"}:
        sweep_ch, lorentz_ch = "ch2", "ch1"
    transmission = ch1 if lorentz_ch == "ch1" else ch2
    sweep = ch1 if sweep_ch == "ch1" else ch2
    lockpoint = quarter_lockpoint_features(t, transmission, sweep)
    return {
        "stats": stats,
        "extrema": extrema,
        "triangle_similarity": tri,
        "likely_sweep_channel": sweep_ch,
        "likely_sweep_input": input1 if sweep_ch == "ch1" else input2,
        "likely_transmission_channel": lorentz_ch,
        "likely_transmission_input": input1 if lorentz_ch == "ch1" else input2,
        "quarter_lockpoint": lockpoint,
        "note": (
            "Classification combines scope input labels with 50 Hz triangle-wave "
            "similarity and localized peak/dip features."
        ),
    }


def make_lockpoint_plot(
    times: np.ndarray,
    ch1: np.ndarray,
    ch2: np.ndarray,
    input1: str,
    input2: str,
    analysis: dict[str, Any],
    path: Path,
    title: str,
) -> dict[str, Any]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        return {"ok": False, "error": f"matplotlib unavailable: {exc!r}"}

    sweep_ch = analysis["likely_sweep_channel"]
    trans_ch = analysis["likely_transmission_channel"]
    sweep = ch1 if sweep_ch == "ch1" else ch2
    transmission = ch1 if trans_ch == "ch1" else ch2
    sweep_label = input1 if sweep_ch == "ch1" else input2
    trans_label = input1 if trans_ch == "ch1" else input2
    lock = analysis.get("quarter_lockpoint", {})

    fig, axes = plt.subplots(2, 2, figsize=(12, 7))
    t_ms = times * 1e3

    axes[0, 0].plot(t_ms, ch1, color="tab:green", lw=1.0)
    axes[0, 0].set_title(f"CH1 / {input1}")
    axes[0, 0].set_xlabel("Time relative to trigger (ms)")
    axes[0, 0].set_ylabel("Voltage (V)")
    axes[0, 0].grid(True, alpha=0.25)

    axes[0, 1].plot(t_ms, ch2, color="tab:red", lw=1.0)
    axes[0, 1].set_title(f"CH2 / {input2}")
    axes[0, 1].set_xlabel("Time relative to trigger (ms)")
    axes[0, 1].set_ylabel("Voltage (V)")
    axes[0, 1].grid(True, alpha=0.25)

    axes[1, 0].plot(sweep, transmission, color="tab:blue", lw=1.0)
    axes[1, 0].set_title(f"Transmission vs sweep ({trans_ch}/{trans_label} vs {sweep_ch}/{sweep_label})")
    axes[1, 0].set_xlabel(f"Sweep voltage {sweep_ch}/{sweep_label} (V)")
    axes[1, 0].set_ylabel(f"Transmission {trans_ch}/{trans_label} (V)")
    axes[1, 0].grid(True, alpha=0.25)

    if lock.get("ok"):
        y_lock = lock["transmission_lock_quarter"]
        axes[1, 0].axhline(y_lock, color="tab:orange", ls="--", lw=1.2, label="1/4 lock level")
        for name, marker, color in (
            ("left_lockpoint", "o", "tab:purple"),
            ("right_lockpoint", "s", "tab:brown"),
        ):
            point = lock.get(name)
            if point:
                axes[1, 0].scatter(
                    [point["sweep_voltage"]],
                    [point["transmission"]],
                    marker=marker,
                    color=color,
                    s=45,
                    label=name.replace("_", " "),
                    zorder=5,
                )
        axes[1, 0].legend(loc="best", fontsize=8)

    axes[1, 1].axis("off")
    lines = [
        f"Capture: {title}",
        f"Likely transmission: {trans_ch}/{trans_label}",
        f"Likely sweep: {sweep_ch}/{sweep_label}",
        f"Triangle similarity: CH1={analysis['triangle_similarity']['ch1']:.3f}, CH2={analysis['triangle_similarity']['ch2']:.3f}",
    ]
    if lock.get("ok"):
        lines.extend(
            [
                f"T_min = {lock['transmission_min']:.6f} V",
                f"T_max = {lock['transmission_max']:.6f} V",
                f"T_lock = Tmin + (Tmax-Tmin)/4 = {lock['transmission_lock_quarter']:.6f} V",
                f"Dip sweep voltage = {lock['dip_sweep_voltage']:.6f} V",
            ]
        )
        for label, point in (
            ("Left 1/4", lock.get("left_lockpoint")),
            ("Right 1/4", lock.get("right_lockpoint")),
        ):
            if point:
                lines.append(
                    f"{label}: sweep={point['sweep_voltage']:.6f} V, time={point['time']*1e3:.3f} ms"
                )
    axes[1, 1].text(0.0, 1.0, "\n".join(lines), va="top", ha="left", family="monospace", fontsize=9)

    fig.suptitle("Pre-lock sweep capture and 1/4-depth lockpoint", fontsize=13)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return {"ok": True, "path": str(path)}
