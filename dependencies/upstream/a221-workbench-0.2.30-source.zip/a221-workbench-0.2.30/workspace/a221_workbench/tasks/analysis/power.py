"""Shared optical-power and throughput calculations."""

from __future__ import annotations


import math
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class OpticalPowerResult:
    input_monitor_power_uw: float | None
    input_monitor_fraction: float
    input_power_uw: float | None
    output_power_uw: float | None
    throughput: float | None
    throughput_pct: float | None
    throughput_db: float | None
    single_ended_loss_db: float | None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _finite(value: float | int | str | None) -> float | None:
    try:
        parsed = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def calculate_optical_power(
    input_monitor_power_uw: float | int | str | None,
    output_power_uw: float | int | str | None,
    *,
    input_monitor_fraction: float | int | str = 0.01,
    strict: bool = False,
) -> OpticalPowerResult:
    monitor = _finite(input_monitor_power_uw)
    output = _finite(output_power_uw)
    fraction = _finite(input_monitor_fraction)
    if fraction is None or fraction <= 0:
        if strict:
            raise ValueError("monitor fraction must be a positive finite value")
        fraction = 0.01
    if monitor is None or monitor <= 0:
        if strict:
            raise ValueError("input monitor power must be a positive finite value")
        return OpticalPowerResult(monitor, fraction, None, output, None, None, None, None)
    if output is not None and output < 0:
        if strict:
            raise ValueError("output power cannot be negative")
        return OpticalPowerResult(monitor, fraction, monitor / fraction, output, None, None, None, None)

    input_power = monitor / fraction
    if output is None:
        return OpticalPowerResult(monitor, fraction, input_power, None, None, None, None, None)
    throughput = output / input_power
    throughput_db = 10.0 * math.log10(throughput) if throughput > 0 else None
    single_ended_loss = -0.5 * throughput_db if throughput_db is not None else None
    return OpticalPowerResult(
        monitor,
        fraction,
        input_power,
        output,
        throughput,
        throughput * 100.0,
        throughput_db,
        single_ended_loss,
    )
