"""Offline spectral comparisons and ultrasound SNR reports."""
