"""Offline raw-NPZ adapter for the existing transmission normalization."""

from __future__ import annotations
from pathlib import Path

import numpy as np

from .process_large_scan import normalize_transmission_with_baseline


def normalize_large_scan_npz(raw_path, output_path, *, transmission_key=None):
    """Normalize all saved transmission samples, preserving the raw input file.

    Transmission selection uses the unique ``*_trans_v`` role, or an explicit
    key. Time is read from ``time_s`` or reconstructed from the raw endpoints.
    No crop, resampling, wavelength inference, MZI processing or fitting occurs.
    """
    raw_path, output_path = Path(raw_path), Path(output_path)
    if output_path.suffix.lower() != '.npz':
        raise ValueError('output_path must end in .npz')
    if raw_path.resolve() == output_path.resolve() or output_path.exists():
        raise FileExistsError(f'Refusing to overwrite {output_path}')
    with np.load(raw_path, allow_pickle=False) as raw:
        if transmission_key is None:
            candidates = [key for key in raw.files if key.lower().endswith('_trans_v')]
            if len(candidates) != 1:
                raise ValueError('Expected one *_trans_v array; pass transmission_key explicitly')
            transmission_key = candidates[0]
        transmission = np.asarray(raw[transmission_key], dtype=float)
        if transmission.ndim != 1 or len(transmission) < 5 or not np.isfinite(transmission).all():
            raise ValueError('Transmission must be a finite 1-D voltage array with at least 5 samples')
        n = len(transmission)
        if 'rows' in raw and int(raw['rows']) != n:
            raise ValueError('Raw rows does not match the transmission length')
        time_s = (np.asarray(raw['time_s'], dtype=float) if 'time_s' in raw else
                  np.linspace(float(raw['time_start_s']), float(raw['time_stop_s']), n))
        if time_s.shape != transmission.shape or not np.isfinite(time_s).all() or not (np.diff(time_s) > 0).all():
            raise ValueError('Time must be finite, increasing and match the transmission length')
    normalized, baseline = normalize_transmission_with_baseline(transmission)
    # Exclusive creation also protects against a concurrent writer. Parent
    # directory must already exist, so a typo cannot silently create a new tree.
    with output_path.open('xb') as handle:
        np.savez_compressed(
            handle, time_s=time_s, transmission_v=transmission,
            baseline_v=baseline, normalized=normalized,
            source_path=np.asarray(str(raw_path.resolve())),
            transmission_key=np.asarray(transmission_key),
            schema_version=np.asarray(1, dtype=np.int64),
            normalization=np.asarray('normalize_transmission_with_baseline'),
        )
    return output_path
