"""Large-scan processing and report adapters; computation requires no hardware."""

import math


def validate_array_min_depth(value: object) -> float:
    """Validate the relative dip-depth cutoff forwarded to array analysis."""
    try:
        depth = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("array_min_depth must be finite and satisfy 0 < x < 1") from exc
    if isinstance(value, bool) or not math.isfinite(depth) or not 0 < depth < 1:
        raise ValueError("array_min_depth must be finite and satisfy 0 < x < 1")
    return depth
