"""Process a large-scan CSV/NPZ using the reusable logic from the old MATLAB GUI.

This ports the useful parts of FittingUtil/dispersion_analyzer.m:
- baseline-normalize transmission and find resonance dips;
- find alternating MZI extrema and map each dip to an MZI mu coordinate;
- convert MZI mu to relative frequency and fold by an estimated resonator FSR.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.analysis.large_scan'

#!/usr/bin/env python3


import argparse
import csv
import fnmatch
import json
import math
from dataclasses import field, asdict, dataclass
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import maximum_filter1d, minimum_filter1d
from scipy.signal import savgol_filter

from a221_workbench._shared.chip7_design import C_M_PER_S, DEFAULT_NG_ESTIMATE, expected_chip7_fsr_mhz
from a221_workbench._shared.campaign_paths import CAMPAIGN_ENV, CHIP_ENV, DATA_ROOT_ENV, default_campaign, default_chip, default_cavity_dir


@dataclass
class ProcessConfig:
    data_path: str
    start_nm: float
    center_nm: float
    stop_nm: float
    mzi_d1_mhz: float
    mzi_d2_mhz: float
    mzi_d3_mhz: float
    disk_fsr_mhz: float
    disk_fsr_source: str
    offset_mhz: float
    peak_sensitivity_db: float
    mzi_sensitivity_db: float
    nominal_width_samples: int
    fsr_scan_min_mhz: float
    fsr_scan_max_mhz: float
    fsr_scan_step_mhz: float
    output_dir: str


def odd_window(value: int, n: int) -> int:
    value = max(5, min(value, n - 1 if n % 2 == 0 else n))
    if value % 2 == 0:
        value -= 1
    return max(5, value)


def select_role_channel(names: Iterable[str], role: str, fallback_channel: int, *, required: bool = True) -> str | None:
    ordered = list(names)
    lowered = [(name, name.lower()) for name in ordered]
    role_suffix = f"_{role}_v"
    for name, lower in lowered:
        if lower.endswith(role_suffix) or f"_{role}_" in lower:
            return name
    fallback = f"ch{fallback_channel}"
    for name, lower in lowered:
        if fallback in lower:
            return name
    if required:
        raise KeyError(f"No {role} channel found. Available columns: {', '.join(ordered)}")
    return None


def read_large_scan_csv(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    data = np.genfromtxt(path, delimiter=",", names=True)
    names = data.dtype.names or ()
    trigger_name = select_role_channel(names, "trigger", 1, required=False)
    trans_name = select_role_channel(names, "trans", 2)
    mzi_name = select_role_channel(names, "mzi", 3)
    trigger = np.asarray(data[trigger_name], dtype=float) if trigger_name else np.full(len(data), np.nan)
    return (
        np.asarray(data["time_s"], dtype=float),
        trigger,
        np.asarray(data[trans_name], dtype=float),
        np.asarray(data[mzi_name], dtype=float),
    )


def read_large_scan_npz(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    data = np.load(path)
    keys = sorted(data.files)
    trigger_name = select_role_channel(keys, "trigger", 1, required=False)
    trans_name = select_role_channel(keys, "trans", 2)
    mzi_name = select_role_channel(keys, "mzi", 3)
    trans = np.asarray(data[trans_name], dtype=float)
    n = len(trans)
    if "time_s" in keys:
        time_s = np.asarray(data["time_s"], dtype=float)
    else:
        t0 = float(np.asarray(data["time_start_s"]))
        t1 = float(np.asarray(data["time_stop_s"]))
        time_s = np.linspace(t0, t1, n)
    trigger = np.asarray(data[trigger_name], dtype=float) if trigger_name else np.full(n, np.nan)
    return (
        time_s,
        trigger,
        trans,
        np.asarray(data[mzi_name], dtype=float),
    )


def read_large_scan_data(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if path.suffix.lower() == ".npz":
        return read_large_scan_npz(path)
    return read_large_scan_csv(path)


def alternating_extrema(indices: np.ndarray, values: np.ndarray, signs: np.ndarray) -> np.ndarray:
    extrema = np.column_stack([indices.astype(float), values.astype(float), signs.astype(float)])
    extrema = extrema[np.argsort(extrema[:, 0])]
    if len(extrema) <= 1:
        return extrema
    keep = np.ones(len(extrema), dtype=bool)
    active = 0
    expected_sign = extrema[0, 2]
    for i in range(1, len(extrema)):
        if extrema[i, 2] != expected_sign:
            active = i
            expected_sign *= -1
            continue
        old_is_less_extreme = math.copysign(1.0, extrema[i, 1] - extrema[active, 1]) == expected_sign
        if old_is_less_extreme:
            keep[active] = False
            active = i
        else:
            keep[i] = False
    return extrema[keep]


def find_mzi_index(mzi_raw: np.ndarray, mzi_sensitivity_db: float) -> np.ndarray:
    n = len(mzi_raw)
    mean_mzi = savgol_filter(mzi_raw, odd_window(501, n), 1)
    mzi = savgol_filter(mzi_raw, odd_window(11, n), 2)
    diff = np.diff(mzi)
    dip_idx = np.where((diff[:-1] < 0) & (diff[1:] >= 0))[0] + 1
    peak_idx = np.where((diff[:-1] > 0) & (diff[1:] <= 0))[0] + 1
    # MATLAB uses the slow mean as the threshold for AC-coupled MZI traces.
    dip_idx = dip_idx[mzi[dip_idx] < mean_mzi[dip_idx]]
    peak_idx = peak_idx[mzi[peak_idx] > mean_mzi[peak_idx]]
    extrema = alternating_extrema(
        np.concatenate([dip_idx, peak_idx]),
        np.concatenate([mzi[dip_idx], mzi[peak_idx]]),
        np.concatenate([-np.ones(len(dip_idx)), np.ones(len(peak_idx))]),
    )
    return extrema[:, 0].astype(int)


def normalize_transmission(trans_raw: np.ndarray) -> np.ndarray:
    trans, _baseline = normalize_transmission_with_baseline(trans_raw)
    return trans


def normalize_transmission_with_baseline(trans_raw: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    n = len(trans_raw)
    baseline = savgol_filter(trans_raw, odd_window(1001, n), 1)
    slope_guard = 10.0 / n
    for i in range(1, n):
        baseline[i] = max(baseline[i], baseline[i - 1] * (1.0 - slope_guard))
    for i in range(n - 2, -1, -1):
        baseline[i] = max(baseline[i], baseline[i + 1] * (1.0 - slope_guard))
    baseline = np.where(np.abs(baseline) < 1e-12, np.nanmedian(trans_raw), baseline)
    trans = trans_raw / baseline
    return savgol_filter(trans, odd_window(51, n), 2), baseline


def find_transmission_dips(
    trans_raw: np.ndarray,
    *,
    peak_sensitivity_db: float,
    nominal_width_samples: int,
    mzi_index: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    trans, baseline = normalize_transmission_with_baseline(trans_raw)
    threshold = (np.quantile(trans, 0.99) - np.quantile(trans, 0.50)) / (10.0 ** (peak_sensitivity_db / 10.0))
    threshold = max(float(threshold), 1e-4)
    clipped = trans.copy()
    clipped[clipped > 1.0 - threshold] = 1.0
    diff = np.diff(clipped)
    dip_idx = np.where((diff[:-1] < 0) & (diff[1:] >= 0))[0] + 1
    dip_idx = dip_idx[clipped[dip_idx] < (1.0 - 2.0 * threshold)]
    peak_idx = np.where((diff[:-1] > 0) & (diff[1:] <= 0))[0] + 1
    peak_idx = peak_idx[clipped[peak_idx] < (1.0 - threshold)]
    extrema = np.column_stack(
        [
            np.concatenate([dip_idx, peak_idx]).astype(float),
            np.concatenate([clipped[dip_idx], clipped[peak_idx]]).astype(float),
            np.concatenate([-np.ones(len(dip_idx)), np.ones(len(peak_idx))]),
        ]
    )
    extrema = extrema[np.argsort(extrema[:, 0])]
    extrema = merge_narrow_extrema(clipped, extrema, max(1, int(nominal_width_samples)))
    if len(extrema) == 0:
        return np.array([], dtype=int), np.array([], dtype=float), trans, baseline

    good = np.ones(len(extrema), dtype=bool)
    for i in range(1, len(extrema) - 1):
        if extrema[i, 2] == -1:
            left_ok = extrema[i - 1, 2] == 1 and extrema[i - 1, 1] - extrema[i, 1] < threshold
            right_ok = extrema[i + 1, 2] == 1 and extrema[i + 1, 1] - extrema[i, 1] < threshold
            if left_ok or right_ok:
                good[i] = False
    extrema = extrema[good]
    if len(extrema) == 0:
        return np.array([], dtype=int), np.array([], dtype=float), trans, baseline

    if len(mzi_index) > 0:
        extrema = extrema[(extrema[:, 0] >= mzi_index[0]) & (extrema[:, 0] <= mzi_index[-1])]
    dips = extrema[extrema[:, 2] == -1]
    return dips[:, 0].astype(int), dips[:, 1].astype(float), trans, baseline


def merge_narrow_extrema(trace: np.ndarray, extrema: np.ndarray, width: int) -> np.ndarray:
    if len(extrema) <= 1:
        return extrema
    window = max(3, int(width) * 2 + 1)
    local_min = minimum_filter1d(trace, size=window, mode="nearest")
    local_max = maximum_filter1d(trace, size=window, mode="nearest")
    indices = extrema[:, 0].astype(int)
    is_dip = extrema[:, 2] < 0
    is_peak = extrema[:, 2] > 0
    keep = np.zeros(len(extrema), dtype=bool)
    keep[is_dip] = extrema[is_dip, 1] <= local_min[indices[is_dip]] + 1e-12
    keep[is_peak] = extrema[is_peak, 1] >= local_max[indices[is_peak]] - 1e-12
    return extrema[keep]


def map_dips_to_mzi_mu(dip_idx: np.ndarray, mzi_index: np.ndarray) -> np.ndarray:
    if len(dip_idx) == 0 or len(mzi_index) < 2:
        return np.array([], dtype=float)
    idx = np.concatenate([[dip_idx[0] - 1], mzi_index, [dip_idx[-1] + 1]]).astype(float)
    mu_values = np.empty(len(dip_idx), dtype=float)
    mzi_mu = 1
    for i, dip in enumerate(dip_idx):
        while mzi_mu < len(idx) and dip > idx[mzi_mu]:
            mzi_mu += 1
        left = idx[mzi_mu - 1]
        right = idx[mzi_mu]
        frac = 0.0 if right == left else (right - dip) / (right - left)
        mu_values[i] = (mzi_mu - frac) / 2.0
    return mu_values


def relative_frequency_mhz(
    mzi_mu: np.ndarray,
    *,
    start_nm: float,
    center_nm: float,
    stop_nm: float,
    d1: float,
    d2: float,
    d3: float,
    offset_mhz: float,
) -> tuple[np.ndarray, float]:
    c = 299_792_458.0
    f_start = c / start_nm
    f_center = c / center_nm
    f_stop = c / stop_nm
    mapped = mzi_mu.copy()
    if f_start > f_stop:
        mapped = -mapped
    mu_center = mapped[0] + (f_center - f_start) / (f_stop - f_start) * (mapped[-1] - mapped[0])
    mu0 = mapped - mu_center
    freq = d1 * mu0 + 0.5 * d2 * mu0**2 + (d3 / 6.0) * mu0**3 + offset_mhz
    return freq, float(mu_center)


def find_fsr_candidates(
    rel_freq_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    min_mhz: float,
    max_mhz: float,
    step_mhz: float,
    min_depth: float = 0.15,
    top_n: int = 12,
) -> list[dict[str, float]]:
    fsr_values, score = fsr_periodicity_scores(
        rel_freq_mhz,
        depth,
        min_mhz=min_mhz,
        max_mhz=max_mhz,
        step_mhz=step_mhz,
        min_depth=min_depth,
    )
    if len(fsr_values) == 0:
        return []
    candidates = []
    order = np.argsort(score)[::-1]
    selected: list[int] = []
    min_separation = max(5, int(round(2_000.0 / step_mhz)))
    for idx in order:
        if all(abs(idx - prev) >= min_separation for prev in selected):
            selected.append(int(idx))
            candidates.append(
                {
                    "fsr_mhz": float(fsr_values[idx]),
                    "fsr_ghz": float(fsr_values[idx] / 1000.0),
                    "score": float(score[idx]),
                }
            )
        if len(candidates) >= top_n:
            break
    return candidates


def fsr_periodicity_scores(
    rel_freq_mhz: np.ndarray,
    depth: np.ndarray,
    *,
    min_mhz: float,
    max_mhz: float,
    step_mhz: float,
    min_depth: float = 0.15,
) -> tuple[np.ndarray, np.ndarray]:
    mask = np.isfinite(rel_freq_mhz) & np.isfinite(depth) & (depth >= min_depth)
    freq = rel_freq_mhz[mask]
    weights = depth[mask]
    if len(freq) < 4 or step_mhz <= 0 or max_mhz <= min_mhz:
        return np.array([], dtype=float), np.array([], dtype=float)
    fsr_values = np.arange(min_mhz, max_mhz + step_mhz / 2.0, step_mhz)
    if len(fsr_values) == 0:
        return np.array([], dtype=float), np.array([], dtype=float)
    weight_sum = np.sum(np.abs(weights))
    if weight_sum <= 0:
        return np.array([], dtype=float), np.array([], dtype=float)
    score = np.empty_like(fsr_values)
    for i, fsr_mhz in enumerate(fsr_values):
        score[i] = abs(np.sum(weights * np.exp(1j * 2.0 * np.pi * freq / fsr_mhz))) / weight_sum
    return fsr_values, score


def select_full_fsr_candidate(
    candidates: list[dict[str, float]],
    *,
    design_fsr_mhz: float,
) -> dict[str, float] | None:
    """Choose the full-FSR branch near the design value, not the higher-score half-FSR alias."""
    if not candidates:
        return None
    full_fsr_candidates = [
        item
        for item in candidates
        if 0.75 * design_fsr_mhz <= float(item["fsr_mhz"]) <= 1.35 * design_fsr_mhz
    ]
    if not full_fsr_candidates:
        return None
    return max(full_fsr_candidates, key=lambda item: float(item["score"]))


def finite_float(value: object) -> float | None:
    try:
        out = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def expected_fsr_from_radius_mhz(radius_um: float, ng: float = DEFAULT_NG_ESTIMATE) -> float:
    radius_m = radius_um * 1e-6
    return C_M_PER_S / (ng * 2.0 * math.pi * radius_m) / 1e6


def find_array_design_path(*starts: Path) -> Path | None:
    seen: set[Path] = set()
    for start in starts:
        directory = start if start.is_dir() else start.parent
        for candidate_dir in (directory, *directory.parents):
            resolved = candidate_dir.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            candidate = candidate_dir / "array_design.json"
            if candidate.exists():
                return candidate
    return None


def die_design_info(design: dict[str, object], die: str) -> dict[str, object]:
    matrix = design.get("die_design_matrix")
    if isinstance(matrix, dict) and isinstance(matrix.get(die), dict):
        return dict(matrix[die])  # type: ignore[arg-type]
    patterns = design.get("radius_step_nm_by_die_pattern")
    if isinstance(patterns, dict):
        for pattern, radius_step in patterns.items():
            if fnmatch.fnmatch(die, str(pattern)):
                return {"radius_step_nm": radius_step}
    return {}


def expected_array_fsr_mhz(
    *,
    data_path: Path,
    output_dir: Path,
    chip: str,
    die: str,
    cavity: str,
) -> tuple[float, str] | None:
    design_path = find_array_design_path(output_dir, data_path)
    if design_path is None:
        return None
    design = json.loads(design_path.read_text(encoding="utf-8-sig"))
    if not isinstance(design, dict):
        return None
    baseline_radius_um = finite_float(design.get("baseline_radius_um"))
    if baseline_radius_um is None or baseline_radius_um <= 0:
        return None
    target_cavity = cavity if cavity not in {"", "."} else str(design.get("baseline_cavity") or "")
    radius_um = baseline_radius_um
    offsets = design.get("cavity_radius_offset_steps")
    info = die_design_info(design, die)
    radius_step_nm = finite_float(info.get("radius_step_nm"))
    if target_cavity and isinstance(offsets, dict) and radius_step_nm is not None:
        offset_steps = finite_float(offsets.get(target_cavity))
        if offset_steps is not None:
            radius_um += offset_steps * radius_step_nm / 1000.0
    if radius_um <= 0:
        return None
    fsr_mhz = expected_fsr_from_radius_mhz(radius_um)
    source = f"array_design_ng{DEFAULT_NG_ESTIMATE:g}_radius_{radius_um:.6g}um_for_{chip}/{die}/{target_cavity or 'baseline'}"
    return fsr_mhz, source


def update_folded_coordinates(rows: list[dict[str, float | int]], disk_fsr_mhz: float) -> None:
    for row in rows:
        rel_freq = float(row["relative_freq_mhz"])
        mode_number = int(round(rel_freq / disk_fsr_mhz))
        row["mode_number"] = mode_number
        row["folded_freq_mhz"] = float(rel_freq - mode_number * disk_fsr_mhz)


def write_dip_table(path: Path, rows: list[dict[str, float | int]]) -> None:
    fieldnames = [
        "dip_id",
        "sample_index",
        "time_s",
        "wavelength_nm_linear",
        "norm_transmission",
        "depth_1_minus_norm",
        "mzi_mu",
        "relative_freq_mhz",
        "mode_number",
        "folded_freq_mhz",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def plot_envelope(
    ax: plt.Axes,
    time_s: np.ndarray,
    values: np.ndarray,
    *,
    target_bins: int,
    color: str,
    label: str,
    lw: float = 0.9,
    alpha: float = 0.18,
) -> None:
    """Plot a bin min/max envelope so narrow dips are not hidden by stride aliasing."""
    bin_size = max(1, math.ceil(len(time_s) / target_bins))
    starts = np.arange(0, len(time_s), bin_size)
    ends = np.minimum(starts + bin_size - 1, len(time_s) - 1)
    t_mid = 0.5 * (time_s[starts] + time_s[ends])
    y_min = np.minimum.reduceat(values, starts)
    y_max = np.maximum.reduceat(values, starts)
    ax.fill_between(t_mid, y_min, y_max, color=color, alpha=alpha, linewidth=0)
    ax.plot(t_mid, y_max, color=color, lw=lw, label=label)


def plot_envelope_xy(
    ax: plt.Axes,
    x: np.ndarray,
    values: np.ndarray,
    *,
    target_bins: int,
    color: str,
    label: str,
    lw: float = 0.9,
    alpha: float = 0.18,
) -> None:
    bin_size = max(1, math.ceil(len(x) / target_bins))
    starts = np.arange(0, len(x), bin_size)
    ends = np.minimum(starts + bin_size - 1, len(x) - 1)
    x_mid = 0.5 * (x[starts] + x[ends])
    y_min = np.minimum.reduceat(values, starts)
    y_max = np.maximum.reduceat(values, starts)
    ax.fill_between(x_mid, y_min, y_max, color=color, alpha=alpha, linewidth=0)
    ax.plot(x_mid, y_max, color=color, lw=lw, label=label)


def wavelength_axis_from_time(time_s: np.ndarray, *, start_nm: float, center_nm: float, stop_nm: float) -> np.ndarray:
    return center_nm + (stop_nm - start_nm) / 20.0 * time_s


def plot_transmission_spectrum(
    *,
    stem: str,
    output_dir: Path,
    time_s: np.ndarray,
    trans_norm: np.ndarray,
    dip_idx: np.ndarray,
    start_nm: float,
    center_nm: float,
    stop_nm: float,
) -> Path:
    wavelength_nm = wavelength_axis_from_time(time_s, start_nm=start_nm, center_nm=center_nm, stop_nm=stop_nm)
    fig, ax = plt.subplots(figsize=(14, 5.6), constrained_layout=True)
    plot_envelope_xy(
        ax,
        wavelength_nm,
        trans_norm,
        target_bins=30000,
        color="#2364aa",
        label="normalized transmission envelope",
        lw=0.65,
    )
    if len(dip_idx):
        pick = dip_idx[:: max(1, len(dip_idx) // 800)]
        ax.scatter(
            wavelength_nm[pick],
            trans_norm[pick],
            s=8,
            color="#c43b3b",
            zorder=3,
            label="detected resonances",
        )
    ax.set_xlim(min(start_nm, stop_nm), max(start_nm, stop_nm))
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("Normalized transmission")
    ax.set_title("Total transmission spectrum")
    ax.legend(loc="best")
    path = output_dir / f"{stem}_transmission_spectrum.png"
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def plot_fsr_periodicity(
    *,
    stem: str,
    output_dir: Path,
    fsr_values_mhz: np.ndarray,
    fsr_score: np.ndarray,
    candidates: list[dict[str, float]],
    selected_fsr: dict[str, float] | None,
    design_fsr_mhz: float,
) -> Path:
    fig, ax = plt.subplots(figsize=(12, 5.8), constrained_layout=True)
    if len(fsr_values_mhz) and len(fsr_score):
        ax.plot(fsr_values_mhz / 1000.0, fsr_score, color="#2364aa", lw=1.0, label="periodicity score")
        if candidates:
            x = np.array([item["fsr_mhz"] / 1000.0 for item in candidates], dtype=float)
            y = np.array([item["score"] for item in candidates], dtype=float)
            ax.scatter(x, y, color="#c43b3b", s=26, zorder=3, label="local maxima")
        if design_fsr_mhz > 0:
            ax.axvline(design_fsr_mhz / 1000.0, color="#6c757d", lw=1.0, ls="--", label="design FSR estimate")
        if selected_fsr is not None:
            selected = float(selected_fsr["fsr_mhz"]) / 1000.0
            ax.axvline(selected, color="#2b8c5a", lw=1.4, label="selected full-FSR branch")
        elif candidates:
            selected = float(candidates[0]["fsr_mhz"]) / 1000.0
            ax.axvline(selected, color="#2b8c5a", lw=1.4, label="dominant score")
        ax.set_xlabel("Candidate spectral period / FSR (GHz)")
        ax.set_ylabel("Weighted phase-coherence score")
        ax.set_title("Dominant spectral-period analysis from resonance positions")
        ax.legend(loc="best")
    else:
        ax.text(0.5, 0.5, "Not enough resonances for FSR-period analysis", ha="center", va="center")
        ax.axis("off")
    path = output_dir / f"{stem}_fsr_periodicity.png"
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def plot_results(
    *,
    stem: str,
    output_dir: Path,
    time_s: np.ndarray,
    trans_raw: np.ndarray,
    mzi_raw: np.ndarray,
    dip_idx: np.ndarray,
    rows: list[dict[str, float | int]],
    disk_fsr_mhz: float,
) -> tuple[Path, Path]:
    fig, axes = plt.subplots(2, 1, figsize=(15, 8), sharex=True, constrained_layout=True)
    plot_envelope(axes[0], time_s, trans_raw, target_bins=20000, color="#2364aa", label="transmission raw envelope")
    if len(dip_idx):
        pick = dip_idx[:: max(1, len(dip_idx) // 400)]
        axes[0].scatter(time_s[pick], trans_raw[pick], s=18, color="#c43b3b", zorder=3, label="detected dips")
        axes[0].legend(loc="best", fontsize=15)
    axes[0].set_ylabel("Transmission (V)", fontsize=18)
    axes[0].set_title(f"{stem}: raw transmission / MZI min-max envelope", fontsize=20)
    plot_envelope(axes[1], time_s, mzi_raw, target_bins=20000, color="#55a868", label="MZI envelope", lw=0.75)
    axes[1].set_xlabel("Time relative to trigger (s)", fontsize=18)
    axes[1].set_ylabel("MZI (V)", fontsize=18)
    for ax in axes:
        ax.tick_params(axis="both", labelsize=15)
    raw_fig = output_dir / f"{stem}_ch2_ch3_raw.png"
    fig.savefig(raw_fig, dpi=240)
    plt.close(fig)

    folded_fig = output_dir / f"{stem}_folded_dispersion.png"
    if rows:
        mode_number = np.array([float(row["mode_number"]) for row in rows])
        folded = np.array([float(row["folded_freq_mhz"]) for row in rows])
        depth = np.array([float(row["depth_1_minus_norm"]) for row in rows])
        fig, ax = plt.subplots(figsize=(12, 5.6), constrained_layout=True)
        sc = ax.scatter(mode_number, folded, c=depth, s=12, cmap="viridis", linewidths=0)
        ax.axhline(0, color="black", lw=0.8)
        ax.axhline(disk_fsr_mhz / 2, color="#999999", lw=0.6, ls="--")
        ax.axhline(-disk_fsr_mhz / 2, color="#999999", lw=0.6, ls="--")
        ax.set_xlabel("Mode number from folded FSR")
        ax.set_ylabel("Folded frequency (MHz)")
        ax.set_title(f"Folded resonance map, disk FSR = {disk_fsr_mhz / 1000:.6g} GHz")
        cb = fig.colorbar(sc, ax=ax)
        cb.set_label("Depth, 1 - normalized transmission")
        fig.savefig(folded_fig, dpi=180)
        plt.close(fig)
    else:
        fig, ax = plt.subplots(figsize=(8, 4), constrained_layout=True)
        ax.text(0.5, 0.5, "No dips detected", ha="center", va="center")
        ax.axis("off")
        fig.savefig(folded_fig, dpi=180)
        plt.close(fig)
    return raw_fig, folded_fig


def plot_normalized_transmission(
    *,
    stem: str,
    output_dir: Path,
    time_s: np.ndarray,
    trans_raw: np.ndarray,
    trans_norm: np.ndarray,
    baseline: np.ndarray,
    dip_idx: np.ndarray,
) -> Path:
    bin_size = max(1, math.ceil(len(time_s) / 25000))
    t_plot = time_s[::bin_size]
    baseline_plot = baseline[::bin_size]

    fig, axes = plt.subplots(2, 1, figsize=(12, 6.6), sharex=True, constrained_layout=True)
    plot_envelope(axes[0], time_s, trans_raw, target_bins=25000, color="#2364aa", label="transmission raw envelope", lw=0.55)
    axes[0].plot(t_plot, baseline_plot, color="#c43b3b", lw=1.0, alpha=0.9, label="estimated baseline")
    axes[0].set_ylabel("Transmission (V)")
    axes[0].legend(loc="best")
    axes[0].set_title("Baseline flattening used for dip detection")

    plot_envelope(
        axes[1],
        time_s,
        trans_norm,
        target_bins=25000,
        color="#2b8c5a",
        label="normalized + smoothed transmission envelope",
        lw=0.6,
    )
    if len(dip_idx):
        pick = dip_idx[:: max(1, len(dip_idx) // 500)]
        axes[1].scatter(time_s[pick], trans_norm[pick], s=8, color="#c43b3b", zorder=3, label="detected dips")
    axes[1].axhline(1.0, color="#777777", lw=0.8, ls="--")
    axes[1].set_xlabel("Time relative to trigger (s)")
    axes[1].set_ylabel("Normalized transmission")
    axes[1].legend(loc="best")

    path = output_dir / f"{stem}_ch2_flattened_for_dips.png"
    fig.savefig(path, dpi=180)
    plt.close(fig)
    return path


@dataclass
class ProcessOptions:
    """Typed inputs shared by the CLI and callable step; no device I/O on construction."""
    data_path: str | None = None
    campaign: str = field(default_factory=default_campaign)
    chip: str = field(default_factory=default_chip)
    die: str = 'die1-1'
    cavity: str = 'c1'
    start_nm: float = 1530.0
    center_nm: float = 1550.0
    stop_nm: float = 1570.0
    mzi_d1_mhz: float = 40.44357
    mzi_d2_mhz: float = 4e-08
    mzi_d3_mhz: float = -3e-14
    disk_fsr_mhz: float | None = None
    offset_mhz: float = 0.0
    peak_sensitivity_db: float = 0.0
    mzi_sensitivity_db: float = 0.0
    nominal_width_samples: int = 50
    fsr_scan_min_mhz: float | None = None
    fsr_scan_max_mhz: float | None = None
    fsr_scan_step_mhz: float = 10.0
    output_dir: str | None = None


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_path", nargs="?", default=None)
    parser.add_argument(
        "--campaign",
        default=default_campaign(),
        help=f"Campaign path under ${DATA_ROOT_ENV}/experiments. Defaults to ${CAMPAIGN_ENV} or wafer_measuement/Batch_260515.",
    )
    parser.add_argument("--chip", default=default_chip(), help=f"Chip/sample id. Defaults to ${CHIP_ENV} or chip7.")
    parser.add_argument("--die", default="die1-1")
    parser.add_argument("--cavity", default="c1")
    parser.add_argument("--start-nm", type=float, default=1530.0)
    parser.add_argument("--center-nm", type=float, default=1550.0)
    parser.add_argument("--stop-nm", type=float, default=1570.0)
    parser.add_argument("--mzi-d1-mhz", type=float, default=40.44357)
    parser.add_argument("--mzi-d2-mhz", type=float, default=4e-8)
    parser.add_argument("--mzi-d3-mhz", type=float, default=-3e-14)
    parser.add_argument(
        "--disk-fsr-mhz",
        type=float,
        default=None,
        help="Reference FSR for folded diagnostic plots. Defaults to chip/die design estimate.",
    )
    parser.add_argument("--offset-mhz", type=float, default=0.0)
    parser.add_argument("--peak-sensitivity-db", type=float, default=0.0)
    parser.add_argument("--mzi-sensitivity-db", type=float, default=0.0)
    parser.add_argument("--nominal-width-samples", type=int, default=50)
    parser.add_argument("--fsr-scan-min-mhz", type=float, default=None)
    parser.add_argument("--fsr-scan-max-mhz", type=float, default=None)
    parser.add_argument("--fsr-scan-step-mhz", type=float, default=10.0)
    parser.add_argument(
        "--output-dir",
        default=None,
        help=f"Output directory. Defaults to the input data directory, or ${DATA_ROOT_ENV}/experiments/... when data_path is omitted.",
    )
    return parser.parse_args(list(argv))


def process_scan(args: ProcessOptions) -> dict[str, object]:
    if args.data_path:
        data_path = Path(args.data_path)
    else:
        result_dir = default_cavity_dir(args.chip, args.die, args.cavity, campaign=args.campaign)
        candidates = list(result_dir.glob("large_scan_*_1530-1570nm.npz")) + list(result_dir.glob("large_scan_*_1530-1570nm.csv"))
        if not candidates:
            raise SystemExit(f"No large-scan data found in {result_dir}")
        data_path = max(candidates, key=lambda p: p.stat().st_mtime)
    output_dir = Path(args.output_dir) if args.output_dir else data_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = data_path.stem
    if args.disk_fsr_mhz is not None:
        disk_fsr_mhz = float(args.disk_fsr_mhz)
        disk_fsr_source = "cli"
    elif args.chip.lower() == "chip7":
        disk_fsr_mhz = expected_chip7_fsr_mhz(args.die)
        disk_fsr_source = f"chip7_design_initial_ng2_radius_for_{args.die}"
    else:
        inferred = expected_array_fsr_mhz(
            data_path=data_path,
            output_dir=output_dir,
            chip=args.chip,
            die=args.die,
            cavity=args.cavity,
        )
        if inferred is None:
            raise SystemExit(
                "Could not infer a design FSR for this non-chip7 data. "
                "Add chip-level array_design.json with baseline_radius_um, or pass --disk-fsr-mhz."
            )
        disk_fsr_mhz, disk_fsr_source = inferred
    design_fsr_mhz_for_plot = disk_fsr_mhz

    fsr_scan_min_mhz = float(args.fsr_scan_min_mhz) if args.fsr_scan_min_mhz is not None else max(20_000.0, 0.20 * disk_fsr_mhz)
    fsr_scan_max_mhz = float(args.fsr_scan_max_mhz) if args.fsr_scan_max_mhz is not None else 1.20 * disk_fsr_mhz
    time_s, _trigger, trans_raw, mzi_raw = read_large_scan_data(data_path)
    mzi_index = find_mzi_index(mzi_raw, args.mzi_sensitivity_db)
    dip_idx, dip_norm, trans_norm, baseline = find_transmission_dips(
        trans_raw,
        peak_sensitivity_db=args.peak_sensitivity_db,
        nominal_width_samples=args.nominal_width_samples,
        mzi_index=mzi_index,
    )
    mzi_mu = map_dips_to_mzi_mu(dip_idx, mzi_index)
    rows: list[dict[str, float | int]] = []
    selected_fsr = None
    fsr_score_values = np.array([], dtype=float)
    fsr_score = np.array([], dtype=float)
    if len(dip_idx) and len(mzi_mu):
        rel_freq, mu_center = relative_frequency_mhz(
            mzi_mu,
            start_nm=args.start_nm,
            center_nm=args.center_nm,
            stop_nm=args.stop_nm,
            d1=args.mzi_d1_mhz,
            d2=args.mzi_d2_mhz,
            d3=args.mzi_d3_mhz,
            offset_mhz=args.offset_mhz,
        )
        mode_number = np.rint(rel_freq / disk_fsr_mhz).astype(int)
        folded = rel_freq - mode_number * disk_fsr_mhz
        depth = 1.0 - dip_norm
        wavelength = args.center_nm + (args.stop_nm - args.start_nm) / 20.0 * time_s[dip_idx]
        for i, idx in enumerate(dip_idx):
            rows.append(
                {
                    "dip_id": i + 1,
                    "sample_index": int(idx),
                    "time_s": float(time_s[idx]),
                    "wavelength_nm_linear": float(wavelength[i]),
                    "norm_transmission": float(dip_norm[i]),
                    "depth_1_minus_norm": float(depth[i]),
                    "mzi_mu": float(mzi_mu[i]),
                    "relative_freq_mhz": float(rel_freq[i]),
                    "mode_number": int(mode_number[i]),
                    "folded_freq_mhz": float(folded[i]),
                }
            )
        fsr_score_values, fsr_score = fsr_periodicity_scores(
            rel_freq,
            depth,
            min_mhz=fsr_scan_min_mhz,
            max_mhz=fsr_scan_max_mhz,
            step_mhz=args.fsr_scan_step_mhz,
        )
        fsr_candidates = find_fsr_candidates(
            rel_freq,
            depth,
            min_mhz=fsr_scan_min_mhz,
            max_mhz=fsr_scan_max_mhz,
            step_mhz=args.fsr_scan_step_mhz,
        )
        if args.disk_fsr_mhz is None:
            selected_fsr = select_full_fsr_candidate(fsr_candidates, design_fsr_mhz=disk_fsr_mhz)
            if selected_fsr is not None:
                disk_fsr_mhz = float(selected_fsr["fsr_mhz"])
                disk_fsr_source = "auto_full_fsr_candidate"
                update_folded_coordinates(rows, disk_fsr_mhz)
    else:
        mu_center = float("nan")
        fsr_candidates = []

    config = ProcessConfig(
        data_path=str(data_path),
        start_nm=args.start_nm,
        center_nm=args.center_nm,
        stop_nm=args.stop_nm,
        mzi_d1_mhz=args.mzi_d1_mhz,
        mzi_d2_mhz=args.mzi_d2_mhz,
        mzi_d3_mhz=args.mzi_d3_mhz,
        disk_fsr_mhz=disk_fsr_mhz,
        disk_fsr_source=disk_fsr_source,
        offset_mhz=args.offset_mhz,
        peak_sensitivity_db=args.peak_sensitivity_db,
        mzi_sensitivity_db=args.mzi_sensitivity_db,
        nominal_width_samples=args.nominal_width_samples,
        fsr_scan_min_mhz=fsr_scan_min_mhz,
        fsr_scan_max_mhz=fsr_scan_max_mhz,
        fsr_scan_step_mhz=args.fsr_scan_step_mhz,
        output_dir=str(output_dir),
    )

    print(json.dumps(asdict(config), indent=2, ensure_ascii=False))
    table_path = output_dir / f"{stem}_dip_table.csv"
    write_dip_table(table_path, rows)
    raw_fig, folded_fig = plot_results(
        stem=stem,
        output_dir=output_dir,
        time_s=time_s,
        trans_raw=trans_raw,
        mzi_raw=mzi_raw,
        dip_idx=dip_idx,
        rows=rows,
        disk_fsr_mhz=disk_fsr_mhz,
    )
    spectrum_fig = plot_transmission_spectrum(
        stem=stem,
        output_dir=output_dir,
        time_s=time_s,
        trans_norm=trans_norm,
        dip_idx=dip_idx,
        start_nm=args.start_nm,
        center_nm=args.center_nm,
        stop_nm=args.stop_nm,
    )
    fsr_fig = plot_fsr_periodicity(
        stem=stem,
        output_dir=output_dir,
        fsr_values_mhz=fsr_score_values,
        fsr_score=fsr_score,
        candidates=fsr_candidates,
        selected_fsr=selected_fsr,
        design_fsr_mhz=design_fsr_mhz_for_plot,
    )
    flattened_fig = plot_normalized_transmission(
        stem=stem,
        output_dir=output_dir,
        time_s=time_s,
        trans_raw=trans_raw,
        trans_norm=trans_norm,
        baseline=baseline,
        dip_idx=dip_idx,
    )
    summary = {
        "config": asdict(config),
        "rows": int(len(time_s)),
        "mzi_extrema_count": int(len(mzi_index)),
        "dip_count": int(len(rows)),
        "mu_center": mu_center,
        "fsr_candidates": fsr_candidates,
        "selected_fsr_candidate": selected_fsr,
        "dip_table": str(table_path),
        "raw_ch2_ch3_figure": str(raw_fig),
        "flattened_ch2_figure": str(flattened_fig),
        "transmission_spectrum_figure": str(spectrum_fig),
        "fsr_periodicity_figure": str(fsr_fig),
        "folded_dispersion_figure": str(folded_fig),
    }
    summary_path = output_dir / f"{stem}_process_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return summary

def main(argv: Iterable[str]) -> int:
    process_scan(ProcessOptions(**vars(parse_args(argv))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(__import__("sys").argv[1:]))
