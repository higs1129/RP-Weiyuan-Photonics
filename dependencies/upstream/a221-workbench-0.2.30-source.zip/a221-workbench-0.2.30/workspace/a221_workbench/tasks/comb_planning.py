"""Calculate a comb reconstruction plan from recorded modes and tuning parameters; no device writes."""
from __future__ import annotations
from typing import Any
from pathlib import Path
from a221_workbench.tasks.array_records import (
    Q_BY_MODE_FILE,
    die_dir,
    family_assignment_path,
    finite_float,
    load_array_design,
    load_family_assignments,
    natural_key,
    normalize_q_slot,
    q_slot_dir,
    validate_name,
)

import csv

import json

import math

from pathlib import Path


DEFAULT_THERMAL_MZI_D1_MHZ = 40.44357


THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN = -1.0


def thermal_q_slot_dir(directory: Path, q_slot: object = "Q") -> Path:
    """Keep legacy Q results in place while isolating all Q' thermal artifacts."""
    normalized = normalize_q_slot(q_slot)
    root = thermal_tuning_dir(directory)
    if normalized == "Q":
        return root
    path = root / "Q_prime"
    path.mkdir(parents=True, exist_ok=True)
    return path


def finite_int(value: object) -> int | None:
    parsed = finite_float(value)
    if parsed is None:
        return None
    return int(round(parsed))


def q_dir_for_die(config: dict[str, Any], chip: str, die: str) -> Path:
    return die_dir(config, chip, die) / "Q"


def read_laser_readback_wavelength_curve(q_dir: Path) -> dict[str, Any]:
    path = q_dir / "laser_readback_vs_mzi.csv"
    if not path.exists():
        return {"ok": False, "path": str(path), "reason": "missing_laser_readback_vs_mzi_csv"}
    points: list[tuple[float, float]] = []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            scope_time_s = finite_float(row.get("scope_time_estimate_s"))
            wavelength_nm = finite_float(row.get("laser_readback_nm"))
            if scope_time_s is None or wavelength_nm is None:
                continue
            points.append((scope_time_s, wavelength_nm))
    points.sort(key=lambda item: item[0])
    deduped: list[tuple[float, float]] = []
    for point in points:
        if deduped and point[0] == deduped[-1][0]:
            deduped[-1] = point
        else:
            deduped.append(point)
    return {
        "ok": len(deduped) >= 2,
        "path": str(path),
        "point_count": len(deduped),
        "points": deduped,
        "reason": None if len(deduped) >= 2 else "not_enough_readback_points",
    }


def interpolate_laser_readback_nm(curve: dict[str, Any], time_s: float | None) -> float | None:
    if time_s is None or not curve.get("ok"):
        return None
    points = curve.get("points")
    if not isinstance(points, list) or len(points) < 2:
        return None
    t = float(time_s)
    if t < float(points[0][0]) or t > float(points[-1][0]):
        return None
    lo = 0
    hi = len(points) - 1
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if float(points[mid][0]) <= t:
            lo = mid
        else:
            hi = mid
    t0, wl0 = points[lo]
    t1, wl1 = points[hi]
    t0 = float(t0)
    t1 = float(t1)
    wl0 = float(wl0)
    wl1 = float(wl1)
    if t1 == t0:
        return wl0
    frac = (t - t0) / (t1 - t0)
    return wl0 + frac * (wl1 - wl0)


def linear_fit_slope(xs: list[float], ys: list[float]) -> float | None:
    if len(xs) < 2 or len(xs) != len(ys):
        return None
    mean_x = sum(xs) / len(xs)
    mean_y = sum(ys) / len(ys)
    denom = sum((x - mean_x) ** 2 for x in xs)
    if denom == 0:
        return None
    return sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / denom


def read_anchor_freq_ghz(q_dir: Path) -> float:
    for name in ("array_q_summary.json", "array_preanalysis_summary.json"):
        path = q_dir / name
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        calibration = payload.get("absolute_wavelength_calibration")
        if isinstance(calibration, dict):
            anchor_freq_mhz = finite_float(calibration.get("anchor_freq_mhz"))
            if anchor_freq_mhz is not None:
                return anchor_freq_mhz / 1000.0
    return wavelength_nm_to_freq_ghz(1550.0)


def read_mzi_slope_correction(q_dir: Path) -> dict[str, Any]:
    for name in ("array_q_summary.json", "array_preanalysis_summary.json"):
        path = q_dir / name
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        comparison = payload.get("laser_readback_vs_mzi")
        correction = comparison.get("recommended_slope_correction") if isinstance(comparison, dict) else None
        if isinstance(correction, dict):
            ratio = finite_float(correction.get("slope_ratio_readback_over_mzi"))
            if ratio is not None:
                return {
                    "ok": True,
                    "ratio": ratio,
                    "source_region": correction.get("source_region") or "",
                    "source": str(path),
                    "anchor_freq_ghz": read_anchor_freq_ghz(q_dir),
                    "method": "summary_recommended_slope_correction",
                }

    path = q_dir / "laser_readback_vs_mzi.csv"
    if not path.exists():
        return {"ok": False, "reason": "missing_laser_readback_vs_mzi_csv"}
    rows: list[tuple[float, float, float]] = []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            scope_time_s = finite_float(row.get("scope_time_estimate_s"))
            laser_nm = finite_float(row.get("laser_readback_nm"))
            mzi_nm = finite_float(row.get("mzi_calibrated_nm"))
            if scope_time_s is None or laser_nm is None or mzi_nm is None:
                continue
            rows.append(
                (
                    float(scope_time_s),
                    wavelength_nm_to_freq_ghz(laser_nm),
                    wavelength_nm_to_freq_ghz(mzi_nm),
                )
            )
    if len(rows) < 2:
        return {"ok": False, "path": str(path), "reason": "not_enough_readback_mzi_pairs"}
    region_rows = [row for row in rows if abs(row[0]) <= 8.0]
    source_region = "center_pm8s"
    if len(region_rows) < 2:
        region_rows = rows
        source_region = "all"
    xs = [row[0] for row in region_rows]
    readback = [row[1] for row in region_rows]
    mzi = [row[2] for row in region_rows]
    readback_slope = linear_fit_slope(xs, readback)
    mzi_slope = linear_fit_slope(xs, mzi)
    if readback_slope is None or mzi_slope is None or mzi_slope == 0:
        return {"ok": False, "path": str(path), "reason": "linear_fit_failed"}
    return {
        "ok": True,
        "ratio": readback_slope / mzi_slope,
        "source_region": source_region,
        "source": str(path),
        "anchor_freq_ghz": read_anchor_freq_ghz(q_dir),
        "method": "load_time_linear_fit",
        "count": len(region_rows),
        "readback_slope_ghz_per_s": readback_slope,
        "mzi_slope_ghz_per_s": mzi_slope,
    }


def load_reconstruction_mode_state(directory: Path) -> dict[str, Any]:
    root = thermal_comb_reconstruction_check_dir(directory)
    summary_path = root / "verification_summary.json"
    plan_path = root / "plan.json"
    final_state_path = root / "final_sgm_outputs.json"

    summary: dict[str, Any] = {}
    plan: dict[str, Any] = {}
    final_state: dict[str, Any] = {}
    for path, target in (
        (summary_path, summary),
        (plan_path, plan),
        (final_state_path, final_state),
    ):
        if not path.exists():
            continue
        try:
            loaded = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        if isinstance(loaded, dict):
            target.update(loaded)

    if isinstance(summary.get("plan"), dict):
        merged_plan = dict(summary["plan"])
        merged_plan.update(plan)
        plan = merged_plan

    plan_rows = [dict(row) for row in plan.get("plan_rows", []) if isinstance(row, dict)]
    plan_by_family: dict[str, dict[str, Any]] = {}
    for row in plan_rows:
        if not isinstance(row, dict):
            continue
        family = str(row.get("family") or "").strip()
        if family and bool(row.get("matched")):
            plan_by_family[family] = dict(row)

    verification_by_family: dict[str, dict[str, Any]] = {}
    verification_rows = summary.get("verification_rows")
    if not isinstance(verification_rows, list):
        verification_rows = []
    for row in verification_rows:
        if not isinstance(row, dict):
            continue
        family = str(row.get("family") or "").strip()
        if family:
            verification_by_family[family] = dict(row)

    comb_segment_indices = plan.get("comb_segment_indices")
    if not isinstance(comb_segment_indices, list) or not comb_segment_indices:
        comb_segment_indices = sorted(
            {
                comb_index
                for row in plan_rows
                if (comb_index := finite_int(row.get("comb_index"))) is not None
            }
        )
    selected_comb_indices = plan.get("selected_comb_indices")
    if not isinstance(selected_comb_indices, list):
        selected_comb_indices = sorted(
            {
                comb_index
                for row in plan_rows
                if bool(row.get("matched"))
                and (comb_index := finite_int(row.get("comb_index"))) is not None
            }
        )
    selected_mode_numbers = plan.get("selected_mode_numbers")
    if not isinstance(selected_mode_numbers, list):
        selected_mode_numbers = sorted(
            {
                mode_number
                for row in plan_rows
                if bool(row.get("matched"))
                and (mode_number := finite_int(row.get("mode_number"))) is not None
            }
        )

    outputs = final_state.get("outputs_v")
    if not isinstance(outputs, dict):
        outputs = summary.get("final_outputs_v")
    outputs_v: dict[str, float] = {}
    if isinstance(outputs, dict):
        for key, value in outputs.items():
            parsed = finite_float(value)
            if parsed is not None:
                outputs_v[str(key)] = parsed

    return {
        "ok": bool(plan_by_family or verification_by_family or outputs_v),
        "directory": str(root),
        "summary_path": str(summary_path),
        "plan_path": str(plan_path),
        "final_state_path": str(final_state_path),
        "plan_by_family": plan_by_family,
        "verification_by_family": verification_by_family,
        "plan_rows": plan_rows,
        "verification_rows": [dict(row) for row in verification_rows if isinstance(row, dict)],
        "comb_segment_indices": comb_segment_indices,
        "comb_segment_start_index": plan.get("comb_segment_start_index") if plan.get("comb_segment_start_index") is not None else (comb_segment_indices[0] if comb_segment_indices else None),
        "comb_segment_end_index": plan.get("comb_segment_end_index") if plan.get("comb_segment_end_index") is not None else (comb_segment_indices[-1] if comb_segment_indices else None),
        "comb_segment_center_offset_teeth": plan.get("comb_segment_center_offset_teeth"),
        "comb_segment_max_center_offset_teeth": plan.get("comb_segment_max_center_offset_teeth"),
        "selected_comb_indices": selected_comb_indices,
        "selected_mode_numbers": selected_mode_numbers,
        "selected_center_wavelength_nm": plan.get("selected_center_wavelength_nm"),
        "center_wavelength_min_nm": plan.get("center_wavelength_min_nm"),
        "center_wavelength_max_nm": plan.get("center_wavelength_max_nm"),
        "comb_spacing_ghz": plan.get("comb_spacing_ghz"),
        "wavelength_basis": plan.get("wavelength_basis"),
        "outputs_v": outputs_v,
        "updated_at": final_state.get("updated_at"),
        "all_passed": summary.get("all_passed"),
        "passed_count": summary.get("passed_count"),
        "checked_count": summary.get("checked_count"),
    }


def load_thermal_modes(config: dict[str, Any], chip: str, die: str, q_slot: object = "Q") -> dict[str, Any]:
    directory = die_dir(config, chip, die)
    normalized_q_slot = normalize_q_slot(q_slot)
    q_dir = q_slot_dir(directory, normalized_q_slot)
    q_table = q_dir / Q_BY_MODE_FILE
    if not q_table.exists():
        return {
            "ok": True,
            "chip": chip,
            "die": die,
            "q_slot": normalized_q_slot,
            "directory": str(directory),
            "q_dir": str(q_dir),
            "q_table": str(q_table),
            "modes": [],
            "message": f"尚未找到 {Q_BY_MODE_FILE}；请先在模式表征页运行或重新分析大扫。",
        }

    readback_curve = read_laser_readback_wavelength_curve(q_dir)
    slope_correction = read_mzi_slope_correction(q_dir)
    modes_by_key: dict[tuple[int, str], dict[str, Any]] = {}
    with q_table.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            mode_number = finite_int(row.get("mode_number"))
            wavelength_nm = finite_float(row.get("wavelength_nm"))
            if mode_number is None or wavelength_nm is None:
                continue
            if row.get("fit_status") and row.get("fit_status") != "ok":
                continue
            family = str(row.get("family_label") or row.get("family") or "").strip()
            if not family:
                continue
            time_s = finite_float(row.get("time_s"))
            fit_center_offset_mhz = finite_float(row.get("fit_center_offset_mhz")) or 0.0
            readback_sample_nm = interpolate_laser_readback_nm(readback_curve, time_s)
            readback_mode_nm = None
            if readback_sample_nm is not None:
                readback_mode_freq_ghz = wavelength_nm_to_freq_ghz(readback_sample_nm) + fit_center_offset_mhz / 1000.0
                readback_mode_nm = freq_ghz_to_wavelength_nm(readback_mode_freq_ghz)
            slope_corrected_nm = finite_float(row.get("wavelength_nm_slope_corrected"))
            slope_ratio = finite_float(row.get("mzi_readback_slope_ratio"))
            slope_region = str(row.get("mzi_readback_slope_region") or "").strip()
            if slope_corrected_nm is None and slope_correction.get("ok"):
                absolute_freq_mhz = finite_float(row.get("absolute_freq_mhz"))
                ratio = finite_float(slope_correction.get("ratio"))
                anchor_freq_ghz = finite_float(slope_correction.get("anchor_freq_ghz"))
                if absolute_freq_mhz is not None and ratio is not None and anchor_freq_ghz is not None:
                    corrected_freq_ghz = anchor_freq_ghz + ratio * (absolute_freq_mhz / 1000.0 - anchor_freq_ghz)
                    slope_corrected_nm = freq_ghz_to_wavelength_nm(corrected_freq_ghz)
                    slope_ratio = ratio
                    slope_region = str(slope_correction.get("source_region") or "")
            modes_by_key[(mode_number, family)] = {
                "family": family,
                "mode_number": mode_number,
                "wavelength_nm": wavelength_nm,
                "wavelength_nm_mzi": wavelength_nm,
                "wavelength_nm_readback": readback_mode_nm,
                "wavelength_nm_slope_corrected": slope_corrected_nm,
                "wavelength_readback_sample_nm": readback_sample_nm,
                "wavelength_basis": "mzi",
                "wavelength_source": row.get("wavelength_source") or "",
                "readback_wavelength_source": "laser_readback_vs_mzi.csv interpolated by mode time_s plus fit_center_offset_mhz"
                if readback_mode_nm is not None
                else "",
                "slope_corrected_wavelength_source": "MZI axis scaled by TOPTICA readback linear slope around the 1550 nm trigger anchor"
                if slope_corrected_nm is not None
                else "",
                "mzi_readback_slope_ratio": slope_ratio,
                "mzi_readback_slope_region": slope_region,
                "relative_freq_ghz": finite_float(row.get("relative_freq_ghz")),
                "folded_freq_ghz": finite_float(row.get("folded_freq_ghz")),
                "depth": finite_float(row.get("depth")),
                "transmission": finite_float(row.get("transmission")),
                "linewidth_loaded_mhz": finite_float(row.get("linewidth_loaded_mhz")),
                "Q0": finite_float(row.get("Q0")),
                "Q1": finite_float(row.get("Q1")),
                "QL": finite_float(row.get("QL")),
                "fit_status": row.get("fit_status") or "",
                "coupling_note": row.get("coupling_note") or "",
            }
    assignment_record = load_family_assignments(config, chip, die, normalized_q_slot)
    assignments_by_family = {
        str(item.get("family") or "").strip(): dict(item)
        for item in assignment_record.get("assignments", [])
        if isinstance(item, dict) and str(item.get("family") or "").strip()
    }
    reconstruction = load_reconstruction_mode_state(directory) if normalized_q_slot == "Q" else {
        "ok": False,
        "directory": str(q_dir / "thermal_tuning" / "comb_reconstruction_check"),
        "plan_by_family": {},
        "verification_by_family": {},
        "plan_rows": [],
        "verification_rows": [],
        "outputs_v": {},
    }
    for mode in modes_by_key.values():
        family = str(mode.get("family") or "").strip()
        assignment = assignments_by_family.get(family, {})
        cavity = str(assignment.get("cavity") or "").strip()
        mode["cavity"] = cavity
        mode["assignment_confidence"] = assignment.get("confidence")
        mode["assignment_status"] = assignment.get("status")
        tuning = tuning_slope_from_assignment(config, chip, die, assignment, normalized_q_slot) if assignment else {"ok": False}
        mode["thermal_tuning_ok"] = bool(tuning.get("ok"))
        mode["thermal_tuning_slope_ghz_per_v2"] = tuning.get("slope_ghz_per_v2")
        mode["thermal_tuning_slope_mhz_per_v2"] = tuning.get("slope_mhz_per_v2")
        mode["thermal_tuning_fit_r2"] = tuning.get("r2")

        plan_row = reconstruction["plan_by_family"].get(family)
        verification_row = reconstruction["verification_by_family"].get(family)
        if not isinstance(plan_row, dict):
            plan_row = {}
        if not isinstance(verification_row, dict):
            verification_row = {}
        selected_mode_number = finite_int(plan_row.get("mode_number"))
        is_reconstructed_mode = selected_mode_number is not None and selected_mode_number == finite_int(mode.get("mode_number"))
        if not is_reconstructed_mode:
            continue
        target_wavelength_nm = finite_float(verification_row.get("target_wavelength_nm"))
        if target_wavelength_nm is None:
            target_wavelength_nm = finite_float(plan_row.get("target_wavelength_nm"))
        offset_ghz = finite_float(verification_row.get("final_dip_offset_ghz"))
        reconstructed_wavelength_nm = None
        if target_wavelength_nm is not None:
            target_freq_ghz = wavelength_nm_to_freq_ghz(target_wavelength_nm)
            observed_freq_ghz = target_freq_ghz + (offset_ghz or 0.0)
            reconstructed_wavelength_nm = freq_ghz_to_wavelength_nm(observed_freq_ghz)
        baseline_freq_ghz = wavelength_nm_to_freq_ghz(float(mode["wavelength_nm"]))
        reconstructed_freq_ghz = (
            wavelength_nm_to_freq_ghz(reconstructed_wavelength_nm)
            if reconstructed_wavelength_nm is not None
            else None
        )
        mode.update(
            {
                "reconstruction_participates": True,
                "reconstruction_comb_index": plan_row.get("comb_index"),
                "reconstruction_target_wavelength_nm": target_wavelength_nm,
                "reconstructed_wavelength_nm": reconstructed_wavelength_nm,
                "reconstruction_frequency_shift_ghz": reconstructed_freq_ghz - baseline_freq_ghz
                if reconstructed_freq_ghz is not None
                else None,
                "reconstruction_final_voltage_v": finite_float(verification_row.get("final_voltage_v")),
                "reconstruction_final_offset_ghz": offset_ghz,
                "reconstruction_passed": bool(verification_row.get("passed")),
                "reconstruction_status": str(verification_row.get("status") or "").strip(),
                "reconstruction_sgm_out": str(verification_row.get("sgm_out") or "").strip(),
            }
        )

    modes = sorted(
        modes_by_key.values(),
        key=lambda item: (int(item.get("mode_number") or 0), natural_key(str(item.get("family") or ""))),
    )
    groups: list[dict[str, Any]] = []
    for mode_number in sorted({int(item["mode_number"]) for item in modes}):
        group = [item for item in modes if int(item["mode_number"]) == mode_number]
        wavelengths = [float(item["wavelength_nm"]) for item in group if item.get("wavelength_nm") is not None]
        readback_wavelengths = [
            float(item["wavelength_nm_readback"])
            for item in group
            if item.get("wavelength_nm_readback") is not None
        ]
        slope_wavelengths = [
            float(item["wavelength_nm_slope_corrected"])
            for item in group
            if item.get("wavelength_nm_slope_corrected") is not None
        ]
        groups.append(
            {
                "mode_number": mode_number,
                "count": len(group),
                "min_wavelength_nm": min(wavelengths) if wavelengths else None,
                "max_wavelength_nm": max(wavelengths) if wavelengths else None,
                "mean_wavelength_nm": sum(wavelengths) / len(wavelengths) if wavelengths else None,
                "readback_count": len(readback_wavelengths),
                "min_wavelength_nm_readback": min(readback_wavelengths) if readback_wavelengths else None,
                "max_wavelength_nm_readback": max(readback_wavelengths) if readback_wavelengths else None,
                "mean_wavelength_nm_readback": sum(readback_wavelengths) / len(readback_wavelengths)
                if readback_wavelengths
                else None,
                "slope_corrected_count": len(slope_wavelengths),
                "min_wavelength_nm_slope_corrected": min(slope_wavelengths) if slope_wavelengths else None,
                "max_wavelength_nm_slope_corrected": max(slope_wavelengths) if slope_wavelengths else None,
                "mean_wavelength_nm_slope_corrected": sum(slope_wavelengths) / len(slope_wavelengths)
                if slope_wavelengths
                else None,
            }
        )
    slope_basis_modes = [item for item in modes if item.get("wavelength_nm_slope_corrected") is not None]
    slope_ratio = next((item.get("mzi_readback_slope_ratio") for item in slope_basis_modes if item.get("mzi_readback_slope_ratio") is not None), None)
    slope_region = next((item.get("mzi_readback_slope_region") for item in slope_basis_modes if item.get("mzi_readback_slope_region")), "")
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "q_slot": normalized_q_slot,
        "directory": str(directory),
        "q_dir": str(q_dir),
        "q_table": str(q_table),
        "modes": modes,
        "mode_groups": groups,
        "wavelength_bases": {
            "mzi": {
                "ok": True,
                "label": "MZI 校准波长",
                "field": "wavelength_nm_mzi",
            },
            "readback": {
                "ok": bool(readback_curve.get("ok")),
                "label": "激光器读回波长",
                "field": "wavelength_nm_readback",
                "path": readback_curve.get("path"),
                "point_count": readback_curve.get("point_count", 0),
                "reason": readback_curve.get("reason"),
            },
            "slope_corrected": {
                "ok": bool(slope_basis_modes),
                "label": "读回斜率修正 MZI",
                "field": "wavelength_nm_slope_corrected",
                "mode_count": len(slope_basis_modes),
                "slope_ratio_readback_over_mzi": slope_ratio,
                "source_region": slope_region,
                "source": slope_correction.get("source"),
                "method": slope_correction.get("method"),
                "reason": None if slope_basis_modes else "没有可用 laser_readback_vs_mzi.csv 或斜率拟合失败；请用新版大扫分析重新生成。",
            },
        },
        "family_assignment": {
            "updated_at": assignment_record.get("updated_at"),
            "assignments": list(assignments_by_family.values()),
        },
        "reconstruction_state": {
            key: value
            for key, value in reconstruction.items()
            if key not in {"plan_by_family", "verification_by_family"}
        },
    }


def wavelength_nm_to_freq_ghz(wavelength_nm: float) -> float:
    return 299_792_458.0 / (float(wavelength_nm) * 1e-9) / 1e9


def freq_ghz_to_wavelength_nm(freq_ghz: float) -> float:
    return 299_792_458.0 / (float(freq_ghz) * 1e9) * 1e9


def positive_quadratic_voltage_for_shift(delta_freq_ghz: float, slope_ghz_per_v2: float) -> float | None:
    if not math.isfinite(delta_freq_ghz) or not math.isfinite(slope_ghz_per_v2) or abs(slope_ghz_per_v2) < 1e-12:
        return None
    ratio = delta_freq_ghz / slope_ghz_per_v2
    if not math.isfinite(ratio):
        return None
    if ratio < -1e-12:
        return None
    if ratio < 1e-18:
        return 0.0
    return math.sqrt(ratio)


def thermal_slope_on_current_axis(raw_slope: float, source_axis_sign: Any = None) -> tuple[float, float, bool]:
    parsed_sign = finite_float(source_axis_sign)
    if parsed_sign is None or abs(parsed_sign) < 1e-12:
        parsed_sign = 1.0
    corrected = float(raw_slope) * (THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN / parsed_sign)
    sign_corrected = abs(parsed_sign - THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN) > 1e-12
    return corrected, parsed_sign, sign_corrected


def nested_get(mapping: dict[str, Any], keys: list[str]) -> Any:
    value: Any = mapping
    for key in keys:
        if not isinstance(value, dict):
            return None
        value = value.get(key)
    return value


def tuning_slope_from_assignment(
    config: dict[str, Any],
    chip: str,
    die: str,
    assignment: dict[str, Any],
    q_slot: object = "Q",
) -> dict[str, Any]:
    family = str(assignment.get("family") or "").strip()
    directory = die_dir(config, chip, die)
    evidence_candidates: list[Path] = []
    raw_evidence = str(assignment.get("evidence") or "").strip()
    if raw_evidence:
        evidence_candidates.append(Path(raw_evidence))
    if family:
        evidence_candidates.append(
            thermal_current_fsr_assignment_dir(directory, q_slot) / family / "current_mode_probe_and_sweep.json"
        )

    direct_slope = finite_float(assignment.get("thermal_tuning_slope_ghz_per_v2"))
    direct_r2 = finite_float(assignment.get("thermal_tuning_fit_r2"))
    if direct_slope is not None:
        slope, source_axis_sign, sign_corrected = thermal_slope_on_current_axis(
            direct_slope,
            assignment.get("thermal_tuning_frequency_axis_sign"),
        )
        return {
            "ok": True,
            "slope_ghz_per_v2": slope,
            "slope_mhz_per_v2": slope * 1000.0,
            "r2": direct_r2,
            "source": "mode_family_assignment.json",
            "raw_slope_ghz_per_v2": direct_slope,
            "source_frequency_axis_sign": source_axis_sign,
            "frequency_axis_sign": THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN,
            "sign_corrected": sign_corrected,
        }

    for path in evidence_candidates:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        fit = nested_get(data, ["sweep", "analysis", "thermal_tuning_fit"])
        if not isinstance(fit, dict):
            fit = data.get("thermal_tuning_fit") if isinstance(data, dict) else None
        if not isinstance(fit, dict):
            continue
        slope = finite_float(fit.get("slope_ghz_per_v2"))
        if slope is None:
            slope_mhz = finite_float(fit.get("slope_mhz_per_v2"))
            slope = slope_mhz / 1000.0 if slope_mhz is not None else None
        if slope is None:
            continue
        slope, source_axis_sign, sign_corrected = thermal_slope_on_current_axis(
            slope,
            fit.get("frequency_axis_sign"),
        )
        return {
            "ok": True,
            "slope_ghz_per_v2": slope,
            "slope_mhz_per_v2": slope * 1000.0,
            "r2": finite_float(fit.get("r2")),
            "source": str(path),
            "raw_slope_ghz_per_v2": finite_float(fit.get("slope_ghz_per_v2")),
            "source_frequency_axis_sign": source_axis_sign,
            "frequency_axis_sign": THERMAL_FINE_SCAN_FREQUENCY_AXIS_SIGN,
            "sign_corrected": sign_corrected,
        }

    return {
        "ok": False,
        "family": family,
        "reason": "missing thermal tuning slope",
        "sources_checked": [str(path) for path in evidence_candidates],
    }


def plan_comb_reconstruction(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    array_design = load_array_design(config, chip)
    expected_cavity_count = finite_int(array_design.get("cavity_count"))
    if expected_cavity_count is None or expected_cavity_count <= 0:
        raise ValueError(f"{chip}/array_design.json 缺少有效 cavity_count")
    if expected_cavity_count > 16:
        raise ValueError(f"当前 DAC 只有 16 路输出，不能对齐 {expected_cavity_count} 腔阵列。")

    center_midpoint_nm = finite_float(payload.get("center_wavelength_nm"))
    center_half_range_nm = finite_float(payload.get("center_wavelength_half_range_nm"))
    comb_spacing_ghz = finite_float(payload.get("comb_spacing_ghz"))
    max_comb_segment_center_offset_teeth = finite_int(
        payload.get("comb_segment_max_center_offset_teeth")
    )
    if max_comb_segment_center_offset_teeth is None:
        max_comb_segment_center_offset_teeth = 5
    max_voltage_v = finite_float(config.get("sgm_max_voltage_v"))
    configured_redshift_margin_ghz = finite_float(
        config.get("comb_reconstruction_min_redshift_margin_ghz")
    )
    if configured_redshift_margin_ghz is None:
        configured_redshift_margin_ghz = 3.2
    configured_approach_guard_ghz = finite_float(
        config.get("comb_reconstruction_initial_approach_guard_ghz")
    )
    if configured_approach_guard_ghz is None:
        configured_approach_guard_ghz = 1.6
    mzi_d1_mhz = finite_float(config.get("mzi_d1_mhz")) or DEFAULT_THERMAL_MZI_D1_MHZ
    verification_tolerance_periods = finite_float(
        config.get("comb_reconstruction_verify_tolerance_mzi_periods")
    )
    if verification_tolerance_periods is None:
        verification_tolerance_periods = 3.0
    mzi_redshift_margin_ghz = abs(float(mzi_d1_mhz) * float(verification_tolerance_periods)) / 1000.0
    min_redshift_margin_ghz = max(float(configured_redshift_margin_ghz), mzi_redshift_margin_ghz)
    if center_midpoint_nm is None or center_midpoint_nm <= 0:
        raise ValueError("需要输入有效的光梳中心波长 nm")
    if center_half_range_nm is None:
        center_half_range_nm = 0.0
    if center_half_range_nm < 0:
        raise ValueError("中心波长可调范围必须大于或等于 0 nm")
    if center_midpoint_nm - center_half_range_nm <= 0:
        raise ValueError("中心波长可调范围包含非正波长")
    if comb_spacing_ghz is None or comb_spacing_ghz <= 0:
        raise ValueError("需要输入有效的梳齿间隔 GHz")
    if not 0 <= max_comb_segment_center_offset_teeth <= 5:
        raise ValueError("连续梳齿区段中心最多允许偏移 0..5 根")
    if max_voltage_v is None or max_voltage_v <= 0:
        raise ValueError("仪器配置 sgm_max_voltage_v 必须为正数")
    if configured_redshift_margin_ghz < 0:
        raise ValueError("仪器配置 comb_reconstruction_min_redshift_margin_ghz 不能为负数")
    if configured_approach_guard_ghz < 0:
        raise ValueError("仪器配置 comb_reconstruction_initial_approach_guard_ghz 不能为负数")
    initial_approach_guard_ghz = min(
        float(configured_approach_guard_ghz),
        float(min_redshift_margin_ghz),
    )

    basis = str(payload.get("wavelength_basis") or "mzi").strip() or "mzi"
    center_min_nm = center_midpoint_nm - center_half_range_nm
    center_max_nm = center_midpoint_nm + center_half_range_nm
    center_frequency_min_ghz = wavelength_nm_to_freq_ghz(center_max_nm)
    center_frequency_max_ghz = wavelength_nm_to_freq_ghz(center_min_nm)
    center_frequency_midpoint_ghz = wavelength_nm_to_freq_ghz(center_midpoint_nm)

    loaded = load_thermal_modes(config, chip, die)
    modes = loaded.get("modes") if isinstance(loaded.get("modes"), list) else []
    family_record = load_family_assignments(config, chip, die)
    raw_assignments = family_record.get("assignments") if isinstance(family_record.get("assignments"), list) else []

    assignment_by_family: dict[str, dict[str, Any]] = {}
    usable_by_family: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []
    for raw in raw_assignments:
        if not isinstance(raw, dict):
            continue
        family = str(raw.get("family") or "").strip()
        cavity = str(raw.get("cavity") or "").strip()
        if not family:
            continue
        assignment_by_family[family] = raw
        if not cavity:
            continue
        slope = tuning_slope_from_assignment(config, chip, die, raw)
        slope_value = finite_float(slope.get("slope_ghz_per_v2")) if slope.get("ok") else None
        if slope_value is None or abs(slope_value) < 1e-12:
            warnings.append(f"{family}/{cavity} 缺少有效热调谐斜率，不能参与对齐。")
            continue
        if slope_value >= 0:
            warnings.append(f"{family}/{cavity} 的热调谐斜率不是红移方向，不能用于当前正电压模型。")
            continue
        usable_by_family[family] = {
            "family": family,
            "cavity": cavity,
            "assignment": raw,
            "slope_ghz_per_v2": slope_value,
            "slope_mhz_per_v2": slope_value * 1000.0,
            "slope_r2": slope.get("r2"),
            "slope_source": slope.get("source"),
        }

    candidates_by_cavity: dict[str, list[dict[str, Any]]] = {}
    all_mode_families: set[str] = set()
    all_mode_numbers: set[int] = set()
    seen_mode_candidates: set[tuple[str, str, int, float]] = set()
    for mode in modes:
        if not isinstance(mode, dict):
            continue
        family = str(mode.get("family") or "").strip()
        mode_number = finite_int(mode.get("mode_number"))
        if family:
            all_mode_families.add(family)
        if mode_number is None or not family:
            continue
        all_mode_numbers.add(mode_number)
        usable = usable_by_family.get(family)
        if not usable:
            continue
        wavelength_nm = mode_wavelength_for_basis_py(mode, basis)
        if wavelength_nm is None:
            continue
        frequency_ghz = wavelength_nm_to_freq_ghz(wavelength_nm)
        cavity = str(usable.get("cavity") or "").strip()
        if not cavity:
            continue
        candidate_key = (cavity, family, mode_number, round(frequency_ghz, 9))
        if candidate_key in seen_mode_candidates:
            continue
        seen_mode_candidates.add(candidate_key)
        candidates_by_cavity.setdefault(cavity, []).append(
            {
                **mode,
                "family": family,
                "cavity": cavity,
                "mode_number": mode_number,
                "wavelength_nm_for_basis": wavelength_nm,
                "frequency_ghz_for_basis": frequency_ghz,
                "slope_ghz_per_v2": usable["slope_ghz_per_v2"],
                "slope_mhz_per_v2": usable["slope_mhz_per_v2"],
                "slope_r2": usable.get("slope_r2"),
                "slope_source": usable.get("slope_source"),
            }
        )

    cavity_names = sorted(candidates_by_cavity, key=natural_key)
    available_cavity_count = len(cavity_names)
    if not all_mode_numbers:
        raise ValueError("q_by_mode.csv 中没有可用于对齐预览的模式。")
    if not cavity_names:
        raise ValueError("没有同时具备物理腔归属、红移调谐斜率和有效波长的模式。")

    # Keep exactly one contiguous block with one tooth per physical cavity, but
    # let the whole block move by at most five teeth around the reference comb
    # center.  A 3x3 array therefore evaluates -9..-1 through +1..+9, while the
    # centered candidate remains -4..+4.
    centered_comb_segment_start_index = -(expected_cavity_count // 2)
    centered_comb_segment_center = (
        centered_comb_segment_start_index
        + centered_comb_segment_start_index
        + expected_cavity_count
        - 1
    ) / 2.0
    comb_segment_candidates = [
        list(range(start_index, start_index + expected_cavity_count))
        for start_index in range(
            centered_comb_segment_start_index - max_comb_segment_center_offset_teeth,
            centered_comb_segment_start_index + max_comb_segment_center_offset_teeth + 1,
        )
    ]
    all_candidate_comb_indices = sorted(
        {comb_index for segment in comb_segment_candidates for comb_index in segment}
    )

    max_voltage_squared = float(max_voltage_v) ** 2
    options_by_cavity_comb: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for cavity, cavity_candidates in candidates_by_cavity.items():
        for candidate in cavity_candidates:
            current_frequency = float(candidate["frequency_ghz_for_basis"])
            slope = float(candidate["slope_ghz_per_v2"])
            tuned_frequency = current_frequency + slope * max_voltage_squared
            tunable_low = min(current_frequency, tuned_frequency)
            tunable_high = current_frequency - min_redshift_margin_ghz
            if tunable_low > tunable_high + 1e-12:
                continue
            comb_index_min = math.ceil(
                (tunable_low - center_frequency_max_ghz) / float(comb_spacing_ghz) - 1e-10
            )
            comb_index_max = math.floor(
                (tunable_high - center_frequency_min_ghz) / float(comb_spacing_ghz) + 1e-10
            )
            reachable_start = max(comb_index_min, all_candidate_comb_indices[0])
            reachable_end = min(comb_index_max, all_candidate_comb_indices[-1])
            for comb_index in range(reachable_start, reachable_end + 1):
                options_by_cavity_comb.setdefault((cavity, comb_index), []).append(candidate)

    center_candidate_by_key: dict[float, float] = {}

    def add_center_frequency_candidate(value: float) -> None:
        if value < center_frequency_min_ghz - 1e-8 or value > center_frequency_max_ghz + 1e-8:
            return
        clipped = min(center_frequency_max_ghz, max(center_frequency_min_ghz, float(value)))
        center_candidate_by_key.setdefault(round(clipped, 9), clipped)

    add_center_frequency_candidate(center_frequency_min_ghz)
    add_center_frequency_candidate(center_frequency_midpoint_ghz)
    add_center_frequency_candidate(center_frequency_max_ghz)
    for (_cavity, comb_index), edge_candidates in options_by_cavity_comb.items():
        for candidate in edge_candidates:
            current_frequency = float(candidate["frequency_ghz_for_basis"])
            slope = float(candidate["slope_ghz_per_v2"])
            add_center_frequency_candidate(
                current_frequency - min_redshift_margin_ghz - comb_index * float(comb_spacing_ghz)
            )
            add_center_frequency_candidate(
                current_frequency + slope * max_voltage_squared - comb_index * float(comb_spacing_ghz)
            )
    center_frequency_candidates = sorted(center_candidate_by_key.values())

    def maximum_cardinality_matching(
        edge_rows: dict[str, dict[int, dict[str, Any]]],
        voltage_limit: float,
    ) -> dict[str, int]:
        slot_owner: dict[int, str] = {}

        def augment(cavity: str, seen_slots: set[int]) -> bool:
            ordered_edges = sorted(
                edge_rows.get(cavity, {}).items(),
                key=lambda item: (float(item[1].get("voltage_v") or math.inf), abs(item[0])),
            )
            for comb_index, row in ordered_edges:
                voltage = finite_float(row.get("voltage_v"))
                if voltage is None or voltage > voltage_limit + 1e-12 or comb_index in seen_slots:
                    continue
                seen_slots.add(comb_index)
                previous_cavity = slot_owner.get(comb_index)
                if previous_cavity is None or augment(previous_cavity, seen_slots):
                    slot_owner[comb_index] = cavity
                    return True
            return False

        ordered_cavities = sorted(
            cavity_names,
            key=lambda cavity: (len(edge_rows.get(cavity, {})), natural_key(cavity)),
        )
        for cavity in ordered_cavities:
            augment(cavity, set())
        return {cavity: comb_index for comb_index, cavity in slot_owner.items()}

    def evaluate_center_frequency(
        center_frequency_ghz: float,
        comb_segment_indices: list[int],
    ) -> dict[str, Any]:
        comb_segment_index_set = set(comb_segment_indices)
        edge_rows: dict[str, dict[int, dict[str, Any]]] = {cavity: {} for cavity in cavity_names}
        for (cavity, comb_index), edge_candidates in options_by_cavity_comb.items():
            if comb_index not in comb_segment_index_set:
                continue
            target_frequency = center_frequency_ghz + comb_index * float(comb_spacing_ghz)
            best_row: dict[str, Any] | None = None
            best_key: tuple[Any, ...] | None = None
            for candidate in edge_candidates:
                current_frequency = float(candidate["frequency_ghz_for_basis"])
                slope = float(candidate["slope_ghz_per_v2"])
                delta_frequency = target_frequency - current_frequency
                required_redshift_ghz = current_frequency - target_frequency
                if required_redshift_ghz < min_redshift_margin_ghz - 1e-10:
                    continue
                voltage = positive_quadratic_voltage_for_shift(delta_frequency, slope)
                if voltage is None or voltage > float(max_voltage_v) + 1e-12:
                    continue
                mode_number = int(candidate["mode_number"])
                candidate_key = (
                    voltage * voltage,
                    abs(delta_frequency),
                    abs(mode_number),
                    natural_key(str(candidate.get("family") or "")),
                )
                if best_key is not None and candidate_key >= best_key:
                    continue
                best_key = candidate_key
                best_row = {
                    "comb_index": comb_index,
                    "target_frequency_ghz": target_frequency,
                    "target_wavelength_nm": freq_ghz_to_wavelength_nm(target_frequency),
                    "family": candidate.get("family"),
                    "cavity": cavity,
                    "mode_number": mode_number,
                    "current_frequency_ghz": current_frequency,
                    "current_wavelength_nm": candidate.get("wavelength_nm_for_basis"),
                    "delta_freq_ghz": delta_frequency,
                    "required_redshift_ghz": required_redshift_ghz,
                    "min_redshift_margin_ghz": min_redshift_margin_ghz,
                    "redshift_headroom_above_min_ghz": required_redshift_ghz - min_redshift_margin_ghz,
                    "available": True,
                    "matched": True,
                    "reason": "",
                    "voltage_v": voltage,
                    "abs_voltage_v": voltage,
                    "voltage_squared_v2": voltage * voltage,
                    "slope_ghz_per_v2": slope,
                    "slope_mhz_per_v2": slope * 1000.0,
                    "slope_r2": candidate.get("slope_r2"),
                    "slope_source": candidate.get("slope_source"),
                    "depth": candidate.get("depth"),
                    "QL": candidate.get("QL"),
                }
            if best_row is not None:
                edge_rows[cavity][comb_index] = best_row

        voltage_values = sorted(
            {
                float(row["voltage_v"])
                for cavity_edges in edge_rows.values()
                for row in cavity_edges.values()
            }
        )
        selected_by_cavity: dict[str, int] = {}
        bottleneck_voltage = 0.0
        maximum_match_count = 0
        if voltage_values:
            full_matching = maximum_cardinality_matching(edge_rows, voltage_values[-1])
            maximum_match_count = len(full_matching)
            low = 0
            high = len(voltage_values) - 1
            while low < high:
                middle = (low + high) // 2
                if len(maximum_cardinality_matching(edge_rows, voltage_values[middle])) >= maximum_match_count:
                    high = middle
                else:
                    low = middle + 1
            bottleneck_voltage = voltage_values[low]
            threshold_matching = maximum_cardinality_matching(edge_rows, bottleneck_voltage)

            active_comb_indices = sorted(
                {
                    comb_index
                    for cavity_edges in edge_rows.values()
                    for comb_index, row in cavity_edges.items()
                    if float(row["voltage_v"]) <= bottleneck_voltage + 1e-12
                }
            )
            if active_comb_indices:
                blocked_cost = 1_000_000_000.0
                unmatched_cost = 1_000_000.0
                real_column_count = len(active_comb_indices)
                costs: list[list[float]] = []
                for cavity_index, cavity in enumerate(cavity_names):
                    cost_row = [blocked_cost] * (real_column_count + len(cavity_names))
                    for slot_index, comb_index in enumerate(active_comb_indices):
                        row = edge_rows.get(cavity, {}).get(comb_index)
                        if row is None or float(row["voltage_v"]) > bottleneck_voltage + 1e-12:
                            continue
                        cost_row[slot_index] = (
                            float(row["voltage_squared_v2"])
                            + abs(float(row["delta_freq_ghz"])) * 1e-9
                            + abs(int(row["mode_number"])) * 1e-12
                        )
                    cost_row[real_column_count + cavity_index] = unmatched_cost
                    costs.append(cost_row)
                for cavity_index, column_index, _cost in solve_min_cost_mode_matching(costs):
                    if column_index >= real_column_count:
                        continue
                    cavity = cavity_names[cavity_index]
                    comb_index = active_comb_indices[column_index]
                    row = edge_rows.get(cavity, {}).get(comb_index)
                    if row is not None and float(row["voltage_v"]) <= bottleneck_voltage + 1e-12:
                        selected_by_cavity[cavity] = comb_index
            if len(selected_by_cavity) < maximum_match_count:
                selected_by_cavity = threshold_matching

        selected_rows = [
            dict(edge_rows[cavity][comb_index])
            for cavity, comb_index in selected_by_cavity.items()
        ]
        selected_rows.sort(key=lambda row: (int(row["comb_index"]), natural_key(str(row.get("cavity") or ""))))
        for slot_index, row in enumerate(selected_rows, start=1):
            row["slot_index"] = slot_index
        matched_count = len(selected_rows)
        max_used_voltage = max((float(row["voltage_v"]) for row in selected_rows), default=0.0)
        sum_voltage_squared = sum(float(row["voltage_squared_v2"]) for row in selected_rows)
        sum_abs_delta = sum(abs(float(row["delta_freq_ghz"])) for row in selected_rows)
        center_wavelength = freq_ghz_to_wavelength_nm(center_frequency_ghz)
        comb_segment_center = (comb_segment_indices[0] + comb_segment_indices[-1]) / 2.0
        comb_segment_center_offset = comb_segment_center - centered_comb_segment_center
        score = (
            -matched_count,
            max_used_voltage,
            sum_voltage_squared,
            abs(comb_segment_center_offset),
            abs(center_wavelength - float(center_midpoint_nm)),
            sum_abs_delta,
        )
        return {
            "center_frequency_ghz": center_frequency_ghz,
            "center_wavelength_nm": center_wavelength,
            "selected_rows": selected_rows,
            "selected_by_cavity": selected_by_cavity,
            "edge_rows": edge_rows,
            "matched_count": matched_count,
            "max_abs_voltage_used_v": max_used_voltage if matched_count else None,
            "sum_voltage_squared_v2": sum_voltage_squared,
            "sum_abs_delta_ghz": sum_abs_delta,
            "comb_segment_indices": list(comb_segment_indices),
            "comb_segment_center_offset_teeth": comb_segment_center_offset,
            "score": score,
        }

    evaluated_plans = [
        evaluate_center_frequency(center_frequency, comb_segment_indices)
        for comb_segment_indices in comb_segment_candidates
        for center_frequency in center_frequency_candidates
    ]
    best_plan = min(evaluated_plans, key=lambda item: item["score"])
    centered_reference_plan = min(
        (
            item
            for item in evaluated_plans
            if abs(float(item["comb_segment_center_offset_teeth"])) < 1e-12
        ),
        key=lambda item: item["score"],
    )
    comb_segment_indices = list(best_plan["comb_segment_indices"])
    selected_rows = list(best_plan["selected_rows"])
    selected_cavities = set(best_plan["selected_by_cavity"])
    edge_rows_at_best = best_plan["edge_rows"]

    unmatched_rows: list[dict[str, Any]] = []
    for cavity in cavity_names:
        if cavity in selected_cavities:
            continue
        cavity_candidates = candidates_by_cavity[cavity]
        families = sorted({str(item.get("family") or "") for item in cavity_candidates if item.get("family")}, key=natural_key)
        candidate_mode_numbers = sorted({int(item["mode_number"]) for item in cavity_candidates})
        has_reachable_edge = bool(edge_rows_at_best.get(cavity))
        unmatched_rows.append(
            {
                "slot_index": None,
                "comb_index": None,
                "target_frequency_ghz": None,
                "target_wavelength_nm": None,
                "family": ", ".join(families),
                "cavity": cavity,
                "mode_number": None,
                "candidate_mode_numbers": candidate_mode_numbers,
                "current_frequency_ghz": None,
                "current_wavelength_nm": None,
                "delta_freq_ghz": None,
                "available": True,
                "matched": False,
                "reason": (
                    "存在可达梳齿，但与其他物理腔发生梳齿占用冲突"
                    if has_reachable_edge
                    else "在当前光梳中心、最小红移安全裕量和 DAC 电压上限内没有可达梳齿"
                ),
            }
        )

    inactive_rows: list[dict[str, Any]] = []
    for family in sorted(all_mode_families, key=natural_key):
        if family in usable_by_family:
            continue
        assignment = assignment_by_family.get(family, {})
        cavity = str(assignment.get("cavity") or "").strip()
        inactive_rows.append(
            {
                "slot_index": None,
                "comb_index": None,
                "target_frequency_ghz": None,
                "target_wavelength_nm": None,
                "family": family,
                "cavity": cavity,
                "mode_number": None,
                "current_frequency_ghz": None,
                "current_wavelength_nm": None,
                "delta_freq_ghz": None,
                "available": False,
                "matched": False,
                "reason": (
                    "已有模式家族归属，但缺少可靠的红移热调谐斜率"
                    if cavity
                    else "尚未识别模式家族对应的物理腔"
                ),
            }
        )

    plan_rows = selected_rows + unmatched_rows + inactive_rows
    selected_mode_numbers = sorted({int(row["mode_number"]) for row in selected_rows})
    selected_comb_indices = sorted({int(row["comb_index"]) for row in selected_rows})
    selected_comb_index_set = set(selected_comb_indices)
    unfilled_comb_indices = [
        comb_index for comb_index in comb_segment_indices if comb_index not in selected_comb_index_set
    ]
    matched_count = int(best_plan["matched_count"])
    max_abs_voltage_used = best_plan.get("max_abs_voltage_used_v")
    sum_voltage_squared = float(best_plan["sum_voltage_squared_v2"])
    selected_center_wavelength = float(best_plan["center_wavelength_nm"])
    selected_center_frequency = float(best_plan["center_frequency_ghz"])

    if available_cavity_count < expected_cavity_count:
        warnings.append(
            f"当前只有 {available_cavity_count} 个物理腔同时具备归属、有效波长和红移热调谐斜率；其余模式不参与对齐。"
        )
    if matched_count < available_cavity_count:
        warnings.append(f"{available_cavity_count} 个可调物理腔中只有 {matched_count} 个找到互不冲突的可达梳齿。")
    if center_half_range_nm > 0 and (
        abs(selected_center_wavelength - center_min_nm) < 1e-8
        or abs(selected_center_wavelength - center_max_nm) < 1e-8
    ):
        warnings.append("最优光梳中心落在允许区间边界；如需继续降低电压，可扩大中心波长可调范围后重新预览。")
    if abs(float(best_plan["comb_segment_center_offset_teeth"])) >= max_comb_segment_center_offset_teeth > 0:
        warnings.append("最优连续梳齿区段落在允许的 ±5 根偏移边界。")
    warnings.append(
        f"所有参与对齐的模式至少预留 {min_redshift_margin_ghz:.3f} GHz 红移裕量，"
        "理论 0 V 匹配不会进入方案。"
    )
    warnings.append(
        f"首次写入会比模型目标少调 {initial_approach_guard_ghz:.3f} GHz，"
        "先停在目标梳齿蓝侧，再由细扫校验单向增加电压接近。"
    )

    unmatched_cavities = [
        {
            "family": row.get("family") or "",
            "cavity": row.get("cavity") or "",
            "comb_index": row.get("comb_index"),
            "target_wavelength_nm": row.get("target_wavelength_nm"),
            "reason": row.get("reason") or "未匹配",
            "available": bool(row.get("available")),
        }
        for row in plan_rows
        if not row.get("matched")
    ]
    missing_targets = [
        {
            "comb_index": row.get("comb_index"),
            "target_wavelength_nm": row.get("target_wavelength_nm"),
            "target_frequency_ghz": row.get("target_frequency_ghz"),
            "family": row.get("family"),
            "cavity": row.get("cavity"),
            "reason": row.get("reason"),
        }
        for row in unmatched_rows
    ]

    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "array_shape": array_design.get("array_shape"),
        "expected_cavity_count": expected_cavity_count,
        "wavelength_basis": basis,
        "requested_mode_number": None,
        "selected_mode_number": selected_mode_numbers[0] if len(selected_mode_numbers) == 1 else None,
        "selected_mode_numbers": selected_mode_numbers,
        "mode_selection": "cross_mu_joint_optimization",
        "comb_selection": "bounded_shift_contiguous_segment",
        "center_wavelength_midpoint_nm": center_midpoint_nm,
        "center_wavelength_half_range_nm": center_half_range_nm,
        "center_wavelength_min_nm": center_min_nm,
        "center_wavelength_max_nm": center_max_nm,
        "center_wavelength_nm": selected_center_wavelength,
        "selected_center_wavelength_nm": selected_center_wavelength,
        "center_wavelength_adjustment_nm": selected_center_wavelength - float(center_midpoint_nm),
        "center_frequency_midpoint_ghz": center_frequency_midpoint_ghz,
        "center_frequency_ghz": selected_center_frequency,
        "comb_spacing_ghz": comb_spacing_ghz,
        "max_abs_voltage_v": max_voltage_v,
        "min_redshift_margin_ghz": min_redshift_margin_ghz,
        "configured_min_redshift_margin_ghz": configured_redshift_margin_ghz,
        "initial_approach_guard_ghz": initial_approach_guard_ghz,
        "configured_initial_approach_guard_ghz": configured_approach_guard_ghz,
        "mzi_redshift_margin_ghz": mzi_redshift_margin_ghz,
        "mzi_d1_mhz_for_margin": mzi_d1_mhz,
        "verification_tolerance_mzi_periods_for_margin": verification_tolerance_periods,
        "allow_negative_voltage": False,
        "voltage_model": (
            "delta_freq_ghz = slope_ghz_per_v2 * V^2, V >= 0; "
            "current_frequency_ghz - target_frequency_ghz >= min_redshift_margin_ghz"
        ),
        "optimization_priority": [
            f"仅保留至少具有 {min_redshift_margin_ghz:.3f} GHz 红移安全裕量且不超过 DAC 上限的匹配",
            f"在中心偏移不超过 ±{max_comb_segment_center_offset_teeth} 根的连续 {expected_cavity_count} 根梳齿内最大化可成功对齐的物理腔数",
            "最小化所有已选模式中的最大 DAC 电压",
            "最小化总 V^2 以降低总热负载",
            "在热负载相同或更优时优先选择更靠近参考中心的连续梳齿区段",
            "最小化光梳中心相对输入区间中点的偏移",
            "最小化模式总频移量",
        ],
        "target_count": expected_cavity_count,
        "plan_row_count": len(plan_rows),
        "mode_slot_count": len(selected_rows) + len(unmatched_rows),
        "mode_candidate_count": sum(len(items) for items in candidates_by_cavity.values()),
        "comb_index_candidate_count": len(all_candidate_comb_indices),
        "comb_segment_candidate_count": len(comb_segment_candidates),
        "available_cavity_count": available_cavity_count,
        "matched_count": matched_count,
        "all_targets_matched": matched_count == expected_cavity_count,
        "all_available_cavities_matched": matched_count == available_cavity_count,
        "max_abs_voltage_used_v": max_abs_voltage_used,
        "sum_voltage_squared_v2": sum_voltage_squared,
        "score": {
            "raw": list(best_plan["score"]),
            "matched_cavities": matched_count,
            "unmatched_available": available_cavity_count - matched_count,
            "max_abs_voltage_v": max_abs_voltage_used,
            "sum_voltage_squared_v2": sum_voltage_squared,
            "center_wavelength_adjustment_nm": selected_center_wavelength - float(center_midpoint_nm),
        },
        "centered_segment_reference": {
            "comb_segment_indices": centered_reference_plan["comb_segment_indices"],
            "matched_count": centered_reference_plan["matched_count"],
            "max_abs_voltage_used_v": centered_reference_plan["max_abs_voltage_used_v"],
            "sum_voltage_squared_v2": centered_reference_plan["sum_voltage_squared_v2"],
            "selected_center_wavelength_nm": centered_reference_plan["center_wavelength_nm"],
        },
        "improvement_vs_centered_segment": {
            "matched_count_delta": matched_count - int(centered_reference_plan["matched_count"]),
            "max_voltage_reduction_v": (
                float(centered_reference_plan["max_abs_voltage_used_v"])
                - float(max_abs_voltage_used)
                if centered_reference_plan.get("max_abs_voltage_used_v") is not None
                and max_abs_voltage_used is not None
                else None
            ),
            "sum_voltage_squared_reduction_v2": (
                float(centered_reference_plan["sum_voltage_squared_v2"])
                - sum_voltage_squared
            ),
        },
        "comb_segment_start_index": comb_segment_indices[0],
        "comb_segment_end_index": comb_segment_indices[-1],
        "comb_segment_indices": comb_segment_indices,
        "comb_segment_contiguous": all(
            right - left == 1 for left, right in zip(comb_segment_indices, comb_segment_indices[1:])
        ),
        "comb_segment_center_offset_teeth": best_plan["comb_segment_center_offset_teeth"],
        "comb_segment_max_center_offset_teeth": max_comb_segment_center_offset_teeth,
        "selected_comb_indices": selected_comb_indices,
        "unfilled_comb_indices": unfilled_comb_indices,
        "evaluated_mode_numbers": sorted(all_mode_numbers),
        "plan_rows": plan_rows,
        "unmatched_cavities": unmatched_cavities,
        "missing_targets": missing_targets,
        "warnings": warnings,
        "candidate_count": len(evaluated_plans),
        "family_assignments_path": str(family_assignment_path(die_dir(config, chip, die))),
        "q_table": str(q_dir_for_die(config, chip, die) / Q_BY_MODE_FILE),
    }


def solve_min_cost_mode_matching(costs: list[list[float]]) -> list[tuple[int, int, float]]:
    if not costs or not costs[0]:
        return []
    try:
        import numpy as np  # type: ignore
        from scipy.optimize import linear_sum_assignment  # type: ignore

        matrix = np.asarray(costs, dtype=float)
        row_indices, col_indices = linear_sum_assignment(matrix)
        return [(int(row), int(col), float(matrix[row, col])) for row, col in zip(row_indices, col_indices)]
    except Exception:
        remaining: list[tuple[float, int, int]] = []
        for row_idx, row in enumerate(costs):
            for col_idx, cost in enumerate(row):
                remaining.append((float(cost), row_idx, col_idx))
        used_rows: set[int] = set()
        used_cols: set[int] = set()
        matches: list[tuple[int, int, float]] = []
        for cost, row_idx, col_idx in sorted(remaining, key=lambda item: item[0]):
            if row_idx in used_rows or col_idx in used_cols:
                continue
            matches.append((row_idx, col_idx, cost))
            used_rows.add(row_idx)
            used_cols.add(col_idx)
            if len(used_rows) >= len(costs):
                break
        return matches


def thermal_tuning_dir(directory: Path) -> Path:
    path = directory / "thermal_tuning"
    path.mkdir(parents=True, exist_ok=True)
    return path


def thermal_current_fsr_assignment_dir(directory: Path, q_slot: object = "Q") -> Path:
    path = thermal_q_slot_dir(directory, q_slot) / "current_fsr_assignment"
    path.mkdir(parents=True, exist_ok=True)
    return path


def thermal_comb_reconstruction_check_dir(directory: Path) -> Path:
    path = thermal_tuning_dir(directory) / "comb_reconstruction_check"
    path.mkdir(parents=True, exist_ok=True)
    return path


def mode_wavelength_for_basis_py(mode: dict[str, Any], basis: str) -> float | None:
    if basis == "readback":
        return finite_float(mode.get("wavelength_nm_readback"))
    if basis == "slope_corrected":
        return finite_float(mode.get("wavelength_nm_slope_corrected"))
    return finite_float(mode.get("wavelength_nm_mzi")) or finite_float(mode.get("wavelength_nm"))
