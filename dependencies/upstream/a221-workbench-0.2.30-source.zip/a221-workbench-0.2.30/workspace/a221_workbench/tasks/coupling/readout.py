"""Coupling power readout and axis/value parsing shared by search strategies."""
from __future__ import annotations
import argparse
import json
import math
import re
import uuid
from urllib.parse import quote
from urllib.request import urlopen
from a221_workbench.instruments.redpitaya.bridge_client import BridgeClient

POWER_RE = re.compile(
    r"P\s+(?P<kind>avg(?:\(\d+f\))?|inst)\s*:\s*(?P<body>[^\n\r]+)",
    re.IGNORECASE,
)
CHANNEL_POWER_RE = re.compile(
    r"(?P<channel>CH[12])\s+"
    r"(?P<value>[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)\s*"
    r"(?P<unit>pW|nW|uW|mW|W)",
    re.IGNORECASE,
)
UNIT_TO_W = {"pw": 1e-12, "nw": 1e-9, "uw": 1e-6, "mw": 1e-3, "w": 1.0}


def parse_axis_token(text: str) -> tuple[str, str]:
    try:
        port, axis = text.split(":", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("axis token must look like COM13:z") from exc
    axis = axis.strip().lower()
    if axis not in {"x", "y", "z"}:
        raise argparse.ArgumentTypeError("axis must be x, y, or z")
    return port.strip().upper(), axis


def parse_offset(text: str) -> tuple[str, str, float]:
    try:
        lhs, value_text = text.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("offset must look like COM13:z=0.24") from exc
    port, axis = parse_axis_token(lhs)
    return port, axis, float(value_text)


def parse_power_from_overlay(text: str, channel: str, power_kind: str) -> float:
    matches = list(POWER_RE.finditer(text))
    if not matches:
        raise ValueError(f"No power line found in overlay: {text!r}")
    preferred = [m for m in matches if m.group("kind").lower().startswith(power_kind)]
    ordered = preferred or matches
    for match in ordered:
        for item in CHANNEL_POWER_RE.finditer(match.group("body")):
            if item.group("channel").upper() == channel.upper():
                return float(item.group("value")) * UNIT_TO_W[item.group("unit").lower()]
    raise ValueError(f"No {channel} power found in overlay: {text!r}")


def _scope_setting(client: BridgeClient, metadata: dict, attribute: str, metadata_key: str):
    """Use current GUI calibration when present, otherwise the headless startup value."""
    reply = client.get(f"scope.{attribute}", return_errors=True)
    if reply.get("ok"):
        return reply["value"]
    error = str(reply.get("error", ""))
    # Missing display-only properties are expected on headless bridges. Network,
    # register and all other errors must propagate, never become cached values.
    if ("AttributeError" in error and "has no attribute" in error and attribute in error
            and metadata_key in metadata):
        return metadata[metadata_key]
    raise RuntimeError(reply)


def _finite(value, label: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"Invalid {label}: {value!r}") from exc
    if not math.isfinite(result):
        raise RuntimeError(f"Non-finite {label}: {value!r}")
    return result


def read_power(bridge: str, *, timeout_s: float = 3.0,
               zero_offsets_v: dict[str, float] | None = None) -> dict:
    """Acquire fresh scope means and convert physical CH1/CH2 readings to watts.

    Uses the existing /scope/single endpoint without input, trigger or output
    writes. Calibration is (mean V - enabled zero offset V) / response (V/W).
    Channels routed to internal signals or another physical input are omitted
    from power_w and explained in unavailable_channels. No GUI frame cache or
    rolling average across optimization points is used. Explicit zero_offsets_v
    replaces each named channel's effective zero, including when GUI zero is off;
    it is never added to the existing offset and never written to the device.
    """
    if not 0 < timeout_s <= 300:
        raise ValueError("timeout_s must be in (0, 300]")
    overrides = {}
    for channel, value in (zero_offsets_v or {}).items():
        if channel not in {"CH1", "CH2"}:
            raise ValueError(f"Unknown power zero channel: {channel!r}")
        overrides[channel] = _finite(value, f"{channel} explicit zero offset V")
    client = BridgeClient(bridge, timeout_s=3.0)
    health = client.health(return_errors=False)
    if not health.get("ok"):
        raise RuntimeError(health)
    metadata = health.get("bridge") or {}
    request_id = uuid.uuid4().hex
    capture = client.request("/scope/single", {
        "tag": "coupling_power_" + request_id, "timeout": timeout_s,
        "plot": "false", "save": "false", "inline": "false",
    }, timeout_s=max(10.0, timeout_s + 5.0) + 2.0)
    if not capture.get("ok"):
        raise RuntimeError(capture)
    if not isinstance(capture.get("n"), int) or capture["n"] <= 0:
        raise RuntimeError(f"Empty or invalid scope capture: {capture}")
    zero = _scope_setting(client, metadata, "scope_zero_enabled", "scope_zero_enabled")
    if not isinstance(zero, bool):
        raise RuntimeError(f"Invalid scope_zero_enabled: {zero!r}")
    stats = (capture.get("analysis") or {}).get("stats") or {}
    inputs, powers, means, offsets, responses, unavailable = {}, {}, {}, {}, {}, {}
    zero_sources = {}
    for index in (1, 2):
        channel = f"CH{index}"
        source = capture.get(f"input{index}")
        inputs[channel] = source
        if source != f"in{index}":
            unavailable[channel] = f"scope.input{index}={source!r}; {channel} optical power requires in{index}"
            continue
        mean = _finite((stats.get(f"ch{index}") or {}).get("mean"), f"{channel} mean voltage")
        response = _finite(_scope_setting(client, metadata, f"ch{index}_power_response_v_per_w",
                                         f"scope_ch{index}_response_v_per_w"), f"{channel} response V/W")
        if response <= 0:
            raise RuntimeError(f"{channel} response V/W must be positive, got {response}")
        if channel in overrides:
            offset = overrides[channel]
            zero_sources[channel] = "explicit"
        else:
            offset = _finite(_scope_setting(client, metadata, f"ch{index}_zero_offset_v",
                                           f"scope_ch{index}_zero_offset_v"), f"{channel} zero offset V") if zero else 0.0
            zero_sources[channel] = "scope" if zero else "disabled"
        means[channel], offsets[channel], responses[channel] = mean, offset, response
        powers[channel] = _finite((mean - offset) / response, f"{channel} power W")
    if not powers:
        raise RuntimeError(f"No physical optical input selected: {unavailable}")
    return {"ok": True, "source": "scope.single", "request_id": request_id,
            "n": capture["n"], "duration_s": capture.get("duration"),
            "input": inputs, "power_w": powers, "raw_mean_v": means,
            "effective_offset_v": offsets, "response_v_per_w": responses,
            "zero_enabled": zero, "zero_offset_source": zero_sources,
            "unavailable_channels": unavailable}


def read_overlay(bridge: str) -> str:
    url = f"{bridge.rstrip('/')}/get?param={quote('scope.active_means_v')}"
    with urlopen(url, timeout=3) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not payload.get("ok"):
        raise RuntimeError(payload)
    return str(payload["value"])


def clamp(value: float, low: float, high: float) -> float:
    return min(high, max(low, value))
