"""Read-only discovery for two Thorlabs MDT693B controllers."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.coupling'


import argparse
from datetime import datetime
import json
from pathlib import Path

from a221_workbench.instruments.mdt693b import discover_ports


DEFAULT_EXPERIMENT_DIR = (
    Path(__file__).resolve().parents[2] / "experiments" / "auto_coupling_mdt693b"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--ports",
        nargs="+",
        default=["COM14", "COM13"],
        help="Serial ports to query. Default: COM14 COM13.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=DEFAULT_EXPERIMENT_DIR / "raw",
        help="Output directory for JSON discovery record.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    rows = discover_ports(args.ports)
    payload = {
        "timestamp": timestamp,
        "purpose": "read-only MDT693B discovery for computer-assisted coupling",
        "port_mapping_expected": {
            "COM14": "left translation stage",
            "COM13": "right translation stage",
        },
        "serial_settings": {
            "baudrate": 115200,
            "data_bits": 8,
            "parity": "none",
            "stop_bits": 1,
            "flow_control": "none",
            "terminator": "CRLF",
        },
        "rows": rows,
    }
    port_tag = "_".join(port.upper().replace(":", "") for port in args.ports)
    out_path = args.out_dir / f"mdt693b_discovery_{port_tag}_{timestamp}.json"
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    print(f"\nSaved: {out_path}")
    return 0 if all(row.get("ok") for row in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
