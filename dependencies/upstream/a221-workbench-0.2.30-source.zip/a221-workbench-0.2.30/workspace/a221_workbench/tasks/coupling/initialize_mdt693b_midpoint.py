"""Initialize MDT693B stages to a reproducible midpoint before manual coupling.

This script is dry-run by default.  Add --execute only after confirming both
fiber probes are safely away from the chip.  The goal is to make the manual
pre-coupling start state reproducible, not to optimize coupling.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.coupling'


import argparse
from datetime import datetime
import json
from pathlib import Path
import time

from a221_workbench.instruments.mdt693b import MDT693B


DEFAULT_EXPERIMENT_DIR = (
    Path(__file__).resolve().parents[2] / "experiments" / "auto_coupling_mdt693b"
)


def parse_offset(text: str) -> tuple[str, str, float]:
    """Parse COM13:x=0.24 style readback-offset entries."""
    try:
        lhs, value_text = text.split("=", 1)
        port, axis = lhs.split(":", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "readback offset must look like COM13:x=0.24"
        ) from exc
    axis = axis.strip().lower()
    if axis not in {"x", "y", "z"}:
        raise argparse.ArgumentTypeError("axis must be x, y, or z")
    try:
        value = float(value_text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("offset must be numeric") from exc
    return port.strip().upper(), axis, value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ports", nargs="+", default=["COM13", "COM14"])
    parser.add_argument("--axes", nargs="+", default=["x", "y", "z"], choices=["x", "y", "z"])
    parser.add_argument("--target-v", type=float, default=37.5)
    parser.add_argument("--min-v", type=float, default=0.0)
    parser.add_argument("--max-v", type=float, default=75.0)
    parser.add_argument(
        "--step-v",
        type=float,
        default=3.0,
        help="Open-loop voltage increment per write after one initial readback.",
    )
    parser.add_argument("--settle-s", type=float, default=0.05)
    parser.add_argument(
        "--readback-offset",
        action="append",
        type=parse_offset,
        default=[],
        help="Optional offset such as COM13:x=0.24; may be repeated.",
    )
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_EXPERIMENT_DIR / "raw")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Actually write voltages. Without this flag, only records the plan.",
    )
    return parser.parse_args()


def read_voltages(dev: MDT693B, axes: list[str]) -> dict[str, float]:
    return {axis: dev.read_axis_voltage(axis) for axis in axes}


def ramp_axis(
    dev: MDT693B,
    *,
    port: str,
    axis: str,
    target_v: float,
    step_v: float,
    min_v: float,
    max_v: float,
    settle_s: float,
    readback_offset_v: float,
    execute: bool,
    start_v: float | None = None,
) -> dict[str, object]:
    if step_v <= 0.0:
        raise ValueError(f"step_v must be positive, got {step_v:g}")

    before_v = dev.read_axis_voltage(axis) if start_v is None else float(start_v)
    delta_v = target_v - before_v
    n_steps = int(abs(delta_v) / step_v + 0.999999)
    planned: list[dict[str, object]] = []
    last_commanded_readback_v = before_v

    error: str | None = None
    direction = 1.0 if delta_v > 0.0 else -1.0
    for idx in range(1, n_steps + 1):
        desired_v = before_v + direction * min(abs(delta_v), idx * step_v)
        command_v = desired_v - readback_offset_v
        row: dict[str, object] = {
            "idx": idx,
            "desired_readback_v": desired_v,
            "command_target_v": command_v,
            "readback_offset_v": readback_offset_v,
        }
        if execute:
            try:
                dev.write_axis_voltage_blind(
                    axis,
                    command_v,
                    min_v=min_v,
                    max_v=max_v,
                )
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                row["ok"] = False
                row["error"] = error
                planned.append(row)
                break
            row["ok"] = True
            time.sleep(settle_s)
        else:
            row["ok"] = True
        last_commanded_readback_v = desired_v
        planned.append(row)

    return {
        "ok": error is None,
        "status": "complete" if error is None else "failed",
        "port": port,
        "axis": axis,
        "before_v": before_v,
        "target_v": target_v,
        "commanded_after_v": last_commanded_readback_v,
        "readback_after_v": None,
        "error": error,
        "execute": execute,
        "n_steps": len(planned),
        "steps": planned,
    }


def main() -> int:
    args = parse_args()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    record_path = args.out_dir / f"mdt693b_midpoint_init_{timestamp}.json"
    offsets = {(port, axis): value for port, axis, value in args.readback_offset}

    payload: dict[str, object] = {
        "ok": False,
        "status": "running",
        "timestamp": timestamp,
        "purpose": "initialize MDT693B axes to midpoint before manual coupling",
        "execute": bool(args.execute),
        "ports": args.ports,
        "axes": args.axes,
        "target_v": args.target_v,
        "step_v": args.step_v,
        "record_path": str(record_path),
        "safety_note": "Execute only when fiber probes are safely away from the chip.",
        "readback_offsets_v": {
            f"{port}:{axis}": value for (port, axis), value in offsets.items()
        },
        "controllers": [],
    }

    failure: dict[str, str] | None = None
    for port in args.ports:
        port_key = port.upper()
        controller: dict[str, object] = {
            "port": port_key,
            "status": "connecting",
            "before_v": None,
            "readback_after_v": None,
            "axis_results": [],
        }
        payload["controllers"].append(controller)
        active_axis: str | None = None
        try:
            with MDT693B(port) as dev:
                controller["status"] = "running"
                controller["before_v"] = read_voltages(dev, args.axes)
                axis_results = controller["axis_results"]
                for axis in args.axes:
                    active_axis = axis
                    axis_result = ramp_axis(
                        dev,
                        port=port_key,
                        axis=axis,
                        target_v=args.target_v,
                        step_v=args.step_v,
                        min_v=args.min_v,
                        max_v=args.max_v,
                        settle_s=args.settle_s,
                        readback_offset_v=offsets.get((port_key, axis), 0.0),
                        execute=args.execute,
                        start_v=controller["before_v"][axis],
                    )
                    axis_results.append(axis_result)
                    if not axis_result["ok"]:
                        failure = {
                            "port": port_key,
                            "axis": axis,
                            "error": str(axis_result.get("error") or "axis initialization failed"),
                        }
                        break

                controller["commanded_after_v"] = {
                    str(axis_result["axis"]): axis_result["commanded_after_v"]
                    for axis_result in axis_results
                }
                controller["status"] = "failed" if failure else "complete"
        except Exception as exc:
            controller["status"] = "failed"
            controller["error"] = f"{type(exc).__name__}: {exc}"
            failure = {
                "port": port_key,
                "axis": active_axis or "unknown",
                "error": str(controller["error"]),
            }

        if failure is not None:
            break

    if failure is None:
        payload["ok"] = True
        payload["status"] = "complete"
        payload["error"] = None
    else:
        payload["status"] = "failed"
        payload["failed_port"] = failure["port"]
        payload["failed_axis"] = failure["axis"]
        payload["error"] = failure["error"]

    record_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Saved: {record_path}\n")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
