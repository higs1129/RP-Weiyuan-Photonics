"""Build a die-level HTML card from existing array-cavity results."""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks'

#!/usr/bin/env python3


import argparse
import csv
import html
import json
import math
import os
import re
import statistics
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote


CSS = r"""
:root{--ink:#172126;--muted:#607077;--line:#ccd6da;--soft:#f4f7f7;--teal:#0d766e;--amber:#9a6500;--red:#b33a3a;--violet:#66508f}
*{box-sizing:border-box}body{margin:0;color:var(--ink);background:#fff;font-family:Arial,"Microsoft YaHei",sans-serif;font-size:14px;line-height:1.45}
a{color:#075c74;text-underline-offset:3px}.inner{width:min(1480px,calc(100% - 40px));margin:0 auto}.masthead{border-bottom:1px solid var(--line);background:#f8faf9}
.masthead .inner{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:24px;align-items:end;padding:28px 0 22px}.eyebrow{color:var(--muted);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0}
h1{margin:5px 0 0;font-size:30px;line-height:1.15;letter-spacing:0}.identity{color:var(--muted);text-align:right}.metrics-band,section{border-bottom:1px solid var(--line)}
.metrics{display:grid;grid-template-columns:repeat(6,minmax(0,1fr))}.metric{min-height:112px;padding:20px 16px;border-left:1px solid var(--line);display:flex;flex-direction:column;justify-content:center}.metric:last-child{border-right:1px solid var(--line)}
.metric-label,.metric-note{display:block;color:var(--muted);font-size:12px}.metric strong{margin:3px 0;font-size:20px;line-height:1.2}section .inner{padding:28px 0}.section-head{display:flex;justify-content:space-between;align-items:baseline;gap:20px;margin-bottom:18px}
h2{margin:0;font-size:19px;letter-spacing:0}h3{margin:2px 0 0;font-size:18px;letter-spacing:0}.section-note{color:var(--muted);font-size:12px}.findings{list-style:none;margin:0;padding:0;border-top:1px solid var(--line)}
.finding{display:grid;grid-template-columns:78px minmax(0,1fr);gap:14px;align-items:start;padding:12px 0;border-bottom:1px solid var(--line)}.badge{display:inline-flex;width:max-content;min-height:22px;align-items:center;padding:1px 7px;border:1px solid #aebbc0;border-radius:3px;color:#435158;background:#fff;font-size:12px;font-weight:700}
.badge.good,.finding.fact .badge{border-color:#6aa69e;color:#075e57;background:#edf8f5}.badge.review,.finding.review .badge{border-color:#d6b05f;color:#7d5000;background:#fff8e7}.badge.bad{border-color:#d89090;color:#9e2929;background:#fff0f0}
.die-overview{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(340px,.85fr);gap:28px;align-items:stretch}.overview-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));border-top:1px solid var(--line)}.overview-facts div{padding:13px 8px 13px 0;border-bottom:1px solid var(--line)}
.overview-facts dt,.compact-kv dt,.cavity-tile dt{color:var(--muted);font-size:12px}.overview-facts dd,.compact-kv dd{margin:3px 0 0;font-weight:700}.overview-image{display:block;min-height:270px;border:1px solid var(--line);background:var(--soft)}.overview-image img{display:block;width:100%;height:100%;min-height:270px;max-height:360px;object-fit:cover}
.subsection-head{display:flex;justify-content:space-between;align-items:baseline;gap:16px;margin:24px 0 12px}.subsection-head h3{font-size:16px}.waveguide-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.waveguide-panel{overflow:hidden;border:1px solid var(--line);border-radius:6px;background:#fff}.waveguide-photo{display:block;width:100%;aspect-ratio:16/7;overflow:hidden;border-bottom:1px solid var(--line);background:var(--soft)}.waveguide-photo img{display:block;width:100%;height:100%;object-fit:cover}.waveguide-photo-placeholder{display:grid;place-items:center;color:var(--muted);font-size:12px}.waveguide-info{padding:13px}.waveguide-info header{display:flex;justify-content:space-between;align-items:center;gap:10px}.waveguide-info p{margin:10px 0 0;color:#445158;overflow-wrap:anywhere}
.polarization-grid,.plot-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}.polarization-panel{border:1px solid var(--line);border-radius:6px;padding:18px}.polarization-panel header{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding-bottom:12px;border-bottom:1px solid var(--line)}
.compact-kv{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));margin:0}.compact-kv div{padding:10px 6px 10px 0;border-bottom:1px solid #e3e9eb}.compact-kv .decision-reason{grid-column:1/-1}.compact-kv .decision-reason dd{font-weight:400;overflow-wrap:anywhere}.polarization-panel footer,.evidence-links{display:flex;flex-wrap:wrap;gap:14px;padding-top:13px;font-size:12px}.plot-grid{margin-top:20px}figure{margin:0;border-top:1px solid var(--line);padding-top:12px}figcaption{margin-bottom:8px;font-weight:700}figure img{display:block;width:100%;aspect-ratio:16/9;object-fit:contain;border:1px solid var(--line);background:#fff}.large-scan-plot-grid figure img{aspect-ratio:2/1}.plot-placeholder{display:grid;place-items:center;width:100%;aspect-ratio:2/1;border:1px solid var(--line);background:var(--soft);color:var(--muted);font-size:12px}.q-plot-grid figure img{aspect-ratio:4/3}.interactive-plot{width:100%;height:430px;border:1px solid var(--line);background:#fff}.alignment-plot-grid .interactive-plot{height:520px}.interactive-fallback[hidden],.interactive-plot[hidden]{display:none}.interactive-fallback a{display:block}.alignment-plot-grid{grid-template-columns:1fr;align-items:start}
.array-scroll{overflow-x:auto;padding-bottom:6px}.array-map{min-width:760px;display:grid;grid-template-columns:repeat(var(--array-columns,4),minmax(170px,1fr));gap:10px}.cavity-tile{min-height:350px;overflow:hidden;border:1px solid var(--line);border-radius:6px;background:#fff;display:flex;flex-direction:column}.cavity-photo{display:block;width:100%;aspect-ratio:4/3;overflow:hidden;border-bottom:1px solid var(--line);background:var(--soft)}.cavity-photo img{display:block;width:100%;height:100%;object-fit:cover;object-position:center 48%}.cavity-photo-placeholder{display:grid;place-items:center;color:var(--muted);font-size:12px}.cavity-info{padding:12px;flex:1}.cavity-tile header{display:flex;justify-content:space-between;gap:8px;font-size:16px}.cavity-tile header span{color:var(--violet);font-weight:700}.tile-badges{display:flex;flex-wrap:wrap;gap:5px;margin:9px 0}.cavity-tile dl{margin:0}.cavity-tile dl div{display:flex;justify-content:space-between;gap:8px;padding:3px 0}.cavity-tile dd{margin:0;text-align:right}.cavity-tile p{margin:8px 0 0;padding-top:8px;border-top:1px solid #e4eaec;color:#445158;font-size:12px}
.table-wrap{overflow-x:auto;border:1px solid var(--line)}table{width:100%;min-width:900px;border-collapse:collapse}th,td{padding:9px 10px;border-bottom:1px solid #dfe6e8;text-align:left;white-space:nowrap}th{background:var(--soft);color:#3c4a50;font-size:12px}.alignment-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:16px;border:1px solid var(--line)}.alignment-summary div{padding:12px;border-right:1px solid var(--line)}.alignment-summary div:last-child{border-right:0}.alignment-summary span{display:block;color:var(--muted);font-size:12px}.alignment-summary strong{display:block;margin-top:3px}.evidence-band{background:#f8faf9}.disabled-link{color:#8b969a}
@media(max-width:1050px){.metrics{grid-template-columns:repeat(3,1fr)}.metric:nth-child(3){border-right:1px solid var(--line)}.die-overview{grid-template-columns:1fr}}
@media(max-width:760px){.inner{width:min(calc(100% - 24px),1480px)}.masthead .inner{grid-template-columns:1fr}.identity{text-align:left}h1{font-size:24px}.metrics{grid-template-columns:repeat(2,1fr)}.metric:nth-child(3){border-right:0}.metric:nth-child(even){border-right:1px solid var(--line)}.polarization-grid,.plot-grid,.waveguide-grid{grid-template-columns:1fr}.alignment-summary{grid-template-columns:repeat(2,1fr)}.alignment-summary div:nth-child(2){border-right:0}.finding{grid-template-columns:72px minmax(0,1fr)}}
"""


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--chip", required=True)
    parser.add_argument("--die", required=True)
    parser.add_argument("--output", type=Path)
    return parser.parse_args(argv)


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def num(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def integer(value: Any) -> int | None:
    value_float = num(value)
    return int(value_float) if value_float is not None else None


def truthy(value: Any) -> bool:
    return value is True or str(value).strip().lower() in {"1", "true", "yes", "ok", "passed"}


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def fmt(value: Any, digits: int = 2, suffix: str = "") -> str:
    value_float = num(value)
    return "--" if value_float is None else f"{value_float:,.{digits}f}{suffix}"


def fmt_q(value: Any) -> str:
    value_float = num(value)
    if value_float is None:
        return "--"
    return f"{value_float / 1_000_000:.2f} M" if abs(value_float) >= 1_000_000 else f"{value_float / 1_000:.1f} k"


def median(rows: list[dict[str, str]], key: str) -> float | None:
    values = [value for row in rows if (value := num(row.get(key))) is not None]
    return statistics.median(values) if values else None


def natural_key(value: str) -> tuple[Any, ...]:
    return tuple(int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", value))


def write_q_distribution_plot(
    rows: list[dict[str, str]],
    path: Path,
    *,
    polarization: str,
    slot: str,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    families = sorted({str(row.get("family") or "") for row in rows if row.get("family")}, key=natural_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with plt.rc_context(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Microsoft YaHei"],
            "font.size": 16,
            "axes.titlesize": 20,
            "axes.labelsize": 18,
            "xtick.labelsize": 15,
            "ytick.labelsize": 15,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "legend.fontsize": 13,
            "lines.linewidth": 1.8,
            "figure.dpi": 150,
            "savefig.dpi": 240,
            "savefig.bbox": "tight",
        }
    ):
        figure, axes = plt.subplots(3, 1, figsize=(13, 12), sharex=True)
        figure.subplots_adjust(left=0.11, right=0.82, top=0.92, bottom=0.08, hspace=0.26)
        color_map = plt.get_cmap("tab20")
        for family_index, family in enumerate(families):
            family_rows = sorted(
                (row for row in rows if row.get("family") == family),
                key=lambda row: num(row.get("wavelength_nm")) or math.inf,
            )
            wavelength = [num(row.get("wavelength_nm")) for row in family_rows]
            q0 = [num(row.get("Q0")) for row in family_rows]
            q1 = [num(row.get("Q1")) for row in family_rows]
            transmission = [num(row.get("transmission")) for row in family_rows]
            valid = [
                (x, y0, y1, trans)
                for x, y0, y1, trans in zip(wavelength, q0, q1, transmission, strict=False)
                if x is not None and y0 is not None and y0 > 0 and y1 is not None and y1 > 0 and trans is not None
            ]
            if not valid:
                continue
            x_values = [item[0] for item in valid]
            color = color_map(family_index % 20)
            axes[0].plot(
                x_values,
                [item[1] / 1e6 for item in valid],
                "o-",
                color=color,
                markersize=4.5,
                label=family,
            )
            axes[1].plot(
                x_values,
                [item[2] / 1e6 for item in valid],
                "s--",
                color=color,
                markersize=4.2,
                alpha=0.82,
            )
            axes[2].plot(
                x_values,
                [item[3] for item in valid],
                "o-",
                color=color,
                markersize=4.5,
            )
        figure.suptitle(f"{polarization} · {slot} mode Q distribution vs wavelength", fontsize=23)
        axes[0].set_title("Intrinsic Q0")
        axes[1].set_title("Coupling Q1")
        axes[2].set_title("Minimum normalized transmission")
        axes[0].set_ylabel("Q0 (million, log)")
        axes[1].set_ylabel("Q1 (million, log)")
        axes[2].set_ylabel("Tmin / platform")
        axes[2].set_xlabel("Wavelength (nm)")
        axes[0].set_yscale("log")
        axes[1].set_yscale("log")
        axes[2].set_ylim(-0.03, 1.03)
        for axis in axes:
            axis.tick_params(axis="both", which="both", direction="out")
            axis.grid(True, which="major", alpha=0.25)
        handles, labels = axes[0].get_legend_handles_labels()
        if handles:
            figure.legend(
                handles,
                labels,
                title="Mode family",
                loc="center left",
                bbox_to_anchor=(0.84, 0.53),
                frameon=True,
            )
        figure.savefig(path)
        plt.close(figure)


def relative_url(path: Path, output_dir: Path) -> str:
    relative = os.path.relpath(path.resolve(), output_dir.resolve()).replace("\\", "/")
    return quote(relative, safe="/.")


def url_for(path: Path, output_dir: Path) -> str | None:
    return relative_url(path, output_dir) if path.exists() else None


def json_for_html(value: Any) -> str:
    return (
        json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        .replace("</", "<\\/")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def minmax_downsample_xy(
    x_values: Any,
    y_values: Any,
    *,
    max_points: int = 10_000,
) -> tuple[list[float], list[float]]:
    """Reduce a dense trace while retaining narrow local extrema."""
    import numpy as np

    x_array = np.asarray(x_values, dtype=float)
    y_array = np.asarray(y_values, dtype=float)
    finite = np.isfinite(x_array) & np.isfinite(y_array)
    x_array = x_array[finite]
    y_array = y_array[finite]
    if not len(x_array):
        return [], []
    if len(x_array) <= max_points:
        indices = np.arange(len(x_array), dtype=int)
    else:
        bucket_count = max(1, max_points // 2)
        edges = np.linspace(0, len(x_array), bucket_count + 1, dtype=int)
        selected: list[int] = [0]
        for start, stop in zip(edges[:-1], edges[1:], strict=False):
            if stop <= start:
                continue
            local = y_array[start:stop]
            local_min = start + int(np.argmin(local))
            local_max = start + int(np.argmax(local))
            selected.extend(sorted({local_min, local_max}))
        selected.append(len(x_array) - 1)
        indices = np.asarray(sorted(set(selected)), dtype=int)
    return (
        [round(float(value), 6) for value in x_array[indices]],
        [round(float(value), 6) for value in y_array[indices]],
    )


def calibrated_large_scan_trace(
    q_dir: Path,
    *,
    max_points: int = 10_000,
    x_range: tuple[float, float] | None = None,
) -> tuple[list[float], list[float]]:
    """Use the same MZI calibration and baseline normalization as preanalysis."""
    import numpy as np


    from a221_workbench.tasks.analysis.large_scan.analyze_array_large_scan import sample_mzi_mu  # type: ignore
    from a221_workbench.tasks.analysis.large_scan.process_large_scan import (  # type: ignore
        find_mzi_index,
        normalize_transmission_with_baseline,
        read_large_scan_data,
        relative_frequency_mhz,
    )

    summary = read_json(q_dir / "array_preanalysis_summary.json")
    mzi = summary.get("mzi") if isinstance(summary.get("mzi"), dict) else {}
    raw_path = q_dir / "raw.npz"
    if not raw_path.exists():
        candidates = sorted(
            q_dir.glob("large_scan_*.npz"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            raise FileNotFoundError(raw_path)
        raw_path = candidates[0]
    acquisition_path = q_dir / "acquisition.json"
    if not acquisition_path.exists():
        acquisition_path = raw_path.with_suffix(".json")
    acquisition = read_json(acquisition_path)
    config = acquisition.get("config") if isinstance(acquisition.get("config"), dict) else {}
    _time_s, _trigger, trans_raw, mzi_raw = read_large_scan_data(raw_path)
    mzi_index = find_mzi_index(mzi_raw, 0.0)
    valid_idx, valid_mu = sample_mzi_mu(len(trans_raw), mzi_index)
    rel_freq_mhz, _mu_center = relative_frequency_mhz(
        valid_mu,
        start_nm=float(config.get("start_nm") or 1530.0),
        center_nm=float(config.get("center_nm") or 1550.0),
        stop_nm=float(config.get("stop_nm") or 1570.0),
        d1=float(mzi.get("d1_mhz") or 40.46318),
        d2=float(mzi.get("d2_mhz") or 4e-8),
        d3=float(mzi.get("d3_mhz") or -3e-14),
        offset_mhz=0.0,
    )
    trans_norm_full, _baseline = normalize_transmission_with_baseline(trans_raw)
    if not len(valid_idx):
        raise RuntimeError(f"MZI 校准后没有有效采样点: {raw_path}")
    frequency_ghz = np.asarray(rel_freq_mhz, dtype=float) / 1000.0
    transmission = np.asarray(trans_norm_full[valid_idx], dtype=float)
    if x_range is not None:
        window = (frequency_ghz >= x_range[0]) & (frequency_ghz <= x_range[1])
        frequency_ghz = frequency_ghz[window]
        transmission = transmission[window]
    return minmax_downsample_xy(
        frequency_ghz,
        transmission,
        max_points=max_points,
    )


def base_plot_layout(
    *,
    x_title: str,
    y_title: str,
    height: int = 430,
) -> dict[str, Any]:
    axis = {
        "showline": True,
        "linecolor": "#69777d",
        "linewidth": 1,
        "ticks": "outside",
        "tickcolor": "#69777d",
        "gridcolor": "#e7ecee",
        "zeroline": False,
        "automargin": True,
    }
    return {
        "height": height,
        "margin": {"l": 72, "r": 28, "t": 22, "b": 62},
        "paper_bgcolor": "#ffffff",
        "plot_bgcolor": "#ffffff",
        "font": {"family": 'Arial, "Microsoft YaHei", sans-serif', "size": 13, "color": "#172126"},
        "hovermode": "closest",
        "legend": {"orientation": "h", "yanchor": "bottom", "y": 1.02, "x": 0},
        "xaxis": {**axis, "title": {"text": x_title}},
        "yaxis": {**axis, "title": {"text": y_title}},
    }


def large_scan_plot_payload(slot_dir: Path) -> dict[str, Any] | None:
    if not (slot_dir / "array_preanalysis_summary.json").exists():
        return None
    try:
        x_values, y_values = calibrated_large_scan_trace(slot_dir)
    except Exception:
        return None
    if not x_values:
        return None
    data: list[dict[str, Any]] = [
        {
            "type": "scattergl",
            "mode": "lines",
            "name": "归一化透过率",
            "x": x_values,
            "y": y_values,
            "line": {"color": "#2468a2", "width": 1.8},
            "hovertemplate": "相对频率 %{x:.3f} GHz<br>透过率 %{y:.4f}<extra>归一化透过率</extra>",
        }
    ]
    mode_rows = read_csv(slot_dir / "array_preanalysis_modes.csv")
    for assigned, label, color, symbol in (
        (True, "已归属模式", "#0d766e", "circle"),
        (False, "未归属 dip", "#8a969b", "x"),
    ):
        rows = [
            row
            for row in mode_rows
            if (str(row.get("family_label") or "").strip().lower() not in {"", "unmatched"}) == assigned
            and num(row.get("relative_freq_ghz")) is not None
            and num(row.get("norm_transmission")) is not None
        ]
        if not rows:
            continue
        data.append(
            {
                "type": "scattergl",
                "mode": "markers",
                "name": label,
                "x": [num(row.get("relative_freq_ghz")) for row in rows],
                "y": [num(row.get("norm_transmission")) for row in rows],
                "customdata": [
                    [
                        row.get("family_label") or "未归属",
                        integer(row.get("mode_number")),
                        num(row.get("wavelength_nm")),
                        num(row.get("depth_1_minus_norm")),
                    ]
                    for row in rows
                ],
                "marker": {"color": color, "size": 7, "symbol": symbol, "line": {"color": "#ffffff", "width": 0.7}},
                "hovertemplate": (
                    "相对频率 %{x:.3f} GHz<br>透过率 %{y:.4f}<br>家族 %{customdata[0]}"
                    "<br>mu %{customdata[1]}<br>波长 %{customdata[2]:.6f} nm"
                    "<br>深度 %{customdata[3]:.4f}<extra>" + label + "</extra>"
                ),
            }
        )
    return {"data": data, "layout": base_plot_layout(x_title="MZI 校准相对频率 (GHz)", y_title="归一化透过率")}


def plot_figure_html(
    title: str,
    plot_id: str,
    payload: dict[str, Any] | None,
    static_url: str | None,
    *,
    missing_text: str,
) -> str:
    fallback = (
        f'<a href="{esc(static_url)}"><img loading="lazy" src="{esc(static_url)}" alt="{esc(title)}"></a>'
        if static_url
        else f'<div class="plot-placeholder">{esc(missing_text)}</div>'
    )
    if not payload:
        return f"<figure><figcaption>{esc(title)}</figcaption>{fallback}</figure>"
    return (
        f'<figure class="interactive-figure"><figcaption>{esc(title)}</figcaption>'
        f'<div id="{esc(plot_id)}" class="interactive-plot" hidden></div>'
        f'<div class="interactive-fallback" data-fallback-for="{esc(plot_id)}">{fallback}</div>'
        f'<script type="application/json" class="plot-spec" data-plot-for="{esc(plot_id)}">'
        f'{json_for_html(payload)}</script></figure>'
    )


def badge(text: str, tone: str = "neutral") -> str:
    return f'<span class="badge {esc(tone)}">{esc(text)}</span>'


def link(url: str | None, label: str) -> str:
    return f'<a href="{esc(url)}">{esc(label)}</a>' if url else f'<span class="disabled-link">{esc(label)}缺失</span>'


def metric(label: str, value: str, note: str = "") -> str:
    note_html = f'<span class="metric-note">{esc(note)}</span>' if note else ""
    return f'<div class="metric"><span class="metric-label">{esc(label)}</span><strong>{esc(value)}</strong>{note_html}</div>'


def workflow_decision(value: Any, kind: str) -> tuple[str, str]:
    normalized = str(value or "undecided").strip().lower()
    if kind == "q":
        return {
            "continue": ("继续大扫测 Q", "good"),
            "stop": ("不再大扫测 Q", "neutral"),
        }.get(normalized, ("待决定", "review"))
    return {
        "proceed": ("进入热调谐", "good"),
        "skip": ("不做热调谐", "neutral"),
    }.get(normalized, ("待决定", "review"))


def result_failure(record: dict[str, Any], *, exists: bool, label: str) -> str | None:
    if not exists:
        return None
    if not record:
        return f"{label}结果为空或无法读取"
    state = str(record.get("state") or record.get("status") or "").strip().lower()
    failed = record.get("ok") is False or state in {
        "failed",
        "error",
        "cancelled",
        "canceled",
        "aborted",
        "stopped",
    }
    explicit_error = str(record.get("error") or "").strip()
    if failed or explicit_error:
        detail = str(
            explicit_error
            or record.get("message")
            or record.get("reason")
            or ""
        ).strip()
        return f"{label}失败" + (f"：{detail}" if detail else "")
    return None


def q_slot_data_signature(slot_dir: Path) -> dict[str, Any]:
    files: dict[str, dict[str, int]] = {}
    for name in ("raw.npz", "array_preanalysis_summary.json", "q_by_mode.csv"):
        path = slot_dir / name
        if not path.exists() or not path.is_file():
            continue
        stat = path.stat()
        files[name] = {"size": int(stat.st_size), "mtime_ns": int(stat.st_mtime_ns)}
    return {"files": files}


def q_summary(
    die_dir: Path,
    slot: str,
    polarization: str | None,
    output_dir: Path,
    *,
    asset_output_dir: Path | None = None,
    asset_url_dir: Path | None = None,
) -> dict[str, Any]:
    slot_dir = die_dir / slot
    pre_path = slot_dir / "array_preanalysis_summary.json"
    summary_path = slot_dir / "array_q_summary.json"
    q_path = slot_dir / "q_by_mode.csv"
    pre = read_json(pre_path)
    summary = read_json(summary_path)
    all_q_rows = read_csv(q_path)
    q_rows = [row for row in all_q_rows if row.get("fit_status") == "ok"]
    pre_failure = result_failure(pre, exists=pre_path.exists(), label="预分析")
    q_failure = result_failure(summary, exists=summary_path.exists(), label="Q 拟合")
    pre_state = "failed" if pre_failure else "available" if pre_path.exists() else "not_run"
    q_state = (
        "failed"
        if q_failure
        else "available"
        if summary_path.exists() or q_path.exists()
        else "not_run"
    )
    if pre_state == "failed" or q_state == "failed":
        analysis_state = "failed"
    elif pre_state == "not_run" and q_state == "available":
        analysis_state = "missing_prerequisite"
    elif pre_state == "not_run" and q_state == "not_run":
        analysis_state = "not_run"
    elif pre_state == "available" and q_state == "available":
        analysis_state = "completed"
    else:
        analysis_state = "partial"
    assignment = pre.get("family_assignment") if isinstance(pre.get("family_assignment"), dict) else {}
    objective = assignment.get("objective") if isinstance(assignment.get("objective"), dict) else {}
    unmatched = integer(objective.get("unmatched_count"))
    unmatched = unmatched if unmatched is not None else (integer(assignment.get("unmatched_count")) or 0)
    rms = num(objective.get("weighted_rms_mhz"))
    assigned = integer(objective.get("assigned_count")) or integer(pre.get("resonance_count_used_for_fsr")) or 0
    plot_name = (
        "Q_q_distribution.png" if slot == "Q" else "Q_prime_q_distribution.png"
    )
    plot_output_dir = (asset_output_dir or output_dir / "array_die_card_assets").resolve()
    plot_url_dir = (asset_url_dir or plot_output_dir).resolve()
    q_plot_path = plot_output_dir / plot_name
    q_plot_url_path = plot_url_dir / plot_name
    if q_rows:
        write_q_distribution_plot(
            q_rows,
            q_plot_path,
            polarization=polarization or "未分配",
            slot=slot,
        )
    else:
        q_plot_path.unlink(missing_ok=True)
    return {
        "slot": slot,
        "polarization": polarization or "未分配",
        "fsr": num(pre.get("selected_fsr_ghz")),
        "resonances": integer(pre.get("resonance_count")) or 0,
        "assigned": assigned,
        "unmatched": unmatched,
        "rms": rms,
        "assignment_available": bool(assignment),
        "q_ok": integer(summary.get("ok_count")) or len(q_rows),
        "q_total": integer(summary.get("mode_count")) or len(all_q_rows),
        "ql": median(q_rows, "QL"),
        "q0": median(q_rows, "Q0"),
        "depth": median(q_rows, "depth"),
        "review": unmatched > 0 or (rms is not None and rms > 500),
        "pre_state": pre_state,
        "q_state": q_state,
        "analysis_state": analysis_state,
        "analysis_error": "；".join(
            message for message in (pre_failure, q_failure) if message
        ),
        "large_scan_plot": url_for(slot_dir / "array_preanalysis_spectrum.png", output_dir),
        "large_scan_interactive": large_scan_plot_payload(slot_dir),
        "plot": url_for(slot_dir / "array_preanalysis_folded_families.png", output_dir),
        "q_plot": relative_url(q_plot_url_path, output_dir) if q_plot_path.exists() else None,
        "pre_url": url_for(pre_path, output_dir),
        "q_url": url_for(q_path, output_dir),
    }


def comb_alignment_plot_payloads(alignment_dir: Path) -> dict[str, Any]:
    verify_dir = alignment_dir / "comb_match_verification"
    plan = read_json(alignment_dir / "plan.json")
    verification = read_json(verify_dir / "comb_match_verification_summary.json")
    mode_rows = read_csv(verify_dir / "comb_match_modes.csv")
    if not mode_rows:
        return {"spectrum": None, "residual": None, "summary": verification}

    spacing_ghz = num(verification.get("target_comb_spacing_ghz"))
    if spacing_ghz is None:
        spacing_ghz = num(plan.get("comb_spacing_ghz")) or 0.0
    center_offset_ghz = num(verification.get("comb_center_fit_offset_ghz")) or 0.0
    mode_by_comb_index = {
        comb_index: row
        for row in mode_rows
        if (comb_index := integer(row.get("comb_index"))) is not None
    }
    segment = [
        value
        for raw_value in (plan.get("comb_segment_indices") or [])
        if (value := integer(raw_value)) is not None
    ]
    if not segment:
        segment = sorted(mode_by_comb_index)
    center_candidates = [
        float(target_relative) - float(comb_index) * spacing_ghz
        for row in mode_rows
        for comb_index, target_relative in [
            (integer(row.get("comb_index")), num(row.get("target_relative_freq_ghz")))
        ]
        if comb_index is not None and target_relative is not None
    ]
    center_relative_ghz = statistics.median(center_candidates) if center_candidates else None
    targets: list[dict[str, Any]] = []
    for comb_index in segment:
        row = mode_by_comb_index.get(comb_index)
        target_relative = (
            float(center_relative_ghz) + float(comb_index) * spacing_ghz
            if center_relative_ghz is not None
            else num((row or {}).get("target_relative_freq_ghz"))
        )
        targets.append(
            {
                "comb_index": comb_index,
                "row": row,
                "target_relative_freq_ghz": target_relative,
                "aligned_target_relative_freq_ghz": (
                    target_relative + center_offset_ghz
                    if target_relative is not None
                    else None
                ),
            }
        )

    observed_targets = [
        target
        for target in targets
        if target["row"] is not None
        and num(target["row"].get("observed_relative_freq_ghz")) is not None
    ]
    static_summary = {
        "center_offset_ghz": center_offset_ghz,
        "fitted_spacing_ghz": num(verification.get("fitted_spacing_ghz")),
        "rms_mhz": num(verification.get("comb_residual_rms_mhz")),
        "max_abs_mhz": num(verification.get("comb_residual_max_abs_mhz")),
        "matched_active_count": integer(verification.get("matched_active_count")),
        "active_target_count": integer(verification.get("active_target_count")),
    }

    spectrum_payload: dict[str, Any] | None = None
    target_frequencies = [
        float(value)
        for target in targets
        if (value := num(target.get("aligned_target_relative_freq_ghz"))) is not None
    ]
    loaded_q_dir = alignment_dir / "loaded_scan" / "Q"
    if target_frequencies and loaded_q_dir.exists():
        loaded_summary = read_json(loaded_q_dir / "array_preanalysis_summary.json")
        fsr_ghz = num(loaded_summary.get("selected_fsr_ghz"))
        margin = fsr_ghz if fsr_ghz is not None and fsr_ghz > 0 else max(5.0, 0.75 * spacing_ghz)
        try:
            loaded_x, loaded_y = calibrated_large_scan_trace(
                loaded_q_dir,
                max_points=12_000,
                x_range=(min(target_frequencies) - margin, max(target_frequencies) + margin),
            )
        except Exception:
            loaded_x, loaded_y = [], []
        if loaded_x:
            y_min = min(loaded_y)
            y_max = max(loaded_y)
            marker_y = y_min + 0.04 * max(0.1, y_max - y_min)
            target_marker_y = y_max - 0.03 * max(0.1, y_max - y_min)
            spectrum_data: list[dict[str, Any]] = [
                {
                    "type": "scattergl",
                    "mode": "lines",
                    "name": "再次大扫透过率",
                    "x": loaded_x,
                    "y": loaded_y,
                    "line": {"color": "#2468a2", "width": 1.8},
                    "hovertemplate": "相对频率 %{x:.3f} GHz<br>透过率 %{y:.4f}<extra>再次大扫透过率</extra>",
                }
            ]
            shapes: list[dict[str, Any]] = []
            for participated, name, color, symbol in (
                (True, "参与对齐梳齿", "#c63d36", "line-ns-open"),
                (False, "空置/未参与梳齿", "#8a969b", "x"),
            ):
                selected = [
                    target
                    for target in targets
                    if truthy((target.get("row") or {}).get("participated")) == participated
                    and num(target.get("aligned_target_relative_freq_ghz")) is not None
                ]
                if not selected:
                    continue
                spectrum_data.append(
                    {
                        "type": "scattergl",
                        "mode": "markers",
                        "name": name,
                        "x": [num(target.get("aligned_target_relative_freq_ghz")) for target in selected],
                        "y": [target_marker_y for _target in selected],
                        "customdata": [
                            [
                                target["comb_index"],
                                (target.get("row") or {}).get("family") or "空置",
                                (target.get("row") or {}).get("cavity") or "--",
                            ]
                            for target in selected
                        ],
                        "marker": {"color": color, "size": 9, "symbol": symbol},
                        "hovertemplate": (
                            "梳齿 k=%{customdata[0]:+d}<br>目标 %{x:.3f} GHz"
                            "<br>模式 %{customdata[1]} / %{customdata[2]}<extra>" + name + "</extra>"
                        ),
                    }
                )
                shapes.extend(
                    {
                        "type": "line",
                        "xref": "x",
                        "yref": "paper",
                        "x0": num(target.get("aligned_target_relative_freq_ghz")),
                        "x1": num(target.get("aligned_target_relative_freq_ghz")),
                        "y0": 0,
                        "y1": 1,
                        "line": {"color": color, "width": 1, "dash": "dot"},
                        "opacity": 0.45 if participated else 0.3,
                    }
                    for target in selected
                )
            if observed_targets:
                spectrum_data.append(
                    {
                        "type": "scattergl",
                        "mode": "markers",
                        "name": "观测模式",
                        "x": [num(target["row"].get("observed_relative_freq_ghz")) for target in observed_targets],
                        "y": [
                            1.0 - (num(target["row"].get("observed_depth")) or 0.0)
                            for target in observed_targets
                        ],
                        "customdata": [
                            [
                                target["comb_index"],
                                target["row"].get("family") or "--",
                                target["row"].get("cavity") or "--",
                                num(target["row"].get("target_error_ghz")),
                                1000.0 * (num(target["row"].get("comb_residual_ghz")) or 0.0),
                                num(target["row"].get("final_voltage_v")),
                            ]
                            for target in observed_targets
                        ],
                        "marker": {"color": "#198754", "size": 9, "line": {"color": "#ffffff", "width": 0.8}},
                        "hovertemplate": (
                            "模式 %{customdata[1]} / %{customdata[2]}<br>梳齿 k=%{customdata[0]:+d}"
                            "<br>观测 %{x:.3f} GHz<br>透过率 %{y:.4f}"
                            "<br>原始目标误差 %{customdata[3]:+.3f} GHz"
                            "<br>扣除中心平移残差 %{customdata[4]:+.1f} MHz"
                            "<br>最终电压 %{customdata[5]:.3f} V<extra>观测模式</extra>"
                        ),
                    }
                )
            missing = [
                target
                for target in targets
                if target.get("row") is not None
                and num(target["row"].get("observed_relative_freq_ghz")) is None
                and num(target.get("aligned_target_relative_freq_ghz")) is not None
            ]
            if missing:
                spectrum_data.append(
                    {
                        "type": "scattergl",
                        "mode": "markers",
                        "name": "目标附近未找到 dip",
                        "x": [num(target.get("aligned_target_relative_freq_ghz")) for target in missing],
                        "y": [marker_y for _target in missing],
                        "customdata": [[target["comb_index"], target["row"].get("family"), target["row"].get("cavity")] for target in missing],
                        "marker": {"color": "#d97706", "size": 10, "symbol": "x"},
                        "hovertemplate": "梳齿 k=%{customdata[0]:+d}<br>模式 %{customdata[1]} / %{customdata[2]}<br>目标 %{x:.3f} GHz<extra>未匹配</extra>",
                    }
                )
            spectrum_layout = base_plot_layout(
                x_title="MZI 校准相对频率 (GHz)",
                y_title="归一化透过率",
                height=520,
            )
            spectrum_layout["shapes"] = shapes
            spectrum_payload = {"data": spectrum_data, "layout": spectrum_layout}

    residual_payload: dict[str, Any] | None = None
    plot_targets = [
        target
        for target in targets
        if num(target.get("aligned_target_relative_freq_ghz")) is not None
    ]
    if plot_targets:
        labels = [
            (
                f"k={target['comb_index']:+d}<br>{target['row'].get('family')}/{target['row'].get('cavity') or '?'}"
                if target.get("row") is not None
                else f"k={target['comb_index']:+d}<br>空置"
            )
            for target in plot_targets
        ]
        residual_data: list[dict[str, Any]] = [
            {
                "type": "scatter",
                "mode": "lines+markers",
                "name": f"理想 {spacing_ghz:.3f} GHz 光梳",
                "x": [target["comb_index"] for target in plot_targets],
                "y": [num(target.get("aligned_target_relative_freq_ghz")) for target in plot_targets],
                "line": {"color": "#c63d36", "width": 1.8, "dash": "dash"},
                "marker": {"symbol": "line-ns-open", "size": 9},
                "hovertemplate": "梳齿 k=%{x:+d}<br>中心平移后目标 %{y:.6f} GHz<extra>理想光梳</extra>",
            }
        ]
        if observed_targets:
            residual_data.append(
                {
                    "type": "scatter",
                    "mode": "markers",
                    "name": "重构观测频率",
                    "x": [target["comb_index"] for target in observed_targets],
                    "y": [num(target["row"].get("observed_relative_freq_ghz")) for target in observed_targets],
                    "customdata": [
                        [
                            target["row"].get("family") or "--",
                            target["row"].get("cavity") or "--",
                            1000.0 * (num(target["row"].get("comb_residual_ghz")) or 0.0),
                            num(target["row"].get("observed_wavelength_nm")),
                        ]
                        for target in observed_targets
                    ],
                    "marker": {"color": "#198754", "size": 10, "line": {"color": "#ffffff", "width": 0.8}},
                    "hovertemplate": (
                        "模式 %{customdata[0]} / %{customdata[1]}<br>梳齿 k=%{x:+d}"
                        "<br>观测 %{y:.6f} GHz<br>波长 %{customdata[3]:.6f} nm"
                        "<br>扣除中心平移残差 %{customdata[2]:+.1f} MHz<extra>重构观测频率</extra>"
                    ),
                }
            )
            residual_data.append(
                {
                    "type": "scatter",
                    "mode": "markers",
                    "name": "频率残差",
                    "x": [target["comb_index"] for target in observed_targets],
                    "y": [1000.0 * (num(target["row"].get("comb_residual_ghz")) or 0.0) for target in observed_targets],
                    "customdata": [[target["row"].get("family") or "--", target["row"].get("cavity") or "--"] for target in observed_targets],
                    "xaxis": "x2",
                    "yaxis": "y2",
                    "marker": {"color": "#198754", "size": 10},
                    "hovertemplate": "模式 %{customdata[0]} / %{customdata[1]}<br>梳齿 k=%{x:+d}<br>残差 %{y:+.1f} MHz<extra>频率残差</extra>",
                }
            )
        missing_targets = [target for target in plot_targets if target not in observed_targets]
        if missing_targets:
            residual_data.append(
                {
                    "type": "scatter",
                    "mode": "markers",
                    "name": "空置/未匹配",
                    "x": [target["comb_index"] for target in missing_targets],
                    "y": [num(target.get("aligned_target_relative_freq_ghz")) for target in missing_targets],
                    "customdata": [[(target.get("row") or {}).get("family") or "空置", (target.get("row") or {}).get("cavity") or "--"] for target in missing_targets],
                    "marker": {"color": "#8a969b", "size": 10, "symbol": "x"},
                    "hovertemplate": "梳齿 k=%{x:+d}<br>%{customdata[0]} / %{customdata[1]}<br>目标 %{y:.6f} GHz<extra>空置/未匹配</extra>",
                }
            )
        layout = base_plot_layout(x_title="", y_title="相对频率 (GHz)", height=520)
        layout["margin"] = {"l": 78, "r": 28, "t": 24, "b": 92}
        layout["xaxis"].update({"domain": [0, 1], "anchor": "y", "showticklabels": False})
        layout["yaxis"].update({"domain": [0.38, 1]})
        layout["xaxis2"] = {
            **layout["xaxis"],
            "title": {"text": "梳齿与目标模式"},
            "anchor": "y2",
            "showticklabels": True,
            "tickmode": "array",
            "tickvals": [target["comb_index"] for target in plot_targets],
            "ticktext": labels,
            "tickangle": 0,
            "matches": "x",
        }
        layout["yaxis2"] = {
            **layout["yaxis"],
            "title": {"text": "残差 (MHz)"},
            "domain": [0, 0.24],
            "anchor": "x2",
            "zeroline": True,
            "zerolinecolor": "#69777d",
            "zerolinewidth": 1,
        }
        residual_payload = {"data": residual_data, "layout": layout}
    return {
        "spectrum": spectrum_payload,
        "residual": residual_payload,
        "summary": static_summary,
    }


def named_rows(record: dict[str, Any], key: str) -> dict[str, dict[str, Any]]:
    rows = record.get(key) if isinstance(record.get(key), list) else []
    return {str(row.get("name") or ""): row for row in rows if isinstance(row, dict) and row.get("name")}


def by_field(rows: list[dict[str, Any]], key: str) -> dict[str, dict[str, Any]]:
    return {str(row.get(key) or ""): row for row in rows if isinstance(row, dict) and row.get(key)}


def normalized_physical_order(
    design: dict[str, Any],
    *cavity_sources: Iterable[str],
) -> tuple[list[list[str]], str, int]:
    raw_order = design.get("physical_order") if isinstance(design.get("physical_order"), list) else []
    order = [
        [str(value) for value in row if str(value).strip()]
        for row in raw_order
        if isinstance(row, list) and any(str(value).strip() for value in row)
    ]
    if order:
        cavity_count = sum(len(row) for row in order)
        columns = max((len(row) for row in order), default=1)
        label = (
            f"{len(order)} × {columns}"
            if len({len(row) for row in order}) == 1
            else f"{cavity_count} 个腔"
        )
        return order, label, columns

    names = {
        str(value)
        for source in cavity_sources
        for value in source
        if re.fullmatch(r"c\d+", str(value), flags=re.I)
    }
    electrode_map = (
        design.get("electrode_to_cavity")
        if isinstance(design.get("electrode_to_cavity"), dict)
        else {}
    )
    names.update(
        str(value)
        for value in electrode_map.values()
        if re.fullmatch(r"c\d+", str(value), flags=re.I)
    )
    for key in ("optical_path_order",):
        values = design.get(key) if isinstance(design.get(key), list) else []
        names.update(
            str(value)
            for value in values
            if re.fullmatch(r"c\d+", str(value), flags=re.I)
        )
    radius_offsets = (
        design.get("cavity_radius_offset_steps")
        if isinstance(design.get("cavity_radius_offset_steps"), dict)
        else {}
    )
    names.update(
        str(value)
        for value in radius_offsets
        if re.fullmatch(r"c\d+", str(value), flags=re.I)
    )

    shape_raw = design.get("array_shape")
    shape: tuple[int, int] | None = None
    if isinstance(shape_raw, list) and len(shape_raw) == 2:
        rows = integer(shape_raw[0])
        columns = integer(shape_raw[1])
        if rows is not None and rows > 0 and columns is not None and columns > 0:
            shape = (rows, columns)
    configured_count = integer(design.get("cavity_count"))
    if configured_count is not None and configured_count <= 0:
        configured_count = None
    if not names:
        count = configured_count or (shape[0] * shape[1] if shape else 0)
        names.update(f"c{index}" for index in range(1, count + 1))
    sorted_names = sorted(names, key=natural_key)
    cavity_count = len(sorted_names)
    if not cavity_count:
        return [], "未配置", 1
    if shape and shape[0] * shape[1] == cavity_count:
        rows, columns = shape
        order = [
            sorted_names[index : index + columns]
            for index in range(0, cavity_count, columns)
        ]
        return order, f"{rows} × {columns}", columns

    display_columns = min(4, cavity_count)
    return [sorted_names], f"{cavity_count} 个腔（物理布局未配置）", display_columns


def build_card(
    results_root: Path,
    chip: str,
    die: str,
    output: Path,
    *,
    asset_output_dir: Path | None = None,
    asset_url_dir: Path | None = None,
) -> str:
    results_root = results_root.resolve()
    die_dir = results_root / chip / die
    if not die_dir.is_dir():
        raise FileNotFoundError(die_dir)
    output_dir = output.resolve().parent
    batch = results_root.parent.name if results_root.name.lower() == "results" else results_root.name

    design = read_json(results_root / chip / "array_design.json")
    die_matrix = design.get("die_design_matrix") if isinstance(design.get("die_design_matrix"), dict) else {}
    die_design = die_matrix.get(die) if isinstance(die_matrix.get(die), dict) else {}
    observation = read_json(die_dir / "observation.json")
    observations = named_rows(observation, "sections")
    electrode_record = read_json(die_dir / "electrode_resistance.json")
    electrode_rows = electrode_record.get("rows") if isinstance(electrode_record.get("rows"), list) else []
    electrical = by_field(electrode_rows, "cavity")
    power = read_json(die_dir / "optical_power.json")
    manifest = read_json(die_dir / "polarization_manifest.json")
    slots = manifest.get("slots") if isinstance(manifest.get("slots"), dict) else {}
    q_items: list[dict[str, Any]] = []
    for slot in ("Q", "Q'"):
        slot_record = slots.get(slot) if isinstance(slots.get(slot), dict) else {}
        polarization = str(slot_record.get("polarization") or "").strip().upper()
        if polarization not in {"TE", "TM"}:
            polarization = ""
        assigned_signature = (
            slot_record.get("data_signature")
            if isinstance(slot_record.get("data_signature"), dict)
            else None
        )
        current_signature = q_slot_data_signature(die_dir / slot)
        polarization_stale = bool(
            polarization
            and assigned_signature
            and assigned_signature != current_signature
        )
        polarization_display = (
            f"{polarization}（标记已过期）"
            if polarization_stale
            else polarization or "未分配"
        )
        item = q_summary(
            die_dir,
            slot,
            polarization_display,
            output_dir,
            asset_output_dir=asset_output_dir,
            asset_url_dir=asset_url_dir,
        )
        item["polarization"] = polarization or "未分配"
        item["polarization_display"] = polarization_display
        item["polarization_stale"] = polarization_stale
        item["polarization_current"] = bool(polarization and not polarization_stale)
        item["assigned_data_signature"] = assigned_signature
        item["current_data_signature"] = current_signature
        item["q_measurement_decision_value"] = str(
            slot_record.get("q_measurement_decision") or "undecided"
        ).strip().lower()
        item["q_measurement_decision"] = workflow_decision(
            item["q_measurement_decision_value"],
            "q",
        )
        item["q_measurement_decision_reason"] = str(
            slot_record.get("q_measurement_decision_reason") or ""
        ).strip()
        item["thermal_tuning_decision_value"] = str(
            slot_record.get("thermal_tuning_decision") or "undecided"
        ).strip().lower()
        item["thermal_tuning_decision"] = workflow_decision(
            item["thermal_tuning_decision_value"],
            "thermal",
        )
        item["thermal_tuning_decision_reason"] = str(
            slot_record.get("thermal_tuning_decision_reason") or ""
        ).strip()
        item["review"] = bool(
            item["review"]
            or polarization_stale
            or item["analysis_state"] in {"failed", "missing_prerequisite"}
        )
        q_items.append(item)

    current_labels = [
        item["polarization"]
        for item in q_items
        if item["polarization_current"]
    ]
    has_current_te_tm_pair = (
        len(current_labels) == 2 and set(current_labels) == {"TE", "TM"}
    )
    if has_current_te_tm_pair:
        display_q_items = sorted(
            q_items,
            key=lambda item: 0 if item["polarization"] == "TE" else 1,
        )
    else:
        display_q_items = q_items

    assignment_path = die_dir / "thermal_tuning" / "current_fsr_assignment" / "assignment_table.csv"
    assignments = read_csv(assignment_path)
    thermal = by_field(assignments, "cavity")
    order, array_shape_label, array_columns = normalized_physical_order(
        design,
        observations.keys(),
        electrical.keys(),
        thermal.keys(),
    )
    accepted = [row for row in assignments if truthy(row.get("thermal_tuning_assignment_accepted"))]
    alignment_dir = die_dir / "thermal_tuning" / "comb_reconstruction_check"
    plan = read_json(alignment_dir / "plan.json")
    plan_rows = plan.get("plan_rows") if isinstance(plan.get("plan_rows"), list) else []
    plan_by_cavity = by_field(plan_rows, "cavity")
    verification = read_json(alignment_dir / "verification_summary.json")
    verification_rows = verification.get("verification_rows") if isinstance(verification.get("verification_rows"), list) else []
    verification_by_cavity = by_field(verification_rows, "cavity")
    checked = integer(verification.get("checked_count")) or len(verification_rows)
    passed = integer(verification.get("passed_count")) or sum(truthy(row.get("passed")) for row in verification_rows)
    failures = [row for row in verification_rows if not truthy(row.get("passed"))]
    alignment_plots = comb_alignment_plot_payloads(alignment_dir)

    latest = read_json(die_dir / "noise_power_spectrum" / "latest.json")
    noise_path = Path(str(latest.get("summary_path") or ""))
    if not noise_path.is_absolute():
        noise_path = die_dir / "noise_power_spectrum" / noise_path
    noise = read_json(noise_path)
    noise_total = integer(noise.get("total")) or 0
    noise_complete = integer(noise.get("completed_count")) or 0
    noise_failed = integer(noise.get("failed_count")) or 0
    skipped = noise.get("skipped") if isinstance(noise.get("skipped"), list) else []
    noise_comparison = Path(str(noise.get("comparison_html") or latest.get("comparison_html") or ""))
    noise_url = url_for(noise_comparison, output_dir) if str(noise_comparison) not in {"", "."} else None

    def fsr_metric_part(item: dict[str, Any]) -> str:
        if item["pre_state"] == "failed":
            return "执行失败"
        if item["pre_state"] != "available":
            return "--"
        return fmt(item["fsr"], 1)

    if has_current_te_tm_pair:
        by_polarization = {item["polarization"]: item for item in display_q_items}
        fsr_label = "TE / TM FSR"
        fsr_value = (
            f"{fsr_metric_part(by_polarization['TE'])} / "
            f"{fsr_metric_part(by_polarization['TM'])} GHz"
        )
    else:
        fsr_label = "Q / Q' FSR"
        fsr_value = (
            f"{fsr_metric_part(q_items[0])} / "
            f"{fsr_metric_part(q_items[1])} GHz"
        )

    primary_item = q_items[0]
    primary_polarization = primary_item["polarization_display"]
    thermal_decision = primary_item["thermal_tuning_decision_value"]
    thermal_reason = primary_item["thermal_tuning_decision_reason"]
    if assignments:
        thermal_metric_value = f"{len(accepted)} / {len(assignments)}"
        thermal_metric_note = f"{primary_polarization}（Q）高可信 / 总模式家族"
        alignment_metric_value = f"{passed} / {checked}" if checked else "未校验"
        alignment_metric_note = "通过 / 校验" if checked else "已有归属，尚未执行对齐校验"
        noise_metric_value = f"{noise_complete} / {noise_total}" if noise_total else "未测量"
        noise_metric_note = f"完成，失败 {noise_failed}" if noise_total else "尚未执行噪声谱测量"
    elif thermal_decision == "skip":
        thermal_metric_value = "已跳过"
        thermal_metric_note = thermal_reason or f"{primary_polarization}（Q）人工决定不做热调谐"
        alignment_metric_value = "不适用"
        alignment_metric_note = "热调谐已主动跳过"
        noise_metric_value = "不适用"
        noise_metric_note = "热调谐已主动跳过"
    elif thermal_decision == "proceed" and not electrode_rows:
        thermal_metric_value = "待准备"
        thermal_metric_note = "已决定进入热调谐，缺电阻/接触记录"
        alignment_metric_value = "未执行"
        alignment_metric_note = "等待热调谐归属"
        noise_metric_value = "未执行"
        noise_metric_note = "等待对齐与锁模"
    elif thermal_decision == "proceed":
        thermal_metric_value = "未执行"
        thermal_metric_note = "电阻记录已存在，尚无热调谐归属结果"
        alignment_metric_value = "未执行"
        alignment_metric_note = "等待热调谐归属"
        noise_metric_value = "未执行"
        noise_metric_note = "等待对齐与锁模"
    else:
        thermal_metric_value = "待决定"
        thermal_metric_note = f"{primary_polarization}（Q）尚未决定是否进入热调谐"
        alignment_metric_value = "未执行"
        alignment_metric_note = "等待流程决定"
        noise_metric_value = "未执行"
        noise_metric_note = "等待流程决定"

    metrics = "".join([
        metric("阵列", array_shape_label, f"gap {fmt(die_design.get('gap_um'), 1, ' um')}"),
        metric("总透过率", fmt(power.get("throughput_pct"), 2, "%"), "die 级，未按偏振命名"),
        metric(fsr_label, fsr_value),
        metric("热调谐归属", thermal_metric_value, thermal_metric_note),
        metric("梳齿对齐", alignment_metric_value, alignment_metric_note),
        metric("噪声谱", noise_metric_value, noise_metric_note),
    ])

    findings: list[tuple[str, str, str]] = []
    for item in display_q_items:
        subject = f"{item['slot']}={item['polarization_display']}"
        if item["analysis_state"] == "failed":
            findings.append((
                "review",
                "执行失败",
                f"{subject}：{item['analysis_error'] or '分析结果标记为失败，不能作为结论使用'}。",
            ))
        elif item["analysis_state"] == "missing_prerequisite":
            findings.append((
                "review",
                "缺前置数据",
                f"{subject}：存在 Q 拟合结果，但缺少可确认的预分析结果。",
            ))
        elif item["analysis_state"] == "not_run" and item["q_measurement_decision_value"] == "stop":
            findings.append((
                "review",
                "主动跳过",
                f"{subject}：人工决定不再大扫测 Q；"
                f"{item['q_measurement_decision_reason'] or '原因未记录'}。",
            ))
        elif item["analysis_state"] == "not_run":
            findings.append(("review", "未执行", f"{subject}：尚无可汇总的大扫/Q 数据。"))
        elif item["polarization_stale"]:
            detail = (
                f"当前槽预分析记录 {item['assigned']} 个模式已归属、"
                f"{item['unmatched']} 个未归属；"
                if item["assignment_available"]
                else ""
            )
            findings.append((
                "review",
                "偏振待确认",
                f"{item['slot']} 槽原人工标记为 {item['polarization']}，但槽内数据已变化；"
                f"{detail}TE/TM 归属需要重新确认。",
            ))
        elif not item["assignment_available"]:
            findings.append((
                "review",
                "部分完成",
                f"{subject}：预分析数据已存在，但尚无可确认的模式家族归属结果。",
            ))
        elif item["review"]:
            findings.append((
                "review",
                "待确认",
                f"{subject}：{item['assigned']} 个模式已归属、"
                f"{item['unmatched']} 个未归属，RMS {fmt(item['rms'], 1, ' MHz')}；归属仍需复核。",
            ))
        else:
            findings.append((
                "fact",
                "事实",
                f"{subject}：{item['assigned']} 个模式已归属、"
                f"{item['unmatched']} 个未归属，RMS {fmt(item['rms'], 1, ' MHz')}。",
            ))
    if thermal_decision == "skip" and not assignments:
        findings.append((
            "review",
            "主动跳过",
            f"{primary_polarization}（Q）热调谐已跳过；对齐和噪声谱因此不适用。"
            + (f" 原因：{thermal_reason}。" if thermal_reason else ""),
        ))
    elif checked:
        findings.append((
            "review" if failures else "fact",
            "现场判断" if failures else "事实",
            f"梳齿对齐 {passed}/{checked} 通过；"
            + ("存在未通过项，请按校验表复核。" if failures else "当前已执行校验未记录失败项。"),
        ))
    elif thermal_decision == "proceed":
        findings.append(("review", "未执行", "已决定进入热调谐，但尚无梳齿对齐校验结果。"))
    findings_html = "".join(f'<li class="finding {tone}">{badge(label,tone)}<span>{esc(text)}</span></li>' for tone, label, text in findings)

    polarization_html = ""
    large_scan_plot_html = ""
    plot_html = ""
    q_plot_html = ""
    for item in display_q_items:
        if item["analysis_state"] == "failed":
            tone, assignment_badge = "bad", "执行失败"
        elif item["analysis_state"] == "missing_prerequisite":
            tone, assignment_badge = "review", "缺前置数据"
        elif item["polarization_stale"]:
            tone, assignment_badge = "review", "偏振标记已过期"
        elif item["analysis_state"] == "not_run" and item["q_measurement_decision_value"] == "stop":
            tone, assignment_badge = "neutral", "主动跳过"
        elif item["analysis_state"] == "not_run":
            tone, assignment_badge = "review", "尚无数据"
        elif not item["assignment_available"]:
            tone, assignment_badge = "review", "部分完成"
        elif item["review"]:
            tone, assignment_badge = "review", "需要复核"
        else:
            tone, assignment_badge = "good", "归属稳健"
        q_decision_label, q_decision_tone = item["q_measurement_decision"]
        thermal_decision_label, thermal_decision_tone = item["thermal_tuning_decision"]
        q_reason_html = ""
        if item["q_measurement_decision_value"] == "stop":
            q_reason = item["q_measurement_decision_reason"] or "原因待补充"
            q_reason_html = f'<div class="decision-reason"><dt>不再大扫原因</dt><dd>{esc(q_reason)}</dd></div>'
        thermal_reason_html = ""
        if item["thermal_tuning_decision_value"] == "skip":
            thermal_reason = item["thermal_tuning_decision_reason"] or "原因待补充"
            thermal_reason_html = f'<div class="decision-reason"><dt>不做热调谐原因</dt><dd>{esc(thermal_reason)}</dd></div>'
        analysis_reason_html = ""
        if item["analysis_state"] == "failed":
            analysis_reason_html = (
                f'<div class="decision-reason"><dt>数据状态</dt>'
                f'<dd>{esc(item["analysis_error"] or "分析执行失败")}</dd></div>'
            )
        elif item["analysis_state"] == "missing_prerequisite":
            analysis_reason_html = (
                '<div class="decision-reason"><dt>数据状态</dt>'
                '<dd>存在 Q 拟合结果，但缺少可确认的预分析结果</dd></div>'
            )
        if item["pre_state"] == "available":
            fsr_text = fmt(item["fsr"], 3, " GHz")
            resonance_assignment_text = (
                f"{item['resonances']} / {item['assigned']}"
                if item["assignment_available"]
                else f"{item['resonances']} / 未执行"
            )
            unmatched_text = str(item["unmatched"]) if item["assignment_available"] else "--"
            rms_text = fmt(item["rms"], 1, " MHz") if item["assignment_available"] else "--"
        elif item["pre_state"] == "failed":
            fsr_text = "执行失败"
            resonance_assignment_text = "执行失败"
            unmatched_text = "--"
            rms_text = "--"
        else:
            pending_text = (
                "主动跳过"
                if item["q_measurement_decision_value"] == "stop"
                else "缺前置数据"
                if item["q_state"] == "available"
                else "未执行"
            )
            fsr_text = pending_text
            resonance_assignment_text = pending_text
            unmatched_text = "--"
            rms_text = "--"
        if item["q_state"] == "failed":
            q_fit_text = "执行失败"
        elif item["q_state"] == "available":
            q_fit_text = f"{item['q_ok']} / {item['q_total']}"
        else:
            q_fit_text = (
                "主动跳过"
                if item["q_measurement_decision_value"] == "stop"
                else "未执行"
            )
        ql_text = fmt_q(item["ql"]) if item["q_state"] == "available" else "--"
        q0_text = fmt_q(item["q0"]) if item["q_state"] == "available" else "--"
        depth_text = fmt(item["depth"], 3) if item["q_state"] == "available" else "--"
        polarization_html += f"""<article class="polarization-panel"><header><div><span class="eyebrow">{esc(item['slot'])}</span><h3>{esc(item['polarization_display'])}</h3></div>{badge(assignment_badge,tone)}</header>
<dl class="compact-kv"><div><dt>大扫测 Q</dt><dd>{badge(q_decision_label,q_decision_tone)}</dd></div><div><dt>后续热调谐</dt><dd>{badge(thermal_decision_label,thermal_decision_tone)}</dd></div>{q_reason_html}{thermal_reason_html}{analysis_reason_html}<div><dt>主导 FSR</dt><dd>{esc(fsr_text)}</dd></div><div><dt>谐振 / 归属</dt><dd>{esc(resonance_assignment_text)}</dd></div><div><dt>未归属</dt><dd>{esc(unmatched_text)}</dd></div><div><dt>归属 RMS</dt><dd>{esc(rms_text)}</dd></div><div><dt>Q 拟合</dt><dd>{esc(q_fit_text)}</dd></div><div><dt>中位 QL</dt><dd>{esc(ql_text)}</dd></div><div><dt>中位 Q0</dt><dd>{esc(q0_text)}</dd></div><div><dt>中位深度</dt><dd>{esc(depth_text)}</dd></div></dl><footer>{link(item['pre_url'],'预分析 JSON')}{link(item['q_url'],'Q 明细 CSV')}</footer></article>"""
        plot_id = "large-scan-q-prime" if item["slot"] == "Q'" else "large-scan-q"
        large_scan_plot_html += plot_figure_html(
            f"{item['polarization_display']} · {item['slot']} 大扫总透过率谱",
            plot_id,
            item["large_scan_interactive"],
            item["large_scan_plot"],
            missing_text="尚无大扫图",
        )
        if item["plot"]:
            plot_html += f'<figure><figcaption>{esc(item["polarization_display"])} · {esc(item["slot"])} 模式折叠色散</figcaption><a href="{esc(item["plot"])}"><img src="{esc(item["plot"])}" alt="{esc(item["polarization_display"])} folded mode-family dispersion"></a></figure>'
        if item["q_plot"]:
            q_plot_html += f'<figure><figcaption>{esc(item["polarization_display"])} · {esc(item["slot"])} 模式 Q 分布</figcaption><a href="{esc(item["q_plot"])}"><img src="{esc(item["q_plot"])}" alt="{esc(item["polarization_display"])} mode Q distribution"></a></figure>'

    cavity_tiles = ""
    for physical_row in order:
        if not isinstance(physical_row, list):
            continue
        for cavity_value in physical_row:
            cavity = str(cavity_value)
            obs = observations.get(cavity, {})
            tune = thermal.get(cavity, {})
            verify = verification_by_cavity.get(cavity, {})
            electrode = electrical.get(cavity, {})
            obs_status = str(obs.get("status") or "未记录")
            if verify:
                align_text, align_tone = (
                    ("梳齿细扫校验通过", "good")
                    if truthy(verify.get("passed"))
                    else ("梳齿细扫校验未通过", "bad")
                )
            elif thermal_decision == "skip" and not assignments:
                align_text, align_tone = "不适用", "neutral"
            else:
                align_text, align_tone = "未参与梳齿对齐", "neutral"
            slope = num(tune.get("thermal_tuning_slope_ghz_per_v2"))
            resistance = num(electrode.get("resistance"))
            resistance_unit = str(electrode.get("resistance_unit") or "Ohm")
            if tune:
                thermal_text = fmt(abs(slope) if slope is not None else None, 2, " GHz/V²")
                assignment_text = "高可信" if truthy(tune.get("thermal_tuning_assignment_accepted")) else "低可信"
            elif thermal_decision == "skip":
                thermal_text = "已跳过"
                assignment_text = "不适用"
            elif thermal_decision == "proceed" and not electrode_rows:
                thermal_text = "待准备"
                assignment_text = "缺电阻记录"
            else:
                thermal_text = "未执行"
                assignment_text = "未归属"
            cavity_images = obs.get("images") if isinstance(obs.get("images"), list) else []
            cavity_photo_url = url_for(die_dir / str(cavity_images[0]), output_dir) if cavity_images else None
            cavity_photo_html = (
                f'<a class="cavity-photo" href="{esc(cavity_photo_url)}"><img loading="lazy" src="{esc(cavity_photo_url)}" alt="{esc(cavity)} cavity observation"></a>'
                if cavity_photo_url
                else '<div class="cavity-photo cavity-photo-placeholder">无腔体照片</div>'
            )
            resistance_text = fmt(resistance, 1, f" {resistance_unit}")
            cavity_tiles += f"""<article class="cavity-tile">{cavity_photo_html}<div class="cavity-info"><header><strong>{esc(cavity)}</strong><span>{esc(tune.get('family') or '--')}</span></header><div class="tile-badges">{badge(obs_status,'good' if obs_status=='完好' else 'review')}{badge(align_text,align_tone)}</div><dl><div><dt>电阻</dt><dd>{esc(resistance_text)}</dd></div><div><dt>热调谐</dt><dd>{esc(thermal_text)}</dd></div><div><dt>归属</dt><dd>{esc(assignment_text)}</dd></div></dl><p>{esc(obs.get('text') or '无腔体观察备注')}</p></div></article>"""

    alignment_rows = ""
    def comb_index_sort_key(value: dict[str, Any]) -> int:
        comb_index = integer(value.get("comb_index"))
        return comb_index if comb_index is not None else 10_000

    for row in sorted(verification_rows, key=comb_index_sort_key):
        ok = truthy(row.get("passed"))
        mode = row.get("mode_number") if row.get("mode_number") is not None else row.get("mu")
        if mode is None:
            mode = plan_by_cavity.get(str(row.get("cavity") or ""), {}).get("mode_number")
        alignment_rows += f"<tr><td>{esc(row.get('family') or '--')}</td><td>{esc(row.get('cavity') or '--')}</td><td>{esc(mode if mode is not None else '--')}</td><td>{esc(row.get('comb_index') if row.get('comb_index') is not None else '--')}</td><td>{esc(fmt(row.get('initial_voltage_v'),3,' V'))}</td><td>{esc(fmt(row.get('final_voltage_v'),3,' V'))}</td><td>{esc(fmt(row.get('final_dip_offset_ghz'),3,' GHz'))}</td><td>{badge('通过' if ok else '未通过','good' if ok else 'bad')}</td></tr>"

    overall = observations.get("整体标识", {})
    images = overall.get("images") if isinstance(overall.get("images"), list) else []
    overall_url = url_for(die_dir / str(images[0]), output_dir) if images else None
    image_html = f'<a class="overview-image" href="{esc(overall_url)}"><img src="{esc(overall_url)}" alt="die overall observation"></a>' if overall_url else '<div class="overview-image"></div>'
    waveguide_html = ""
    for waveguide_name in ("左侧耦合波导", "右侧耦合波导"):
        waveguide = observations.get(waveguide_name, {})
        status = str(waveguide.get("status") or "未记录")
        if status in {"完好", "正常"}:
            status_tone = "good"
        elif status in {"可疑", "未检查"}:
            status_tone = "review"
        elif status in {"损坏", "异常"}:
            status_tone = "bad"
        else:
            status_tone = "neutral"
        waveguide_images = waveguide.get("images") if isinstance(waveguide.get("images"), list) else []
        waveguide_url = url_for(die_dir / str(waveguide_images[0]), output_dir) if waveguide_images else None
        waveguide_photo_html = (
            f'<a class="waveguide-photo" href="{esc(waveguide_url)}"><img loading="lazy" src="{esc(waveguide_url)}" alt="{esc(waveguide_name)} observation"></a>'
            if waveguide_url
            else '<div class="waveguide-photo waveguide-photo-placeholder">无波导照片</div>'
        )
        waveguide_html += (
            f'<article class="waveguide-panel">{waveguide_photo_html}'
            f'<div class="waveguide-info"><header><strong>{esc(waveguide_name)}</strong>'
            f'{badge(status, status_tone)}</header>'
            f'<p>{esc(waveguide.get("text") or "无观察备注")}</p></div></article>'
        )
    failed_text = "、".join(f"{row.get('family','--')}/{row.get('cavity','--')}" for row in failures) or "无"
    skipped_text = "、".join(f"{row.get('family','--')}/{row.get('cavity','--')}" for row in skipped if isinstance(row, dict)) or "无"
    selected_modes = plan.get("selected_mode_numbers") if isinstance(plan.get("selected_mode_numbers"), list) else []
    if alignment_rows:
        alignment_content = f"""<div class="table-wrap"><table><thead><tr><th>模式</th><th>腔</th><th>mu</th><th>梳齿</th><th>初始电压</th><th>最终电压</th><th>最终偏差</th><th>结果</th></tr></thead><tbody>{alignment_rows}</tbody></table></div>"""
    else:
        alignment_content = (
            f'<ul class="findings"><li class="finding review">{badge(alignment_metric_value, "review")}'
            f'<span>{esc(alignment_metric_note)}</span></li></ul>'
        )
    comb_verify_dir = alignment_dir / "comb_match_verification"
    comb_plot_summary = alignment_plots.get("summary") if isinstance(alignment_plots.get("summary"), dict) else {}
    residual_caption = "模式频率与预期差异"
    if num(comb_plot_summary.get("rms_mhz")) is not None:
        residual_caption += (
            f" · RMS {fmt(comb_plot_summary.get('rms_mhz'), 1, ' MHz')}"
            f"，最大 |残差| {fmt(comb_plot_summary.get('max_abs_mhz'), 1, ' MHz')}"
        )
    alignment_plot_html = "".join(
        [
            plot_figure_html(
                "模式对齐后的再次大扫与梳齿匹配",
                "comb-match-spectrum",
                alignment_plots.get("spectrum"),
                url_for(comb_verify_dir / "comb_match_mu_spectrum.png", output_dir),
                missing_text="尚无对齐后大扫重构结果",
            ),
            plot_figure_html(
                residual_caption,
                "comb-frequency-residual",
                alignment_plots.get("residual"),
                url_for(comb_verify_dir / "comb_match_pair_spacing.png", output_dir),
                missing_text="尚无模式频率残差结果",
            ),
        ]
    )
    noise_summary = (
        f"{noise_complete}/{noise_total} 完成，{noise_failed} 失败；跳过 {skipped_text}"
        if noise_total
        else f"{noise_metric_value}；{noise_metric_note}"
    )
    evidence = "".join([
        link(url_for(results_root / chip / "array_design.json", output_dir), "阵列设计"),
        link(url_for(die_dir / "observation.json", output_dir), "观察记录"),
        link(url_for(die_dir / "electrode_resistance.json", output_dir), "电阻记录"),
        link(url_for(die_dir / "optical_power.json", output_dir), "光功率"),
        link(url_for(die_dir / "polarization_manifest.json", output_dir), "偏振分配"),
        link(url_for(assignment_path, output_dir), "热调谐归属"),
        link(url_for(alignment_dir / "plan.json", output_dir), "梳齿方案"),
        link(url_for(alignment_dir / "verification_table.csv", output_dir), "校验明细"),
        link(url_for(comb_verify_dir / "comb_match_modes.csv", output_dir), "重构模式明细"),
        link(url_for(comb_verify_dir / "comb_match_pair_spacing.csv", output_dir), "模式间隔明细"),
        link(url_for(comb_verify_dir / "comb_match_verification_summary.json", output_dir), "重构校验汇总"),
    ])

    has_interactive_plots = any(
        item.get("large_scan_interactive") for item in display_q_items
    ) or bool(alignment_plots.get("spectrum") or alignment_plots.get("residual"))
    plot_runtime = ""
    if has_interactive_plots:
        plot_runtime = r"""<script>
(() => {
  const renderPlots = () => {
    if (!window.Plotly) return;
    const config = {
      responsive: true,
      displaylogo: false,
      scrollZoom: true,
      modeBarButtonsToRemove: ["lasso2d", "select2d"],
      toImageButtonOptions: {format: "png", scale: 2}
    };
    document.querySelectorAll("script.plot-spec[data-plot-for]").forEach((spec) => {
      const plotId = spec.dataset.plotFor;
      const target = document.getElementById(plotId);
      const fallback = document.querySelector(`[data-fallback-for="${plotId}"]`);
      if (!target) return;
      let payload;
      try { payload = JSON.parse(spec.textContent); } catch (_error) { return; }
      target.hidden = false;
      window.Plotly.newPlot(target, payload.data, payload.layout, config)
        .then(() => { if (fallback) fallback.hidden = true; })
        .catch(() => { target.hidden = true; if (fallback) fallback.hidden = false; });
    });
  };
  if (window.Plotly) {
    renderPlots();
    return;
  }
  const script = document.createElement("script");
  script.src = "https://cdn.plot.ly/plotly-2.35.2.min.js";
  script.onload = renderPlots;
  document.head.appendChild(script);
})();
</script>"""

    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(batch)} · {esc(chip)} · {esc(die)} array die card</title><style>{CSS}</style></head><body>
<header class="masthead"><div class="inner"><div><span class="eyebrow">Array die card</span><h1>{esc(batch)} · {esc(chip)} · {esc(die)}</h1></div><div class="identity">生成于 {esc(datetime.now().astimezone().isoformat(timespec='seconds'))}<br>只读汇总现有测量结果</div></div></header>
<div class="metrics-band"><div class="inner metrics">{metrics}</div></div>
<section><div class="inner"><div class="section-head"><h2>结论与边界</h2><span class="section-note">事实、现场判断和待确认项分开呈现</span></div><ul class="findings">{findings_html}</ul></div></section>
<section><div class="inner"><div class="section-head"><h2>设计与光路</h2><span class="section-note">功率记录尚未按偏振命名</span></div><div class="die-overview"><dl class="overview-facts"><div><dt>耦合 gap</dt><dd>{esc(fmt(die_design.get('gap_um'),2,' um'))}</dd></div><div><dt>半径步进</dt><dd>{esc(fmt(die_design.get('radius_step_nm'),2,' nm'))}</dd></div><div><dt>金属宽度</dt><dd>{esc(fmt(die_design.get('metal_width_um'),1,' um'))}</dd></div><div><dt>阵列规模</dt><dd>{esc(array_shape_label)}</dd></div><div><dt>输入功率</dt><dd>{esc(fmt(power.get('input_power_uw'),3,' uW'))}</dd></div><div><dt>输出功率</dt><dd>{esc(fmt(power.get('output_power_uw'),3,' uW'))}</dd></div><div><dt>双端透过率</dt><dd>{esc(fmt(power.get('throughput_db'),2,' dB'))}</dd></div><div><dt>单端损耗</dt><dd>{esc(fmt(power.get('single_ended_loss_db'),2,' dB'))}</dd></div></dl>{image_html}</div><div class="subsection-head"><h3>耦合波导观察</h3><span class="section-note">读取当前 die 的左右耦合波导记录</span></div><div class="waveguide-grid">{waveguide_html}</div></div></section>
<section><div class="inner"><div class="section-head"><h2>偏振与模式家族</h2><span class="section-note">人工分配：Q={esc(q_items[0]['polarization_display'])}，Q'={esc(q_items[1]['polarization_display'])}；仅当前 TE/TM 成对标记用于偏振排序</span></div><div class="polarization-grid">{polarization_html}</div><div class="plot-grid large-scan-plot-grid">{large_scan_plot_html}</div><div class="plot-grid">{plot_html}</div><div class="plot-grid q-plot-grid">{q_plot_html}</div></div></section>
<section><div class="inner"><div class="section-head"><h2>物理阵列 · {esc(array_shape_label)}</h2><span class="section-note">观察、热调谐归属和梳齿校验状态</span></div><div class="array-scroll"><div class="array-map" style="--array-columns:{array_columns}">{cavity_tiles}</div></div></div></section>
<section><div class="inner"><div class="section-head"><h2>梳齿对齐与噪声测量</h2><span class="section-note">读取已有运行记录，不触发重新对齐</span></div><div class="alignment-summary"><div><span>中心波长</span><strong>{esc(fmt(plan.get('selected_center_wavelength_nm'),6,' nm'))}</strong></div><div><span>梳齿间隔</span><strong>{esc(fmt(plan.get('comb_spacing_ghz'),2,' GHz'))}</strong></div><div><span>参与 mu</span><strong>{esc(', '.join(str(value) for value in selected_modes) or '--')}</strong></div><div><span>未通过</span><strong>{esc(failed_text if checked else '--')}</strong></div></div>{alignment_content}<div class="plot-grid alignment-plot-grid">{alignment_plot_html}</div><div class="evidence-links"><strong>噪声谱：</strong><span>{esc(noise_summary)}</span>{link(noise_url,'打开噪声谱对比')}</div></div></section>
<section class="evidence-band"><div class="inner"><div class="section-head"><h2>证据入口</h2><span class="section-note">card 是索引，不替代原始记录</span></div><div class="evidence-links">{evidence}</div></div></section>{plot_runtime}</body></html>"""


def main(argv: Iterable[str] | None = None) -> int:
    args = parse_args(argv)
    output = (args.output or args.results_root / args.chip / args.die / "array_die_card.html").resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(build_card(args.results_root, args.chip, args.die, output), encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
