"""Array experiment records and report publication; no device operations."""
from __future__ import annotations
from a221_workbench._shared.paths import configuration_dir
from typing import Any
from pathlib import Path

import base64

import fnmatch

import json

import os

import re

import shutil

import tempfile

import threading

import time

from datetime import datetime

from pathlib import Path

from typing import Any

from a221_workbench.tasks.array_die_card import build_card as build_array_die_card_html

from a221_workbench.tasks.analysis.power import calculate_optical_power

from a221_workbench._shared.runtime import write_json_atomic as core_write_json_atomic


CONFIG_FILE = configuration_dir('array_cavity_dashboard') / 'config.local.json'


CONFIG_EXAMPLE = configuration_dir('array_cavity_dashboard') / 'config' / "config.local.example.json"


OBSERVATION_FILE = "observation.json"


ELECTRODE_FILE = "electrode_resistance.json"


FAMILY_ASSIGNMENT_FILE = "mode_family_assignment.json"


POLARIZATION_MANIFEST_FILE = "polarization_manifest.json"


OPTICAL_POWER_FILE = "optical_power.json"


Q_BY_MODE_FILE = "q_by_mode.csv"


ARRAY_DIE_CARD_STATE_FILE = "array_die_card_state.json"


EXPERIMENT_CONTEXT_FILE = "experiment_context.json"


README_FILE = "README.md"


README_START = "<!-- ARRAY_CAVITY_DASHBOARD:OBSERVATION_START -->"


README_END = "<!-- ARRAY_CAVITY_DASHBOARD:OBSERVATION_END -->"


ELECTRODE_START = "<!-- ARRAY_CAVITY_DASHBOARD:ELECTRODE_START -->"


ELECTRODE_END = "<!-- ARRAY_CAVITY_DASHBOARD:ELECTRODE_END -->"


VALID_NAME_RE = re.compile(r"^[A-Za-z0-9_.\-\u4e00-\u9fff]+$")


POLARIZATION_Q_SLOTS = ("Q", "Q'")


POLARIZATION_LABELS = {"TE", "TM"}


POLARIZATION_Q_MEASUREMENT_DECISIONS = {"undecided", "continue", "stop"}


POLARIZATION_THERMAL_TUNING_DECISIONS = {"undecided", "proceed", "skip"}


NON_DIE_DIR_NAMES = {
    "figures",
    "figure",
    "images",
    "image",
    "plots",
    "plot",
    "q",
    "thermal_tuning",
    "scripts",
    "cache",
    "__pycache__",
}


NON_CHIP_DIR_NAMES = NON_DIE_DIR_NAMES | {"instrument_checks"}


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif"}


MAX_UPLOAD_BYTES = 25 * 1024 * 1024


POLARIZATION_MANIFEST_LOCK = threading.Lock()


OBSERVATION_RECORD_LOCK = threading.RLock()


DEFAULT_CONFIG: dict[str, Any] = {
    "listen_host": "127.0.0.1",
    "listen_port": 7890,
    "data_root": "",
    "rp_type": "pyrpl_bridge",
    "bridge_base": "http://127.0.0.1:7870",
    "rp_device_id": "",
    "rp_hostname": "RP-f0f1bf",
    "laser_type": "toptica_tcp",
    "laser_serial": "",
    "weiyuan_port": "COM5",
    "laser_host": "192.168.1.13",
    "toptica_python": "",
    "scope_type": "tektronix_mso66b",
    "scope_serial": "",
    "scope_resource": "TCPIP::192.168.1.32::INSTR",
    "trigger_channel": "1",
    "trans_channel": "2",
    "mzi_channel": "3",
    "mzi_d1_mhz": 40.44357,
    "array_min_depth": None,
    "fine_trigger_channel": "4",
    "fine_trigger_level_v": "0",
    "fine_trigger_slope": "negative",
    "fine_horizontal_delay_s": "",
    "fine_arc_factor_v_per_v": 25.0,
    "thermal_move_center_after_jump": True,
    "thermal_move_center_branch": "negative",
    "thermal_move_center_tolerance_v": 0.03,
    "thermal_move_center_gain": 0.8,
    "thermal_move_center_max_step_v": 3.0,
    "thermal_move_center_iterations": 2,
    "sgm_ssh_user": "root",
    "sgm_ssh_host": "",
    "sgm_remote_dir": "/root/sgm5348_control",
    "sgm_vref_v": 2.048,
    "sgm_pcb_map": "legacy16",
    "sgm_cavity_to_out": None,
    "sgm_enabled_cavities": None,
    "sgm_max_voltage_v": 2.0,
    "sgm_auto_assignment_voltage_step_v": 0.05,
    "sgm_auto_assignment_max_voltage_v": 8.0,
    "sgm_service_url": "",
    "sgm_service_token": "",
    "sgm_service_timeout_s": 1.5,
    "sgm_service_autorestart": True,
    "quick_probe_timeout_s": 300.0,
    "comb_reconstruction_min_redshift_margin_ghz": 3.2,
    "comb_reconstruction_initial_approach_guard_ghz": 1.6,
    "comb_reconstruction_verify_tolerance_mzi_periods": 3.0,
    "comb_reconstruction_verify_search_half_ghz": 2.0,
    "comb_reconstruction_verify_min_adjust_step_v": 0.002,
    "comb_reconstruction_verify_settle_s": 0.08,
}


def load_json_file(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    if not path.exists():
        return dict(default)
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return dict(default)
    if not isinstance(data, dict):
        return dict(default)
    result = dict(default)
    result.update(data)
    return result


def ensure_config_file() -> None:
    if CONFIG_FILE.exists():
        return
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    if CONFIG_EXAMPLE.exists():
        CONFIG_FILE.write_text(CONFIG_EXAMPLE.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")


def expand_path(text: str | None) -> Path | None:
    raw = str(text or "").strip()
    if not raw:
        return None
    expanded = os.path.expanduser(os.path.expandvars(raw))
    if "%" in expanded:
        return None
    return Path(expanded)


def read_config() -> dict[str, Any]:
    ensure_config_file()
    config = load_json_file(CONFIG_FILE, DEFAULT_CONFIG)
    if config.get("laser_type") == "toptica_serial":
        config["laser_type"] = "toptica_tcp"
    config.pop("laser_port", None)
    return config


def save_config(config: dict[str, Any]) -> dict[str, Any]:
    current = read_config()
    for key in DEFAULT_CONFIG:
        if key in config:
            current[key] = config[key]
    CONFIG_FILE.write_text(json.dumps(current, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return current


def data_root(config: dict[str, Any]) -> Path | None:
    return expand_path(str(config.get("data_root") or ""))


def validate_name(name: str, kind: str) -> str:
    value = str(name or "").strip()
    if not value:
        raise ValueError(f"{kind} 不能为空")
    if not VALID_NAME_RE.match(value):
        raise ValueError(f"{kind} 只能包含中文、英文、数字、下划线、短横线和点号")
    if value in {".", ".."}:
        raise ValueError(f"{kind} 不合法")
    return value


def require_root(config: dict[str, Any]) -> Path:
    root = data_root(config)
    if root is None:
        raise ValueError("请先在仪器设置里配置外部 results 数据根目录")
    if not root.exists():
        raise FileNotFoundError(f"数据根目录不存在: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"数据根不是目录: {root}")
    return root


def chip_dir(config: dict[str, Any], chip: str, *, create: bool = False) -> Path:
    root = require_root(config)
    name = validate_name(chip, "chip")
    path = root / name
    if create:
        path.mkdir(parents=True, exist_ok=True)
        ensure_readme(path, f"# {name}\n")
    if not path.exists():
        raise FileNotFoundError(f"chip 不存在: {name}")
    return path


def die_dir(config: dict[str, Any], chip: str, die: str, *, create: bool = False) -> Path:
    base = chip_dir(config, chip, create=create)
    name = validate_name(die, "die")
    path = base / name
    if create:
        path.mkdir(parents=True, exist_ok=True)
        ensure_readme(path, f"# {chip} / {die}\n")
        (path / "images" / "observations").mkdir(parents=True, exist_ok=True)
    if not path.exists():
        raise FileNotFoundError(f"die 不存在: {chip}/{die}")
    return path


def ensure_readme(directory: Path, initial_text: str) -> None:
    path = directory / README_FILE
    if not path.exists():
        path.write_text(initial_text.rstrip() + "\n", encoding="utf-8")


def list_chips(config: dict[str, Any]) -> list[str]:
    root = data_root(config)
    if root is None or not root.exists():
        return []
    return list_chips_at_root(root)


def list_chips_at_root(root: Path) -> list[str]:
    chips: list[str] = []
    for path in root.iterdir():
        if not path.is_dir():
            continue
        lowered = path.name.lower()
        if lowered in NON_CHIP_DIR_NAMES or lowered.startswith("."):
            continue
        chips.append(path.name)
    return sorted(chips, key=natural_key)


def list_dies(config: dict[str, Any], chip: str) -> list[str]:
    base = chip_dir(config, chip)
    return list_dies_at_chip_dir(base)


def list_dies_at_chip_dir(base: Path) -> list[str]:
    dies: list[str] = []
    for path in base.iterdir():
        if not path.is_dir():
            continue
        name = path.name
        lowered = name.lower()
        if lowered in NON_DIE_DIR_NAMES or lowered.startswith("."):
            continue
        if not re.match(r"^die[A-Za-z0-9_.-]*$", lowered):
            continue
        dies.append(name)
    return sorted(dies, key=natural_key)


def reference_results_root(value: object) -> Path:
    root = expand_path(str(value or ""))
    if root is None:
        raise ValueError("请选择参考 die 所在的 results 数据根目录")
    root = root.resolve()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"参考 results 数据根目录不存在: {root}")
    return root


def _path_is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _copy_experiment_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _copy_experiment_tree(source: Path, target: Path, *, exclude_runtime: bool = False) -> None:
    if not source.exists() or not source.is_dir():
        return
    ignore = (
        shutil.ignore_patterns("progress.json", "runtime.json", "*.tmp", "*.partial")
        if exclude_runtime
        else None
    )
    shutil.copytree(source, target, copy_function=shutil.copy2, ignore=ignore)


def create_experiment_workspace(payload: dict[str, Any]) -> dict[str, Any]:
    source_root = reference_results_root(payload.get("reference_results_root"))
    chip = validate_name(str(payload.get("reference_chip") or ""), "chip")
    die = validate_name(str(payload.get("reference_die") or ""), "die")
    source_chip = source_root / chip
    source_die = source_chip / die
    if not source_die.exists() or not source_die.is_dir():
        raise FileNotFoundError(f"参考 die 不存在: {source_die}")
    design_path = source_chip / "array_design.json"
    if not design_path.exists() or not design_path.is_file():
        raise FileNotFoundError(f"参考 chip 缺少 array_design.json: {design_path}")

    target_workspace = expand_path(str(payload.get("experiment_dir") or ""))
    if target_workspace is None:
        raise ValueError("请填写独立实验目录")
    target_workspace = target_workspace.resolve()
    if target_workspace.exists():
        if not target_workspace.is_dir():
            raise NotADirectoryError(f"实验路径不是目录: {target_workspace}")
        if any(target_workspace.iterdir()):
            raise FileExistsError(f"实验目录必须为空，未写入任何文件: {target_workspace}")
    elif not target_workspace.parent.exists():
        raise FileNotFoundError(f"实验目录的上级目录不存在: {target_workspace.parent}")
    if _path_is_within(target_workspace, source_root) or _path_is_within(source_root, target_workspace):
        raise ValueError("独立实验目录不能与参考 results 目录互相包含")

    experiment_name = str(payload.get("experiment_name") or target_workspace.name).strip()
    if not experiment_name:
        experiment_name = target_workspace.name
    staging = Path(tempfile.mkdtemp(prefix=f".{target_workspace.name}.creating_", dir=str(target_workspace.parent)))
    try:
        staged_results = staging / "results"
        staged_chip = staged_results / chip
        staged_die = staged_chip / die
        staged_die.mkdir(parents=True, exist_ok=True)

        _copy_experiment_file(design_path, staged_chip / design_path.name)
        for filename in (
            README_FILE,
            OBSERVATION_FILE,
            ELECTRODE_FILE,
            FAMILY_ASSIGNMENT_FILE,
            POLARIZATION_MANIFEST_FILE,
        ):
            source = source_die / filename
            if source.exists() and source.is_file():
                _copy_experiment_file(source, staged_die / filename)
        _copy_experiment_tree(source_die / "images" / "observations", staged_die / "images" / "observations")
        for q_slot in POLARIZATION_Q_SLOTS:
            _copy_experiment_tree(source_die / q_slot, staged_die / q_slot)
        _copy_experiment_tree(
            source_die / "thermal_tuning" / "current_fsr_assignment",
            staged_die / "thermal_tuning" / "current_fsr_assignment",
            exclude_runtime=True,
        )
        _copy_experiment_tree(
            source_die / "thermal_tuning" / "Q_prime" / "current_fsr_assignment",
            staged_die / "thermal_tuning" / "Q_prime" / "current_fsr_assignment",
            exclude_runtime=True,
        )

        copied_files = sorted(
            path.relative_to(staged_results).as_posix()
            for path in staged_results.rglob("*")
            if path.is_file()
        )
        copied_file_fingerprints = {}
        for relative_path in copied_files:
            stat = (staged_results / relative_path).stat()
            copied_file_fingerprints[relative_path] = {
                "size": int(stat.st_size),
                "mtime_ns": int(stat.st_mtime_ns),
            }
        warnings: list[str] = []
        for q_slot in POLARIZATION_Q_SLOTS:
            if not (staged_die / q_slot / Q_BY_MODE_FILE).exists():
                warnings.append(f"{q_slot} 未找到 {Q_BY_MODE_FILE}，该偏振没有可继承的 Q 基线")
        if not (staged_die / ELECTRODE_FILE).exists():
            warnings.append(f"未找到 {ELECTRODE_FILE}，没有可继承的电阻基线")

        final_results = target_workspace / "results"
        context = {
            "schema_version": 1,
            "kind": "array_cavity_reference_experiment",
            "experiment_name": experiment_name,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "results_root": str(final_results),
            "active_chip": chip,
            "active_die": die,
            "reference": {
                "results_root": str(source_root),
                "chip": chip,
                "die": die,
                "directory": str(source_die.resolve()),
                "access": "read_only_source",
            },
            "inheritance": {
                "strategy": "copied_baseline_snapshot",
                "copied_files": copied_files,
                "copied_file_fingerprints": copied_file_fingerprints,
                "includes": [
                    "array design and cavity/electrode mapping",
                    "observation record and observation images",
                    "electrode resistance baseline",
                    "Q and Q-prime large-scan/Q/family data",
                    "thermal tuning assignment and efficiency baseline",
                ],
                "excludes": [
                    "current optical power",
                    "current DAC voltage state",
                    "coupling runs",
                    "comb reconstruction and alignment runs",
                    "noise measurements",
                    "generated die card",
                    "active progress/runtime files",
                ],
            },
            "warnings": warnings,
        }
        (staged_results / EXPERIMENT_CONTEXT_FILE).write_text(
            json.dumps(context, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        if target_workspace.exists():
            target_workspace.rmdir()
        staging.replace(target_workspace)
    except Exception:
        if staging.exists() and staging.parent.resolve() == target_workspace.parent.resolve():
            shutil.rmtree(staging, ignore_errors=True)
        raise

    return {
        "ok": True,
        "message": "独立实验工作区已创建；参考 die 保持只读，后续数据写入新 results 目录。",
        "experiment_dir": str(target_workspace),
        "data_root": str(target_workspace / "results"),
        "chip": chip,
        "die": die,
        "context": context,
        "warnings": context["warnings"],
    }


def natural_key(text: str) -> list[int | str]:
    parts = re.split(r"(\d+)", str(text))
    return [int(part) if part.isdigit() else part.lower() for part in parts]


def load_array_design(config: dict[str, Any], chip: str) -> dict[str, Any]:
    base = chip_dir(config, chip)
    path = base / "array_design.json"
    if not path.exists():
        raise FileNotFoundError(f"缺少 chip 级 array_design.json: {path}")
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"array_design.json 不是 JSON object: {path}")
    data["_path"] = str(path)
    return data


def physical_position_map(design: dict[str, Any]) -> dict[str, dict[str, int]]:
    out: dict[str, dict[str, int]] = {}
    rows = design.get("physical_order") if isinstance(design.get("physical_order"), list) else []
    for row_index, row in enumerate(rows, start=1):
        if not isinstance(row, list):
            continue
        for col_index, cavity in enumerate(row, start=1):
            out[str(cavity)] = {"row": row_index, "col": col_index}
    return out


def optical_index_map(design: dict[str, Any]) -> dict[str, int]:
    order = design.get("optical_path_order") if isinstance(design.get("optical_path_order"), list) else []
    return {str(cavity): index for index, cavity in enumerate(order, start=1)}


def die_design_info(design: dict[str, Any], die: str) -> dict[str, Any]:
    matrix = design.get("die_design_matrix")
    if isinstance(matrix, dict) and isinstance(matrix.get(die), dict):
        return dict(matrix[die])
    patterns = design.get("radius_step_nm_by_die_pattern")
    if isinstance(patterns, dict):
        for pattern, radius_step in patterns.items():
            if fnmatch.fnmatch(die, str(pattern)):
                return {"radius_step_nm": radius_step}
    return {}


def electrode_sort_key(electrode: str) -> list[int | str]:
    return natural_key(electrode.lstrip("Ee"))


def electrode_default_rows(design: dict[str, Any], die: str) -> list[dict[str, Any]]:
    mapping = design.get("electrode_to_cavity")
    if not isinstance(mapping, dict) or not mapping:
        return []
    positions = physical_position_map(design)
    optical = optical_index_map(design)
    offsets = design.get("cavity_radius_offset_steps") if isinstance(design.get("cavity_radius_offset_steps"), dict) else {}
    info = die_design_info(design, die)
    radius_step_nm = info.get("radius_step_nm")
    rows: list[dict[str, Any]] = []
    for electrode in sorted((str(key) for key in mapping.keys()), key=electrode_sort_key):
        cavity = str(mapping[electrode])
        pos = positions.get(cavity, {})
        offset_steps = offsets.get(cavity)
        try:
            offset_steps_float = float(offset_steps)
        except (TypeError, ValueError):
            offset_steps_float = None
        try:
            radius_step_float = float(radius_step_nm)
        except (TypeError, ValueError):
            radius_step_float = None
        radius_delta_nm = (
            offset_steps_float * radius_step_float
            if offset_steps_float is not None and radius_step_float is not None
            else None
        )
        rows.append(
            {
                "electrode": electrode,
                "cavity": cavity,
                "physical_row": pos.get("row"),
                "physical_col": pos.get("col"),
                "optical_order": optical.get(cavity),
                "radius_offset_steps": offset_steps_float,
                "radius_step_nm": radius_step_float,
                "radius_delta_nm": radius_delta_nm,
                "gap_um": info.get("gap_um"),
                "metal_width_um": info.get("metal_width_um"),
                "resistance": "",
                "resistance_unit": "Ohm",
                "contact_status": "未检查",
                "note": "",
            }
        )
    return rows


def default_sections(chip: str) -> list[dict[str, Any]]:
    lower = chip.lower()
    count = 16 if "chip9" in lower else 9
    names = ["整体标识", "左侧耦合波导", "右侧耦合波导"] + [f"c{i}" for i in range(1, count + 1)]
    return [{"name": name, "status": "未检查", "text": "", "images": [], "image_paths": ""} for name in names]


def empty_observation(chip: str, die: str) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": None,
        "overall_observation": "",
        "sections": default_sections(chip),
    }


def observation_path(directory: Path) -> Path:
    return directory / OBSERVATION_FILE


def load_observation(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    directory = die_dir(config, chip, die)
    path = observation_path(directory)
    if not path.exists():
        return empty_observation(chip, die)
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        return empty_observation(chip, die)
    data.setdefault("schema_version", 1)
    data.setdefault("chip", chip)
    data.setdefault("die", die)
    data.setdefault("updated_at", None)
    data.setdefault("overall_observation", "")
    data.setdefault("sections", default_sections(chip))
    return data


def safe_relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def copy_observation_images(directory: Path, section: dict[str, Any]) -> tuple[list[str], list[str]]:
    copied: list[str] = []
    missing: list[str] = []
    existing = section.get("images")
    if isinstance(existing, list):
        for item in existing:
            text = str(item).strip().replace("\\", "/")
            if text.startswith("images/"):
                copied.append(text)
    image_paths_text = str(section.get("image_paths") or "")
    sources = [line.strip() for line in image_paths_text.splitlines() if line.strip()]
    target_dir = directory / "images" / "observations"
    target_dir.mkdir(parents=True, exist_ok=True)
    for raw in sources:
        if raw.replace("\\", "/").startswith("images/"):
            if raw.replace("\\", "/") not in copied:
                copied.append(raw.replace("\\", "/"))
            continue
        source = expand_path(raw)
        if source is None or not source.exists() or not source.is_file():
            missing.append(raw)
            continue
        if source.suffix.lower() not in IMAGE_EXTENSIONS:
            missing.append(raw)
            continue
        base = re.sub(r"[^A-Za-z0-9_.-]+", "_", source.stem).strip("_") or "image"
        target = target_dir / f"{base}{source.suffix.lower()}"
        counter = 2
        while target.exists() and target.resolve() != source.resolve():
            target = target_dir / f"{base}_{counter}{source.suffix.lower()}"
            counter += 1
        if target.resolve() != source.resolve():
            shutil.copy2(source, target)
        rel = safe_relative(target, directory)
        if rel not in copied:
            copied.append(rel)
    return copied, missing


def image_suffix(filename: str, mime: str) -> str:
    suffix = Path(str(filename or "")).suffix.lower()
    if suffix in IMAGE_EXTENSIONS:
        return suffix
    return {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/gif": ".gif",
        "image/bmp": ".bmp",
        "image/tiff": ".tif",
    }.get(str(mime or "").split(";")[0].lower(), ".png")


def save_uploaded_observation_image(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    data_url = str(payload.get("data_url") or "")
    match = re.match(r"^data:(image/[A-Za-z0-9.+-]+);base64,(.*)$", data_url, flags=re.S)
    if not match:
        raise ValueError("粘贴内容不是可保存的图片")
    mime = match.group(1).lower()
    raw = base64.b64decode(match.group(2), validate=True)
    if len(raw) > MAX_UPLOAD_BYTES:
        raise ValueError(f"图片太大，超过 {MAX_UPLOAD_BYTES // 1024 // 1024} MB")
    with OBSERVATION_RECORD_LOCK:
        observation = load_observation(config, chip, die)
        if "base_updated_at" not in payload:
            raise ValueError("图片上传请求缺少观察记录版本；请刷新页面后重试")
        if payload.get("base_updated_at") != observation.get("updated_at"):
            raise ValueError("观察记录已在其他页面更新；图片未上传，请刷新当前 die 后重试")
        target_dir = directory / "images" / "observations"
        target_dir.mkdir(parents=True, exist_ok=True)
        name_hint = str(payload.get("section") or payload.get("filename") or "image")
        stem = re.sub(r"[^A-Za-z0-9_.\-\u4e00-\u9fff]+", "_", Path(name_hint).stem).strip("._-") or "image"
        suffix = image_suffix(str(payload.get("filename") or ""), mime)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        target = target_dir / f"{timestamp}_{stem}{suffix}"
        counter = 2
        while target.exists():
            target = target_dir / f"{timestamp}_{stem}_{counter}{suffix}"
            counter += 1
        target.write_bytes(raw)
        rel = safe_relative(target, directory)
        try:
            section_name = str(payload.get("section") or "").strip()
            sections = observation.get("sections") if isinstance(observation.get("sections"), list) else []
            section = next(
                (
                    item
                    for item in sections
                    if isinstance(item, dict) and str(item.get("name") or "").strip() == section_name
                ),
                None,
            )
            if section is None:
                raise ValueError(f"当前观察记录中不存在对象: {section_name or '未指定'}")
            images = section.get("images") if isinstance(section.get("images"), list) else []
            normalized_images = [str(item).replace("\\", "/") for item in images if str(item).strip()]
            if rel not in normalized_images:
                normalized_images.append(rel)
            section["images"] = normalized_images
            observation["updated_at"] = datetime.now().isoformat(timespec="microseconds")
            persist_observation(directory, observation)
            readme = directory / README_FILE
        except Exception:
            target.unlink(missing_ok=True)
            raise
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "rel": rel,
        "path": str(target),
        "mime": mime,
        "size": len(raw),
        "observation_path": str(observation_path(directory)),
        "readme_path": str(readme),
        "updated_at": observation["updated_at"],
    }


def delete_observation_image(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    rel = str(payload.get("rel") or "").strip().replace("\\", "/")
    if not rel.startswith("images/observations/") or ".." in Path(rel).parts:
        raise ValueError("只能删除当前 die 的 images/observations 里的图片")
    directory = die_dir(config, chip, die)
    target = (directory / rel).resolve()
    target.relative_to((directory / "images" / "observations").resolve())
    with OBSERVATION_RECORD_LOCK:
        observation = load_observation(config, chip, die)
        if "base_updated_at" not in payload:
            raise ValueError("图片删除请求缺少观察记录版本；请刷新页面后重试")
        if payload.get("base_updated_at") != observation.get("updated_at"):
            raise ValueError("观察记录已在其他页面更新；图片未删除，请刷新当前 die 后重试")
        if target.exists() and not target.is_file():
            raise ValueError(f"不是图片文件: {rel}")
        tombstone: Path | None = None
        if target.exists():
            tombstone = target.with_name(
                f".{target.name}.{os.getpid()}.{threading.get_ident()}.delete"
            )
            target.replace(tombstone)
        try:
            sections = observation.get("sections") if isinstance(observation.get("sections"), list) else []
            for section in sections:
                if not isinstance(section, dict):
                    continue
                images = section.get("images") if isinstance(section.get("images"), list) else []
                section["images"] = [
                    str(item).replace("\\", "/")
                    for item in images
                    if str(item).replace("\\", "/") != rel
                ]
            observation["updated_at"] = datetime.now().isoformat(timespec="microseconds")
            persist_observation(directory, observation)
            readme = directory / README_FILE
        except Exception:
            if tombstone is not None and tombstone.exists() and not target.exists():
                tombstone.replace(target)
            raise
        deleted = tombstone is not None
        cleanup_error = None
        if tombstone is not None:
            try:
                tombstone.unlink(missing_ok=True)
            except OSError as exc:
                cleanup_error = repr(exc)
    return {
        "ok": True,
        "chip": chip,
        "die": die,
        "rel": rel,
        "deleted": deleted,
        "cleanup_error": cleanup_error,
        "path": str(target),
        "observation_path": str(observation_path(directory)),
        "readme_path": str(readme),
        "updated_at": observation["updated_at"],
    }


def normalize_observation(config: dict[str, Any], payload: dict[str, Any]) -> tuple[Path, dict[str, Any], list[str]]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    missing_images: list[str] = []
    normalized_sections: list[dict[str, Any]] = []
    sections = payload.get("sections") if isinstance(payload.get("sections"), list) else []
    for raw_section in sections:
        if not isinstance(raw_section, dict):
            continue
        name = str(raw_section.get("name") or "").strip()
        if not name:
            continue
        section = {
            "name": name,
            "status": str(raw_section.get("status") or "未检查"),
            "text": str(raw_section.get("text") or ""),
            "image_paths": str(raw_section.get("image_paths") or ""),
            "images": raw_section.get("images") if isinstance(raw_section.get("images"), list) else [],
        }
        images, missing = copy_observation_images(directory, section)
        section["images"] = images
        missing_images.extend(missing)
        normalized_sections.append(section)
    if not normalized_sections:
        normalized_sections = default_sections(chip)
    observation = {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": datetime.now().isoformat(timespec="microseconds"),
        "overall_observation": str(payload.get("overall_observation") or ""),
        "sections": normalized_sections,
    }
    return directory, observation, missing_images


def save_observation(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    with OBSERVATION_RECORD_LOCK:
        chip = validate_name(str(payload.get("chip") or ""), "chip")
        die = validate_name(str(payload.get("die") or ""), "die")
        existing = load_observation(config, chip, die)
        if "base_updated_at" not in payload:
            raise ValueError("观察记录保存请求缺少版本信息；请刷新页面后重试")
        if payload.get("base_updated_at") != existing.get("updated_at"):
            raise ValueError(
                "观察记录已被图片操作或其他页面更新；当前未保存编辑仍保留在页面中，"
                "请先刷新当前 die 的记录后再决定如何合并"
            )
        directory, observation, missing_images = normalize_observation(config, payload)
        persist_observation(directory, observation)
        readme = directory / README_FILE
    return {
        "ok": True,
        "chip": observation["chip"],
        "die": observation["die"],
        "observation_path": str(observation_path(directory)),
        "readme_path": str(readme),
        "missing_images": missing_images,
        "observation": observation,
    }


def electrode_path(directory: Path) -> Path:
    return directory / ELECTRODE_FILE


def electrode_number(electrode: str) -> int | None:
    match = re.search(r"(\d+)", electrode)
    return int(match.group(1)) if match else None


def probe_for_electrode(electrode: str, e1_probe: int | None) -> int | None:
    number = electrode_number(electrode)
    if number is None or e1_probe is None:
        return None
    return e1_probe + number - 1


def _parse_sgm_routing(
    config: dict[str, Any], cavities: set[str],
) -> tuple[dict[str, int] | None, set[str] | None]:
    """Validate cavity -> PCB OUT labels, independently of the DAC PCB profile."""
    mapping = config.get("sgm_cavity_to_out")
    enabled = config.get("sgm_enabled_cavities")
    if mapping is None:
        if enabled is not None:
            raise ValueError("sgm_enabled_cavities 必须配合显式 sgm_cavity_to_out 使用")
        return None, None
    if not isinstance(mapping, dict):
        raise ValueError("sgm_cavity_to_out 必须是腔号到 PCB OUT 编号的 object")
    used_outputs: set[int] = set()
    for cavity, out in mapping.items():
        if cavity not in cavities:
            raise ValueError(f"sgm_cavity_to_out 包含设计中不存在的腔号: {cavity!r}")
        if type(out) is not int or not 0 <= out <= 15:
            raise ValueError(f"{cavity} 的 PCB OUT 必须是 0..15 的整数，收到 {out!r}")
        if out in used_outputs:
            raise ValueError(f"sgm_cavity_to_out 重复使用 PCB OUT{out}")
        used_outputs.add(out)
    if enabled is None:
        return dict(mapping), None
    if not isinstance(enabled, list):
        raise ValueError("sgm_enabled_cavities 必须是已映射腔号的列表")
    enabled_set: set[str] = set()
    for cavity in enabled:
        if not isinstance(cavity, str) or cavity not in mapping:
            raise ValueError(f"sgm_enabled_cavities 包含未映射的腔号: {cavity!r}")
        if cavity in enabled_set:
            raise ValueError(f"sgm_enabled_cavities 包含重复腔号: {cavity!r}")
        enabled_set.add(cavity)
    return dict(mapping), enabled_set


def sgm_entry_from_electrode(row: dict[str, Any], *, good_only: bool = True) -> dict[str, Any]:
    """Resolve a loaded row's route and permission without changing contact evidence."""
    probe_value = finite_float(row.get("probe"))
    probe = int(round(probe_value)) if probe_value is not None else None
    out = probe - 1 if probe is not None else None
    contact = str(row.get("contact_status") or "")
    allowed = "接触良好" in contact if good_only else "开路" not in contact
    explicit = row.get("routing_source") == "sgm_cavity_to_out"
    enabled = row.get("enabled_by_config") if explicit else None
    if enabled is not None:
        allowed = enabled is True
    valid_route = probe is not None and 1 <= probe <= 16 and out is not None and 0 <= out <= 15
    usable = bool(valid_route and allowed)
    reason = "" if usable else "电极没有接触良好记录，或缺少有效 probe/SGM out 映射"
    if explicit and not valid_route:
        reason = "该腔没有显式 PCB OUT 映射"
    elif explicit and enabled is False:
        reason = "该腔未列入 sgm_enabled_cavities 使用声明"
    entry = {
        "cavity": str(row.get("cavity") or ""),
        "electrode": str(row.get("electrode") or ""),
        "probe": probe,
        "out": out,
        "contact_status": contact,
        "usable": usable,
        "reason": reason,
    }
    if explicit:
        entry.update(
            routing_source="sgm_cavity_to_out",
            availability_source="sgm_enabled_cavities" if enabled is not None else "contact_status",
            enabled_by_config=enabled,
        )
    return entry


def apply_saved_electrode_values(rows: list[dict[str, Any]], saved: dict[str, Any]) -> list[dict[str, Any]]:
    saved_rows = saved.get("rows") if isinstance(saved.get("rows"), list) else []
    by_electrode = {
        str(row.get("electrode")): row
        for row in saved_rows
        if isinstance(row, dict) and row.get("electrode")
    }
    for row in rows:
        saved_row = by_electrode.get(str(row.get("electrode")))
        if not saved_row:
            continue
        for key in ("resistance", "resistance_unit", "contact_status", "note"):
            if key in saved_row:
                row[key] = saved_row[key]
    return rows


def electrode_record_default(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    design = load_array_design(config, chip)
    rows = electrode_default_rows(design, die)
    return {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": None,
        "design_path": design.get("_path"),
        "probe_count": 16,
        "e1_probe": "",
        "rows": rows,
        "design_summary": electrode_design_summary(design, die),
    }


def load_electrode_record(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    directory = die_dir(config, chip, die)
    record = electrode_record_default(config, chip, die)
    mapping, enabled = _parse_sgm_routing(config, {row["cavity"] for row in record["rows"]})
    path = electrode_path(directory)
    if path.exists():
        saved = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(saved, dict):
            record["updated_at"] = saved.get("updated_at")
            record["probe_count"] = saved.get("probe_count", 16)
            record["e1_probe"] = saved.get("e1_probe", "")
            record["rows"] = apply_saved_electrode_values(record["rows"], saved)
    e1_probe_value = record.get("e1_probe")
    try:
        e1_probe_int = int(e1_probe_value) if str(e1_probe_value).strip() else None
    except (TypeError, ValueError):
        e1_probe_int = None
    for row in record["rows"]:
        if mapping is None:
            row["probe"] = probe_for_electrode(str(row.get("electrode")), e1_probe_int)
        else:
            out = mapping.get(row["cavity"])
            row["out"] = out
            row["probe"] = out + 1 if out is not None else None
            row["routing_source"] = "sgm_cavity_to_out"
            row["enabled_by_config"] = row["cavity"] in enabled if enabled is not None else None
    return record


def electrode_design_summary(design: dict[str, Any], die: str) -> dict[str, Any]:
    info = die_design_info(design, die)
    return {
        "chip": design.get("chip"),
        "array_shape": design.get("array_shape"),
        "baseline_cavity": design.get("baseline_cavity"),
        "baseline_radius_um": design.get("baseline_radius_um"),
        "radius_step_nm": info.get("radius_step_nm"),
        "gap_um": info.get("gap_um"),
        "metal_width_um": info.get("metal_width_um"),
        "electrode_count": len(design.get("electrode_to_cavity") or {}),
    }


def normalize_electrode_record(config: dict[str, Any], payload: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    design = load_array_design(config, chip)
    rows = electrode_default_rows(design, die)
    by_electrode = {str(row.get("electrode")): row for row in rows}
    submitted = payload.get("rows") if isinstance(payload.get("rows"), list) else []
    for raw in submitted:
        if not isinstance(raw, dict):
            continue
        electrode = str(raw.get("electrode") or "")
        row = by_electrode.get(electrode)
        if row is None:
            continue
        row["resistance"] = str(raw.get("resistance") or "").strip()
        row["resistance_unit"] = str(raw.get("resistance_unit") or "Ohm")
        row["contact_status"] = str(raw.get("contact_status") or "未检查")
        row["note"] = str(raw.get("note") or "")
    e1_probe_raw = str(payload.get("e1_probe") or "").strip()
    e1_probe: int | str = ""
    if e1_probe_raw:
        e1_probe = int(float(e1_probe_raw))
        if e1_probe < 1 or e1_probe > 16:
            raise ValueError("E1 对应探针编号必须在 1 到 16 之间")
    for row in rows:
        row["probe"] = probe_for_electrode(str(row.get("electrode")), e1_probe if isinstance(e1_probe, int) else None)
        if row["probe"] is not None and row["probe"] > 16:
            raise ValueError("按当前 E1 探针编号推算，部分电极超过 16 个探针范围")
    record = {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "design_path": design.get("_path"),
        "probe_count": 16,
        "e1_probe": e1_probe,
        "rows": rows,
        "design_summary": electrode_design_summary(design, die),
    }
    return directory, record


def save_electrode_record(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    directory, record = normalize_electrode_record(config, payload)
    electrode_path(directory).write_text(
        json.dumps(record, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    readme = update_electrode_readme(directory, record)
    return {
        "ok": True,
        "chip": record["chip"],
        "die": record["die"],
        "electrode_path": str(electrode_path(directory)),
        "readme_path": str(readme),
        "record": record,
    }


def normalize_q_slot(value: object) -> str:
    q_slot = str(value or "Q").strip()
    if q_slot not in POLARIZATION_Q_SLOTS:
        raise ValueError(f"偏振数据槽必须是 Q 或 Q'，收到 {q_slot!r}")
    return q_slot


def normalize_polarization_decision(
    value: object,
    allowed: set[str],
    label: str,
    *,
    strict: bool = True,
) -> str:
    decision = str(value or "undecided").strip().lower()
    if decision in {"", "pending", "unknown"}:
        decision = "undecided"
    if decision not in allowed:
        if not strict:
            return "undecided"
        raise ValueError(f"{label} 状态不合法: {decision!r}")
    return decision


def normalize_polarization_decision_reason(value: object, label: str) -> str:
    reason = str(value or "").strip()
    if len(reason) > 500:
        raise ValueError(f"{label}原因不能超过 500 个字符")
    return reason


def q_slot_dir(directory: Path, q_slot: object = "Q") -> Path:
    return directory / normalize_q_slot(q_slot)


def polarization_manifest_path(directory: Path) -> Path:
    return directory / POLARIZATION_MANIFEST_FILE


def q_slot_data_signature(q_dir: Path) -> dict[str, Any]:
    files: dict[str, dict[str, int]] = {}
    for name in ("raw.npz", "array_preanalysis_summary.json", Q_BY_MODE_FILE):
        path = q_dir / name
        if not path.exists() or not path.is_file():
            continue
        stat = path.stat()
        files[name] = {"size": int(stat.st_size), "mtime_ns": int(stat.st_mtime_ns)}
    return {"files": files}


def empty_polarization_manifest(chip: str, die: str) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": None,
        "slots": {
            slot: {
                "polarization": None,
                "assignment_source": None,
                "assigned_at": None,
                "note": "",
                "data_signature": None,
                "q_measurement_decision": "undecided",
                "q_measurement_decision_reason": "",
                "thermal_tuning_decision": "undecided",
                "thermal_tuning_decision_reason": "",
                "workflow_decision_source": None,
                "workflow_decision_updated_at": None,
            }
            for slot in POLARIZATION_Q_SLOTS
        },
    }


def read_polarization_manifest(directory: Path, chip: str, die: str) -> dict[str, Any]:
    record = empty_polarization_manifest(chip, die)
    path = polarization_manifest_path(directory)
    if not path.exists():
        return record
    loaded = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(loaded, dict):
        raise ValueError(f"偏振归属文件不是 JSON object: {path}")
    record.update({key: value for key, value in loaded.items() if key != "slots"})
    loaded_slots = loaded.get("slots") if isinstance(loaded.get("slots"), dict) else {}
    for slot in POLARIZATION_Q_SLOTS:
        raw = loaded_slots.get(slot) if isinstance(loaded_slots.get(slot), dict) else {}
        record["slots"][slot].update(raw)
    record["schema_version"] = 1
    record["chip"] = chip
    record["die"] = die
    return record


def load_polarization_manifest(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    directory = die_dir(config, chip, die, create=True)
    record = read_polarization_manifest(directory, chip, die)
    slots: dict[str, dict[str, Any]] = {}
    for slot in POLARIZATION_Q_SLOTS:
        item = dict(record["slots"][slot])
        q_dir = q_slot_dir(directory, slot)
        current_signature = q_slot_data_signature(q_dir)
        assigned_signature = item.get("data_signature") if isinstance(item.get("data_signature"), dict) else None
        polarization = str(item.get("polarization") or "").upper()
        if polarization not in POLARIZATION_LABELS:
            polarization = ""
        item["polarization"] = polarization or None
        item["q_measurement_decision"] = normalize_polarization_decision(
            item.get("q_measurement_decision"),
            POLARIZATION_Q_MEASUREMENT_DECISIONS,
            "大扫测 Q",
            strict=False,
        )
        item["thermal_tuning_decision"] = normalize_polarization_decision(
            item.get("thermal_tuning_decision"),
            POLARIZATION_THERMAL_TUNING_DECISIONS,
            "热调谐",
            strict=False,
        )
        item["q_measurement_decision_reason"] = str(item.get("q_measurement_decision_reason") or "").strip()
        item["thermal_tuning_decision_reason"] = str(
            item.get("thermal_tuning_decision_reason") or ""
        ).strip()
        item["q_dir"] = str(q_dir)
        item["data_present"] = bool(current_signature["files"])
        item["current_data_signature"] = current_signature
        item["stale"] = bool(polarization and assigned_signature and assigned_signature != current_signature)
        slots[slot] = item
    record["slots"] = slots
    record["manifest_path"] = str(polarization_manifest_path(directory))
    return record


def save_manual_polarization_assignment(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = normalize_q_slot(payload.get("q_slot"))
    polarization = str(payload.get("polarization") or "").strip().upper()
    if polarization in {"", "UNKNOWN", "未知"}:
        polarization = ""
    elif polarization not in POLARIZATION_LABELS:
        raise ValueError("人工偏振归属只能选择未知、TE 或 TM")

    directory = die_dir(config, chip, die, create=True)
    path = polarization_manifest_path(directory)
    with POLARIZATION_MANIFEST_LOCK:
        record = read_polarization_manifest(directory, chip, die)
        if polarization and not bool(payload.get("confirm_duplicate")):
            duplicate_slots = [
                slot
                for slot in POLARIZATION_Q_SLOTS
                if slot != q_slot
                and str(record["slots"][slot].get("polarization") or "").upper() == polarization
            ]
            if duplicate_slots:
                raise ValueError(
                    f"{polarization} 已分配给 {duplicate_slots[0]}；如确为同偏振重复测量，请明确确认重复分配。"
                )

        now = datetime.now().isoformat(timespec="seconds")
        record["updated_at"] = now
        record["slots"][q_slot].update({
            "polarization": polarization or None,
            "assignment_source": "manual" if polarization else None,
            "assigned_at": now if polarization else None,
            "note": str(payload.get("note") or "").strip(),
            "data_signature": q_slot_data_signature(q_slot_dir(directory, q_slot)) if polarization else None,
        })
        write_json_atomic_with_retry(path, record)
    return {
        "ok": True,
        "message": f"已将 {q_slot} 人工标记为 {polarization}" if polarization else f"已清除 {q_slot} 的偏振标记",
        "manifest_path": str(path),
        "record": load_polarization_manifest(config, chip, die),
    }


def save_polarization_workflow_decisions(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    q_slot = normalize_q_slot(payload.get("q_slot"))
    q_decision = normalize_polarization_decision(
        payload.get("q_measurement_decision"),
        POLARIZATION_Q_MEASUREMENT_DECISIONS,
        "大扫测 Q",
    )
    thermal_decision = normalize_polarization_decision(
        payload.get("thermal_tuning_decision"),
        POLARIZATION_THERMAL_TUNING_DECISIONS,
        "热调谐",
    )
    q_reason = normalize_polarization_decision_reason(
        payload.get("q_measurement_decision_reason"),
        "不再大扫测 Q",
    )
    thermal_reason = normalize_polarization_decision_reason(
        payload.get("thermal_tuning_decision_reason"),
        "不做热调谐",
    )
    if q_decision == "stop" and not q_reason:
        raise ValueError("选择“不再大扫测 Q”时必须填写原因")
    if thermal_decision == "skip" and not thermal_reason:
        raise ValueError("选择“不做热调谐”时必须填写原因")
    if q_decision != "stop":
        q_reason = ""
    if thermal_decision != "skip":
        thermal_reason = ""

    directory = die_dir(config, chip, die, create=True)
    path = polarization_manifest_path(directory)
    with POLARIZATION_MANIFEST_LOCK:
        record = read_polarization_manifest(directory, chip, die)
        now = datetime.now().isoformat(timespec="seconds")
        record["updated_at"] = now
        record["slots"][q_slot].update(
            {
                "q_measurement_decision": q_decision,
                "q_measurement_decision_reason": q_reason,
                "thermal_tuning_decision": thermal_decision,
                "thermal_tuning_decision_reason": thermal_reason,
                "workflow_decision_source": "manual",
                "workflow_decision_updated_at": now,
            }
        )
        write_json_atomic_with_retry(path, record)
    return {
        "ok": True,
        "message": f"已更新 {q_slot} 的大扫测 Q / 热调谐决策",
        "manifest_path": str(path),
        "record": load_polarization_manifest(config, chip, die),
    }


def family_assignment_path(directory: Path, q_slot: object = "Q") -> Path:
    normalized = normalize_q_slot(q_slot)
    if normalized == "Q":
        return directory / FAMILY_ASSIGNMENT_FILE
    return q_slot_dir(directory, normalized) / FAMILY_ASSIGNMENT_FILE


def load_family_assignments(config: dict[str, Any], chip: str, die: str, q_slot: object = "Q") -> dict[str, Any]:
    directory = die_dir(config, chip, die, create=True)
    normalized_q_slot = normalize_q_slot(q_slot)
    path = family_assignment_path(directory, normalized_q_slot)
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(data, dict):
            data.setdefault("schema_version", 1)
            data.setdefault("chip", chip)
            data.setdefault("die", die)
            data.setdefault("q_slot", normalized_q_slot)
            data.setdefault("assignments", [])
            return data
    return {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "q_slot": normalized_q_slot,
        "updated_at": None,
        "assignments": [],
    }


def save_family_assignments(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    q_slot = normalize_q_slot(payload.get("q_slot"))
    raw_assignments = payload.get("assignments") if isinstance(payload.get("assignments"), list) else []
    assignments: list[dict[str, Any]] = []
    for raw in raw_assignments:
        if not isinstance(raw, dict):
            continue
        family = str(raw.get("family") or "").strip()
        cavity = str(raw.get("cavity") or "").strip()
        if not family or not cavity:
            continue
        assignments.append(
            {
                "family": family,
                "cavity": cavity,
                "note": str(raw.get("note") or "").strip(),
                "evidence": str(raw.get("evidence") or "").strip(),
                "confidence": str(raw.get("confidence") or "").strip(),
                "status": str(raw.get("status") or "").strip(),
            }
        )
    record = {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "q_slot": q_slot,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "assignments": assignments,
    }
    path = family_assignment_path(directory, q_slot)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"ok": True, "family_assignment_path": str(path), "record": record}


def finite_float(value: object) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed == parsed and parsed not in (float("inf"), float("-inf")) else None


def optical_power_path(directory: Path) -> Path:
    return directory / OPTICAL_POWER_FILE


def build_optical_power_record(chip: str, die: str, payload: dict[str, Any]) -> dict[str, Any]:
    monitor_power_uw = finite_float(payload.get("input_monitor_power_uw"))
    monitor_fraction_raw = finite_float(payload.get("input_monitor_fraction"))
    monitor_fraction = 0.01 if monitor_fraction_raw is None else monitor_fraction_raw
    output_raw = payload.get("output_power_uw")
    output_text = str(output_raw if output_raw is not None else "").strip()
    output_power_uw = finite_float(output_raw) if output_text else None
    if monitor_power_uw is None or monitor_power_uw <= 0:
        raise ValueError("输入光功率必须是大于 0 的有限数值")
    if monitor_fraction <= 0:
        raise ValueError("monitor 分光比例必须大于 0")
    if output_power_uw is not None and output_power_uw < 0:
        raise ValueError("输出光功率不能小于 0")
    power = calculate_optical_power(
        monitor_power_uw,
        output_power_uw,
        input_monitor_fraction=monitor_fraction,
    )
    return {
        "schema_version": 1,
        "chip": chip,
        "die": die,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        **power.as_dict(),
    }


def load_optical_power_record(config: dict[str, Any], chip: str, die: str) -> dict[str, Any] | None:
    directory = die_dir(config, chip, die)
    path = optical_power_path(directory)
    if not path.exists():
        return None
    record = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(record, dict):
        raise ValueError(f"光功率记录格式错误: {path}")
    return {**record, "source": str(path)}


def save_optical_power_record(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    directory = die_dir(config, chip, die, create=True)
    record = build_optical_power_record(chip, die, payload)
    path = optical_power_path(directory)
    path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"ok": True, "power_path": str(path), "power": {**record, "source": str(path)}}


def array_die_card_source_paths(config: dict[str, Any], chip: str, die: str) -> list[Path]:
    directory = die_dir(config, chip, die)
    candidates = [
        directory.parent / "array_design.json",
        directory / OBSERVATION_FILE,
        directory / ELECTRODE_FILE,
        directory / OPTICAL_POWER_FILE,
        directory / POLARIZATION_MANIFEST_FILE,
        directory / "thermal_tuning" / "current_fsr_assignment" / "assignment_table.csv",
        directory / "thermal_tuning" / "Q_prime" / "current_mode_sweep" / "current_mode_probe_and_sweep.json",
        directory / "thermal_tuning" / "Q_prime" / "current_fsr_assignment" / "assignment_table.csv",
        directory / "thermal_tuning" / "Q_prime" / "current_fsr_assignment" / "assignment_summary.json",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "plan.json",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "verification_summary.json",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "verification_table.csv",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "comb_match_verification" / "comb_match_verification_summary.json",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "comb_match_verification" / "comb_match_modes.csv",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "comb_match_verification" / "comb_match_pair_spacing.csv",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "comb_match_verification" / "comb_match_mu_spectrum.png",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "comb_match_verification" / "comb_match_pair_spacing.png",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "loaded_scan" / "Q" / "raw.npz",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "loaded_scan" / "Q" / "acquisition.json",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "loaded_scan" / "Q" / "array_preanalysis_summary.json",
        directory / "thermal_tuning" / "comb_reconstruction_check" / "loaded_scan" / "Q" / "array_preanalysis_modes.csv",
        directory / "noise_power_spectrum" / "latest.json",
    ]
    for slot in ("Q", "Q'"):
        slot_dir = directory / slot
        candidates.extend(
            [
                slot_dir / "array_preanalysis_summary.json",
                slot_dir / "array_q_summary.json",
                slot_dir / Q_BY_MODE_FILE,
                slot_dir / "array_preanalysis_modes.csv",
                slot_dir / "raw.npz",
                slot_dir / "acquisition.json",
                slot_dir / "array_preanalysis_spectrum.png",
                slot_dir / "array_preanalysis_folded_families.png",
            ]
        )
    observation = load_observation(config, chip, die)
    sections = observation.get("sections") if isinstance(observation.get("sections"), list) else []
    for section in sections:
        if not isinstance(section, dict):
            continue
        images = section.get("images") if isinstance(section.get("images"), list) else []
        for image in images:
            rel = str(image or "").strip().replace("\\", "/")
            if rel.startswith("images/") and ".." not in Path(rel).parts:
                candidates.append(directory / rel)
    latest = load_json_file(directory / "noise_power_spectrum" / "latest.json", {})
    for key in ("summary_path", "comparison_html"):
        raw = str(latest.get(key) or "").strip()
        if not raw:
            continue
        path = Path(raw)
        candidates.append(path if path.is_absolute() else directory / "noise_power_spectrum" / path)
    unique: dict[str, Path] = {}
    for path in candidates:
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if resolved.exists() and resolved.is_file():
            unique[str(resolved).lower()] = resolved
    return list(unique.values())


def array_die_card_source_fingerprints(config: dict[str, Any], chip: str, die: str) -> dict[str, dict[str, int]]:
    fingerprints: dict[str, dict[str, int]] = {}
    for path in array_die_card_source_paths(config, chip, die):
        stat = path.stat()
        fingerprints[str(path.resolve())] = {
            "size": int(stat.st_size),
            "mtime_ns": int(stat.st_mtime_ns),
        }
    return fingerprints


def array_die_card_status(config: dict[str, Any], chip: str, die: str) -> dict[str, Any]:
    chip = validate_name(chip, "chip")
    die = validate_name(die, "die")
    directory = die_dir(config, chip, die)
    card_path = directory / "array_die_card.html"
    state_path = directory / ARRAY_DIE_CARD_STATE_FILE
    sources = array_die_card_source_paths(config, chip, die)
    newest_source = max(sources, key=lambda path: path.stat().st_mtime_ns, default=None)
    card_mtime_ns = card_path.stat().st_mtime_ns if card_path.exists() else 0
    newest_source_mtime_ns = newest_source.stat().st_mtime_ns if newest_source else 0
    source_fingerprints = array_die_card_source_fingerprints(config, chip, die)
    saved_state = load_json_file(state_path, {})
    saved_fingerprints = (
        saved_state.get("source_fingerprints")
        if isinstance(saved_state.get("source_fingerprints"), dict)
        else None
    )
    if not card_path.exists():
        state = "missing"
    elif saved_fingerprints is not None:
        state = "current" if saved_fingerprints == source_fingerprints else "stale"
    else:
        state = "stale" if newest_source_mtime_ns > card_mtime_ns else "current"

    def timestamp(path: Path | None) -> str | None:
        if path is None or not path.exists():
            return None
        return datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(timespec="seconds")

    return {
        "ok": True,
        "state": state,
        "chip": chip,
        "die": die,
        "card_path": str(card_path),
        "state_path": str(state_path),
        "card_updated_at": timestamp(card_path),
        "newest_source": str(newest_source) if newest_source else None,
        "newest_source_updated_at": timestamp(newest_source),
        "source_count": len(sources),
    }


def remove_card_generation_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def publish_array_die_card_generation(
    replacements: list[tuple[Path, Path, Path]],
) -> None:
    states: list[dict[str, Any]] = []
    try:
        for target, staged, backup in replacements:
            state = {
                "target": target,
                "staged": staged,
                "backup": backup,
                "backed_up": False,
                "published": False,
            }
            states.append(state)
            if target.exists():
                target.replace(backup)
                state["backed_up"] = True
            staged.replace(target)
            state["published"] = True
    except Exception as exc:
        rollback_errors: list[str] = []
        for state in reversed(states):
            target = state["target"]
            backup = state["backup"]
            try:
                if state["published"] and target.exists():
                    remove_card_generation_path(target)
                if state["backed_up"] and backup.exists():
                    backup.replace(target)
            except OSError as rollback_exc:
                rollback_errors.append(f"{target}: {rollback_exc!r}")
        if rollback_errors:
            raise RuntimeError(
                "阵列 card 发布失败且回滚不完整；备份文件已保留："
                + "；".join(rollback_errors)
            ) from exc
        raise
    else:
        for state in states:
            backup = state["backup"]
            if not backup.exists():
                continue
            try:
                remove_card_generation_path(backup)
            except OSError:
                pass


def save_array_die_card(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    chip = validate_name(str(payload.get("chip") or ""), "chip")
    die = validate_name(str(payload.get("die") or ""), "die")
    root = require_root(config)
    directory = die_dir(config, chip, die)
    card_path = directory / "array_die_card.html"
    state_path = directory / ARRAY_DIE_CARD_STATE_FILE
    asset_dir = directory / "array_die_card_assets"
    token = f"{os.getpid()}.{threading.get_ident()}.{time.time_ns()}"
    temp_path = directory / f".{card_path.name}.{token}.tmp"
    temp_state_path = directory / f".{state_path.name}.{token}.tmp"
    temp_asset_dir = directory / f".{asset_dir.name}.{token}.tmp"
    backup_path = directory / f".{card_path.name}.{token}.bak"
    backup_state_path = directory / f".{state_path.name}.{token}.bak"
    backup_asset_dir = directory / f".{asset_dir.name}.{token}.bak"
    started = time.perf_counter()
    source_fingerprints = array_die_card_source_fingerprints(config, chip, die)
    try:
        if asset_dir.exists():
            if not asset_dir.is_dir():
                raise ValueError(f"阵列 card 资产路径不是目录: {asset_dir}")
            shutil.copytree(asset_dir, temp_asset_dir)
        else:
            temp_asset_dir.mkdir(parents=True)
        content = build_array_die_card_html(
            root,
            chip,
            die,
            card_path,
            asset_output_dir=temp_asset_dir,
            asset_url_dir=asset_dir,
        )
        temp_path.write_text(content, encoding="utf-8")
        temp_state_path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "chip": chip,
                    "die": die,
                    "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                    "card_path": str(card_path),
                    "source_fingerprints": source_fingerprints,
                },
                indent=2,
                ensure_ascii=False,
            )
            + "\n",
            encoding="utf-8",
        )
        publish_array_die_card_generation(
            [
                (asset_dir, temp_asset_dir, backup_asset_dir),
                (card_path, temp_path, backup_path),
                (state_path, temp_state_path, backup_state_path),
            ]
        )
    finally:
        for pending in (temp_path, temp_state_path, temp_asset_dir):
            if pending.exists():
                remove_card_generation_path(pending)
    asset_paths = sorted(str(path) for path in asset_dir.glob("*.png")) if asset_dir.exists() else []
    return {
        "ok": True,
        "message": "阵列 card 已保存/更新",
        "chip": chip,
        "die": die,
        "card_path": str(card_path),
        "asset_dir": str(asset_dir),
        "q_distribution_figure_count": len(asset_paths),
        "q_distribution_figures": asset_paths,
        "elapsed_s": time.perf_counter() - started,
        "card_status": array_die_card_status(config, chip, die),
    }


def write_json_atomic_with_retry(path: Path, payload: dict[str, Any], *, retries: int = 25, delay_s: float = 0.025) -> None:
    core_write_json_atomic(path, payload, retries=retries, delay_s=delay_s)


def render_observation_markdown(observation: dict[str, Any]) -> str:
    chip = observation.get("chip", "")
    die = observation.get("die", "")
    lines: list[str] = [
        README_START,
        "",
        "## 显微观察",
        "",
        f"- 更新时间：{observation.get('updated_at') or '未记录'}",
        f"- 对象：`{chip}` / `{die}`",
    ]
    overall = str(observation.get("overall_observation") or "").strip()
    if overall:
        lines += ["", "### 总体观察", "", overall]
    for section in observation.get("sections", []):
        if not isinstance(section, dict):
            continue
        name = str(section.get("name") or "").strip()
        if not name:
            continue
        status = str(section.get("status") or "未检查")
        text = str(section.get("text") or "").strip()
        images = section.get("images") if isinstance(section.get("images"), list) else []
        lines += ["", f"### {name}", "", f"- 状态：{status}"]
        if text:
            lines += ["", text]
        if images:
            lines += ["", "图片：", ""]
            for rel in images:
                label = Path(str(rel)).name
                rel_path = str(rel).replace("\\", "/")
                lines.append(f"- ![{label}](<{rel_path}>)")
    lines += ["", README_END, ""]
    return "\n".join(lines)


def update_die_readme(directory: Path, observation: dict[str, Any]) -> Path:
    readme = directory / README_FILE
    if readme.exists():
        current = readme.read_text(encoding="utf-8-sig")
    else:
        current = f"# {observation.get('chip')} / {observation.get('die')}\n"
    block = render_observation_markdown(observation)
    if README_START in current and README_END in current:
        pattern = re.compile(
            re.escape(README_START) + r".*?" + re.escape(README_END) + r"\n?",
            re.DOTALL,
        )
        updated = pattern.sub(block, current)
    else:
        updated = current.rstrip() + "\n\n" + block
    write_text_atomic(readme, updated.rstrip() + "\n")
    return readme


def write_text_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=path.parent,
            delete=False,
        ) as handle:
            handle.write(text)
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def persist_observation(directory: Path, observation: dict[str, Any]) -> None:
    record_path = observation_path(directory)
    readme_path = directory / README_FILE
    previous_record = record_path.read_text(encoding="utf-8-sig") if record_path.exists() else None
    previous_readme = readme_path.read_text(encoding="utf-8-sig") if readme_path.exists() else None
    try:
        core_write_json_atomic(record_path, observation)
        update_die_readme(directory, observation)
    except Exception:
        if previous_record is None:
            record_path.unlink(missing_ok=True)
        else:
            write_text_atomic(record_path, previous_record)
        if previous_readme is None:
            readme_path.unlink(missing_ok=True)
        else:
            write_text_atomic(readme_path, previous_readme)
        raise


def format_optional(value: Any, suffix: str = "") -> str:
    if value in (None, ""):
        return ""
    if isinstance(value, float):
        text = f"{value:g}"
    else:
        text = str(value)
    return f"{text}{suffix}"


def render_electrode_markdown(record: dict[str, Any]) -> str:
    summary = record.get("design_summary") if isinstance(record.get("design_summary"), dict) else {}
    lines = [
        ELECTRODE_START,
        "",
        "## 电极接触 / 电阻记录",
        "",
        f"- 更新时间：{record.get('updated_at') or '未记录'}",
        f"- 对象：`{record.get('chip')}` / `{record.get('die')}`",
        f"- 阵列：{summary.get('array_shape')}",
        f"- 基准腔：`{summary.get('baseline_cavity') or ''}`",
        f"- 半径步进：{format_optional(summary.get('radius_step_nm'), ' nm')}",
        f"- gap：{format_optional(summary.get('gap_um'), ' um')}",
        f"- 金属宽度：{format_optional(summary.get('metal_width_um'), ' um')}",
        f"- E1 对应探针：{record.get('e1_probe') or '未记录'} / {record.get('probe_count', 16)}",
        "",
        "| 电极 | 探针 | 对应腔 | 物理位置 | 光路顺序 | 半径差 | 电阻 | 接触状态 | 备注 |",
        "|---|---:|---|---|---:|---:|---:|---|---|",
    ]
    for row in record.get("rows", []):
        if not isinstance(row, dict):
            continue
        position = (
            f"第{row.get('physical_row')}行第{row.get('physical_col')}列"
            if row.get("physical_row") and row.get("physical_col")
            else ""
        )
        radius = format_optional(row.get("radius_delta_nm"), " nm")
        resistance = str(row.get("resistance") or "")
        if resistance:
            resistance = f"{resistance} {row.get('resistance_unit') or 'Ohm'}"
        lines.append(
            "| "
            + " | ".join(
                [
                    str(row.get("electrode") or ""),
                    str(row.get("probe") or ""),
                    f"`{row.get('cavity') or ''}`",
                    position,
                    str(row.get("optical_order") or ""),
                    radius,
                    resistance,
                    str(row.get("contact_status") or ""),
                    str(row.get("note") or "").replace("\n", "<br>"),
                ]
            )
            + " |"
        )
    lines += ["", ELECTRODE_END, ""]
    return "\n".join(lines)


def update_electrode_readme(directory: Path, record: dict[str, Any]) -> Path:
    readme = directory / README_FILE
    if readme.exists():
        current = readme.read_text(encoding="utf-8-sig")
    else:
        current = f"# {record.get('chip')} / {record.get('die')}\n"
    block = render_electrode_markdown(record)
    if ELECTRODE_START in current and ELECTRODE_END in current:
        pattern = re.compile(
            re.escape(ELECTRODE_START) + r".*?" + re.escape(ELECTRODE_END) + r"\n?",
            re.DOTALL,
        )
        updated = pattern.sub(block, current)
    else:
        updated = current.rstrip() + "\n\n" + block
    readme.write_text(updated.rstrip() + "\n", encoding="utf-8")
    return readme
