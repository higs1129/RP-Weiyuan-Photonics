"""One RP monitor and PID handoff implementation for both laser workflows."""
from __future__ import annotations
import argparse
import time
from typing import Any
import numpy as np
from .bridge import bridge_get, set_param, reset_pid_input_filter

def get_value(base: str, param: str) -> Any:
    result = bridge_get(base, "/get", {"param": param})
    if not result.get("ok"):
        raise RuntimeError(result)
    return result["value"]


def safe_off(base: str) -> None:
    for param, value in (
        ("pid0.p", 0),
        ("pid0.i", 0),
        ("pid0.output_direct", "off"),
        ("asg0.output_direct", "off"),
    ):
        try:
            set_param(base, param, value)
        except Exception as exc:
            print(f"WARN safe_off {param}: {exc}", flush=True)


def sample(base: str) -> dict[str, float]:
    return {
        "ch1": float(get_value(base, "scope.voltage_in1")),
        "ch2": float(get_value(base, "scope.voltage_in2")),
        "ival": float(get_value(base, "pid0.ival")),
        "p": float(get_value(base, "pid0.p")),
        "i": float(get_value(base, "pid0.i")),
    }


def monitor_live(
    base: str, seconds: float, interval: float, target: float
) -> dict[str, Any]:
    rows: list[dict[str, float]] = []
    start = time.time()
    while time.time() - start < seconds:
        row = sample(base)
        row["t_s"] = time.time() - start
        rows.append(row)
        time.sleep(interval)

    if not rows:
        return {"ok": False, "n": 0}

    ch1 = np.asarray([row["ch1"] for row in rows], dtype=float)
    ch2 = np.asarray([row["ch2"] for row in rows], dtype=float)
    ival = np.asarray([row["ival"] for row in rows], dtype=float)
    return {
        "ok": True,
        "n": int(len(rows)),
        "ch1_first": float(ch1[0]),
        "ch1_last": float(ch1[-1]),
        "ch1_mean": float(np.mean(ch1)),
        "ch1_min": float(np.min(ch1)),
        "ch1_max": float(np.max(ch1)),
        "ch1_ptp": float(np.ptp(ch1)),
        "ch2_mean": float(np.mean(ch2)),
        "ch2_min": float(np.min(ch2)),
        "ch2_max": float(np.max(ch2)),
        "ch2_ptp": float(np.ptp(ch2)),
        "ival_mean": float(np.mean(ival)),
        "ival_min": float(np.min(ival)),
        "ival_max": float(np.max(ival)),
        "ival_ptp": float(np.ptp(ival)),
        "target": float(target),
        "target_error_mean": float(np.mean(ch1) - target),
        "out2_saturated": bool(np.any(np.abs(ch2) > args_saturation.out2_limit_v)),
        "ival_saturated": bool(np.any(np.abs(ival) > args_saturation.ival_limit_v)),
    }


class args_saturation:
    out2_limit_v = 0.98
    ival_limit_v = 3.8


def pid_handoff(args: argparse.Namespace, target: float) -> tuple[float, list[dict[str, Any]]]:
    steps: list[dict[str, Any]] = []
    selected_sign = -1.0
    set_param(args.base, "asg0.output_direct", "off")
    set_param(args.base, "pid0.p", 0)
    set_param(args.base, "pid0.i", 0)
    reset_pid_input_filter(args.base)
    set_param(args.base, "pid0.output_direct", "out2")
    set_param(args.base, "pid0.setpoint", target)
    set_param(args.base, "pid0.ival", args.initial_ival)
    set_param(args.base, "pid0.p", args.p)
    set_param(args.base, "pid0.i", selected_sign * abs(args.low_i))
    steps.append({"stage": "low_i_fixed_handoff", "i": selected_sign * abs(args.low_i)})
    set_param(args.base, "pid0.i", selected_sign * args.final_i_magnitude)
    return selected_sign, steps
