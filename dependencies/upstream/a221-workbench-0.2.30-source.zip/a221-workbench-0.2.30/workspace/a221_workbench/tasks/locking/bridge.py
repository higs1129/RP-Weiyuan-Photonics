"""Shared helpers for the streamlined Red Pitaya microcavity lock workflow."""

from __future__ import annotations
from a221_workbench._shared.paths import module_file, project_root


import sys
from pathlib import Path

import numpy as np

LOCK_DIR = Path(__file__).resolve().parent
SRC_DIR = LOCK_DIR.parent
REPO_ROOT = project_root()

from a221_workbench.instruments.redpitaya.bridge_client import BridgeClient

COMMON_DIR = SRC_DIR / "common"
DRIVERS_DIR = SRC_DIR / "drivers"

from a221_workbench._shared.lock_paths import RESULTS_DIR
from a221_workbench.instruments.toptica.control import (
    read_arc_factor as adapter_read_arc_factor,
    read_pc as adapter_read_pc,
    write_arc_factor as adapter_write_arc_factor,
    write_pc_voltage as adapter_write_pc_voltage,
)


def bridge_get(base: str, path: str, params: dict[str, object] | None = None) -> dict:
    # A supplied instrument object keeps the caller's connection and resource guard.
    if not isinstance(base, str):
        return base.request(path, params)
    return BridgeClient(base, timeout_s=30.0).request(path, params)


def set_param(base: str, param: str, value: object) -> object:
    result = bridge_get(base, "/set", {"param": param, "value": str(value)})
    if not result.get("ok"):
        raise RuntimeError(result)
    return result.get("after")


def reset_pid_input_filter(base: str) -> object:
    """Use raw in1 for DC transmission locking."""
    result = bridge_get(base, "/get", {"param": "pid0.inputfilter"})
    if result.get("ok"):
        value = result.get("value")
        try:
            values = list(value)
            if values and all(abs(float(v)) < 1e-12 for v in values):
                return value
        except (TypeError, ValueError):
            try:
                if abs(float(value)) < 1e-12:
                    return value
            except (TypeError, ValueError):
                pass
    return set_param(base, "pid0.inputfilter", 0)


def stop_bridge_acquisitions(base: str) -> None:
    try:
        result = bridge_get(base, "/acquisition/stop")
        if not result.get("ok"):
            print(f"WARN bridge acquisition stop returned: {result}", flush=True)
    except Exception as exc:
        print(f"WARN could not stop spectrum/network acquisitions before scope setup: {exc}", flush=True)


def read_arc_factor(host: str) -> dict[str, object]:
    return adapter_read_arc_factor(connection="tcp", host=host, port="")


def read_pc(host: str) -> dict[str, float | bool]:
    return adapter_read_pc(connection="tcp", host=host, port="")  # type: ignore[return-value]


def write_pc_voltage(host: str, value: float, *, readback: str = "full") -> dict[str, float | bool]:
    return adapter_write_pc_voltage(
        connection="tcp",
        host=host,
        port="",
        value=value,
        readback=readback,
    )  # type: ignore[return-value]


def write_arc_factor(host: str, value: float) -> dict[str, float | bool]:
    return adapter_write_arc_factor(connection="tcp", host=host, port="", value=value)  # type: ignore[return-value]


def configure_prelock_sweep(base: str, duration: float, frequency: float, amplitude: float) -> None:
    try:
        result = bridge_get(
            base,
            "/lock/prepare-sweep",
            {
                "duration": duration,
                "frequency": frequency,
                "amplitude": amplitude,
            },
        )
        if result.get("ok"):
            return
        print(f"WARN bulk pre-lock sweep setup returned: {result}", flush=True)
    except Exception as exc:
        print(f"WARN bulk pre-lock sweep setup unavailable; using legacy writes: {exc}", flush=True)

    for param, value in (
        ("pid0.output_direct", "off"),
        ("pid0.p", 0),
        ("pid0.i", 0),
        ("asg0.waveform", "ramp"),
        ("asg0.frequency", frequency),
        ("asg0.amplitude", amplitude),
        ("asg0.offset", 0),
        ("asg0.output_direct", "out2"),
        ("asg1.waveform", "square"),
        ("asg1.frequency", frequency),
        ("asg1.amplitude", 0.5),
        ("asg1.offset", 0),
        ("scope.input1", "in1"),
        ("scope.input2", "out2"),
        ("scope.trigger_source", "asg0"),
        ("scope.trigger_delay", 0),
        ("scope.duration", duration),
        ("scope.rolling_mode", "false"),
    ):
        set_param(base, param, value)
    try:
        set_param(base, "scope.run_continuous", "true")
    except Exception as exc:
        print(f"WARN could not force scope run_continuous before lock capture: {exc}", flush=True)


from a221_workbench.tasks.analysis.lock_trace import analyze_apparent_width, assess_raw_lock_presence, contiguous_regions, crossing_x, downsweep_segment
