"""Restore scope fine-scan viewing and optionally serial TOPTICA wavelength/arc factor.

Does not configure or start the RP fine-scan source. TOPTICA TCP is not supported
by this entry point; --scope-only leaves the laser untouched.
"""

from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
if __package__ in (None, ""):
    _source_root = next((p for p in _Path(__file__).resolve().parents if (p / "a221_workbench").is_dir()), None)
    if _source_root is not None:
        _sys.path.insert(0, str(_source_root))
        __package__ = 'a221_workbench.tasks.large_scan'

#!/usr/bin/env python3


import argparse
import json
import time
from dataclasses import dataclass, asdict
import sys
from typing import Iterable

from a221_workbench.instruments.toptica import TopticaDlcPro
from a221_workbench.instruments.oscilloscopes import create_scope


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scope-type", choices=["rs_rte", "tektronix_mso66b"], default="rs_rte")
    parser.add_argument("--scope-resource", default="TCPIP::192.168.1.8::INSTR")
    parser.add_argument("--visa-backend", default="@py")
    parser.add_argument("--laser-port", default="COM3")
    parser.add_argument("--trigger-channel", type=int, default=4)
    parser.add_argument("--trigger-level-v", type=float, default=0.0)
    parser.add_argument("--trigger-slope", choices=["positive", "negative"], default="negative")
    parser.add_argument("--trigger-mode", choices=["auto", "normal"], default="auto")
    parser.add_argument("--time-scale-s-per-div", type=float, default=1e-3)
    parser.add_argument("--horizontal-delay-s", type=float, default=None)
    parser.add_argument("--arc-factor-v-per-v", type=float, default=25.0)
    parser.add_argument("--fine-center-nm", type=float, default=1550.0)
    parser.add_argument("--scope-only", action="store_true")
    parser.add_argument("--dry-run", action="store_true", help="Print planned settings without connecting.")
    return parser.parse_args(list(argv))


@dataclass
class RestoreOptions:
    """Fine-scan restore policy; borrowed devices are never closed here."""
    scope_type: str = "rs_rte"
    scope_resource: str = "TCPIP::192.168.1.8::INSTR"
    visa_backend: str = "@py"
    laser_port: str = "COM3"
    trigger_channel: int = 4
    trigger_level_v: float = 0.0
    trigger_slope: str = "negative"
    trigger_mode: str = "auto"
    time_scale_s_per_div: float = 1e-3
    horizontal_delay_s: float | None = None
    arc_factor_v_per_v: float = 25.0
    fine_center_nm: float = 1550.0
    scope_only: bool = False
    dry_run: bool = False
    restore_wavelength_mode: str = "fine-center"
    initial_wavelength_nm: float | None = None
    laser_settle_timeout_s: float = 90.0
    laser_settle_tolerance_nm: float | None = None
    cycle_smile_after_scan: bool = False
    smile_settle_seconds: float = 0.0
    cycle_emission_after_scan: bool = False
    emission_off_seconds: float = 2.0
    emission_on_settle_seconds: float = 2.0


def restore_fine_scan(args: RestoreOptions, *, laser=None, scope=None, metadata=None, mark_phase=None) -> dict:
    """Restore using existing devices or standalone serial/VISA connections.

    Existing TOPTICA TCP connections supplied by acquisition are supported;
    standalone connection remains serial. No RP operations are performed.
    """
    if args.restore_wavelength_mode not in {"initial", "fine-center", "none"}:
        raise ValueError("Unknown restore wavelength mode")
    if not args.scope_only and args.restore_wavelength_mode == "initial" and args.initial_wavelength_nm is None:
        raise ValueError("initial restore requires initial_wavelength_nm")
    if args.scope_only and (args.cycle_smile_after_scan or args.cycle_emission_after_scan):
        raise ValueError("scope_only cannot cycle the laser")
    if args.dry_run:
        plan = {"dry_run": True, "requires_instrument_connection": False,
                "config": asdict(args), "laser_connection": None if args.scope_only else "serial",
                "restores_rp_source": False}
        print(json.dumps(plan, indent=2))
        return plan
    meta = metadata if metadata is not None else {}
    if mark_phase is None:
        def mark_phase(name, started_at):
            meta.setdefault("phase_seconds", {})[name] = round(time.perf_counter() - started_at, 3)
    own_laser = laser is None and not args.scope_only
    own_scope = scope is None
    laser_closed = False
    try:
        if not args.scope_only:
            if own_laser:
                laser = TopticaDlcPro(args.laser_port)
            phase_t = time.perf_counter()
            restore_nm = None
            if args.restore_wavelength_mode == "initial":
                restore_nm = args.initial_wavelength_nm
                print(
                    "Moving TOPTICA wavelength back to initial "
                    f"{restore_nm:.9f} nm..."
                )
                laser.move_to_wavelength(
                    restore_nm,
                    timeout_s=args.laser_settle_timeout_s,
                    **({"tolerance_nm": args.laser_settle_tolerance_nm} if args.laser_settle_tolerance_nm is not None else {}),
                )
                meta["laser_restore_target_nm"] = restore_nm
                meta["laser_restore_commanded"] = True
                meta["laser_restore_readback_nm"] = laser.wavelength_nm()
            elif args.restore_wavelength_mode == "fine-center":
                restore_nm = args.fine_center_nm
                print(
                    "Moving TOPTICA wavelength back to fine-scan center "
                    f"{restore_nm:g} nm..."
                )
                laser.move_to_wavelength(
                    restore_nm,
                    timeout_s=args.laser_settle_timeout_s,
                    **({"tolerance_nm": args.laser_settle_tolerance_nm} if args.laser_settle_tolerance_nm is not None else {}),
                )
                meta["laser_restore_target_nm"] = restore_nm
                meta["laser_restore_commanded"] = True
                meta["laser_restore_readback_nm"] = laser.wavelength_nm()
                meta["laser_fine_center_readback_nm"] = meta["laser_restore_readback_nm"]
            else:
                print("Leaving TOPTICA wavelength at post-scan state (--restore-wavelength-mode none).")
                meta["laser_restore_target_nm"] = None
                meta["laser_restore_readback_nm"] = laser.wavelength_nm()

            meta["laser_restore_mode"] = args.restore_wavelength_mode
            meta["laser_restore_tolerance_nm"] = args.laser_settle_tolerance_nm
            mark_phase("restore_wavelength", phase_t)
            phase_t = time.perf_counter()
            print("Restoring TOPTICA external input arc factor for fine scan...")
            laser.configure_fine_scan_arc_factor(args.arc_factor_v_per_v)
            meta["fine_scan_arc_factor_restored"] = True
            # Preserve the standalone connection lifetime when no post-laser action is requested.
            if own_laser and not (args.cycle_smile_after_scan or args.cycle_emission_after_scan):
                laser.close()
                laser_closed = True
        if args.scope_only:
            phase_t = time.perf_counter()
        if own_scope:
            scope = create_scope(args.scope_type, args.scope_resource, visa_backend=args.visa_backend)
            print(f"Scope: {scope.idn()}")
        print(
            "Restoring oscilloscope to fine-scan idle state: "
            f"{args.time_scale_s_per_div:g} s/div, CH1 off, CH{args.trigger_channel} "
            f"{args.trigger_slope}-edge {args.trigger_mode} trigger at {args.trigger_level_v:g} V..."
        )
        scope.configure_fine_scan_idle(
            trigger_channel=args.trigger_channel,
            trigger_level_v=args.trigger_level_v,
            trigger_slope=args.trigger_slope,
            trigger_mode=args.trigger_mode,
            time_scale_s_per_div=args.time_scale_s_per_div,
            horizontal_delay_s=args.horizontal_delay_s,
        )
        meta["scope_idle_restored"] = True
        meta["fine_scan_trigger_channel"] = args.trigger_channel
        meta["fine_scan_trigger_level_v"] = args.trigger_level_v
        meta["fine_scan_trigger_slope"] = args.trigger_slope
        meta["fine_scan_horizontal_delay_s"] = args.horizontal_delay_s
        meta["fine_scan_trigger_source_note"] = "RP OUT1 via pid1(asg0) when using the current bench wiring"
        mark_phase("restore_fine_scan_state", phase_t)

        if args.cycle_smile_after_scan:
            phase_t = time.perf_counter()
            meta["smile_post_cycle_order"] = "after_fine_scan_restore"
            print("Fine-scan state restored; cycling TOPTICA Motor Control SMILE after scan: OFF -> ON...")
            meta["smile_post_cycle_result"] = laser.cycle_motor_control_smile()
            if args.smile_settle_seconds > 0:
                time.sleep(args.smile_settle_seconds)
            meta["smile_post_cycle"] = True
            meta["smile_post_cycle_kind"] = "motor_control_smile_enable"
            meta["smile_post_cycle_param"] = laser.MOTOR_CONTROL_SMILE_PARAM
            meta["smile_post_cycle_settle_seconds"] = args.smile_settle_seconds
            meta["laser_readback_after_post_smile_cycle_nm"] = laser.wavelength_nm()
            mark_phase("post_smile_cycle", phase_t)

        if args.cycle_emission_after_scan:
            phase_t = time.perf_counter()
            meta["emission_post_cycle_order"] = "after_fine_scan_restore"
            print("Fine-scan state restored; cycling TOPTICA emission after scan: OFF...")
            laser.set_emission_enabled(False)
            time.sleep(args.emission_off_seconds)
            meta["emission_post_cycle_off_seconds"] = args.emission_off_seconds
            print("Fine-scan state restored; cycling TOPTICA emission after scan: ON...")
            laser.set_emission_enabled(True)
            time.sleep(args.emission_on_settle_seconds)
            meta["emission_post_cycle_on_settle_seconds"] = args.emission_on_settle_seconds
            meta["laser_readback_after_post_emission_cycle_nm"] = laser.wavelength_nm()
            mark_phase("post_emission_cycle", phase_t)

        return meta
    finally:
        if own_scope and scope is not None:
            scope.close()
        if own_laser and laser is not None and not laser_closed:
            laser.close()


def main(argv: Iterable[str]) -> int:
    restore_fine_scan(RestoreOptions(**vars(parse_args(argv))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
