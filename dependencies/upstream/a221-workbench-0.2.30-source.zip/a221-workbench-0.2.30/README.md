# A221 Array Cavity Workbench

阵列微腔的设备代码、简单任务和组合测量流程。具体实验参数、记录与结果仍在 `D:/daily_note_v2/`，本仓库维护可复用代码。

## 代码只分三类

```text
workspace/
  pyproject.toml   Python 包构建配置
  a221_workbench/
    instruments/   设备连接、命令、读回与原始采集
    tasks/         一项采集、恢复、计算、拟合或报告任务
    workflows/     组合任务：大扫、锁定、耦合、热调谐及 dashboard
    _shared/       少量路径和进程辅助，不放实验功能
  config/          本机配置及配置示例
  skills/          Agent 操作方法
  tools/           规则发布等维护工具
```

公共功能集中在实际实现模块，调用方直接引用。没有 `scripts/` 旧入口、兼容转发和 `experiment_workbench` 模拟项目；按用户要求暂不保留测试目录。页面资源在所属流程的 `static/` 下。

## RP*微源光子测控平台

**RP\*微源光子测控平台** 已迁入独立项目 `D:/RP-Weiyuan-Photonics`，应用源码为该项目的 `src/rp_weiyuan/`。它使用独立 Python 环境及固定版本的已安装公共库，修改本仓库源码不会自动影响该产品。使用与迁移说明见 [产品说明](docs/weiyuan-package.md)。本仓库继续维护公共设备、任务和其他阵列微腔流程。

## 启动

根目录只保留本说明与 `AGENTS.md` 两个普通文件。其他说明在 `docs/`，配置在 `workspace/config/`，启动器随所属程序存放。

双击 [阵列 dashboard 启动入口](workspace/a221_workbench/workflows/array_dashboard/launch.cmd)。同目录 `launch.py` 只负责选择本机 Python 并启动阵列 dashboard：

```powershell
./workspace/a221_workbench/workflows/array_dashboard/launch.cmd
./workspace/a221_workbench/workflows/array_dashboard/launch.cmd --port 7890 --no-open
```

启动器使用 `workspace/config/redpitaya_microcavity_lock/runtime.local.json` 中的 Python，或显式设置的 `A221_RUNTIME_PYTHON`。它不自动重装环境，也不主动结束已有设备进程。

其他程序通过已配置的仪器 Python 启动，例如 `python -m a221_workbench microcavity-control`、`python -m a221_workbench large-scan --help`。这些命令需在安装了包的环境中运行。

外部实验项目使用已安装的 `a221-workbench==0.2.2`；函数直接从实际模块导入，不再经旧接口转发。使用方式见 [接口与目录说明](docs/usage.md)。0.1.x 的 Python 导入路径已移除，调用方需要更新。

## 当前拆分

- TOPTICA 串口、TCP 服务、锁定监测/PID 接管和耦合读数各有一个实现。
- 大扫调用采集、共用恢复、分析及报告任务。完整大扫和独立采集均默认在扫描前、返回初始波长并恢复细扫后，各做一次 SMILE 关→开。
- 阵列 dashboard 分开记录、计划、快速探测、组合重建、噪声测量和页面。主入口负责请求分派；部分复合流程仍较长，可继续按实际维护需求缩小。
- 正常大扫完成后，dashboard 只补做 RP 恢复；失败/中止保留异常恢复。

科学模型、通道含义和已有默认参数保持；此次只做离线校验，没有执行真实仪器测量。

共享实现只在本项目维护；外部调用方发现接口问题时提交 [修改说明](docs/CHANGE_REQUEST.md)。规则见 [AGENTS.md](AGENTS.md)。[规则发布入口](workspace/tools/agent_publish/publish.cmd) 用于本机规则/Skill 发布，GitHub 推送另行授权。

RP 后台失联时可使用 [RP 后台显式重启](docs/rp-bridge-restart.md)；重启和恢复细扫是两个独立操作。
