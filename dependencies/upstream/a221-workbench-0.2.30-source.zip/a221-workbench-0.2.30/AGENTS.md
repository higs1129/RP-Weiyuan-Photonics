# A221 Array Cavity Workbench

本项目维护阵列微腔设备与测量代码。实验记录和数据在 `D:/daily_note_v2/workspace/experiments/`。

根目录的普通文件只保留 `README.md` 和 `AGENTS.md`（Git 自身元数据除外）。其他说明放 `docs/`，Python 构建配置放 `workspace/pyproject.toml`，本机配置放 `workspace/config/`。专用启动器和入口放在所属程序目录。

## 三类程序

- `workspace/a221_workbench/instruments/`：设备连接、控制、读回及原始采集。
- `workspace/a221_workbench/tasks/`：完成一项明确的采集、恢复、分析或报告任务。
- `workspace/a221_workbench/workflows/`：通过参数和函数组合简单任务，包含 dashboard 操作入口。
- `_shared/` 仅放少量路径、进程和数据位置辅助，不放实验业务。
- 设备不依赖界面或组合流程；离线分析不连接设备。每个功能只有唯一实现，不添加旧路径转发、兼容副本或通用编排框架。
- 本机配置在 `workspace/config/`。Skill 源码在 `workspace/skills/`，安装目录仅为运行副本；维护前读其 AGENTS.md 和目标 Skill。

## 维护与验证

- 按用户要求，不保留测试目录、模拟 experiment_workbench 或旧 scripts 树。仍需做与改动相称的导入、参数预演和离线结果核对；临时校验放仓库外。
- 修改科学模型、标定、单位、默认设备动作时必须明确说明，不能藏在目录整理中。开发验证不执行真实测量，不改实验记录。
- 外部实验项目只使用已安装包的实际模块：`a221_workbench.instruments.*`、`a221_workbench.tasks.*`、`a221_workbench.workflows.*`。不修改或复制共享实现；缺口按 `docs/CHANGE_REQUEST.md` 提出。
- 阵列 dashboard 的 `launch.py` / `launch.cmd` 在 `workspace/a221_workbench/workflows/array_dashboard/`。规则发布入口在 `workspace/tools/agent_publish/publish.cmd`，不等于 GitHub 推送。
- 保留用户已有修改，使用本项目任务分支。只提交当前任务变更，不提交配置、结果、缓存或密钥。推送、PR、合并需用户授权。

GitHub：`https://github.com/pacebryanht57urv-sudo/a221-in-array-cavity-characterization`。
